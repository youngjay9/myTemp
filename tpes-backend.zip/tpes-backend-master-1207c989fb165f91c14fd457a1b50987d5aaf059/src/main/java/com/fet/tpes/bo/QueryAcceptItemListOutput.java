package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.CfgSystemProperties;

public class QueryAcceptItemListOutput extends BaseOutputBo{
	List<CfgSystemProperties> acceptItemList;

	public List<CfgSystemProperties> getAcceptItemList() {
		return acceptItemList;
	}

	public void setAcceptItemList(List<CfgSystemProperties> acceptItemList) {
		this.acceptItemList = acceptItemList;
	}
	
	
}
