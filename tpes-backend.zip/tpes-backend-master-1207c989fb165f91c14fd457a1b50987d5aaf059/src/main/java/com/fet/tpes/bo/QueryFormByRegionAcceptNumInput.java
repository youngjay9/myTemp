package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QueryFormByRegionAcceptNumInput extends BaseInputBo {

	private String acceptNum;
	
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(getRegion()) && StringUtil.isNotEmpty(acceptNum);
	}
	
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
}
