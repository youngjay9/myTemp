package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class CheckSSOInput extends BaseInputBo {

	private String userId;
	private String pwwd;	 // 密碼 (for codeScan)
	
	private String apuid;
	private String apPwwd;
	
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(userId) && StringUtil.isNotEmpty(pwwd) && StringUtil.isNotEmpty(apuid) && StringUtil.isNotEmpty(apPwwd);
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPwwd() {
		return pwwd;
	}
	public void setPwwd(String pwwd) {
		this.pwwd = pwwd;
	}
	public String getApuid() {
		return apuid;
	}
	public void setApuid(String apuid) {
		this.apuid = apuid;
	}
	public String getApPwwd() {
		return apPwwd;
	}
	public void setApPwwd(String apPwwd) {
		this.apPwwd = apPwwd;
	}
}
