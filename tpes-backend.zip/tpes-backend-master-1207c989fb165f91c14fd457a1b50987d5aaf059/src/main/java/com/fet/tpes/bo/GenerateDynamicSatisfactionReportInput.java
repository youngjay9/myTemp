package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class GenerateDynamicSatisfactionReportInput extends BaseInputBo {


	private String startDate;
	private String endDate;
	private boolean isAllRegion; //是否查詢全區處 (For 業務處)
	private String unSatisfyPercent; //不滿意度比例

	@Override
	public boolean isValid() {
		boolean isPass = true;

		return isPass;
	}

	public boolean isAllRegion() {
		return isAllRegion;
	}

	public void setAllRegion(boolean allRegion) {
		isAllRegion = allRegion;
	}

	public String getUnSatisfyPercent() {
		return unSatisfyPercent;
	}

	public void setUnSatisfyPercent(String unSatisfyPercent) {
		this.unSatisfyPercent = unSatisfyPercent;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
}
