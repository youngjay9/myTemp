package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bean.AuthEmpRoleMapBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class DeleteEmpRoleInput extends BaseInputBo{
	
	private List<AuthEmpRoleMapBean> deleteEmpAuthList;	
	private boolean isSettingStyleAuto;

	public List<AuthEmpRoleMapBean> getDeleteEmpAuthList() {
		return deleteEmpAuthList;
	}

	public void setDeleteEmpAuthList(List<AuthEmpRoleMapBean> deleteEmpAuthList) {
		this.deleteEmpAuthList = deleteEmpAuthList;
	}
	public boolean getIsSettingStyleAuto() {
		return isSettingStyleAuto;
	}

	public void setIsSettingStyleAuto(boolean isSettingStyleAuto) {
		this.isSettingStyleAuto = isSettingStyleAuto;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(deleteEmpAuthList)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數deleteEmpAuthList為空值");
		} 
		
		return result;
	}

}
