package com.fet.tpes.bo;

import com.fet.tpes.bean.AccountingBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryWaitArchiveBySeqOutput extends BaseOutputBo{
	private AccountingBean accountingBean;

	public AccountingBean getAccountingBean() {
		return accountingBean;
	}

	public void setAccountingBean(AccountingBean accountingBean) {
		this.accountingBean = accountingBean;
	}
	
	
}
