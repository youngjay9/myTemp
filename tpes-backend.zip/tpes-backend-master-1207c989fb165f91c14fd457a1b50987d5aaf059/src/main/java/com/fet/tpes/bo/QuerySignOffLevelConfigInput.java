package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QuerySignOffLevelConfigInput extends BaseInputBo {

	private String action;

	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(action);
	}
	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
}
