package com.fet.tpes.bo;

import java.util.HashMap;

import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryRoleByCodeOutput extends BaseOutputBo {
	HashMap<String, Integer> authLimitMap = new HashMap<>();

	public HashMap<String, Integer> getAuthLimitMap() {
		return authLimitMap;
	}

	public void setAuthLimitMap(HashMap<String, Integer> authLimitMap) {
		this.authLimitMap = authLimitMap;
	}

}
