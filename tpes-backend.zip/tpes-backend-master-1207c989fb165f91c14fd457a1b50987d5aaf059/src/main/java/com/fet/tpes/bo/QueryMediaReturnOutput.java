package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.media.MediaReturnBean;
import com.fet.tpes.bo.base.BaseOutputBo;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/11/17 下午 02:23
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
@SuppressWarnings("rawtypes")
public class QueryMediaReturnOutput extends BaseOutputBo {

	private List<MediaReturnBean> returnList;

	public List<MediaReturnBean> getReturnList() {
		return returnList;
	}

	public void setReturnList(List<MediaReturnBean> returnList) {
		this.returnList = returnList;
	}
}
