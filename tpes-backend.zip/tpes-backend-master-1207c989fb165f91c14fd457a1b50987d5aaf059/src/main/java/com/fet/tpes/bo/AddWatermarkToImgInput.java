package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class AddWatermarkToImgInput extends BaseInputBo {

	private byte[] imgBytes;
	private String fileExt;
	private String watermark;
	
	@Override
	public boolean isValid() {
		return imgBytes != null && imgBytes.length > 0 && StringUtil.isNotEmpty(fileExt);
	}

	public byte[] getImgBytes() {
		return imgBytes;
	}
	public void setImgBytes(byte[] imgBytes) {
		this.imgBytes = imgBytes;
	}
	public String getFileExt() {
		return fileExt;
	}
	public void setFileExt(String fileExt) {
		this.fileExt = fileExt;
	}
	public String getWatermark() {
		return watermark;
	}
	public void setWatermark(String watermark) {
		this.watermark = watermark;
	}
}
