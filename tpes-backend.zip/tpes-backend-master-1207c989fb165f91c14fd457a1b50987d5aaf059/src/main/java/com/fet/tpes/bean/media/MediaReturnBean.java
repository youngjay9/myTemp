package com.fet.tpes.bean.media;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/11/17 下午 05:50
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
public class MediaReturnBean<T> {
    private Long id;
    private String mediaName;
    private String mediaType;
    private String createDate;
    private String createAuthor;
    private String createAuthorName;
    private String updateDate;
    private String updateAuthor;
    private String updateAuthorName;
    private String rejectUser;
    private String rejectUserName;
    private String rejectReason;
    private String rejectDesc;
    private String rejectDate;
    private T detailData ;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMediaName() {
        return mediaName;
    }

    public void setMediaName(String mediaName) {
        this.mediaName = mediaName;
    }

    public String getMediaType() {
        return mediaType;
    }

    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getCreateAuthor() {
        return createAuthor;
    }

    public void setCreateAuthor(String createAuthor) {
        this.createAuthor = createAuthor;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateAuthor() {
        return updateAuthor;
    }

    public void setUpdateAuthor(String updateAuthor) {
        this.updateAuthor = updateAuthor;
    }

    public T getDetailData() {
        return detailData;
    }

    public void setDetailData(T detailData) {
        this.detailData = detailData;
    }

    public String getRejectUser() {
        return rejectUser;
    }

    public void setRejectUser(String rejectUser) {
        this.rejectUser = rejectUser;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public String getRejectDesc() {
        return rejectDesc;
    }

    public void setRejectDesc(String rejectDesc) {
        this.rejectDesc = rejectDesc;
    }

    public String getRejectDate() {
        return rejectDate;
    }

    public void setRejectDate(String rejectDate) {
        this.rejectDate = rejectDate;
    }

    public String getCreateAuthorName() {
        return createAuthorName;
    }

    public void setCreateAuthorName(String createAuthorName) {
        this.createAuthorName = createAuthorName;
    }

    public String getUpdateAuthorName() {
        return updateAuthorName;
    }

    public void setUpdateAuthorName(String updateAuthorName) {
        this.updateAuthorName = updateAuthorName;
    }

    public String getRejectUserName() {
        return rejectUserName;
    }

    public void setRejectUserName(String rejectUserName) {
        this.rejectUserName = rejectUserName;
    }
}
