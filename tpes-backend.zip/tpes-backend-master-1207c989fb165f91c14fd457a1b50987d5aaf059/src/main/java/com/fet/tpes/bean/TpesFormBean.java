package com.fet.tpes.bean;

import java.util.Date;
import java.util.List;

public class TpesFormBean {

	private int seq;
	private String acceptNum;
	private String region;
	private String custName;
	private String status;
	private String contractType;
	private String electricNum;
	private String computeDate;
	private String acceptDept;
	private String acceptDeptName;
	private String acceptUser;
	private String acceptUserName;
	private Date acceptDate;
	private String acceptItem;
	private String formType;
	private String applyType;
	private String isAgent;
	private String uniformNum;
	private String archiveNum;
	private Date archiveDate;
	private Date closeDate;
	private String rejectToDept;
	private String rejectUser;
	private String rejectReason;
	private String rejectDesc;
	private Date rejectDate;
	private String cancelReason;
	private Date cancelDate;
	private List<String> formHistoryList;
	private String formHistoryJson;
	private Date createDate;
	private String createAuthor;
	private Date updateDate;
	private String updateAuthor;
	private String isAgentForm;  // 用於前端顯示該件是否為代理件
	private String accounting;  // 核算員
	
	// 轉為字串格式供前端顯示
	private String acceptDateStr;
	private String createDateStr;
	private String updateDateStr;
	private String rejectDateStr;
	private String closeDateStr;
	private String cancelDateStr;
	private String archiveDateStr;
	
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getElectricNum() {
		return electricNum;
	}
	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}
	public String getComputeDate() {
		return computeDate;
	}
	public void setComputeDate(String computeDate) {
		this.computeDate = computeDate;
	}
	public String getAcceptDept() {
		return acceptDept;
	}
	public void setAcceptDept(String acceptDept) {
		this.acceptDept = acceptDept;
	}
	public String getAcceptDeptName() {
		return acceptDeptName;
	}
	public void setAcceptDeptName(String acceptDeptName) {
		this.acceptDeptName = acceptDeptName;
	}
	public String getAcceptUser() {
		return acceptUser;
	}
	public void setAcceptUser(String acceptUser) {
		this.acceptUser = acceptUser;
	}
	public String getAcceptUserName() {
		return acceptUserName;
	}
	public void setAcceptUserName(String acceptUserName) {
		this.acceptUserName = acceptUserName;
	}
	public Date getAcceptDate() {
		return acceptDate;
	}
	public void setAcceptDate(Date acceptDate) {
		this.acceptDate = acceptDate;
	}
	public String getAcceptItem() {
		return acceptItem;
	}
	public void setAcceptItem(String acceptItem) {
		this.acceptItem = acceptItem;
	}
	public String getFormType() {
		return formType;
	}
	public void setFormType(String formType) {
		this.formType = formType;
	}
	public String getApplyType() {
		return applyType;
	}
	public void setApplyType(String applyType) {
		this.applyType = applyType;
	}
	public String getIsAgent() {
		return isAgent;
	}
	public void setIsAgent(String isAgent) {
		this.isAgent = isAgent;
	}
	public String getUniformNum() {
		return uniformNum;
	}
	public void setUniformNum(String uniformNum) {
		this.uniformNum = uniformNum;
	}
	public String getArchiveNum() {
		return archiveNum;
	}
	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}
	public Date getArchiveDate() {
		return archiveDate;
	}
	public void setArchiveDate(Date archiveDate) {
		this.archiveDate = archiveDate;
	}
	public Date getCloseDate() {
		return closeDate;
	}
	public void setCloseDate(Date closeDate) {
		this.closeDate = closeDate;
	}
	public String getRejectToDept() {
		return rejectToDept;
	}
	public void setRejectToDept(String rejectToDept) {
		this.rejectToDept = rejectToDept;
	}
	public String getRejectUser() {
		return rejectUser;
	}
	public void setRejectUser(String rejectUser) {
		this.rejectUser = rejectUser;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getRejectDesc() {
		return rejectDesc;
	}
	public void setRejectDesc(String rejectDesc) {
		this.rejectDesc = rejectDesc;
	}
	public Date getRejectDate() {
		return rejectDate;
	}
	public void setRejectDate(Date rejectDate) {
		this.rejectDate = rejectDate;
	}
	public String getCancelReason() {
		return cancelReason;
	}
	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}
	public Date getCancelDate() {
		return cancelDate;
	}
	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}
	public List<String> getFormHistoryList() {
		return formHistoryList;
	}
	public void setFormHistoryList(List<String> formHistoryList) {
		this.formHistoryList = formHistoryList;
	}
	public String getFormHistoryJson() {
		return formHistoryJson;
	}
	public void setFormHistoryJson(String formHistoryJson) {
		this.formHistoryJson = formHistoryJson;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateAuthor() {
		return createAuthor;
	}
	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateAuthor() {
		return updateAuthor;
	}
	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}
	public String getAcceptDateStr() {
		return acceptDateStr;
	}
	public void setAcceptDateStr(String acceptDateStr) {
		this.acceptDateStr = acceptDateStr;
	}
	public String getCreateDateStr() {
		return createDateStr;
	}
	public void setCreateDateStr(String createDateStr) {
		this.createDateStr = createDateStr;
	}
	public String getUpdateDateStr() {
		return updateDateStr;
	}
	public void setUpdateDateStr(String updateDateStr) {
		this.updateDateStr = updateDateStr;
	}
	public String getRejectDateStr() {
		return rejectDateStr;
	}
	public void setRejectDateStr(String rejectDateStr) {
		this.rejectDateStr = rejectDateStr;
	}
	public String getCloseDateStr() {
		return closeDateStr;
	}
	public void setCloseDateStr(String closeDateStr) {
		this.closeDateStr = closeDateStr;
	}
	public String getCancelDateStr() {
		return cancelDateStr;
	}
	public void setCancelDateStr(String cancelDateStr) {
		this.cancelDateStr = cancelDateStr;
	}
	public String getArchiveDateStr() {
		return archiveDateStr;
	}
	public void setArchiveDateStr(String archiveDateStr) {
		this.archiveDateStr = archiveDateStr;
	}
	public String getIsAgentForm() {
		return isAgentForm;
	}
	public void setIsAgentForm(String isAgentForm) {
		this.isAgentForm = isAgentForm;
	}
	public String getAccounting() {
		return accounting;
	}
	public void setAccounting(String accounting) {
		this.accounting = accounting;
	}
}
