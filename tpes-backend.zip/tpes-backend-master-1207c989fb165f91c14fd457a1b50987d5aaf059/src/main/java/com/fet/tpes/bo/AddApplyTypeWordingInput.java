package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class AddApplyTypeWordingInput extends BaseInputBo {

	private String file;
	private String fileExt;
	private String applyType;
	
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(file) && StringUtil.isNotEmpty(fileExt) && StringUtil.isNotEmpty(applyType);
	}

	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getFileExt() {
		return fileExt;
	}
	public void setFileExt(String fileExt) {
		this.fileExt = fileExt;
	}
	public String getApplyType() {
		return applyType;
	}
	public void setApplyType(String applyType) {
		this.applyType = applyType;
	}
}
