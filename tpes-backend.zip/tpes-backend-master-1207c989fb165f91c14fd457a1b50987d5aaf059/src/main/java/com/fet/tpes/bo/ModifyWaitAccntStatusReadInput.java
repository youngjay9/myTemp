package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class ModifyWaitAccntStatusReadInput extends BaseInputBo{
	private int seq;
	private String status;
	private String agent;
	
	
	
	public int getSeq() {
		return seq;
	}



	public void setSeq(int seq) {
		this.seq = seq;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getAgent() {
		return agent;
	}



	public void setAgent(String agent) {
		this.agent = agent;
	}



	@Override
	public boolean isValid() {
		return true;
	}
}
