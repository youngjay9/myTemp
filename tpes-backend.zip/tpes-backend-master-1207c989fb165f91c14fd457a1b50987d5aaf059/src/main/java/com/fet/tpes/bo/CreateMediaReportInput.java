package com.fet.tpes.bo;

import java.util.Map;

import com.fet.tpes.bo.base.BaseInputBo;

public class CreateMediaReportInput extends BaseInputBo {

	private Map<String,Object> parameterMap;

	@Override
	public boolean isValid() {
		return parameterMap != null;
	}

	public Map<String, Object> getParameterMap() {
		return parameterMap;
	}

	public void setParameterMap(Map<String, Object> parameterMap) {
		this.parameterMap = parameterMap;
	}
}
