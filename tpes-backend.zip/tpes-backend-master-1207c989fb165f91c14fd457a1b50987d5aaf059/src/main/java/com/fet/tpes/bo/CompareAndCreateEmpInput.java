package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseInputBo;

public class CompareAndCreateEmpInput extends BaseInputBo {
	List<EmpInfoBean> empInfoBeanList;

	public List<EmpInfoBean> getEmpInfoBeanList() {
		return empInfoBeanList;
	}

	public void setEmpInfoBeanList(List<EmpInfoBean> empInfoBeanList) {
		this.empInfoBeanList = empInfoBeanList;
	}

	@Override
	public boolean isValid() {
		return true;
	}
}
