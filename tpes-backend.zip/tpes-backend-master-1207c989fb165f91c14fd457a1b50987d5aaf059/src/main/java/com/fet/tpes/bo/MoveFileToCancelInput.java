package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class MoveFileToCancelInput extends BaseInputBo {

	private int formSeq;
	private String cancelType; // 個人取消 or 公司主動取消
	private String sign;	// 取消簽名 base64
	private String acceptNum;
	private String formType;
	
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(getRegion()) && StringUtil.isNotEmpty(acceptNum) && StringUtil.isNotEmpty(cancelType);
	}
	
	public int getFormSeq() {
		return formSeq;
	}
	public void setFormSeq(int formSeq) {
		this.formSeq = formSeq;
	}
	public String getCancelType() {
		return cancelType;
	}
	public void setCancelType(String cancelType) {
		this.cancelType = cancelType;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}

	public String getFormType() {
		return formType;
	}

	public void setFormType(String formType) {
		this.formType = formType;
	}
}
