package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QueryErrMsgByErrCodeInput extends BaseInputBo{
	
	private String errorCode;	

	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(errorCode)) {
			result = false;
			// 補Log
		}
		return result;
	}
	
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
