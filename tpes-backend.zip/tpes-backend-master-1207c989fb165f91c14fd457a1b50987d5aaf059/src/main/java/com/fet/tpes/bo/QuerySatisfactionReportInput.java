package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import org.apache.commons.lang3.StringUtils;

public class QuerySatisfactionReportInput extends BaseInputBo {

	private String category;
	private String startDate;
	private String endDate;

	@Override
	public boolean isValid() {
		boolean isPass = true;
		if(StringUtils.isBlank(getCategory())) {
			isPass = Boolean.FALSE;
		}
		return isPass;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
}
