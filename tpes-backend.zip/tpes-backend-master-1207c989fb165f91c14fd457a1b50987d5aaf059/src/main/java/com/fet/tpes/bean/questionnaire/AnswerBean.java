package com.fet.tpes.bean.questionnaire;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/10/26 下午 04:57
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
public class AnswerBean {
    private Long answerId;
    private String label;
    private String value;

    public Long getAnswerId() {
        return answerId;
    }

    public void setAnswerId(Long answerId) {
        this.answerId = answerId;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
