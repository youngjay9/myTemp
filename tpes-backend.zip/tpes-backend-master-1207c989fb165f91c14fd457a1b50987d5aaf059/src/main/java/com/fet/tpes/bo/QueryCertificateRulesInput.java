package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QueryCertificateRulesInput extends BaseInputBo {

	private String formType;
	private String acceptItem;
	private String identity;
	private String applyType;
	private String status;
	
	@Override
	public boolean isValid() {
		boolean isPass = true;
		
		if(StringUtil.isEmptyOrNull(this.formType)) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.acceptItem)) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.identity)) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.applyType)) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.status)) {
			isPass = false;
		}
		
		return isPass;
	}

	public String getFormType() {
		return formType;
	}

	public void setFormType(String formType) {
		this.formType = formType;
	}

	public String getAcceptItem() {
		return acceptItem;
	}

	public void setAcceptItem(String acceptItem) {
		this.acceptItem = acceptItem;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getApplyType() {
		return applyType;
	}

	public void setApplyType(String applyType) {
		this.applyType = applyType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
