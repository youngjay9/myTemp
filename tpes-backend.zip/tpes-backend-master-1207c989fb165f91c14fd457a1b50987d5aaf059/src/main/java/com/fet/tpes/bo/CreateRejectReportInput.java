package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.TpesFormBean;
import com.fet.tpes.bo.base.BaseInputBo;

public class CreateRejectReportInput extends BaseInputBo {

	private List<TpesFormBean> beanList;

	@Override
	public boolean isValid() {
		return beanList != null;
	}

	public List<TpesFormBean> getBeanList() {
		return beanList;
	}
	public void setBeanList(List<TpesFormBean> beanList) {
		this.beanList = beanList;
	}
}
