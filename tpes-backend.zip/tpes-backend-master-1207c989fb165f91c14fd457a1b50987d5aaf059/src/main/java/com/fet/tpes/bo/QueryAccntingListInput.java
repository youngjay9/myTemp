package com.fet.tpes.bo;

import java.util.Date;
import java.util.List;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryAccntingListInput extends BaseInputBo {
	private List<String> statusList;
	private List<String> empNoList;
	private List<String> formStatusList;
	private String acceptNum;
	private String electricNum;
	private String custName;
	private String cumulativeDay;
	private String computeDate;
	private String archiveNum;
	private Date dispatchStartDate;
	private Date dispatchEndDate;
	private String contractType;
	private String acceptItem;
	
	
	@Override
	public boolean isValid() {
		return true;
	}
	
	public List<String> getStatusList() {
		return statusList;
	}
	public void setStatusList(List<String> statusList) {
		this.statusList = statusList;
	}
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
	public String getElectricNum() {
		return electricNum;
	}
	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCumulativeDay() {
		return cumulativeDay;
	}
	public void setCumulativeDay(String cumulativeDay) {
		this.cumulativeDay = cumulativeDay;
	}
	public String getComputeDate() {
		return computeDate;
	}
	public void setComputeDate(String computeDate) {
		this.computeDate = computeDate;
	}
	public String getArchiveNum() {
		return archiveNum;
	}
	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}
	public Date getDispatchStartDate() {
		return dispatchStartDate;
	}
	public void setDispatchStartDate(Date dispatchStartDate) {
		this.dispatchStartDate = dispatchStartDate;
	}
	public Date getDispatchEndDate() {
		return dispatchEndDate;
	}
	public void setDispatchEndDate(Date dispatchEndDate) {
		this.dispatchEndDate = dispatchEndDate;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	
	public List<String> getEmpNoList() {
		return empNoList;
	}

	public void setEmpNoList(List<String> empNoList) {
		this.empNoList = empNoList;
	}

	public List<String> getFormStatusList() {
		return formStatusList;
	}

	public void setFormStatusList(List<String> formStatusList) {
		this.formStatusList = formStatusList;
	}

	public String getAcceptItem() {
		return acceptItem;
	}

	public void setAcceptItem(String acceptItem) {
		this.acceptItem = acceptItem;
	}

	
	
	
}
