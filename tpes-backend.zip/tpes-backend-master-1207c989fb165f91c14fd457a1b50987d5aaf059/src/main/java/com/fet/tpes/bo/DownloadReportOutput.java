package com.fet.tpes.bo;

import org.apache.poi.ss.usermodel.Workbook;

import com.fet.tpes.bo.base.BaseOutputBo;

public class DownloadReportOutput extends BaseOutputBo {

	private Workbook wb;
	private String reportName;

	public Workbook getWb() {
		return wb;
	}
	public void setWb(Workbook wb) {
		this.wb = wb;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
}
