package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class AuditWaitAccountingInput extends BaseInputBo {
	private Integer seq;
	private Integer formSeq; // 表單流水號
	private String memo;
	private String acceptNum;
	private String rejectToDept; // 核算退件才有值，取受理部門
	private String rejectReason; // 核算退件才有值，退件原因選項
	private String rejectDesc; // 核算退件才有值，使用者自己填的退件說明
	private String accounting; // 用來與使用者比對判斷是否為代理人在操作

	public String getAccounting() {
		return accounting;
	}

	public void setAccounting(String accounting) {
		this.accounting = accounting;
	}

	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public Integer getFormSeq() {
		return formSeq;
	}

	public void setFormSeq(Integer formSeq) {
		this.formSeq = formSeq;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getAcceptNum() {
		return acceptNum;
	}

	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

	public String getRejectDesc() {
		return rejectDesc;
	}

	public void setRejectDesc(String rejectDesc) {
		this.rejectDesc = rejectDesc;
	}

	public String getRejectToDept() {
		return rejectToDept;
	}

	public void setRejectToDept(String rejectToDept) {
		this.rejectToDept = rejectToDept;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if (this.seq == null) {
			result = false;
			LogUtil.error(this.getClass(), "AuditWaitAccountingInput input 缺少 seq");
		}
		if (this.formSeq == null) {
			result = false;
			LogUtil.error(this.getClass(), "AuditWaitAccountingInput input 缺少 formSeq");
		}
		if (StringUtil.isEmpty(this.acceptNum)) {
			result = false;
			LogUtil.error(this.getClass(), "AuditWaitAccountingInpu input參數缺少acceptNum");
		}
		if (StringUtil.isEmpty(this.getEmpNo())) {
			result = false;
			LogUtil.error(this.getClass(), "AuditWaitAccountingInput input參數缺少empNo");
		}
		if (StringUtil.isEmpty(this.getEmpName())) {
			result = false;
			LogUtil.error(this.getClass(), "AuditWaitAccountingInput input參數缺少empName");
		}
		if (StringUtil.isEmpty(this.getRegion())) {
			result = false;
			LogUtil.error(this.getClass(), "AuditWaitAccountingInput input參數缺少region");
		}
		return result;
	}

}
