package com.fet.tpes.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExternalFileBean {
	
	@JsonProperty("CATEGORY")
	private String CATEGORY;
	@JsonProperty("FILE_NAME")
	private String FILE_NAME;
	@JsonProperty("ORIGINCAL_FILE_NAME")
	private String ORIGINAL_FILE_NAME;
	@JsonProperty("FILE_EXT")
	private String FILE_EXT;
	@JsonProperty("FILE")
	private String FILE;	
	
	public ExternalFileBean() {
		super();
	}
	public ExternalFileBean(String category, String fileName, String originalFileName, String fileExt, String file) {
		super();
		this.CATEGORY = category;
		this.FILE_NAME = fileName;
		this.ORIGINAL_FILE_NAME = originalFileName;
		this.FILE_EXT = fileExt;
		this.FILE = file;
	}
	
	public String getCATEGORY() {
		return CATEGORY;
	}
	public void setCATEGORY(String cATEGORY) {
		CATEGORY = cATEGORY;
	}
	public String getFILE_NAME() {
		return FILE_NAME;
	}
	public void setFILE_NAME(String fILE_NAME) {
		FILE_NAME = fILE_NAME;
	}
	public String getORIGINAL_FILE_NAME() {
		return ORIGINAL_FILE_NAME;
	}
	public void setORIGINAL_FILE_NAME(String oRIGINAL_FILE_NAME) {
		ORIGINAL_FILE_NAME = oRIGINAL_FILE_NAME;
	}
	public String getFILE_EXT() {
		return FILE_EXT;
	}
	public void setFILE_EXT(String fILE_EXT) {
		FILE_EXT = fILE_EXT;
	}
	public String getFILE() {
		return FILE;
	}
	public void setFILE(String fILE) {
		FILE = fILE;
	}
	
	@Override
	public String toString() {
		return "ExternalFileBean [category=" + CATEGORY + ", fileName=" + FILE_NAME + ", originalFileName="
				+ ORIGINAL_FILE_NAME + ", fileExt=" + FILE_EXT + "]";
	}

}
