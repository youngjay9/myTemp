package com.fet.tpes.bean;

import java.util.Date;

public class AccountingBean {
	private int seq;
	private int formSeq;
	private String region;
	private String acceptNum;
	private String accounting;
	private String accountingDept;
	private String calculate;
	private String agent;
	private String status;
	private String memo;
	private Date createDate;
	private String createAuthor;
	private Date updateDate;
	private String updateAuthor;
	private String dispatchType;
	
	private TpesFormBean tpesFormBean;

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public int getFormSeq() {
		return formSeq;
	}

	public void setFormSeq(int formSeq) {
		this.formSeq = formSeq;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getAcceptNum() {
		return acceptNum;
	}

	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}

	public String getAccounting() {
		return accounting;
	}

	public void setAccounting(String accounting) {
		this.accounting = accounting;
	}

	public String getCalculate() {
		return calculate;
	}

	public void setCalculate(String calculate) {
		this.calculate = calculate;
	}

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateAuthor() {
		return createAuthor;
	}

	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateAuthor() {
		return updateAuthor;
	}

	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}

	public TpesFormBean getTpesFormBean() {
		return tpesFormBean;
	}

	public void setTpesFormBean(TpesFormBean tpesFormBean) {
		this.tpesFormBean = tpesFormBean;
	}

	public String getAccountingDept() {
		return accountingDept;
	}

	public void setAccountingDept(String accountingDept) {
		this.accountingDept = accountingDept;
	}

	public String getDispatchType() {
		return dispatchType;
	}

	public void setDispatchType(String dispatchType) {
		this.dispatchType = dispatchType;
	}

	
	
	
}
