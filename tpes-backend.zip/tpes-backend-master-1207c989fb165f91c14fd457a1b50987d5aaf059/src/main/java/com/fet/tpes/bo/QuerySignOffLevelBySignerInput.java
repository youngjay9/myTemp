package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QuerySignOffLevelBySignerInput extends BaseInputBo{

	private String signer;	
	private List<String> actionList;

	public String getSigner() {
		return signer;
	}

	public void setSigner(String signer) {
		this.signer = signer;
	}
	public List<String> getActionList() {
		return actionList;
	}
	
	public void setActionList(List<String> actionList) {
		this.actionList = actionList;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(signer)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數signer為空值");
		} else if(CollectionUtils.isEmpty(actionList)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數actionList為空值");
		}
		return result;
	}

	
}
