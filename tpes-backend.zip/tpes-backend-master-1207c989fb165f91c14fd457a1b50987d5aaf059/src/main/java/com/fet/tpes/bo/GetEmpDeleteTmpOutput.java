package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.TmpEmployee;

public class GetEmpDeleteTmpOutput extends BaseOutputBo{
	List<TmpEmployee> tmpEmployeeList;
	
	

	

	public List<TmpEmployee> getTmpEmployeeList() {
		return tmpEmployeeList;
	}

	public void setTmpEmployeeList(List<TmpEmployee> tmpEmployeeList) {
		this.tmpEmployeeList = tmpEmployeeList;
	}
	
}
