package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryFilesByConditionsInput extends BaseInputBo {

	private Integer formSeq;
	private String category;
	private String needSeal;
	
	@Override
	public boolean isValid() {
		return true;
	}
	
	public Integer getFormSeq() {
		return formSeq;
	}
	public void setFormSeq(Integer formSeq) {
		this.formSeq = formSeq;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getNeedSeal() {
		return needSeal;
	}
	public void setNeedSeal(String needSeal) {
		this.needSeal = needSeal;
	}
}
