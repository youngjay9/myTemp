package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryRoleByEmpNoInput extends BaseInputBo{
	
	private List<String> empNoList;
	private String roleCode;

	public List<String> getEmpNoList() {
		return empNoList;
	}
	public void setEmpNoList(List<String> empNoList) {
		this.empNoList = empNoList;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(empNoList)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數empNoList為空值");
		}

		return result;
	}

}
