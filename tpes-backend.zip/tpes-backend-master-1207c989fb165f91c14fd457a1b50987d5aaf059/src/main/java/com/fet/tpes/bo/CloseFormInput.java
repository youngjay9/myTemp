package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class CloseFormInput extends BaseInputBo {

	private String fmNo;
	private String fmbhNo;
	private String formType;
	private String apitCod;
	private String archiveNum;
	private String electMeterValue;
	private String signTraje;
	
	// for 有缺少 input 資訊時告知呼叫方缺少的參數
	private String errorMsg;
	
	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(getRegion())) {
			result = false;
			errorMsg = "input 參數缺少區處資訊";
		}
		else if (StringUtil.isEmpty(fmNo)) {
			result = false;
			errorMsg = "input 參數缺少受理編號資訊";
		}
		else if (StringUtil.isEmpty(archiveNum)) {
			result = false;
			errorMsg = "input 參數缺少整理號碼資訊";
		}
		else if (StringUtil.isEmpty(signTraje)) {
			result = false;
			errorMsg = "input 參數缺少簽核軌跡資訊";
		}
		
		return result;
	}

	public String getFmNo() {
		return fmNo;
	}
	public void setFmNo(String fmNo) {
		this.fmNo = fmNo;
	}
	public String getFmbhNo() {
		return fmbhNo;
	}
	public void setFmbhNo(String fmbhNo) {
		this.fmbhNo = fmbhNo;
	}
	public String getFormType() {
		return formType;
	}
	public void setFormType(String formType) {
		this.formType = formType;
	}
	public String getApitCod() {
		return apitCod;
	}
	public void setApitCod(String apitCod) {
		this.apitCod = apitCod;
	}
	public String getArchiveNum() {
		return archiveNum;
	}
	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}
	public String getElectMeterValue() {
		return electMeterValue;
	}
	public void setElectMeterValue(String electMeterValue) {
		this.electMeterValue = electMeterValue;
	}
	public String getSignTraje() {
		return signTraje;
	}
	public void setSignTraje(String signTraje) {
		this.signTraje = signTraje;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}
