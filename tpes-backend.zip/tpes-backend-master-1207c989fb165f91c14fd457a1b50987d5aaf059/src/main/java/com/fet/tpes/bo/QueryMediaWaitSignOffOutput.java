package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.media.MediaSignOffBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryMediaWaitSignOffOutput extends BaseOutputBo{
	private List<MediaSignOffBean> mediaSignOffBeanList;

	public List<MediaSignOffBean> getMediaSignOffBeanList() {
		return mediaSignOffBeanList;
	}

	public void setMediaSignOffBeanList(List<MediaSignOffBean> mediaSignOffBeanList) {
		this.mediaSignOffBeanList = mediaSignOffBeanList;
	}
	
}
