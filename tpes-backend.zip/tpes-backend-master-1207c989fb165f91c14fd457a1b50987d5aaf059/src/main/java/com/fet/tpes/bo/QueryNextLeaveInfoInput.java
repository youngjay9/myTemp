package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryNextLeaveInfoInput extends BaseInputBo{
	
	private String applicantEmpNo;
	private String agentEmpNo;
	
	public String getApplicantEmpNo() {
		return applicantEmpNo;
	}

	public void setApplicantEmpNo(String applicantEmpNo) {
		this.applicantEmpNo = applicantEmpNo;
	}

	public String getAgentEmpNo() {
		return agentEmpNo;
	}

	public void setAgentEmpNo(String agentEmpNo) {
		this.agentEmpNo = agentEmpNo;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(applicantEmpNo) && StringUtil.isEmpty(agentEmpNo)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數applicantEmpNo,agentEmpNo為空值");
		} else if(StringUtil.isEmpty(this.getRegion())) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數Region為空值");
		} 
		
		return result;
	}

}
