package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class ModifyWaitAccntMemoInput extends BaseInputBo {
	private Integer seq;
	private String memo;
	private String agent;

	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if (this.seq == null) {
			result = false;
			LogUtil.error(this.getClass(), "ModifyWaitAccntMemoInput 缺少seq");
		}
		return result;
	}
}
