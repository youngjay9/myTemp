package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryAllClassNameOutput extends BaseOutputBo{
	List<String> classNameList;

	public List<String> getClassNameList() {
		return classNameList;
	}

	public void setClassNameList(List<String> classNameList) {
		this.classNameList = classNameList;
	}
	
}
