package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

import java.util.Optional;

public class DownloadMediaFileInput extends BaseInputBo {

	private Long id;

	private String category;

	@Override
	public boolean isValid() {
		return Optional.ofNullable(id).isPresent();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
}
