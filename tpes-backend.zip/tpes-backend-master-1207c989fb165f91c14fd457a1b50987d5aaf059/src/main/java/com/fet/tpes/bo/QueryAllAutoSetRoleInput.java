package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryAllAutoSetRoleInput extends BaseInputBo{

	
	@Override
	public boolean isValid() {
		return true;
	}
}
