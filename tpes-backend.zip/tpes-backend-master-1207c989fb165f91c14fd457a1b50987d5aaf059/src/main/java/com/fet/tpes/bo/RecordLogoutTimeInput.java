package com.fet.tpes.bo;

import com.fet.tpes.bean.LogLoginBean;
import com.fet.tpes.bo.base.BaseInputBo;

public class RecordLogoutTimeInput extends BaseInputBo{
	private LogLoginBean logLoginBean;
	
	public LogLoginBean getLogLoginBean() {
		return logLoginBean;
	}

	public void setLogLoginBean(LogLoginBean logLoginBean) {
		this.logLoginBean = logLoginBean;
	}

	@Override
	public boolean isValid() {
		return true;
	}
}
