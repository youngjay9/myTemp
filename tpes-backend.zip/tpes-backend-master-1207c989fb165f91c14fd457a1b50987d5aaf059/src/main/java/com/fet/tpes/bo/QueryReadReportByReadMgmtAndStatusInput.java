package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryReadReportByReadMgmtAndStatusInput extends BaseInputBo{
	
	private List<String> empNoList;
	private String status;

	public List<String> getEmpNoList() {
		return empNoList;
	}

	public void setEmpNoList(List<String> empNoList) {
		this.empNoList = empNoList;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(empNoList)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數empNoList為空值");
		} else if (StringUtil.isEmpty(status)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數status為空值");
		}
		return result;
	}

}
