package com.fet.tpes.bean;

import java.util.Date;

public class ReadReportBean {
	private Integer seq;
	private Date readDateStart;
	private Date readDateEnd;	
	private String status;
	private String region;
	private Integer fileNo;
	private String readMgmtSigner;
	private String readMgmtSignAgent;
	private Date readMgmtSignDate;
	private String readMgmtSignerDeptNum;
	private String leaderSigner;
	private String leaderSignAgent;
	private Date leaderSignDate;
	private String leaderSignerDeptNum;
	private String managerSigner;
	private String managerSignAgent;
	private Date managerSignDate;
	private String managerSignerDeptNum;
	private Date createDate;
	private String createAuthor;
	private Date updateDate;
	private String updateAuthor;
	
	// 判斷是否需要簽核
	private boolean needReadMgmtSign;
	private boolean needLeaderSign;
	private boolean needManagerSign;
	// 供前端顯示
	private String yearMonth;
	private String readMgmtSignDateStr;
	private String leaderSignDateStr;
	private String managerSignDateStr;
	
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public Date getReadDateStart() {
		return readDateStart;
	}
	public void setReadDateStart(Date readDateStart) {
		this.readDateStart = readDateStart;
	}
	public Date getReadDateEnd() {
		return readDateEnd;
	}
	public void setReadDateEnd(Date readDateEnd) {
		this.readDateEnd = readDateEnd;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getFileNo() {
		return fileNo;
	}
	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}
	public String getReadMgmtSigner() {
		return readMgmtSigner;
	}
	public void setReadMgmtSigner(String readMgmtSigner) {
		this.readMgmtSigner = readMgmtSigner;
	}
	public String getReadMgmtSignAgent() {
		return readMgmtSignAgent;
	}
	public void setReadMgmtSignAgent(String readMgmtSignAgent) {
		this.readMgmtSignAgent = readMgmtSignAgent;
	}
	public Date getReadMgmtSignDate() {
		return readMgmtSignDate;
	}
	public void setReadMgmtSignDate(Date readMgmtSignDate) {
		this.readMgmtSignDate = readMgmtSignDate;
	}
	public String getLeaderSigner() {
		return leaderSigner;
	}
	public void setLeaderSigner(String leaderSigner) {
		this.leaderSigner = leaderSigner;
	}
	public String getLeaderSignAgent() {
		return leaderSignAgent;
	}
	public void setLeaderSignAgent(String leaderSignAgent) {
		this.leaderSignAgent = leaderSignAgent;
	}
	public Date getLeaderSignDate() {
		return leaderSignDate;
	}
	public void setLeaderSignDate(Date leaderSignDate) {
		this.leaderSignDate = leaderSignDate;
	}
	public String getManagerSigner() {
		return managerSigner;
	}
	public void setManagerSigner(String managerSigner) {
		this.managerSigner = managerSigner;
	}
	public String getManagerSignAgent() {
		return managerSignAgent;
	}
	public void setManagerSignAgent(String managerSignAgent) {
		this.managerSignAgent = managerSignAgent;
	}
	public Date getManagerSignDate() {
		return managerSignDate;
	}
	public void setManagerSignDate(Date managerSignDate) {
		this.managerSignDate = managerSignDate;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateAuthor() {
		return createAuthor;
	}
	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateAuthor() {
		return updateAuthor;
	}
	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}
	public boolean isNeedReadMgmtSign() {
		return needReadMgmtSign;
	}
	public void setNeedReadMgmtSign(boolean needReadMgmtSign) {
		this.needReadMgmtSign = needReadMgmtSign;
	}
	public boolean isNeedLeaderSign() {
		return needLeaderSign;
	}
	public void setNeedLeaderSign(boolean needLeaderSign) {
		this.needLeaderSign = needLeaderSign;
	}
	public boolean isNeedManagerSign() {
		return needManagerSign;
	}
	public void setNeedManagerSign(boolean needManagerSign) {
		this.needManagerSign = needManagerSign;
	}
	public String getYearMonth() {
		return yearMonth;
	}
	public void setYearMonth(String yearMonth) {
		this.yearMonth = yearMonth;
	}
	public String getReadMgmtSignDateStr() {
		return readMgmtSignDateStr;
	}
	public void setReadMgmtSignDateStr(String readMgmtSignDateStr) {
		this.readMgmtSignDateStr = readMgmtSignDateStr;
	}
	public String getLeaderSignDateStr() {
		return leaderSignDateStr;
	}
	public void setLeaderSignDateStr(String leaderSignDateStr) {
		this.leaderSignDateStr = leaderSignDateStr;
	}
	public String getManagerSignDateStr() {
		return managerSignDateStr;
	}
	public void setManagerSignDateStr(String managerSignDateStr) {
		this.managerSignDateStr = managerSignDateStr;
	}
	public String getReadMgmtSignerDeptNum() {
		return readMgmtSignerDeptNum;
	}
	public void setReadMgmtSignerDeptNum(String readMgmtSignerDeptNum) {
		this.readMgmtSignerDeptNum = readMgmtSignerDeptNum;
	}
	public String getLeaderSignerDeptNum() {
		return leaderSignerDeptNum;
	}
	public void setLeaderSignerDeptNum(String leaderSignerDeptNum) {
		this.leaderSignerDeptNum = leaderSignerDeptNum;
	}
	public String getManagerSignerDeptNum() {
		return managerSignerDeptNum;
	}
	public void setManagerSignerDeptNum(String managerSignerDeptNum) {
		this.managerSignerDeptNum = managerSignerDeptNum;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	
	
}	
