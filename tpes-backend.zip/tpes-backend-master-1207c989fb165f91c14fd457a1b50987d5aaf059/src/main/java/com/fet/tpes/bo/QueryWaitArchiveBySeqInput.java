package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryWaitArchiveBySeqInput extends BaseInputBo{
	private Integer seq;
	
	
	
	public Integer getSeq() {
		return seq;
	}



	public void setSeq(Integer seq) {
		this.seq = seq;
	}



	@Override
	public boolean isValid() {
		boolean result = true;
		if(this.seq == null) {
			result = false;
			LogUtil.error(this.getClass(), "QueryWaitArchiveBySeqInput input缺少參數seq");
		}
		return result;
	}
}
