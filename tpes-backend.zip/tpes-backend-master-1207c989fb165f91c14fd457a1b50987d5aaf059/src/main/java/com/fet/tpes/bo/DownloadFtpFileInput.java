package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class DownloadFtpFileInput extends BaseInputBo {
	private String url;
	private Integer port;
	private String userName;
	private String pwwd;	// 密碼 (for codeScan)
	private String remotePath;
	private String fileName;
	private String localPath;
	
	// 參數檢查失敗時回傳訊息用
	private String errorMsg;
	
	@Override
	public boolean isValid() {
		boolean pass = true;
		if (StringUtil.isEmpty(url)) {
			pass = false;
			errorMsg = "input 參數缺少 url";
		}
		else if (port == null) {
			pass = false;
			errorMsg = "input 參數缺少 port";
		}
		else if (StringUtil.isEmpty(userName)) {
			pass = false;
			errorMsg = "input 參數缺少 user";
		}
		else if (StringUtil.isEmpty(pwwd)) {
			pass = false;
			errorMsg = "input 參數缺少 password";
		}
		else if (StringUtil.isEmpty(remotePath)) {
			pass = false;
			errorMsg = "input 參數缺少 remotePath";
		}
		else if (StringUtil.isEmpty(fileName)) {
			pass = false;
			errorMsg = "input 參數缺少 fileName";
		}
		else if (StringUtil.isEmpty(localPath)) {
			pass = false;
			errorMsg = "input 參數缺少 localPath";
		}
		
		return pass;
	}

	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPwwd() {
		return pwwd;
	}
	public void setPwwd(String pwwd) {
		this.pwwd = pwwd;
	}
	public String getRemotePath() {
		return remotePath;
	}
	public void setRemotePath(String remotePath) {
		this.remotePath = remotePath;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getLocalPath() {
		return localPath;
	}
	public void setLocalPath(String localPath) {
		this.localPath = localPath;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}
