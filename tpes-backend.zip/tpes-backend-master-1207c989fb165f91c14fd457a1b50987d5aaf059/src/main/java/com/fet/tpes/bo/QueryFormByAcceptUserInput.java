package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryFormByAcceptUserInput extends BaseInputBo{
	private List<String> acceptUserList;
	private String status;
	
	@Override
	public boolean isValid() {
        boolean result = true;
        if(CollectionUtils.isEmpty(acceptUserList)) {
        	result = false;
        	LogUtil.error(this.getClass(), "傳入參數 acceptUserList 為空值");
        } else if(StringUtil.isEmpty(status)) {
        	result = false;
        	LogUtil.error(this.getClass(), "傳入參數 status 為空值");
        } else if(StringUtil.isEmpty(this.getRegion())) {
        	result = false;
        	LogUtil.error(this.getClass(), "傳入參數 Region 為空值");
        }
        
        return result;
    }
	
	public List<String> getAcceptUserList() {
		return acceptUserList;
	}
	public void setAcceptUserList(List<String> acceptUserList) {
		this.acceptUserList = acceptUserList;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
