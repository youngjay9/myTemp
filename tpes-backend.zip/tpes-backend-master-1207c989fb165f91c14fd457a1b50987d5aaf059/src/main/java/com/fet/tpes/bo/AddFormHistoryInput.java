package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class AddFormHistoryInput extends BaseInputBo {

	private String acceptNum;
	private String actionType;

	@Override
	public boolean isValid() {
		boolean isPass = true;
		
		if(StringUtil.isEmptyOrNull(this.acceptNum)) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.actionType)) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.getEmpNo())) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.getEmpName())) {
			isPass = false;
		}
		
		return isPass;
	}

	public String getAcceptNum() {
		return acceptNum;
	}

	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
}
