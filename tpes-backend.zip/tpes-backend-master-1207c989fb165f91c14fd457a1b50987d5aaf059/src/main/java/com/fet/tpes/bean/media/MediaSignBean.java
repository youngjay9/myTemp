package com.fet.tpes.bean.media;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/11/17 下午 05:50
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
public class MediaSignBean<T> {
    private Long signOffNo;
    private Long id;
    private String mediaSignName;
    private String mediaSignType;
    private String region;
    @JsonIgnore
    private String category;
    private String createDate;
    private String createAuthor;
    private String createAuthorName;
    private String updateDate;
    private String updateAuthor;
    private String hasFile;
    private T detailData ;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSignOffNo() {
        return signOffNo;
    }

    public void setSignOffNo(Long signOffNo) {
        this.signOffNo = signOffNo;
    }

    public String getMediaSignName() {
        return mediaSignName;
    }

    public void setMediaSignName(String mediaSignName) {
        this.mediaSignName = mediaSignName;
    }

    public String getMediaSignType() {
        return mediaSignType;
    }

    public void setMediaSignType(String mediaSignType) {
        this.mediaSignType = mediaSignType;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getCreateAuthor() {
        return createAuthor;
    }

    public void setCreateAuthor(String createAuthor) {
        this.createAuthor = createAuthor;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateAuthor() {
        return updateAuthor;
    }

    public void setUpdateAuthor(String updateAuthor) {
        this.updateAuthor = updateAuthor;
    }

    public String getCreateAuthorName() {
        return createAuthorName;
    }

    public void setCreateAuthorName(String createAuthorName) {
        this.createAuthorName = createAuthorName;
    }

    public T getDetailData() {
        return detailData;
    }

    public void setDetailData(T detailData) {
        this.detailData = detailData;
    }

    public String getHasFile() {
        return hasFile;
    }

    public void setHasFile(String hasFile) {
        this.hasFile = hasFile;
    }
}
