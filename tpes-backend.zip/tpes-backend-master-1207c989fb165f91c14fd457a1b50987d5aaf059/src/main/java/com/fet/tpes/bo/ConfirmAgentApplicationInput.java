package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AgentApplicationBean;
import com.fet.tpes.bo.base.BaseInputBo;

public class ConfirmAgentApplicationInput extends BaseInputBo {

	private AgentApplicationBean empApplicationBean;
	private List<AgentApplicationBean> agentApplicationBeanList;

	@Override
	public boolean isValid() {
		return true;
	}

	public AgentApplicationBean getEmpApplicationBean() {
		return empApplicationBean;
	}
	public void setEmpApplicationBean(AgentApplicationBean empApplicationBean) {
		this.empApplicationBean = empApplicationBean;
	}
	public List<AgentApplicationBean> getAgentApplicationBeanList() {
		return agentApplicationBeanList;
	}
	public void setAgentApplicationBeanList(List<AgentApplicationBean> agentApplicationBeanList) {
		this.agentApplicationBeanList = agentApplicationBeanList;
	}
}
