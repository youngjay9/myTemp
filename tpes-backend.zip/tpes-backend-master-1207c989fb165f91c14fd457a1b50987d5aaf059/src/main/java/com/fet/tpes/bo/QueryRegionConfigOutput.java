package com.fet.tpes.bo;

import com.fet.tpes.bean.CfgRegionBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryRegionConfigOutput extends BaseOutputBo{
	
	private CfgRegionBean cfgRegionBean;

	public CfgRegionBean getCfgRegionBean() {
		return cfgRegionBean;
	}

	public void setCfgRegionBean(CfgRegionBean cfgRegionBean) {
		this.cfgRegionBean = cfgRegionBean;
	}
}
