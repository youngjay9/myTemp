package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryReadReportByReadMgmtInput extends BaseInputBo{
	private List<String> readMgmtSignerList;	
	
	public List<String> getReadMgmtSignerList() {
		return readMgmtSignerList;
	}
	
	public void setReadMgmtSignerList(List<String> readMgmtSignerList) {
		this.readMgmtSignerList = readMgmtSignerList;
	}
	

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(readMgmtSignerList)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數readMgmtSignerList為空值");
		}
		return result;
	}




}
