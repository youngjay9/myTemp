package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class ConfirmAgentApplicationOutput extends BaseOutputBo {

	private boolean hasOverTwoTiersAgent; // 判斷是否超過兩層代理
	private boolean hasLeaveRecord; // 判斷是否已有請假紀錄
	private boolean isAgentLeave; // 判斷選擇的代理人在該請假範圍中是否為請假狀態
	private boolean hasAgentOverTwice; // 判斷代理人平行代理是否超過兩位員工
	
	public boolean getHasOverTwoTiersAgent() {
		return hasOverTwoTiersAgent;
	}
	public void setHasOverTwoTiersAgent(boolean hasOverTwoTiersAgent) {
		this.hasOverTwoTiersAgent = hasOverTwoTiersAgent;
	}
	public boolean getHasLeaveRecord() {
		return hasLeaveRecord;
	}
	public void setHasLeaveRecord(boolean hasLeaveRecord) {
		this.hasLeaveRecord = hasLeaveRecord;
	}
	public boolean getIsAgentLeave() {
		return isAgentLeave;
	}
	public void setIsAgentLeave(boolean isAgentLeave) {
		this.isAgentLeave = isAgentLeave;
	}
	public boolean getHasAgentOverTwice() {
		return hasAgentOverTwice;
	}
	public void setHasAgentOverTwice(boolean hasAgentOverTwice) {
		this.hasAgentOverTwice = hasAgentOverTwice;
	}
}
