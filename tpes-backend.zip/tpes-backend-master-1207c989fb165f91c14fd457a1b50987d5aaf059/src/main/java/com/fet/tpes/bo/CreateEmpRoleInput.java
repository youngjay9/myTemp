package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bean.AuthEmpRoleMapBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class CreateEmpRoleInput extends BaseInputBo{
	
	private List<AuthEmpRoleMapBean> authEmpRoleMapBeanList;
	private boolean isSettingStyleAuto; // 設定方式是Auto還是Manual

	public List<AuthEmpRoleMapBean> getAuthEmpRoleMapBeanList() {
		return authEmpRoleMapBeanList;
	}
	
	public void setAuthEmpRoleMapBeanList(List<AuthEmpRoleMapBean> authEmpRoleMapBeanList) {
		this.authEmpRoleMapBeanList = authEmpRoleMapBeanList;
	}
	
	public boolean getIsSettingStyleAuto() {
		return isSettingStyleAuto;
	}

	public void setIsSettingStyleAuto(boolean isSettingStyleAuto) {
		this.isSettingStyleAuto = isSettingStyleAuto;
	}	
	
	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(authEmpRoleMapBeanList)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數authEmpRoleMapBeanList為空值");
		}
		return result;
	}

}
