package com.fet.tpes.bo;

import java.util.Map;

import com.fet.tpes.bo.base.BaseInputBo;

public class ListSatisfactionRawDataInput extends BaseInputBo {

	private String applyType;
	private String applyUser;
	private String applyDept;
	private String applyNum;
	private String startDate;
	private String endDate;
	private Map<String, String> acceptItemMap;

	@Override
	public boolean isValid() {
		boolean isPass = true;

		return isPass;
	}

	public String getApplyType() {
		return applyType;
	}
	public void setApplyType(String applyType) {
		this.applyType = applyType;
	}
	public String getApplyUser() {
		return applyUser;
	}
	public void setApplyUser(String applyUser) {
		this.applyUser = applyUser;
	}
	public String getApplyDept() {
		return applyDept;
	}
	public void setApplyDept(String applyDept) {
		this.applyDept = applyDept;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Map<String, String> getAcceptItemMap() {
		return acceptItemMap;
	}
	public void setAcceptItemMap(Map<String, String> acceptItemMap) {
		this.acceptItemMap = acceptItemMap;
	}
}
