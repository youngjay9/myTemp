package com.fet.tpes.bo;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.fet.tpes.bean.AgentApplicationBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import org.apache.commons.lang3.StringUtils;

public class GetAgentApplicationForTpesInput extends BaseInputBo{
	private String status;
	private List<AgentApplicationBean> agentApplicationBeanList;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

	public List<AgentApplicationBean> getAgentApplicationBeanList() {
		return agentApplicationBeanList;
	}

	public void setAgentApplicationBeanList(List<AgentApplicationBean> agentApplicationBeanList) {
		this.agentApplicationBeanList = agentApplicationBeanList;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtils.isEmpty(this.status)) {
			result = false;
			LogUtil.error(this.getClass(), "GetAgentApplicationForTpesInput input缺少參數status");
		}
		if(CollectionUtils.isEmpty(this.agentApplicationBeanList)) {
			result = false;
			LogUtil.error(this.getClass(), "GetAgentApplicationForTpesInput input缺少參數agentApplicationBeanList");
		}
		return result;
	}
}
