package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.entity.AuthEmpRoleMap;

public class CreateEmpRoleMapInput extends BaseInputBo{
	List<AuthEmpRoleMap> authEmpRoleMapList;
	
	private String recordType;
	private String settingStyle;
	
	
	
	public String getRecordType() {
		return recordType;
	}


	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}


	public String getSettingStyle() {
		return settingStyle;
	}


	public void setSettingStyle(String settingStyle) {
		this.settingStyle = settingStyle;
	}


	public List<AuthEmpRoleMap> getAuthEmpRoleMapList() {
		return authEmpRoleMapList;
	}


	public void setAuthEmpRoleMapList(List<AuthEmpRoleMap> authEmpRoleMapList) {
		this.authEmpRoleMapList = authEmpRoleMapList;
	}


	@Override
	public boolean isValid() {
		return true;
	}
}
