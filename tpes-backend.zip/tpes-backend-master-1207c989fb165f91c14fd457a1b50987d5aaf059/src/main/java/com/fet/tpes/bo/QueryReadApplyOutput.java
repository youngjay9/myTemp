package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.ReadApply;

public class QueryReadApplyOutput extends BaseOutputBo {

	private List<ReadApply> applyList;

	public List<ReadApply> getApplyList() {
		return applyList;
	}
	public void setApplyList(List<ReadApply> applyList) {
		this.applyList = applyList;
	}
}
