package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.CfgCertificateRuleBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryCertificateRulesOutput extends BaseOutputBo {

	private List<CfgCertificateRuleBean> certificateRuleList;

	public List<CfgCertificateRuleBean> getCertificateRuleList() {
		return certificateRuleList;
	}

	public void setCertificateRuleList(List<CfgCertificateRuleBean> certificateRuleList) {
		this.certificateRuleList = certificateRuleList;
	}
}
