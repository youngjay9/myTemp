package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.entity.TpesFile;
import com.fet.tpes.util.StringUtil;

public class MoveFileToCaseTempInput extends BaseInputBo {
	
	private List<TpesFile> fileList;
	private String acceptNum;

	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(getRegion()) && StringUtil.isNotEmpty(acceptNum);
	}
	
	public List<TpesFile> getFileList() {
		return fileList;
	}
	public void setFileList(List<TpesFile> fileList) {
		this.fileList = fileList;
	}
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
}
