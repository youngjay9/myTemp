package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryEmpRoleByEmpInfoInput extends BaseInputBo{
	private String division;
	private String group;
	private String section;
	private String roleCode;
	private String settingEmpNo;
		
	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	
	public String getSettingEmpNo() {
		return settingEmpNo;
	}

	public void setSettingEmpNo(String settingEmpNo) {
		this.settingEmpNo = settingEmpNo;
	}

	@Override
	public boolean isValid() {
		
		boolean result = true;
		if(StringUtil.isEmpty(division)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數division為空值");
		} else if(StringUtil.isEmpty(settingEmpNo)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數settingEmpNo為空值");
		}		
		
		return result;
	}

}
