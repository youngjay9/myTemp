package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.TpesFile;

public class QueryFilesByUploadNoOutput extends BaseOutputBo{
	private List<TpesFile> fileList;

	public List<TpesFile> getFileList() {
		return fileList;
	}

	public void setFileList(List<TpesFile> fileList) {
		this.fileList = fileList;
	}

}
