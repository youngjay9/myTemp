package com.fet.tpes.bean;

import java.util.Date;


public class AuthEmpRoleMapBean {
	private String empNo;
	private String roleCode;
	private String empName;
	private String roleName;
	private String settingStyle;
	private Date createDate;
	private String createAuthor;
	private Date updateDate;
	private String updateAuthor;
	private String roleDeptNum;
	private String memo;
	
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getSettingStyle() {
		return settingStyle;
	}
	public void setSettingStyle(String settingStyle) {
		this.settingStyle = settingStyle;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateAuthor() {
		return createAuthor;
	}
	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateAuthor() {
		return updateAuthor;
	}
	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}
	public String getRoleDeptNum() {
		return roleDeptNum;
	}
	public void setRoleDeptNum(String roleDeptNum) {
		this.roleDeptNum = roleDeptNum;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	
	
}
