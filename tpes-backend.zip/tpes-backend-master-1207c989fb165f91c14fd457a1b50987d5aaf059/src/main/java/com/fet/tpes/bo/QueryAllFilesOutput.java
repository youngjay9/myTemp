package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.FileVo;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryAllFilesOutput extends BaseOutputBo {

	private List<FileVo> fileList;

	public List<FileVo> getFileList() {
		return fileList;
	}
	public void setFileList(List<FileVo> fileList) {
		this.fileList = fileList;
	}
}
