package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.marquee.MarqueeBean;
import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.Marquee;

public class CreateMarqueeOutput extends BaseOutputBo{
	
	private Long marqueeId;
	private List<Marquee> marqueeList;
	private List<MarqueeBean> marqueeBeanList;
	
	public List<Marquee> getMarqueeList() {
		return marqueeList;
	}

	public void setMarqueeList(List<Marquee> marqueeList) {
		this.marqueeList = marqueeList;
	}

	public List<MarqueeBean> getMarqueeBeanList() {
		return marqueeBeanList;
	}

	public void setMarqueeBeanList(List<MarqueeBean> marqueeBeanList) {
		this.marqueeBeanList = marqueeBeanList;
	}

	public Long getMarqueeId() {
		return marqueeId;
	}

	public void setMarqueeId(Long marqueeId) {
		this.marqueeId = marqueeId;
	}


}
