package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryDuplicateComputeDayInput extends BaseInputBo{
	
	private List<String> computeDayList;
	private String accounting;

	public List<String> getComputeDayList() {
		return computeDayList;
	}
	
	public void setComputeDayList(List<String> computeDayList) {
		this.computeDayList = computeDayList;
	}
	
	public String getAccounting() {
		return accounting;
	}

	public void setAccounting(String accounting) {
		this.accounting = accounting;
	}
	
	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.getRegion())) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數region為空值");
		} else if(CollectionUtils.isEmpty(computeDayList)){
			result = false;
			LogUtil.error(this.getClass(), "傳入參數computeDayList為空值");
		} else if(StringUtil.isEmpty(accounting)){
			result = false;
			LogUtil.error(this.getClass(), "傳入參數accounting為空值");
		}		 
		return result;
	}

}
