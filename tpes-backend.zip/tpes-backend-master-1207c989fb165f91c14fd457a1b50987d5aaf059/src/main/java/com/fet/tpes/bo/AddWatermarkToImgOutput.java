package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class AddWatermarkToImgOutput extends BaseOutputBo {

	private byte[] imgBytes;

	public byte[] getImgBytes() {
		return imgBytes;
	}
	public void setImgBytes(byte[] imgBytes) {
		this.imgBytes = imgBytes;
	}
}
