package com.fet.tpes.bo;

import java.util.List;
import java.util.Map;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.entity.ReadApply;
import com.fet.tpes.util.StringUtil;

public class CreateReadReportInput extends BaseInputBo {

	private String beginDate;
	private String endDate;
	private Map<String, List<ReadApply>> dataMap;

	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(beginDate) && StringUtil.isNotEmpty(endDate) && dataMap != null;
	}

	public String getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Map<String, List<ReadApply>> getDataMap() {
		return dataMap;
	}
	public void setDataMap(Map<String, List<ReadApply>> dataMap) {
		this.dataMap = dataMap;
	}
}
