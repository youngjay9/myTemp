package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class GetEmpInfoOutput extends BaseOutputBo{
	private String responseString;

	public String getResponseString() {
		return responseString;
	}

	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}
	
}
