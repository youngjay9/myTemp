package com.fet.tpes.bo;

import java.util.Date;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bean.TpesFormBean;
import com.fet.tpes.bo.base.BaseInputBo;

public class ReadApplyInput extends BaseInputBo {

	private String acceptNum;
	private String applyReason;
	private String applyDesc;
	private String reader; // 實際調閱者
	private String readerName;
	private String readerDept;
	private String readNum;
	private EmpInfoBean empInfo;
	private Date readDate;
	
	private TpesFormBean form;
	private int finalLevel;
	
	public boolean isValid() {
		return true;
	}

	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
	public String getApplyReason() {
		return applyReason;
	}
	public void setApplyReason(String applyReason) {
		this.applyReason = applyReason;
	}
	public String getApplyDesc() {
		return applyDesc;
	}
	public void setApplyDesc(String applyDesc) {
		this.applyDesc = applyDesc;
	}
	public String getReader() {
		return reader;
	}
	public void setReader(String reader) {
		this.reader = reader;
	}
	public String getReaderName() {
		return readerName;
	}
	public void setReaderName(String readerName) {
		this.readerName = readerName;
	}
	public String getReaderDept() {
		return readerDept;
	}
	public void setReaderDept(String readerDept) {
		this.readerDept = readerDept;
	}
	public String getReadNum() {
		return readNum;
	}
	public void setReadNum(String readNum) {
		this.readNum = readNum;
	}
	public EmpInfoBean getEmpInfo() {
		return empInfo;
	}
	public void setEmpInfo(EmpInfoBean empInfo) {
		this.empInfo = empInfo;
	}
	public TpesFormBean getForm() {
		return form;
	}
	public void setForm(TpesFormBean form) {
		this.form = form;
	}
	public int getFinalLevel() {
		return finalLevel;
	}
	public void setFinalLevel(int finalLevel) {
		this.finalLevel = finalLevel;
	}

	public Date getReadDate() {
		return readDate;
	}

	public void setReadDate(Date readDate) {
		this.readDate = readDate;
	}
}
