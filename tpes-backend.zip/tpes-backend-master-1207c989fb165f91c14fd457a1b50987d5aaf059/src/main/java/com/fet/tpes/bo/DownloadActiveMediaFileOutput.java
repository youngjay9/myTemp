package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.program.ProgramBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class DownloadActiveMediaFileOutput extends BaseOutputBo {
    private List<ProgramBean> activatedList;

    public List<ProgramBean> getActivatedList() {
        return activatedList;
    }

    public void setActivatedList(List<ProgramBean> activatedList) {
        this.activatedList = activatedList;
    }
}
