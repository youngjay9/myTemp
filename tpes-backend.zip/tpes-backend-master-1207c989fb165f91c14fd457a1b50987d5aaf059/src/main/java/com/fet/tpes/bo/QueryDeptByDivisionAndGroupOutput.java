package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.DepartmentBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryDeptByDivisionAndGroupOutput extends BaseOutputBo{
	private List<DepartmentBean> departmentBeanList;

	public List<DepartmentBean> getDepartmentBeanList() {
		return departmentBeanList;
	}

	public void setDepartmentBeanList(List<DepartmentBean> departmentBeanList) {
		this.departmentBeanList = departmentBeanList;
	}
	
}
