package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryGeneralEmpByListInput extends BaseInputBo{
	
	private List<String> divisionList;
	private List<String> groupList;
	private List<String> sectionList;	

	public List<String> getDivisionList() {
		return divisionList;
	}

	public void setDivisionList(List<String> divisionList) {
		this.divisionList = divisionList;
	}

	public List<String> getGroupList() {
		return groupList;
	}

	public void setGroupList(List<String> groupList) {
		this.groupList = groupList;
	}

	public List<String> getSectionList() {
		return sectionList;
	}

	public void setSectionList(List<String> sectionList) {
		this.sectionList = sectionList;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(divisionList)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數divisionList為空值");
		} else if(CollectionUtils.isEmpty(groupList)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數groupList為空值");
		} 
		return result; 
	}

	
}
