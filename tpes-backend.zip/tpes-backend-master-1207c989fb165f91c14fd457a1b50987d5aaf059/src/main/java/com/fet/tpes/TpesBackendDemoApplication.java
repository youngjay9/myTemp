package com.fet.tpes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;
import org.springframework.boot.web.server.ErrorPage;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;

@SpringBootApplication
public class TpesBackendDemoApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(TpesBackendDemoApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(TpesBackendDemoApplication.class);
	}
	@Bean
	public WebServerFactoryCustomizer<ConfigurableWebServerFactory> containerCustomizer() {
		return container -> {
			ErrorPage error401Page = new ErrorPage(HttpStatus.UNAUTHORIZED, "/static/errorpage/OOPS.html");//401
			ErrorPage error404Page = new ErrorPage(HttpStatus.NOT_FOUND, "/static/errorpage/OOPS.html");//404
			ErrorPage error500Page = new ErrorPage(HttpStatus.INTERNAL_SERVER_ERROR, "/static/errorpage/OOPS.html");//500
			container.addErrorPages(error401Page, error404Page, error500Page);
		};
	}
}
