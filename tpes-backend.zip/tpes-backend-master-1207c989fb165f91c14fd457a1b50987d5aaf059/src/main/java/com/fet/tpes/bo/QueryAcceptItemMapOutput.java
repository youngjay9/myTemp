package com.fet.tpes.bo;

import java.util.Map;

import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryAcceptItemMapOutput extends BaseOutputBo {

	private Map<String, String> acceptItemMap;
	private Map<String, String> acceptDeptMap;

	public Map<String, String> getAcceptItemMap() {
		return acceptItemMap;
	}
	public void setAcceptItemMap(Map<String, String> acceptItemMap) {
		this.acceptItemMap = acceptItemMap;
	}

	public Map<String, String> getAcceptDeptMap() {
		return acceptDeptMap;
	}

	public void setAcceptDeptMap(Map<String, String> acceptDeptMap) {
		this.acceptDeptMap = acceptDeptMap;
	}
}
