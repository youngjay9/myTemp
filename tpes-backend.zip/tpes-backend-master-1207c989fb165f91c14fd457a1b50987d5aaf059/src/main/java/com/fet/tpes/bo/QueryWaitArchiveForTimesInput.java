package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryWaitArchiveForTimesInput extends BaseInputBo {
	private List<String> statusList;

	public List<String> getStatusList() {
		return statusList;
	}

	public void setStatusList(List<String> statusList) {
		this.statusList = statusList;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if (CollectionUtils.isEmpty(this.statusList)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryWaitArchiveByDateInput input缺少參數statusList");
		}
		return result;
	}
}
