package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class ReadSignOffInput extends BaseInputBo {

	private String readNum;
	private Boolean pass;
	private String rejectReason;
	private String rejectDesc;
	
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(getRegion()) && StringUtil.isNotEmpty(readNum) && pass != null;
	}

	public String getReadNum() {
		return readNum;
	}
	public void setReadNum(String readNum) {
		this.readNum = readNum;
	}
	public Boolean getPass() {
		return pass;
	}
	public void setPass(Boolean pass) {
		this.pass = pass;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getRejectDesc() {
		return rejectDesc;
	}
	public void setRejectDesc(String rejectDesc) {
		this.rejectDesc = rejectDesc;
	}
}
