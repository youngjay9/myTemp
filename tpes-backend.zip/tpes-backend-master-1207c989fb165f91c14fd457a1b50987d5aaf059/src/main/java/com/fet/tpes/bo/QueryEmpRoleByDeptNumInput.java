package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryEmpRoleByDeptNumInput extends BaseInputBo{
	
	private List<String> deptNumList;
	public List<String> getDeptNumList() {
		return deptNumList;
	}	
	
	public void setDeptNumList(List<String> deptNumList) {
		this.deptNumList = deptNumList;
	}	

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(deptNumList)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數deptNumList為空值");
		}
		return result;
	}



}
