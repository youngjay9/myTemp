package com.fet.tpes.bo;

import com.fet.tpes.bean.FileVo;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryFileByFileNoOutput extends BaseOutputBo {

	private FileVo file;

	public FileVo getFile() {
		return file;
	}
	public void setFile(FileVo file) {
		this.file = file;
	}
}
