package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryReturnFormInput extends BaseInputBo{
	
	private boolean isMgmt; // 是否為主管
	private List<String> empNoList;
	
	public boolean getIsMgmt() {
		return isMgmt;
	}

	public void setIsMgmt(boolean isMgmt) {
		this.isMgmt = isMgmt;
	}
	public List<String> getEmpNoList() {
		return empNoList;
	}

	public void setEmpNoList(List<String> empNoList) {
		this.empNoList = empNoList;
	}	
	

	@Override
	public boolean isValid() {
		boolean result = true;		
		
		if(StringUtil.isEmpty(this.getRegion())) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數Region為空值");
		}
		
		return result;
	}

}
