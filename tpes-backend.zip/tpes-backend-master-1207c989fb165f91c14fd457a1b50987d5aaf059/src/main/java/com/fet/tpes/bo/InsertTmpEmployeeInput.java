package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.entity.TmpEmployee;
import com.fet.tpes.util.LogUtil;

public class InsertTmpEmployeeInput extends BaseInputBo{
	List<TmpEmployee> tmpEmployeeList;
	
	
	public List<TmpEmployee> getTmpEmployeeList() {
		return tmpEmployeeList;
	}


	public void setTmpEmployeeList(List<TmpEmployee> tmpEmployeeList) {
		this.tmpEmployeeList = tmpEmployeeList;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(this.tmpEmployeeList)) {
			result = false;
			LogUtil.error(this.getClass(), "InsertTmpEmployeeInput input參數缺少tmpEmployeeList");
		}
		return result;
	}
}
