package com.fet.tpes.bean;

public class CfgPropertyBean {
	
	private String code;
	private String codeName;
	private String codeValue;
	private String codeCate;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCodeName() {
		return codeName;
	}
	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}
	public String getCodeValue() {
		return codeValue;
	}
	public void setCodeValue(String codeValue) {
		this.codeValue = codeValue;
	}
	public String getCodeCate() {
		return codeCate;
	}
	public void setCodeCate(String codeCate) {
		this.codeCate = codeCate;
	}
}
