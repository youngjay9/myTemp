package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class DeleteAgentLeaveInfoInput extends BaseInputBo{
	private Integer seq;
	private String status;
	
	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(this.seq == null) {
			result = false;			
			LogUtil.error(this.getClass(), "DeleteAgentLeaveInfoInput input缺少參數seq");
		}
		if(StringUtil.isEmpty(this.status)) {
			result = false;			
			LogUtil.error(this.getClass(), "DeleteAgentLeaveInfoInput input缺少參數status");
		}
		return result;
	}
}
