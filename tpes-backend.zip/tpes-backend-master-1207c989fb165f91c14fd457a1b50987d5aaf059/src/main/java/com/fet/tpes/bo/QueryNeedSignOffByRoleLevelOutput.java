package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.media.MediaSignBean;
import com.fet.tpes.bo.base.BaseOutputBo;

@SuppressWarnings("rawtypes")
public class QueryNeedSignOffByRoleLevelOutput extends BaseOutputBo{
	private List<MediaSignBean> signList;

	public List<MediaSignBean> getSignList() {
		return signList;
	}

	public void setSignList(List<MediaSignBean> signList) {
		this.signList = signList;
	}
}
