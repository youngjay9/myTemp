package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AuthRoleSettingRangeBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryDeptByRoleCodeOutput extends BaseOutputBo{
	private List<AuthRoleSettingRangeBean> authRoleSettingRangeBeanList;

	public List<AuthRoleSettingRangeBean> getAuthRoleSettingRangeBeanList() {
		return authRoleSettingRangeBeanList;
	}

	public void setAuthRoleSettingRangeBeanList(List<AuthRoleSettingRangeBean> authRoleSettingRangeBeanList) {
		this.authRoleSettingRangeBeanList = authRoleSettingRangeBeanList;
	}

	
}
