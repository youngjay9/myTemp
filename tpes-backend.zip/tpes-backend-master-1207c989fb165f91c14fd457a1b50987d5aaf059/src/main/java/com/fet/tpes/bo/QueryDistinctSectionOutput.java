package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryDistinctSectionOutput extends BaseOutputBo{
	private List<String> distinctDept;

	public List<String> getDistinctDept() {
		return distinctDept;
	}

	public void setDistinctDept(List<String> distinctDept) {
		this.distinctDept = distinctDept;
	}
	
	
}
