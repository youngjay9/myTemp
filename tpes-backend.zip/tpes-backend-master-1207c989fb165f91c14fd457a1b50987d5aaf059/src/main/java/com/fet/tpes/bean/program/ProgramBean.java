package com.fet.tpes.bean.program;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fet.tpes.bean.material.MediaFileBean;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/11/9 下午 04:43
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProgramBean {

    private Long programId;
    private String programName;
    private String programType;
    private String memo;
    private String region;
    private String status;
    private String signStatus;
    private String releaseStartDate;
    private String releaseEndDate;
    private Integer curLevel;
    private Integer finalLevel;
    private String leaderSignDate;
    private String managerSignDate;
    private String createDate;
    private String createAuthor;
    private String createAuthorName;
    private String updateDate;
    private String updateAuthor;
    private String updateAuthorName;
    private String rejectUser;
    private String rejectUserName;
    private String rejectReason;
    private String rejectDesc;
    private String rejectDate;
    private List<MediaFileBean> programMaterials;

    public Long getProgramId() {
        return programId;
    }

    public void setProgramId(Long programId) {
        this.programId = programId;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getProgramType() {
        return programType;
    }

    public void setProgramType(String programType) {
        this.programType = programType;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSignStatus() {
        return signStatus;
    }

    public void setSignStatus(String signStatus) {
        this.signStatus = signStatus;
    }

    public String getReleaseStartDate() {
        return releaseStartDate;
    }

    public void setReleaseStartDate(String releaseStartDate) {
        this.releaseStartDate = releaseStartDate;
    }

    public String getReleaseEndDate() {
        return releaseEndDate;
    }

    public void setReleaseEndDate(String releaseEndDate) {
        this.releaseEndDate = releaseEndDate;
    }

    public Integer getCurLevel() {
        return curLevel;
    }

    public void setCurLevel(Integer curLevel) {
        this.curLevel = curLevel;
    }

    public Integer getFinalLevel() {
        return finalLevel;
    }

    public void setFinalLevel(Integer finalLevel) {
        this.finalLevel = finalLevel;
    }

    public String getLeaderSignDate() {
        return leaderSignDate;
    }

    public void setLeaderSignDate(String leaderSignDate) {
        this.leaderSignDate = leaderSignDate;
    }

    public String getManagerSignDate() {
        return managerSignDate;
    }

    public void setManagerSignDate(String managerSignDate) {
        this.managerSignDate = managerSignDate;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getCreateAuthor() {
        return createAuthor;
    }

    public void setCreateAuthor(String createAuthor) {
        this.createAuthor = createAuthor;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateAuthor() {
        return updateAuthor;
    }

    public void setUpdateAuthor(String updateAuthor) {
        this.updateAuthor = updateAuthor;
    }

    public String getRejectUser() {
        return rejectUser;
    }

    public void setRejectUser(String rejectUser) {
        this.rejectUser = rejectUser;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public String getRejectDesc() {
        return rejectDesc;
    }

    public void setRejectDesc(String rejectDesc) {
        this.rejectDesc = rejectDesc;
    }

    public String getRejectDate() {
        return rejectDate;
    }

    public void setRejectDate(String rejectDate) {
        this.rejectDate = rejectDate;
    }

    public List<MediaFileBean> getProgramMaterials() {
        return programMaterials;
    }

    public void setProgramMaterials(List<MediaFileBean> programMaterials) {
        this.programMaterials = programMaterials;
    }

    public String getCreateAuthorName() {
        return createAuthorName;
    }

    public void setCreateAuthorName(String createAuthorName) {
        this.createAuthorName = createAuthorName;
    }

    public String getUpdateAuthorName() {
        return updateAuthorName;
    }

    public void setUpdateAuthorName(String updateAuthorName) {
        this.updateAuthorName = updateAuthorName;
    }

    public String getRejectUserName() {
        return rejectUserName;
    }

    public void setRejectUserName(String rejectUserName) {
        this.rejectUserName = rejectUserName;
    }
}
