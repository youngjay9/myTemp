package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class DeleteSealSignOffByFormSeqInput extends BaseInputBo {
	
	private Integer formSeq;

	@Override
	public boolean isValid() {
		return this.formSeq != null;
	}

	public Integer getFormSeq() {
		return formSeq;
	}

	public void setFormSeq(Integer formSeq) {
		this.formSeq = formSeq;
	}

}
