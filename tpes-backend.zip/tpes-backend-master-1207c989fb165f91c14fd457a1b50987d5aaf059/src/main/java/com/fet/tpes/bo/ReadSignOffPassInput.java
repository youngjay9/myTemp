package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.entity.ReadApply;

public class ReadSignOffPassInput extends BaseInputBo {

	private ReadApply readApply;
	
	@Override
	public boolean isValid() {
		return true;
	}

	public ReadApply getReadApply() {
		return readApply;
	}
	public void setReadApply(ReadApply readApply) {
		this.readApply = readApply;
	}

}
