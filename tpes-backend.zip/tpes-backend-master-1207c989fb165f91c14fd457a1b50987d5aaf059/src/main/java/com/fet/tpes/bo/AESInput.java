package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class AESInput extends BaseInputBo {

	private byte[] bytes;
	private char[] key;
	private char[] vipara;
	
	@Override
	public boolean isValid() {
		boolean isPass = true;
		
		if(key == null || key.length == 0) {
			isPass = false;
			LogUtil.error(this.getClass(), "AESInput key is null");
		}
		else if(vipara == null || vipara.length == 0) {
			isPass = false;
			LogUtil.error(this.getClass(), "AESInput vipara is null");
		}
		
		return isPass;
	}
	
	public byte[] getBytes() {
		return bytes;
	}
	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}
	public char[] getKey() {
		return key;
	}
	public void setKey(char[] key) {
		this.key = key;
	}
	public char[] getVipara() {
		return vipara;
	}
	public void setVipara(char[] vipara) {
		this.vipara = vipara;
	}
}
