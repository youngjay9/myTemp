package com.fet.tpes.bo;

import com.fet.tpes.bean.TpesFormBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryFormByAcceptNumOutput extends BaseOutputBo {
	private TpesFormBean tpesFormBean;

	public TpesFormBean getTpesFormBean() {
		return tpesFormBean;
	}

	public void setTpesFormBean(TpesFormBean tpesFormBean) {
		this.tpesFormBean = tpesFormBean;
	}
}