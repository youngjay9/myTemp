package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AccountingBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryUndispatchListOutput extends BaseOutputBo{
	List<AccountingBean> accountingBean;

	public List<AccountingBean> getAccountingBean() {
		return accountingBean;
	}

	public void setAccountingBean(List<AccountingBean> accountingBean) {
		this.accountingBean = accountingBean;
	}
	
}
