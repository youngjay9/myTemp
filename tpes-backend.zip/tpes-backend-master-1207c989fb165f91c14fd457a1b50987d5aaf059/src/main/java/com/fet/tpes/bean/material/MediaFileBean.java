package com.fet.tpes.bean.material;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MediaFileBean {
	private Long id;
	private String materialName;
	private String materialType;
	private String memo;
	private String fileName;
	@JsonIgnore
	private String category;
	private String originalFileName;
	private String fileSize;
	private String fileExt;
	private String filePath;
	private String dataUrl;
	private String base64;
	private String createDate;
	private String createAuthor;
	private String createAuthorName;
	private String updateDate;
	private String updateAuthor;
	private String updateAuthorName;
	private List<RelatedInfoBean> relatedInfos;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}

	public String getFileExt() {
		return fileExt;
	}

	public void setFileExt(String fileExt) {
		this.fileExt = fileExt;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getDataUrl() {
		return dataUrl;
	}

	public void setDataUrl(String dataUrl) {
		this.dataUrl = dataUrl;
	}

	public String getBase64() {
		return base64;
	}

	public void setBase64(String base64) {
		this.base64 = base64;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreateAuthor() {
		return createAuthor;
	}

	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateAuthor() {
		return updateAuthor;
	}

	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}

	public String getMaterialName() {
		return materialName;
	}

	public void setMaterialName(String materialName) {
		this.materialName = materialName;
	}

	public String getMaterialType() {
		return materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public List<RelatedInfoBean> getRelatedInfos() {
		return relatedInfos;
	}

	public void setRelatedInfos(List<RelatedInfoBean> relatedInfos) {
		this.relatedInfos = relatedInfos;
	}

	public String getCreateAuthorName() {
		return createAuthorName;
	}

	public void setCreateAuthorName(String createAuthorName) {
		this.createAuthorName = createAuthorName;
	}

	public String getUpdateAuthorName() {
		return updateAuthorName;
	}

	public void setUpdateAuthorName(String updateAuthorName) {
		this.updateAuthorName = updateAuthorName;
	}
}
