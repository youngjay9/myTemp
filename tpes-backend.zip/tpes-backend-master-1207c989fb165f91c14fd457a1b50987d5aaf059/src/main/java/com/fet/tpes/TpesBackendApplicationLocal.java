package com.fet.tpes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpesBackendApplicationLocal {

	public static void main(String[] args) {
		SpringApplication.run(TpesBackendApplicationLocal.class, args);
	}

}
