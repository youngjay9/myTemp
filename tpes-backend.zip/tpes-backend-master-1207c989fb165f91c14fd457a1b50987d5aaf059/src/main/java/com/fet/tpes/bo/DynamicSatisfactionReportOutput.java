package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;
import org.apache.poi.ss.usermodel.Workbook;


public class DynamicSatisfactionReportOutput extends BaseOutputBo {

	private Workbook report;
	private String reportName;

	public Workbook getReport() {
		return report;
	}

	public void setReport(Workbook report) {
		this.report = report;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
}
