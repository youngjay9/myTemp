package com.fet.tpes.bean.satisfaction;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/12/2 下午 06:38
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
public class SatisfactionReportBean {
    private Long fileId;
    private String reportName;
    private String category;
    private String dataDate;
    private String region;
    private String createDate;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public String getDataDate() {
        return dataDate;
    }

    public void setDataDate(String dataDate) {
        this.dataDate = dataDate;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }
}
