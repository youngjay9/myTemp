package com.fet.tpes.bo;

import java.util.List;
import java.util.Map;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.ReadApply;

public class QueryReadApplyCountOutput extends BaseOutputBo {

	private String beginDate;
	private String endDate;
	private Map<String, List<ReadApply>> dataMap;
	
	public String getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Map<String, List<ReadApply>> getDataMap() {
		return dataMap;
	}
	public void setDataMap(Map<String, List<ReadApply>> dataMap) {
		this.dataMap = dataMap;
	}
}
