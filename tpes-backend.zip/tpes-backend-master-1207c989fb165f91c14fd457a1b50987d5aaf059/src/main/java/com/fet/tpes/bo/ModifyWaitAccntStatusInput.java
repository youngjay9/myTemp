package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import org.apache.commons.lang3.StringUtils;

public class ModifyWaitAccntStatusInput extends BaseInputBo{
	private int seq;
	private String status;
	private String agent;
	private String memo;
	
	@Override
	public boolean isValid() {
		boolean result = true;		
		if(StringUtils.isEmpty(this.status)) {
			result = false;
			LogUtil.error(this.getClass(), "ModifyWaitAccntStatusInput input 缺少 status");
		}
		return result;
	}
	
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAgent() {
		return agent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
}
