package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryEmpArchiveFormInput extends BaseInputBo{
	private List<String> statusList;	
	private List<String> empNoList;
	private List<String> formStatusList;
	
	
	@Override
	public boolean isValid() {
		boolean result = true;			
		
		if(CollectionUtils.isEmpty(this.statusList)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryEmpAccntFormInput input 缺少 statusList");
		}
		
		return result;
	}
	
	public List<String> getStatusList() {
		return statusList;
	}
	public void setStatusList(List<String> statusList) {
		this.statusList = statusList;
	}

	public List<String> getEmpNoList() {
		return empNoList;
	}

	public void setEmpNoList(List<String> empNoList) {
		this.empNoList = empNoList;
	}

	public List<String> getFormStatusList() {
		return formStatusList;
	}

	public void setFormStatusList(List<String> formStatusList) {
		this.formStatusList = formStatusList;
	}
	
	
}
