package com.fet.tpes.bo;

import java.util.Map;

import com.fet.tpes.bean.DepartmentBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryDeptByDeptNumOutput extends BaseOutputBo{
	private Map<String,DepartmentBean> deptBeanMap;

	public Map<String,DepartmentBean> getDeptBeanMap() {
		return deptBeanMap;
	}

	public void setDeptBeanMap(Map<String,DepartmentBean> deptBeanMap) {
		this.deptBeanMap = deptBeanMap;
	}
}
