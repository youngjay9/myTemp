package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class NcpsCancelFormInput extends BaseInputBo {
	private String DITR_NO; // 區處
	private String FM_NO; // 受理編號
	private String FMBH_NO; // 受理分號
	private String SR_TP; // 收送別
	private String CANCEL_CODE; // 取消代碼
	private String DEPT_NO; // 部門編號
	private String USER_SC_NO; // 使用者單位
	private String USER_DEPT_NO; // 使用者部門
	private String USER_ID; // 使用者ID
	private String RECORD_KIND; // 紀錄類型
	private String DCIS_FG; // DCIS註記

	@Override
	public boolean isValid() {
		boolean result = true;
		if (StringUtil.isEmpty(this.DITR_NO)) {
			result = false;
			LogUtil.error(this.getClass(), "NcpsCancelFormInput input 缺少參數 DITR_NO");
		}
		if (StringUtil.isEmpty(this.FM_NO)) {
			result = false;
			LogUtil.error(this.getClass(), "NcpsCancelFormInput input 缺少參數 FM_NO");
		}
		return result;
	}

	public String getDITR_NO() {
		return DITR_NO;
	}

	public void setDITR_NO(String dITR_NO) {
		DITR_NO = dITR_NO;
	}

	public String getFM_NO() {
		return FM_NO;
	}

	public void setFM_NO(String fM_NO) {
		FM_NO = fM_NO;
	}

	public String getFMBH_NO() {
		return FMBH_NO;
	}

	public void setFMBH_NO(String fMBH_NO) {
		FMBH_NO = fMBH_NO;
	}

	public String getSR_TP() {
		return SR_TP;
	}

	public void setSR_TP(String sR_TP) {
		SR_TP = sR_TP;
	}

	public String getCANCEL_CODE() {
		return CANCEL_CODE;
	}

	public void setCANCEL_CODE(String cANCEL_CODE) {
		CANCEL_CODE = cANCEL_CODE;
	}

	public String getDEPT_NO() {
		return DEPT_NO;
	}

	public void setDEPT_NO(String dEPT_NO) {
		DEPT_NO = dEPT_NO;
	}

	public String getUSER_SC_NO() {
		return USER_SC_NO;
	}

	public void setUSER_SC_NO(String uSER_SC_NO) {
		USER_SC_NO = uSER_SC_NO;
	}

	public String getUSER_DEPT_NO() {
		return USER_DEPT_NO;
	}

	public void setUSER_DEPT_NO(String uSER_DEPT_NO) {
		USER_DEPT_NO = uSER_DEPT_NO;
	}

	public String getUSER_ID() {
		return USER_ID;
	}

	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}

	public String getRECORD_KIND() {
		return RECORD_KIND;
	}

	public void setRECORD_KIND(String rECORD_KIND) {
		RECORD_KIND = rECORD_KIND;
	}

	public String getDCIS_FG() {
		return DCIS_FG;
	}

	public void setDCIS_FG(String dCIS_FG) {
		DCIS_FG = dCIS_FG;
	}
}
