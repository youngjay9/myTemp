package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.RejectReportBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryRejectReportOutput extends BaseOutputBo {

	private List<RejectReportBean> beanList;

	public List<RejectReportBean> getBeanList() {
		return beanList;
	}
	public void setBeanList(List<RejectReportBean> beanList) {
		this.beanList = beanList;
	}
}
