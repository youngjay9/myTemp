package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class DownloadFtpFileOutput extends BaseOutputBo {

	private boolean hasFile;
	private byte[] fileByte;

	public boolean getHasFile() {
		return hasFile;
	}
	public void setHasFile(boolean hasFile) {
		this.hasFile = hasFile;
	}
	public byte[] getFileByte() {
		return fileByte;
	}
	public void setFileByte(byte[] fileByte) {
		this.fileByte = fileByte;
	}
}
