package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AuthRoleSettingRangeBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QuerySettingDeptByRoleCodeOutput extends BaseOutputBo{
	private List<AuthRoleSettingRangeBean> deptBeanList;

	public List<AuthRoleSettingRangeBean> getDeptBeanList() {
		return deptBeanList;
	}

	public void setDeptBeanList(List<AuthRoleSettingRangeBean> deptBeanList) {
		this.deptBeanList = deptBeanList;
	}
	

	
}
