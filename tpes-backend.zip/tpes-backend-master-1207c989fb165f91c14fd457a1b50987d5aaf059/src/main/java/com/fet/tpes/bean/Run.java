package com.fet.tpes.bean;

import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class Run {
	private String color;
	private String fontFamily;
	private int fontSize;
	private UnderlinePatterns underline;
	private boolean isBold;
	private boolean isItalic;
	private boolean isStrike;
	private String text;
	
	// constructor
	public Run() {
		
	}
	
	@SuppressWarnings("deprecation")
	public Run(XWPFRun run, StringBuilder builder) {
		this.color = run.getColor();
		if(run.getCTR() != null && run.getCTR().getRPr() != null && run.getCTR().getRPr().getRFonts() != null) {
			if(run.getCTR().getRPr().getRFonts().getEastAsia() != null) {				
				this.fontFamily = run.getCTR().getRPr().getRFonts().getEastAsia();
			}
			else {
				this.fontFamily = run.getCTR().getRPr().getRFonts().getAscii();
			}
		}
		this.fontSize = run.getFontSize();
		this.underline = run.getUnderline();
		this.isBold = run.isBold();
		this.isItalic = run.isItalic();
		this.isStrike = run.isStrike();
		if(builder == null) {
			this.text = "";
		}else {
			this.text = builder.toString();
		}
	}
	
	@SuppressWarnings("deprecation")
	public Run(XWPFRun run, String text) {
		this.color = run.getColor();
		if(run.getCTR() != null && run.getCTR().getRPr() != null && run.getCTR().getRPr().getRFonts() != null) {
			if(run.getCTR().getRPr().getRFonts().getEastAsia() != null) {				
				this.fontFamily = run.getCTR().getRPr().getRFonts().getEastAsia();
			}
			else {
				this.fontFamily = run.getCTR().getRPr().getRFonts().getAscii();
			}
		}
		this.fontSize = run.getFontSize();
		this.underline = run.getUnderline();
		this.isBold = run.isBold();
		this.isItalic = run.isItalic();
		this.isStrike = run.isStrike();
		this.text = text;
	}
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getFontFamily() {
		return fontFamily;
	}
	public void setFontFamily(String fontFamily) {
		this.fontFamily = fontFamily;
	}
	public int getFontSize() {
		return fontSize;
	}
	public void setFontSize(int fontSize) {
		this.fontSize = fontSize;
	}
	public UnderlinePatterns getUnderline() {
		return underline;
	}
	public void setUnderline(UnderlinePatterns underline) {
		this.underline = underline;
	}
	public boolean isBold() {
		return isBold;
	}
	public void setBold(boolean isBold) {
		this.isBold = isBold;
	}
	public boolean isItalic() {
		return isItalic;
	}
	public void setItalic(boolean isItalic) {
		this.isItalic = isItalic;
	}
	public boolean isStrike() {
		return isStrike;
	}
	public void setStrike(boolean isStrike) {
		this.isStrike = isStrike;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
}
