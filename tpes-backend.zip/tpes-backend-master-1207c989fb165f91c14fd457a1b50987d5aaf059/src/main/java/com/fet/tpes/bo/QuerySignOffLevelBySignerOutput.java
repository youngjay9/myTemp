package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.CfgSignOffLevelBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QuerySignOffLevelBySignerOutput extends BaseOutputBo{
	private List<CfgSignOffLevelBean> configList;

	public List<CfgSignOffLevelBean> getConfigList() {
		return configList;
	}

	public void setConfigList(List<CfgSignOffLevelBean> configList) {
		this.configList = configList;
	}

	
}
