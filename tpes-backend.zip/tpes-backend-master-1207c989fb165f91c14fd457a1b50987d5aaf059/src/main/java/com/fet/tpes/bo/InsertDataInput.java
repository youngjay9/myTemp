package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bean.AccountingDispatchBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class InsertDataInput extends BaseInputBo{
	
	public List<AccountingDispatchBean> accountingDispatchBeanList;	

	public List<AccountingDispatchBean> getAccountingDispatchBeanList() {
		return accountingDispatchBeanList;
	}

	public void setAccountingDispatchBeanList(List<AccountingDispatchBean> accountingDispatchBeanList) {
		this.accountingDispatchBeanList = accountingDispatchBeanList;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(accountingDispatchBeanList)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數accountingDispatchBeanList為空值");
		}
		
		return result;
	}

}
