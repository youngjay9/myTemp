package com.fet.tpes.bean;

import java.util.Date;

public class AuthRoleSettingTargetBean {
	private Integer seq;
	private String roleCode;
	private String setRoleCode;
	private String  setRoleName;
	private Date createDate;
	private String createAuthor;
	private Date updateDate;
	private String updateAuthor;
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getSetRoleCode() {
		return setRoleCode;
	}
	public void setSetRoleCode(String setRoleCode) {
		this.setRoleCode = setRoleCode;
	}
	public String getSetRoleName() {
		return setRoleName;
	}
	public void setSetRoleName(String setRoleName) {
		this.setRoleName = setRoleName;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateAuthor() {
		return createAuthor;
	}
	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateAuthor() {
		return updateAuthor;
	}
	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}
	
	
}
