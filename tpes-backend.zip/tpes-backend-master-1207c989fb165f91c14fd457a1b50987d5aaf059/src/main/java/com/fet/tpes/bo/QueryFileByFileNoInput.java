package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryFileByFileNoInput extends BaseInputBo {

	private Integer fileNo;

	@Override
	public boolean isValid() {
		boolean isPass = true;
		
		if(this.fileNo == null) {
			isPass = false;
		}
		
		return isPass;
	}

	public Integer getFileNo() {
		return fileNo;
	}

	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}
}
