package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryReadApplyBySignerInput extends BaseInputBo{
	
	private String signer;
	private String signOffStatus;
	private List<String> readApplyStatusList;	

	public String getSigner() {
		return signer;
	}
	public void setSigner(String signer) {
		this.signer = signer;
	}
	public String getSignOffStatus() {
		return signOffStatus;
	}
	public void setSignOffStatus(String signOffStatus) {
		this.signOffStatus = signOffStatus;
	}	
	
	public List<String> getReadApplyStatusList() {
		return readApplyStatusList;
	}
	public void setReadApplyStatusList(List<String> readApplyStatusList) {
		this.readApplyStatusList = readApplyStatusList;
	}
	
	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(signer)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數signer為空值");
		} else if (StringUtil.isEmpty(signer)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數signOffStatus為空值");
		} else if (CollectionUtils.isEmpty(readApplyStatusList)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數readApplyStatusList為空值");
		} 
		
		
		return result;
	}

	
}
