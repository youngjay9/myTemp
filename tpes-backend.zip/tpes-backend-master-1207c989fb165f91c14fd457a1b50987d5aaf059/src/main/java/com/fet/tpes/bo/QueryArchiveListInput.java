package com.fet.tpes.bo;

import java.util.List;

public class QueryArchiveListInput {
	private List<String> statusList;
	private List<String> empNoList;
	private String acceptNum;
	private String electricNum;	
	private String archiveNum;
	private List<String> formStatusList;
	
	public List<String> getStatusList() {
		return statusList;
	}
	public void setStatusList(List<String> statusList) {
		this.statusList = statusList;
	}
	public List<String> getEmpNoList() {
		return empNoList;
	}
	public void setEmpNoList(List<String> empNoList) {
		this.empNoList = empNoList;
	}
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
	public String getElectricNum() {
		return electricNum;
	}
	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}
	public String getArchiveNum() {
		return archiveNum;
	}
	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}
	public List<String> getFormStatusList() {
		return formStatusList;
	}
	public void setFormStatusList(List<String> formStatusList) {
		this.formStatusList = formStatusList;
	}
	
	
}
