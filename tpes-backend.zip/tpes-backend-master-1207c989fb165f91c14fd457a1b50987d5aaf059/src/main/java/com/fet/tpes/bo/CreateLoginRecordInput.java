package com.fet.tpes.bo;

import com.fet.tpes.bean.LogLoginBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class CreateLoginRecordInput extends BaseInputBo{
	private LogLoginBean logLoginBean;
	
	
	public LogLoginBean getLogLoginBean() {
		return logLoginBean;
	}


	public void setLogLoginBean(LogLoginBean logLoginBean) {
		this.logLoginBean = logLoginBean;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(this.logLoginBean == null) {
			result = false;
			LogUtil.error(this.getClass(), "CreateLoginRecordInput input參數缺少logLoginBean");
		}
		return result;
	}
}
