package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AuthEmpRoleMapBean;
import com.fet.tpes.bo.base.BaseInputBo;

public class DeleteEmpRoleByEmpNoInput extends BaseInputBo{
	List<String> deleteEmpNoList;
	
	private List<AuthEmpRoleMapBean> authEmpRoleMapBeanList;
	private String settingStyle;
	private String recordType;
	private String createAuthor;
	private String updateAuthor;
	
	
	
	public String getSettingStyle() {
		return settingStyle;
	}



	public void setSettingStyle(String settingStyle) {
		this.settingStyle = settingStyle;
	}



	public String getRecordType() {
		return recordType;
	}



	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}



	public List<AuthEmpRoleMapBean> getAuthEmpRoleMapBeanList() {
		return authEmpRoleMapBeanList;
	}



	public void setAuthEmpRoleMapBeanList(List<AuthEmpRoleMapBean> authEmpRoleMapBeanList) {
		this.authEmpRoleMapBeanList = authEmpRoleMapBeanList;
	}



	public List<String> getDeleteEmpNoList() {
		return deleteEmpNoList;
	}



	public void setDeleteEmpNoList(List<String> deleteEmpNoList) {
		this.deleteEmpNoList = deleteEmpNoList;
	}

	

	public String getCreateAuthor() {
		return createAuthor;
	}



	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}



	public String getUpdateAuthor() {
		return updateAuthor;
	}



	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}



	@Override
	public boolean isValid() {
		return true;
	}
}
