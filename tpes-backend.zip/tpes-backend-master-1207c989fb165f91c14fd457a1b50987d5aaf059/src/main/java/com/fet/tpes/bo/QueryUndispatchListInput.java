package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryUndispatchListInput extends BaseInputBo{
	private List<String> statusList;
	private String acceptItem;
	
	
	public List<String> getStatusList() {
		return statusList;
	}



	public void setStatusList(List<String> statusList) {
		this.statusList = statusList;
	}



	public String getAcceptItem() {
		return acceptItem;
	}



	public void setAcceptItem(String acceptItem) {
		this.acceptItem = acceptItem;
	}



	@Override
	public boolean isValid() {
		boolean result = true;
		return result;
	}
}
