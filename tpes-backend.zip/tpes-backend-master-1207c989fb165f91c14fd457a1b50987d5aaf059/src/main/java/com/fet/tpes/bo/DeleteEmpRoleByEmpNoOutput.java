package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class DeleteEmpRoleByEmpNoOutput extends BaseOutputBo{

}
