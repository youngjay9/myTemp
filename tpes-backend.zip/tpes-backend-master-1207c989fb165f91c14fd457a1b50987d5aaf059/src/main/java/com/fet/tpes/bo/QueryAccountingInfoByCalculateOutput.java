package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AccountingBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryAccountingInfoByCalculateOutput extends BaseOutputBo{
	private List<AccountingBean> accountingBeanList;

	public List<AccountingBean> getAccountingBeanList() {
		return accountingBeanList;
	}

	public void setAccountingBeanList(List<AccountingBean> accountingBeanList) {
		this.accountingBeanList = accountingBeanList;
	}
}
