package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.ReadReportBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryReadReportOutput extends BaseOutputBo {

	private List<ReadReportBean> beanList;

	public List<ReadReportBean> getBeanList() {
		return beanList;
	}
	public void setBeanList(List<ReadReportBean> beanList) {
		this.beanList = beanList;
	}
}
