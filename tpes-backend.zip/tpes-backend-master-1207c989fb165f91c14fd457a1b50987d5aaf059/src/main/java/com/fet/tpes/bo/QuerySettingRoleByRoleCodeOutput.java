package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AuthRoleSettingTargetBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QuerySettingRoleByRoleCodeOutput extends BaseOutputBo{
	private List<AuthRoleSettingTargetBean> authRoleSettingTargetBeanList;

	public List<AuthRoleSettingTargetBean> getAuthRoleSettingTargetBeanList() {
		return authRoleSettingTargetBeanList;
	}

	public void setAuthRoleSettingTargetBeanList(List<AuthRoleSettingTargetBean> authRoleSettingTargetBeanList) {
		this.authRoleSettingTargetBeanList = authRoleSettingTargetBeanList;
	}
}
