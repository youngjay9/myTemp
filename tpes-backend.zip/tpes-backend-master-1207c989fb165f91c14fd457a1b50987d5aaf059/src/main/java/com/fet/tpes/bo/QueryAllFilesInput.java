package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryAllFilesInput extends BaseInputBo {

	private Integer formSeq;
	private Integer uploadNo;

	@Override
	public boolean isValid() {
		boolean isPass = true;
		
		return isPass;
	}
	
	public Integer getFormSeq() {
		return formSeq;
	}
	public void setFormSeq(Integer formSeq) {
		this.formSeq = formSeq;
	}
	public Integer getUploadNo() {
		return uploadNo;
	}
	public void setUploadNo(Integer uploadNo) {
		this.uploadNo = uploadNo;
	}
}
