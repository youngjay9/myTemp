package com.fet.tpes.bo;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QuerySpacificRoleOutput extends BaseOutputBo {

	private EmpInfoBean empInfo;
	private String roleName; // for 失敗時寫 log 用

	public EmpInfoBean getEmpInfo() {
		return empInfo;
	}
	public void setEmpInfo(EmpInfoBean empInfo) {
		this.empInfo = empInfo;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String positionName) {
		this.roleName = positionName;
	}
}
