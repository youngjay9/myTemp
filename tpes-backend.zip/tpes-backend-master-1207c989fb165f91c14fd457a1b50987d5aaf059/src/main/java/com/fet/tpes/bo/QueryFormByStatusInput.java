package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QueryFormByStatusInput extends BaseInputBo {

	private String status;

	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(status);
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
