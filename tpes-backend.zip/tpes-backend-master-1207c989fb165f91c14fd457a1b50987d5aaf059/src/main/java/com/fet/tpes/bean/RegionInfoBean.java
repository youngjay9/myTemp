package com.fet.tpes.bean;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/12/24 下午 03:16
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
public class RegionInfoBean {

    private String regionName;
    private String empRegion;
    private String businessRegion;

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public String getEmpRegion() {
        return empRegion;
    }

    public void setEmpRegion(String empRegion) {
        this.empRegion = empRegion;
    }

    public String getBusinessRegion() {
        return businessRegion;
    }

    public void setBusinessRegion(String businessRegion) {
        this.businessRegion = businessRegion;
    }
}
