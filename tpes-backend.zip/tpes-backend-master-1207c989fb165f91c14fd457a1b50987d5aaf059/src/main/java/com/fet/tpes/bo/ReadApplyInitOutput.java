package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.CfgSystemProperties;

public class ReadApplyInitOutput extends BaseOutputBo {

	private String userType;
	private List<CfgSystemProperties> reasonList;
	private List<EmpInfoBean> ownReaderList;
	private List<EmpInfoBean> agentReaderList;
	
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public List<CfgSystemProperties> getReasonList() {
		return reasonList;
	}
	public void setReasonList(List<CfgSystemProperties> reasonList) {
		this.reasonList = reasonList;
	}
	public List<EmpInfoBean> getOwnReaderList() {
		return ownReaderList;
	}
	public void setOwnReaderList(List<EmpInfoBean> ownReaderList) {
		this.ownReaderList = ownReaderList;
	}
	public List<EmpInfoBean> getAgentReaderList() {
		return agentReaderList;
	}
	public void setAgentReaderList(List<EmpInfoBean> agentReaderList) {
		this.agentReaderList = agentReaderList;
	}
	
}
