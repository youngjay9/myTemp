package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QuerySettingDeptByRoleCodeInput extends BaseInputBo{
	
	private List<String> roleCodeList;
	
	public List<String> getRoleCodeList() {
		return roleCodeList;
	}
	
	public void setRoleCodeList(List<String> roleCodeList) {
		this.roleCodeList = roleCodeList;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(roleCodeList)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數roleCodeList為空值");
		}
		return result;
	}


}
