package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import org.apache.commons.lang3.StringUtils;

public class DistributeUndispatchInput extends BaseInputBo{
	private Integer seq;
	private String className;
	private String accounting;
	
	
	
	public Integer getSeq() {
		return seq;
	}



	public void setSeq(Integer seq) {
		this.seq = seq;
	}



	public String getClassName() {
		return className;
	}



	public void setClassName(String className) {
		this.className = className;
	}



	public String getAccounting() {
		return accounting;
	}



	public void setAccounting(String accounting) {
		this.accounting = accounting;
	}



	@Override 
	public boolean isValid() {
		boolean result = true;
		if(StringUtils.isEmpty(this.accounting) && StringUtils.isEmpty(this.className)) {
			result = false;
			LogUtil.error(this.getClass(), "DistributeUndispatchInput input參數同時缺少accounting與className");
		}
		if(this.seq == null) {
			result = false;
			LogUtil.error(this.getClass(), "DistributeUndispatchInput input缺少參數seq");
		}
		return result;
	}
}
