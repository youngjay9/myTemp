package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.ReadApply;

public class QueryNeedSignOffReadOutput extends BaseOutputBo {

	private List<ReadApply> needSignOffList;

	public List<ReadApply> getNeedSignOffList() {
		return needSignOffList;
	}
	public void setNeedSignOffList(List<ReadApply> needSignOffList) {
		this.needSignOffList = needSignOffList;
	}
}
