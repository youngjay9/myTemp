package com.fet.tpes.bo;

import java.util.List;
import java.util.Map;

import com.fet.tpes.bean.TpesFormBean;
import com.fet.tpes.bo.base.BaseOutputBo;


public class QueryFormOutput extends BaseOutputBo {
	private List<TpesFormBean> tpesFormBeanList;
	private Map<String, String> contractTypeMap;
	private Map<String, String> acceptItemMap;

	public List<TpesFormBean> getTpesFormBeanList() {
		return tpesFormBeanList;
	}
	public void setTpesFormBeanList(List<TpesFormBean> tpesFormBeanList) {
		this.tpesFormBeanList = tpesFormBeanList;
	}
	public Map<String, String> getContractTypeMap() {
		return contractTypeMap;
	}
	public void setContractTypeMap(Map<String, String> contractTypeMap) {
		this.contractTypeMap = contractTypeMap;
	}
	public Map<String, String> getAcceptItemMap() {
		return acceptItemMap;
	}
	public void setAcceptItemMap(Map<String, String> acceptItemMap) {
		this.acceptItemMap = acceptItemMap;
	}
}
