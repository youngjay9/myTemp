package com.fet.tpes.bean;

import java.util.Date;

public class SealSignOffBean {

	private Integer seq;
	private Integer formSeq;
	private String acceptNum;
	private String custName;
	private String electricNum;
	private String contractType;
	private String acceptDateStr;
	private String computeDate;
	private String sealStatus;
	private String acceptItem;
	private String signer;
	private String signerName;
	private String deptNum;
	private Date updateDate;
	private String updateAuthor;
	
	
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	
	public Integer getFormSeq() {
		return formSeq;
	}
	public void setFormSeq(Integer formSeq) {
		this.formSeq = formSeq;
	}
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getElectricNum() {
		return electricNum;
	}
	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getAcceptDateStr() {
		return acceptDateStr;
	}
	public void setAcceptDateStr(String acceptDateStr) {
		this.acceptDateStr = acceptDateStr;
	}
	public String getComputeDate() {
		return computeDate;
	}
	public void setComputeDate(String computeDate) {
		this.computeDate = computeDate;
	}
	public String getSealStatus() {
		return sealStatus;
	}
	public void setSealStatus(String sealStatus) {
		this.sealStatus = sealStatus;
	}
	public String getAcceptItem() {
		return acceptItem;
	}
	public void setAcceptItem(String acceptItem) {
		this.acceptItem = acceptItem;
	}
	public String getSigner() {
		return signer;
	}
	public void setSigner(String signer) {
		this.signer = signer;
	}
	public String getSignerName() {
		return signerName;
	}
	public void setSignerName(String signerName) {
		this.signerName = signerName;
	}
	public String getDeptNum() {
		return deptNum;
	}
	public void setDeptNum(String deptNum) {
		this.deptNum = deptNum;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateAuthor() {
		return updateAuthor;
	}
	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}
	
}
