package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryFormInput extends BaseInputBo {

	private String acceptNum;
	private String electricNum;
	private String custName;
	private String archiveNum;
	private String contractType;
	private String acceptStartDate;
	private String acceptEndDate;
	private String archiveStartDate;
	private String archiveEndDate;
	
	@Override
	public boolean isValid() {
		return true;
	}

	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
	public String getElectricNum() {
		return electricNum;
	}
	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getArchiveNum() {
		return archiveNum;
	}
	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}
	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getAcceptStartDate() {
		return acceptStartDate;
	}
	public void setAcceptStartDate(String acceptStartDate) {
		this.acceptStartDate = acceptStartDate;
	}
	public String getAcceptEndDate() {
		return acceptEndDate;
	}
	public void setAcceptEndDate(String acceptEndDate) {
		this.acceptEndDate = acceptEndDate;
	}
	public String getArchiveStartDate() {
		return archiveStartDate;
	}
	public void setArchiveStartDate(String archiveStartDate) {
		this.archiveStartDate = archiveStartDate;
	}
	public String getArchiveEndDate() {
		return archiveEndDate;
	}
	public void setArchiveEndDate(String archiveEndDate) {
		this.archiveEndDate = archiveEndDate;
	}
}
