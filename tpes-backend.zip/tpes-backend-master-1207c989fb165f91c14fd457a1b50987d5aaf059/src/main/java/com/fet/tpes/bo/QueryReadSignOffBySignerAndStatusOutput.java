package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.ReadSignOffBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryReadSignOffBySignerAndStatusOutput extends BaseOutputBo{
	private List<ReadSignOffBean> readSignOffBeanList;

	public List<ReadSignOffBean> getReadSignOffBeanList() {
		return readSignOffBeanList;
	}

	public void setReadSignOffBeanList(List<ReadSignOffBean> readSignOffBeanList) {
		this.readSignOffBeanList = readSignOffBeanList;
	}
}
