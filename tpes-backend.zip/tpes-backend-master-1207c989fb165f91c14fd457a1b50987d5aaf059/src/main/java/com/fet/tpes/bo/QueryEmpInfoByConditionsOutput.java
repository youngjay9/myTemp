package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryEmpInfoByConditionsOutput extends BaseOutputBo{

	private List<EmpInfoBean> empBeanList;

	public List<EmpInfoBean> getEmpBeanList() {
		return empBeanList;
	}

	public void setEmpBeanList(List<EmpInfoBean> empBeanList) {
		this.empBeanList = empBeanList;
	}
	
}
