package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class EditLoginRecordInput extends BaseInputBo{
	private String ipAddress;
	private String loginKey;
	private String loginPath;
	private boolean isLogin; //T為登入，F為登出
	private boolean loginSuccess; //T為登入成功，F為登入失敗
	private String apiName; //NCPS開TPES表單時記錄的api名稱
	
	
	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getLoginKey() {
		return loginKey;
	}

	public void setLoginKey(String loginKey) {
		this.loginKey = loginKey;
	}

	public String getLoginPath() {
		return loginPath;
	}

	public void setLoginPath(String loginPath) {
		this.loginPath = loginPath;
	}

	
	

	public boolean isLogin() {
		return isLogin;
	}

	public void setLogin(boolean isLogin) {
		this.isLogin = isLogin;
	}
	

	public boolean isLoginSuccess() {
		return loginSuccess;
	}

	public void setLoginSuccess(boolean loginSuccess) {
		this.loginSuccess = loginSuccess;
	}
	
	


	public String getApiName() {
		return apiName;
	}

	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	@Override
	public boolean isValid() {
		return true;
	}
}
