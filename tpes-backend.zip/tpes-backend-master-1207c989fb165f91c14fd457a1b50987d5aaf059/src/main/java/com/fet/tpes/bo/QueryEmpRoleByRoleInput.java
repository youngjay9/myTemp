package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryEmpRoleByRoleInput extends BaseInputBo{
	private String roleCode;
	private String roleDeptNum;
	
	public String getRoleCode() {
		return roleCode;
	}
	
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getRoleDeptNum() {
		return roleDeptNum;
	}
	
	public void setRoleDeptNum(String roleDeptNum) {
		this.roleDeptNum = roleDeptNum;
	}
	
	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(roleCode)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數roleCode為空值");
		}
		
		return result;
	}



}
