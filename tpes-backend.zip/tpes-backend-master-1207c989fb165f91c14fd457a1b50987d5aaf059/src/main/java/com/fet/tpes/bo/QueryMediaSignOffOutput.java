package com.fet.tpes.bo;

import com.fet.tpes.bean.media.MediaSignBean;
import com.fet.tpes.bo.base.BaseOutputBo;

import java.util.List;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/11/17 下午 02:23
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
@SuppressWarnings("rawtypes")
public class QueryMediaSignOffOutput extends BaseOutputBo {

	private List<MediaSignBean> signList;

	public List<MediaSignBean> getSignList() {
		return signList;
	}

	public void setSignList(List<MediaSignBean> signList) {
		this.signList = signList;
	}
}
