package com.fet.tpes.bean;

public class NcpsFormFileBean {

	private String fileName;
	private String fileFormat;
	private String fileId;
	private String fileBody;
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileFormat() {
		return fileFormat;
	}
	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFileBody() {
		return fileBody;
	}
	public void setFileBody(String fileBody) {
		this.fileBody = fileBody;
	}
}
