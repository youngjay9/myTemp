package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.SealSignOff;

public class QueryNeedSignOffSealOutput extends BaseOutputBo {

	private List<SealSignOff> needSignOffList;

	public List<SealSignOff> getNeedSignOffList() {
		return needSignOffList;
	}
	public void setNeedSignOffList(List<SealSignOff> needSignOffList) {
		this.needSignOffList = needSignOffList;
	}
}
