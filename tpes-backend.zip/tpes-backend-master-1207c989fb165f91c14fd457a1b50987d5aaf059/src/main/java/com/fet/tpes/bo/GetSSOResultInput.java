package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class GetSSOResultInput extends BaseInputBo {

	private String apUid;
	private String userId;
	private String timeStamp;
	private String apX;
	private String userX;
	
	// 參數檢查失敗時傳訊息用
	private String errorMsg;
	@Override
	public boolean isValid() {
		boolean pass = true;
		
		if(StringUtil.isEmpty(apUid)) {
			pass = false;
			errorMsg = "input 參數缺少 apUid";
		}
		else if (StringUtil.isEmpty(userId)) {
			pass = false;
			errorMsg = "input 參數缺少 userId";
		}
		else if (StringUtil.isEmpty(timeStamp)) {
			pass = false;
			errorMsg = "input 參數缺少 timeStamp";
		}
		else if (StringUtil.isEmpty(apX)) {
			pass = false;
			errorMsg = "input 參數缺少 apX";
		}
		else if (StringUtil.isEmpty(userX)) {
			pass = false;
			errorMsg = "input 參數缺少 userX";
		}
		
		return pass;
	}
	
	public String getApUid() {
		return apUid;
	}
	public void setApUid(String apUid) {
		this.apUid = apUid;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getApX() {
		return apX;
	}
	public void setApX(String apX) {
		this.apX = apX;
	}
	public String getUserX() {
		return userX;
	}
	public void setUserX(String userX) {
		this.userX = userX;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}
