package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryEmpRoleByCodeInput extends BaseInputBo{
private String roleCode;
	
	
	
	public String getRoleCode() {
		return roleCode;
	}



	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}



	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.roleCode)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryEmpRoleByCodeInput input參數缺少roleCode");
		}
		return result;
	}
}
