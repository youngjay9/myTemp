package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryLast50CancelFormInput extends BaseInputBo{
	private List<String> acceptUserList;
	private boolean isMgmt;
	private List<String> mgmtAcceptDeptList;
	
	public List<String> getAcceptUserList() {
		return acceptUserList;
	}	
	
	public void setAcceptUserList(List<String> acceptUserList) {
		this.acceptUserList = acceptUserList;
	}
	public List<String> getMgmtAcceptDeptList() {
		return mgmtAcceptDeptList;
	}
	
	public void setMgmtAcceptDeptList(List<String> mgmtAcceptDeptList) {
		this.mgmtAcceptDeptList = mgmtAcceptDeptList;
	}
	
	public boolean getIsMgmt() {
		return isMgmt;
	}
	
	public void setIsMgmt(boolean isMgmt) {
		this.isMgmt = isMgmt;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(acceptUserList)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數acceptUserList為空值");
		}
		return result;
	}


}
