package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.SealSignOff;

public class QueryNeedSignOffSealByFormSeqOutput extends BaseOutputBo {

	private SealSignOff sealSignOff;

	public SealSignOff getSealSignOff() {
		return sealSignOff;
	}

	public void setSealSignOff(SealSignOff sealSignOff) {
		this.sealSignOff = sealSignOff;
	}
}
