package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AccountingDispatchBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryAccounterListOutput extends BaseOutputBo{
	List<AccountingDispatchBean> accountingDispatchBeanList;

	public List<AccountingDispatchBean> getAccountingDispatchBeanList() {
		return accountingDispatchBeanList;
	}

	public void setAccountingDispatchBeanList(List<AccountingDispatchBean> accountingDispatchBeanList) {
		this.accountingDispatchBeanList = accountingDispatchBeanList;
	}
	
}
