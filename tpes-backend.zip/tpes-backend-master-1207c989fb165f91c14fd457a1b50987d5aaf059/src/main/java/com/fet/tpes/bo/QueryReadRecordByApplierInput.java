package com.fet.tpes.bo;

import java.util.Date;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryReadRecordByApplierInput extends BaseInputBo{
	private List<String> fileReaderList;
	private String acceptNum;
	private String electricNum;
	private String archiveNum;
	private Date readStartDate;
	private Date readEndDate;
	
	public List<String> getFileReaderList() {
		return fileReaderList;
	}

	public void setFileReaderList(List<String> fileReaderList) {
		this.fileReaderList = fileReaderList;
	}


	public String getAcceptNum() {
		return acceptNum;
	}

	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}

	public String getElectricNum() {
		return electricNum;
	}

	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}

	public String getArchiveNum() {
		return archiveNum;
	}

	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}

	public Date getReadStartDate() {
		return readStartDate;
	}

	public void setReadStartDate(Date readStartDate) {
		this.readStartDate = readStartDate;
	}

	public Date getReadEndDate() {
		return readEndDate;
	}

	public void setReadEndDate(Date readEndDate) {
		this.readEndDate = readEndDate;
	}
	
	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(fileReaderList)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數fileReaderList為空值");
		} else if(StringUtil.isEmpty(this.getRegion())) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數region為空值");
		}
		return result;
	}

}
