package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class RecordBrowseFormOutput extends BaseOutputBo{

}
