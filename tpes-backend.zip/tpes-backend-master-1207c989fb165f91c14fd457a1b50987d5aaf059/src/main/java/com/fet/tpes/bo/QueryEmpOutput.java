package com.fet.tpes.bo;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryEmpOutput extends BaseOutputBo {

	private EmpInfoBean empInfo;

	public EmpInfoBean getEmpInfo() {
		return empInfo;
	}
	public void setEmpInfo(EmpInfoBean empInfo) {
		this.empInfo = empInfo;
	}
}
