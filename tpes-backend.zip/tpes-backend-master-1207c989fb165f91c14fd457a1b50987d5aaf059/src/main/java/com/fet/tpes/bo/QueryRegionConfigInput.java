package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryRegionConfigInput extends BaseInputBo{

	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.getRegion())) {
			result = false;
			LogUtil.warn(this.getClass(), "region 驗證為空");
		}
		return result;
	}
}
