package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AgentApplicationBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class GetLeaveInfoOutput extends BaseOutputBo {

	private List<AgentApplicationBean> leaveList;
	private String responseString;

	public List<AgentApplicationBean> getLeaveList() {
		return leaveList;
	}
	public void setLeaveList(List<AgentApplicationBean> leaveList) {
		this.leaveList = leaveList;
	}
	public String getResponseString() {
		return responseString;
	}
	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}
}
