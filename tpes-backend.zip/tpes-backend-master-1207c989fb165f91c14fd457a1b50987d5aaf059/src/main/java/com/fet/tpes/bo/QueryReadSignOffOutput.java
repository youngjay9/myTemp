package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.ReadApplyBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryReadSignOffOutput extends BaseOutputBo {

	private List<ReadApplyBean> applyList;

	public List<ReadApplyBean> getApplyList() {
		return applyList;
	}
	public void setApplyList(List<ReadApplyBean> applyList) {
		this.applyList = applyList;
	}
}
