package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class DeleteAutoSetRoleByEmpNoInput extends BaseInputBo {
	private List<String> empNoList;
	private String settingStyle;
	private String recordType;
	private String createAuthor;
	private String updateAuthor;
	

	public List<String> getEmpNoList() {
		return empNoList;
	}

	public void setEmpNoList(List<String> empNoList) {
		this.empNoList = empNoList;
	}

	public String getSettingStyle() {
		return settingStyle;
	}

	public void setSettingStyle(String settingStyle) {
		this.settingStyle = settingStyle;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}


	



	public String getCreateAuthor() {
		return createAuthor;
	}

	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}

	public String getUpdateAuthor() {
		return updateAuthor;
	}

	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if (CollectionUtils.isEmpty(this.empNoList)) {
			result = false;
			LogUtil.error(this.getClass(), "DeleteAutoSetRoleByEmpNoInput input缺少參數empNoList");
		}
		return result;
	}
}
