package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.CfgSignOffLevel;

public class QuerySignOffLevelConfigOutput extends BaseOutputBo {

	private List<CfgSignOffLevel> configList;

	public List<CfgSignOffLevel> getConfigList() {
		return configList;
	}
	public void setConfigList(List<CfgSignOffLevel> configList) {
		this.configList = configList;
	}
}
