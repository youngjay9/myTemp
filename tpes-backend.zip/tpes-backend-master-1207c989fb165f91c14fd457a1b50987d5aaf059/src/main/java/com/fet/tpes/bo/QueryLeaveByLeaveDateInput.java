package com.fet.tpes.bo;

import java.util.Date;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryLeaveByLeaveDateInput extends BaseInputBo{
	
	private Date leaveStartDate;
	private Date leaveEndDate;
	
	public Date getLeaveStartDate() {
		return leaveStartDate;
	}

	public void setLeaveStartDate(Date leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}

	public Date getLeaveEndDate() {
		return leaveEndDate;
	}

	public void setLeaveEndDate(Date leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(leaveStartDate == null) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數leaveStartDate為空值");			
		} else if (leaveEndDate == null) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數leaveEndDate為空值");
		}		
		
		return result;
	}

}
