package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryDeptFormListByConditionsInput extends BaseInputBo{
	
	private List<String> statusList;
	private List<String> accountingStatusList;

	public List<String> getStatusList() {
		return statusList;
	}

	public void setStatusList(List<String> statusList) {
		this.statusList = statusList;
	}
	public List<String> getAccountingStatusList() {
		return accountingStatusList;
	}

	public void setAccountingStatusList(List<String> accountingStatusList) {
		this.accountingStatusList = accountingStatusList;
	}
	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.getRegion())) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數region為空值");
					
		} else if(CollectionUtils.isEmpty(statusList)){
			result = false;
			LogUtil.error(this.getClass(), "傳入參數statusList為空值");
		} else if(CollectionUtils.isEmpty(accountingStatusList)){
			result = false;
			LogUtil.error(this.getClass(), "傳入參數accountingStatusList為空值");
		}
		return result;
	}

	

}
