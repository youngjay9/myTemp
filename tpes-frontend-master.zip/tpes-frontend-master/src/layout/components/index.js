export { default as Sidemenu } from './Sidemenu/index.vue'
export { default as CoreContent } from './Content'
export { default as CoreTopnav } from './TopNav'
export { default as CoreFooter } from './Footer'