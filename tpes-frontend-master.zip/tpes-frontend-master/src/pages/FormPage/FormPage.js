// import EventBus from "@/assets/services/eventBus";
import moment from 'moment';
import MessageService from "@/assets/services/message.service";
import CommonService from "@/assets/services/common.service";
import ValidateUtil from '@/assets/services/validateUtil';
import AjaxService from '@/assets/services/ajax.service.js';
import PMCService from '@/assets/services/pmc.service.js';
import EventBus from '@/assets/services/eventBus';
import { checkQuestionnaireAnswered} from '@/api/questionnaire'
  

export default {
    name: 'Form',
    props: {
        restrictMode: String,
        formParam: Object,
        queryMemo: String,
        isRead: Boolean,
    },
    mounted() {
        this.init();
    },
    created(){
      //檢測問卷視窗是否被關 參考QuestionnaireView.vue內的 created中呼叫opener
      window.handleSurveyAnswerClosed = this.closeSurveyPortal;

      // 檢測表單簽名頁是否被關
      window.handleFormSignPageClosed = this.formSignPageClosed;
      // 控制 focus
      window.focusFormSignPage = this.focusFormSignPage;
    },
    beforeDestroy(){
        if(this.formSignPage){
            this.formSignPage.close();
            this.formSignPage = null;
        }

        if(this.windowRef) {
          this.windowRef.close();
        }

        if(this.usePmc && !this.isExtendScreen){
            try {
                // 將畫面顯示改為延伸
                PMCService.callDualScreenAdapterExtend();
            } catch (error) {
                MessageService.showError("PMC 未開啟或異常", "PMC ");
                
            }
        }
    },
    computed: {
        isCanEditFile() {
            return (this.formPageMode == 'edit' || (this.formPageMode == 'cancel' && this.isAgent == 'Y'));
        },
        isAttachmentNotSealed(){
            return (!ValidateUtil.isEmpty(this.onlySealFileCode) && !this.isHasSealedAttachment);
        }
    },
    data() {
        return {
            empNo: null,
            region: null,
            modeList: [
                {name: "新增/修改", value: "edit"},
                {name: "核算", value: "accounting"},
                {name: "檢視", value: "view"},
                {name: "檢視 (可下載)", value: "viewDownload"},
                {name: "取消", value: "cancel"},
                {name: "取消檢視", value: "cancel_view"},
            ],
            formPageMode: "edit",
            panel: [0, 1, 2, 3],
            imgSrcPrefix: "data:image/jpeg;base64,",
            formSeq: null,          // 表單流水號
            formImgFileNo: null,       // 表單檔案編號
            editedFormFileNo: null, // 已編輯的表單檔案編號
            acceptNum: null,        // 受理編號
            fmbhNo: null,           // 受理分號
            formType: null,         // 登記單代碼
            apitCod: null,          // 申請項目編號
            applyType: null,        // 案件進件類型
            uniformNum: null,       // 統編
            isAgent: null,          // 申請人
            custName: null,         // 戶名
            contractType: null,     // 契約別
            electricNum: null,      // 電號
            computeDate: null,      // 計算日
            acceptDept: null,       // 受理部門
            acceptDeptName: null,   // 受理部門名稱
            acceptUser: null,       // 受理人員
            acceptUserName: null,   // 受理人員姓名
            acceptDate: null,       // 受理日期
            acceptItem: null,       // 受理項目
            isUpdate: null,         // 修正件
            isAddAttachment: null,  // 補附件操作
            isAffidavit: null,      // 切結註記
            uploadNo: null,     // 證件編號
            formSignPage: null,
            isFormSignPageOpened: false,
            formAnswered: false, // 問卷是否填寫過
            customerSign: {},
            cancelSign: {},
            certificateList: [],
            oriCertificateList: [],
            certificateNo: 1,
            attachmentList: [],
            oriAttachmentList: [],
            attachmentNo: 1,
            uploadingAttachment: null,
            viewImageDialog: false,
            viewImageTitle: "",
            viewImageSrc: "",
            showModeSelect: true,
            accountingMemo: "",
            setCertificateType: -1,
            selectedCertificate: {},
            selectedAttachment: {},
            certificateOptions: [
                {
                    fileName: '本人身分證正面',
                    fileCode: 'ID_CARD_FRONT'
                },
                {
                    fileName: '本人身分證背面',
                    fileCode: 'ID_CARD_BACK'
                },
                {
                    fileName: '現役軍人眷屬身分證正面',
                    fileCode: 'MILITARY_FAMILY_ID_CARD_FRONT'
                },
                {
                    fileName: '現役軍人眷屬身分證背面',
                    fileCode: 'MILITARY_FAMILY_ID_CARD_BACK'
                },
                {
                    fileName: '戶口名簿',
                    fileCode: 'HOUSEHOLD_REGISTRY'
                },
                {
                    fileName: '電氣技術人員執照', 
                    fileCode: 'ELECTRIC_TECH_LIC',
                    color: '#D6E5F5'
                },
                {
                    fileName: '門牌整編證明',
                    fileCode: 'HOUSE_NUM_CERTIFICATE',
                    color: '#D6E5F5'
                },
                {
                    fileName: '扣繳代繳帳號資料或中獎證明',
                    fileCode: 'PAYMENT_OR_WINNING',
                    color: '#D6E5F5'
                },
                {
                    fileName: '抄表事故聯絡單',
                    fileCode: 'ACCIDENT_CONTACT',
                    color: '#D6E5F5'
                },
                {
                    fileName: '切結書', 
                    fileCode: 'AFFIDAVIT_LETTER',
                    color: '#D6E5F5'
                },
                {
                    fileName: '紙本申請單', 
                    fileCode: 'PAPER_APPLY',
                    color: '#D6E5F5'
                },
                {
                    fileName: '農業動力用電主管機關證明文件', 
                    fileCode: 'AGRI_COMP_AUTH_DOC',
                    color: '#D6E5F5'
                },
            ],
            setAttachmentType: -1,
            attachmentOptions: [
                {
                    fileName: '本人身分證正面',
                    fileCode: 'ID_CARD_FRONT'
                },
                {
                    fileName: '本人身分證背面',
                    fileCode: 'ID_CARD_BACK'
                },
                {
                    fileName: '現役軍人眷屬身分證正面',
                    fileCode: 'MILITARY_FAMILY_ID_CARD_FRONT'
                },
                {
                    fileName: '現役軍人眷屬身分證背面',
                    fileCode: 'MILITARY_FAMILY_ID_CARD_BACK'
                },
                {
                    fileName: '戶口名簿',
                    fileCode: 'HOUSEHOLD_REGISTRY'
                },
                {
                    fileName: '電氣技術人員執照', 
                    fileCode: 'ELECTRIC_TECH_LIC',
                    color: '#D6E5F5'
                },
                {
                    fileName: '門牌整編證明',
                    fileCode: 'HOUSE_NUM_CERTIFICATE',
                    color: '#D6E5F5'
                },
                {
                    fileName: '扣繳代繳帳號資料或中獎證明',
                    fileCode: 'PAYMENT_OR_WINNING',
                    color: '#D6E5F5'
                },
                {
                    fileName: '抄表事故聯絡單',
                    fileCode: 'ACCIDENT_CONTACT',
                    color: '#D6E5F5'
                },
                {
                    fileName: '切結書', 
                    fileCode: 'AFFIDAVIT_LETTER',
                    color: '#D6E5F5'
                },
                {
                    fileName: '用電資料表', 
                    fileCode: 'ELECTRIC_INFO',
                    color: '#D6E5F5'
                },
                {
                    fileName: '證明函', 
                    fileCode: 'CERTIFICATE_LETTER',
                    hintText: "屬受理部門掣開證明時，請受理人員上傳證明函；屬核算課掣開證明時，受理人員無需上傳證明函，由核算課人員上傳證明函",
                    color: '#D6E5F5'
                },
                {
                    fileName: '紙本申請單', 
                    fileCode: 'PAPER_APPLY',
                    color: '#D6E5F5'
                },
                {
                    fileName: '農業動力用電主管機關證明文件', 
                    fileCode: 'AGRI_COMP_AUTH_DOC',
                    color: '#D6E5F5'
                },
            ],
            setCertificateModal: false,
            setAttachmentModal: false,
            otherCertificate: '',
            otherAttachment: '',
            isBlocking: false,
            blockingMsg: null,
            cancelReason: null,
            scanDataList: [],
            needScanFileList: [],
            needScanFileHint: null,
            needScanAttachHint: null,
            oriNeedScanFileList: [],
            isNeedScanCertificate: false,
            isNeedScanAttachment: false,
            isNeedSign: false,
            maxSignVersion: 0,
            isLoading: false,
            encryptedParam: null,
            empName: null,
            windowRef: null,//開啟問卷存放回傳物件
            usePmc: false,
            onlySealFileCode: null,
            acctUploadFileCode: null,
            isCreateForm: false,
            isCancelForm: false,
            isHasSealedAttachment: false,
            attachmentCategory: "ATTACHMENT",
            certificateCategory: "CERTIFICATE",
            isExtendScreen: false,
            viewHintDialog: false,
            dialogHintText: "",
            deleteSealDialog: false,
            sealFileNo: null,
            sealedFileNo: null,
            isSavedForm: false,
        }
    },
    methods: {
        async init(){
            if(this.restrictMode){
                this.formPageMode = this.restrictMode;
                this.showModeSelect = false;
            }
            if(this.queryMemo){
                this.accountingMemo = this.queryMemo;
            }
           
            await this.getInitParam();
            this.formInit(false);

            EventBus.subscriber("scan-data-list", this.getScanDataList);
            EventBus.subscriber("scan-error", this.showScanErrorMsg);

            // 若表單頁面關閉，將問卷頁也關閉
            window.addEventListener("beforeunload",()=>{
              if(this.windowRef) {
                this.windowRef.close();
              }
            });
        },
        async getInitParam(){
            // 從網址取得參數
            let formParam = CommonService.getURLParamObject();
            let page = CommonService.getURLPage();

            // 若無資料改從頁面參數取
            if(ValidateUtil.isEmpty(formParam)){
                formParam = this.formParam;
            }

            if(!ValidateUtil.isEmpty(formParam)){
                this.empNo = formParam.EMP_NO;
                this.region = formParam.REGION;
                this.acceptNum = formParam.FM_NO;
                this.fmbhNo = formParam.FMBH_NO;
                this.formType = formParam.FORM_TYPE;
                this.apitCod = formParam.APIT_COD;
                this.applyType = formParam.APPLY_TYPE;
                this.uniformNum = formParam.UNIFORM_NUM;
                this.isAgent = formParam.IS_AGENT;
                this.custName = formParam.CUST_NAME;
                this.contractType = formParam.CONTRACT_TYPE;
                this.electricNum = formParam.ELECTRIC_NUM;
                this.computeDate = formParam.COMPUTE_DATE;
                this.acceptDept = formParam.ACCEPT_DEPT;
                this.acceptDeptName = formParam.ACCEPT_DEPT_NAME;
                this.acceptUser = formParam.ACCEPT_USER;
                this.acceptUserName = formParam.ACCEPT_USER_NAME;
                this.acceptDate = formParam.ACCEPT_DATE;
                this.acceptItem = formParam.ACCEPT_ITEM;
                this.isUpdate = formParam.IS_UPDATE;
                this.isAddAttachment = formParam.IS_ADD_ATTACHMENT;
                this.isAffidavit = formParam.IS_AFFIDAVIT;
                this.uploadNo = formParam.UPLOAD_NO;
                this.cancelReason = formParam.CANCEL_REASON;
                this.encryptedParam = formParam.encryptedParam;
                
                this.formPageMode = ValidateUtil.isEmpty(formParam.formPageMode) ? this.formPageMode : formParam.formPageMode;
            }

            // 依頁面改變顯示模式
            if(page == "createForm"){
                this.formPageMode = "edit";
                this.showModeSelect = false;
                this.usePmc = true;
                this.isCreateForm = true;
                this.$emit("showOnlyContent");
            }
            else if(page == "cancelForm_cust"){
                this.formPageMode = "cancel";
                this.showModeSelect = false;
                this.usePmc = true;
                this.isCancelForm = true;
                this.$emit("showOnlyContent");

                // 取消表單若要關閉頁面需先確認
                window.addEventListener('beforeunload', this.confirmClosePage);
            }
            else if(page == "viewForm"){
                this.formPageMode = "view";
                this.showModeSelect = false;
                this.$emit("showOnlyContent");
            }
        },
        async formInit(canSkipValidateTime){
            // 等待 1.5 秒確定 PMC 連線後將畫面顯示改為延伸
            setTimeout(() => {
                if(this.usePmc && !this.isExtendScreen){
                    try {
                        PMCService.callDualScreenAdapterExtend()
                        this.isExtendScreen = true;
                    } catch (error) {
                        MessageService.showError("PMC 未開啟或異常", "PMC ");
                        
                    }
                }
            }, 1500);

            // 驗證是否有受理編號，若無直接擋件
            if(ValidateUtil.isEmpty(this.acceptNum) && ValidateUtil.isEmpty(this.encryptedParam)){
                this.isBlocking = true;
                this.blockingMsg = "查無受理編號";
                return;
            }
            
            let param = {
                acceptNum: this.acceptNum,
                fmbhNo: this.fmbhNo,
                formType: this.formType,
                apitCod: this.apitCod,
                applyType: this.applyType,
                uniformNum: this.uniformNum,
                isAgent: this.isAgent,
                custName: this.custName,
                contractType: this.contractType,
                electricNum: this.electricNum,
                computeDate: this.computeDate,
                acceptDept: this.acceptDept,
                acceptDeptName: this.acceptDeptName,
                acceptUser: this.acceptUser,
                acceptUserName: this.acceptUserName,
                acceptDate: this.acceptDate,
                acceptItem: this.acceptItem,
                isUpdate: this.isUpdate,
                isAddAttachment: this.isAddAttachment,
                isAffidavit: this.isAffidavit,
                uploadNo: this.uploadNo,
                formPageMode: this.formPageMode,
                empNo: this.empNo,
                region: this.region,
                encryptedParam: this.encryptedParam,
                canSkipValidateTime: canSkipValidateTime,
                createForm: this.isCreateForm,
                cancelForm: this.isCancelForm,
            }

            await AjaxService.post("/tpesForm/init", param, 
            async (response) => {
                // 驗證是否成功
                if (!response.restData.success) {
                    this.isBlocking = true;
                    this.blockingMsg = response.restData.message;
                    MessageService.showError(response.restData.message,'表單初始化');
                    return;
                }

                this.formSeq = response.restData.formSeq;
                this.formImgFileNo = response.restData.formImgFileNo;
                this.editedFormFileNo = response.restData.editedFormFileNo;
                this.accountingMemo = response.restData.accountingMemo;
                this.needScanFileList = response.restData.needScanFileList;
                this.oriNeedScanFileList = response.restData.needScanFileList;
                this.isNeedScanCertificate = response.restData.needScanCertificate;
                this.isNeedScanAttachment = response.restData.needScanAttachment;
                this.isNeedSign = response.restData.needSign;
                this.maxSignVersion = response.restData.maxSignVersion;
                this.empName = response.restData.empName;
                this.isHasSealedAttachment = response.restData.hasSealedAttachment;
                this.isAgent = response.restData.isAgent;
                this.applyType = response.restData.applyType;

                // 初始化一次後就將修正件 flag 壓為 N 避免每次都是修正件
                this.isUpdate = "N";

                // 若為加密參數進件，放入解密後才有的參數
                this.setDescryptedParam(response.restData);

                // 簽名
                if(!ValidateUtil.isEmpty(response.restData.customerSign)){
                    this.customerSign = response.restData.customerSign;
                }

                // 取消簽名
                if(!ValidateUtil.isEmpty(response.restData.cancelSign)){
                    this.cancelSign = response.restData.cancelSign;
                }

                // 整理證件及附件
                await this.setCertificateList(response.restData.certificateList);
                await this.setAttachmentList(response.restData.attachmentList);

                // 檢查證件及附件是否已依規範掃描及上傳，同時檢查有無特殊附件
                this.checkNeedScanFile(false);
            },
            (error) => {
                MessageService.showSystemError();
                
            });
        },
        setDescryptedParam(data){
            if(!ValidateUtil.isEmpty(data.empNo)){
                this.empNo = data.empNo;
            }
            if(!ValidateUtil.isEmpty(data.region)){
                this.region = data.region;
            }
            if(!ValidateUtil.isEmpty(data.acceptNum)){
                this.acceptNum = data.acceptNum;
            }
            if(!ValidateUtil.isEmpty(data.cancelReason)){
                this.cancelReason = data.cancelReason;
            }
            if(!ValidateUtil.isEmpty(data.isAddAttachment)){
                this.isAddAttachment = data.isAddAttachment;
            }
        },
        async setCertificateList(certificateList){
            this.oriCertificateList = [];

            // 若證件已有資料，為避免刷新時造成已上傳的檔案消失，移除尚未改動過且已上傳的檔案
            // 同時記錄已上傳且有改動的檔案，避免重複新增
            let hasEditFileNoList = [];
            if(!ValidateUtil.isEmpty(this.certificateList)){
                for(let index = 0 ; index < this.certificateList.length ; index ++){
                    let certificate = this.certificateList[index];
                    if(certificate.fileNo != null && certificate.hasEdit){
                        hasEditFileNoList.push(certificate.fileNo);
                    }
                    else if(certificate.fileNo != null && !certificate.hasEdit){
                        this.certificateList.splice(index, 1);
                        index--;
                    }
                }
            }

            if(!ValidateUtil.isEmpty(certificateList)){
                for (let certificate of certificateList) {
                    // 已有改動過的檔案不重複新增
                    if(!hasEditFileNoList.includes(certificate.fileNo)){
                        // 加入已上傳的證件
                        this.certificateList.push({
                            id: this.certificateNo,
                            fileName: certificate.fileName,
                            originalFileName: certificate.originalFileName,
                            fileCode: certificate.fileCode,
                            category: certificate.category,
                            fileNo: certificate.fileNo,
                            filePath: certificate.filePath,
                            imgSrc: certificate.imgSrc,
                            isAdditional: false,
                            hasEdit: false,
                        });
                    }

                    // 用來對照哪些證件要刪除
                    this.oriCertificateList.push({
                        id: this.certificateNo,
                        fileName: certificate.fileName,
                        originalFileName: certificate.originalFileName,
                        fileCode: certificate.fileCode,
                        fileExt: certificate.fileExt,
                        category: certificate.category,
                        fileNo: certificate.fileNo,
                        filePath: certificate.filePath,
                        imgSrc: certificate.imgSrc,
                        isAdditional: false,
                        hasEdit: false,
                    });
                    this.certificateNo++;
                }
            }
        },
        async setAttachmentList(attachmentList){
            this.oriAttachmentList = [];

            // 若附件已有資料，為避免刷新時造成已上傳的檔案消失，移除尚未改動過或已上傳的檔案
            // 同時記錄已上傳且有改動的檔案，避免重複新增
            let hasEditFileNoList = [];
            if(!ValidateUtil.isEmpty(this.attachmentList)){
                for(let index = 0 ; index < this.attachmentList.length ; index ++){
                    let attachment = this.attachmentList[index];
                    // 若為核算時可補件附件，會上傳就刷新
                    if((attachment.fileNo != null && !attachment.hasEdit) || this.acctUploadFileCode == attachment.fileCode){
                        this.attachmentList.splice(index, 1);
                        index--;
                    }
                    else if(attachment.fileNo != null && attachment.hasEdit){
                        hasEditFileNoList.push(attachment.fileNo);
                    }
                }
            }

            if(!ValidateUtil.isEmpty(attachmentList)){
                for (let attachment of attachmentList) {
                    // 已有改動過的檔案不重複新增
                    if(!hasEditFileNoList.includes(attachment.fileNo)){
                        // 加入已上傳的附件
                        this.attachmentList.push({
                            id: this.attachmentNo,
                            fileName: attachment.fileName,
                            fileCode: attachment.fileCode,
                            fileExt: attachment.fileExt,
                            category: attachment.category,
                            originalFileName: attachment.originalFileName,
                            fileNo: attachment.fileNo,
                            filePath: attachment.filePath,
                            imgSrc: attachment.imgSrc,
                            base64: attachment.base64,
                            hasEdit: false,
                            needSeal: attachment.needSeal,
                            canOnlyView: attachment.canOnlyView,
                            isSelecting: false,
                            canAcctUpload: false,
                            isAdditional: false,
                        });
                    }

                    // 用來對照哪些附件要刪除
                    this.oriAttachmentList.push({
                        id: this.attachmentNo,
                        fileName: attachment.fileName,
                        fileCode: attachment.fileCode,
                        category: attachment.category,
                        originalFileName: attachment.originalFileName,
                        fileNo: attachment.fileNo,
                        filePath: attachment.filePath,
                        imgSrc: attachment.imgSrc,
                        base64: attachment.base64,
                        hasEdit: false,
                        needSeal: attachment.needSeal,
                        canOnlyView: attachment.canOnlyView,
                        isSelecting: false,
                        canAcctUpload: false,
                        isAdditional: false,
                    });
                    this.attachmentNo++;
                }
            }
        },
        openFormSignPage(){
            let config = "width=" + screen.availWidth + ",height=" + screen.availHeight + 'top=0,left=0,statusbar=no,scrollbars=yes,status=no,location=no';

            let routeData = this.$router.resolve({
                name: 'ImageEditor', // Router Name
            });
            
            this.formSignPage = window.open(routeData.href, "_blank", config);

            // 若為取消需將模式傳給簽名頁做取消簽名
            if(this.formPageMode == "cancel"){
                this.formSignPage.mode = "cancel";
                this.formSignPage.signFileNo = this.cancelSign.fileNo;
            }
            // 若為檢視表單則不需簽名
            else if(this.formPageMode == "accounting" || this.formPageMode == "view" || this.formPageMode == "viewDownload" || this.formPageMode == "cancel_view"){
                this.formSignPage.mode = "view";
            }
            else{
                this.formSignPage.signFileNo = this.customerSign.fileNo;
            }

            this.formSignPage.formImgFileNo = this.formImgFileNo;
            this.formSignPage.editedFormFileNo = this.editedFormFileNo;
            this.formSignPage.acceptNum = this.acceptNum;
            this.formSignPage.formSeq = this.formSeq;
            this.formSignPage.maxSignVersion = this.maxSignVersion;
            this.formSignPage.empNo = this.empNo;
            this.formSignPage.region = this.region;
            this.formSignPage.isRead = this.isRead;
            this.formSignPage.applyType = this.applyType;

            // 依照有無使用 PMC 更改 title 避免不必要的 focus
            if(this.usePmc){
                this.formSignPage.pageTitle = 'TPES-預覽表單及簽名';
            }
            else{
                this.formSignPage.pageTitle = 'TPES-檢視表單及簽名';
            }

            // this.formSignPage.onbeforeunload = this.formSignPageClosed;
            // this.formSignPage.addEventListener("beforeunload", this.formSignPageClosed);
            
            this.isFormSignPageOpened = true;
        },
        focusFormSignPage(){
            if(this.usePmc){
                try {
                    this.formSignPage.focus();
                    // 等待 0.5 秒後將畫面顯示改為同步
                    setTimeout(() => PMCService.callDualScreenAdapterClone(), 500);
                    this.isExtendScreen = false;
                } catch (error) {
                    MessageService.showError("PMC 未開啟或異常", "PMC ");
                    
                }
            }
        },
        formSignPageClosed(){
            if(this.usePmc && !this.isExtendScreen){
                try {
                    // 將畫面顯示改為延伸
                    PMCService.callDualScreenAdapterExtend();
                    this.isExtendScreen = true;
                } catch (error) {
                    MessageService.showError("PMC 未開啟或異常", "PMC ");
                    
                }
            }

            this.isFormSignPageOpened = false;
            this.formSignPage = null;
            this.formInit(true);
        },
        closeFormSignPage(){
            // if(this.usePmc && !this.isExtendScreen){
            //     try {
            //         // 將畫面顯示改為延伸
            //         PMCService.callDualScreenAdapterExtend();
            //         this.isExtendScreen = true;
            //     } catch (error) {
            //         MessageService.showError("PMC 未開啟或異常", "PMC ");
            //         
            //     }
            // }

            this.isFormSignPageOpened = false;
            if(!this.formSignPage) {
                return;
            }
            this.formSignPage.close();
        },
        deleteCertificate(index){
            this.certificateList.splice(index, 1);
        },
        deleteAttachment(deleteAttachment, index){
            // 若刪除需套印專用章的檔案，檢查是否有已套印檔案，若有需提示一併刪除
            if(deleteAttachment.fileCode == this.onlySealFileCode){
                for (let attachment of this.attachmentList) {
                    if(attachment.category == "ATTACHMENT_SEAL"){
                        this.sealFileNo = this.attachmentList[index].fileNo;
                        this.sealedFileNo = attachment.fileNo;

                        // 開啟確認刪除 modal
                        this.deleteSealDialog = true;

                        return;
                    }
                }
            }

            this.attachmentList.splice(index, 1);
        },
        openSetCertificateModal(certificate){
            this.setCertificateModal = true;
            this.otherCertificate = '';
            this.setCertificateType = -1;
            this.selectedCertificate = certificate;
        },
        selectCertificate(index){
            this.setCertificateType = index;
        },
        setCertificate(){
            let fileName = this.setCertificateType == this.certificateOptions.length ? this.otherCertificate : this.certificateOptions[this.setCertificateType].fileName;
            let fileCode = this.setCertificateType == this.certificateOptions.length ? "OTHER" : this.certificateOptions[this.setCertificateType].fileCode;

            let canSet = true;
            if(!ValidateUtil.isEmpty(this.certificateList)){
                for(let certificate of this.certificateList){
                    if(fileName && fileName == certificate.fileName){
                        canSet = false;
                        MessageService.showInfo("不可設定已有相同名稱的證件/附件");
                        break;
                    }
                }
            }

            if(canSet && !ValidateUtil.isEmpty(this.attachmentList)){
                for(let attachment of this.attachmentList){
                    if(fileName && fileName == attachment.fileName){
                        canSet = false;
                        MessageService.showInfo("不可設定已有相同名稱的證件/附件");
                        break;
                    }
                }
            }

            if(canSet){
                this.selectedCertificate.fileName = fileName;
                this.selectedCertificate.fileCode = fileCode;
                this.selectedCertificate.hasEdit = true;
            }

            this.setCertificateModal = false;
        },
        addCertificate(base64){
            let fileExt = null;

            if(base64.charAt(0) == "/"){
                fileExt = "jpg";
            }
            else if(base64.charAt(0) == "i"){
                fileExt = "png";
            }

            if(ValidateUtil.isEmpty(fileExt)) return;

            let imgSrc = "data:image/" + fileExt + ";base64," + base64;

            // 套浮水印
            this.addWaterMark(imgSrc).then(({data}) => {

                this.certificateList.push({
                    id: this.certificateNo,
                    // 其他證件，須由使用者輸入證件類別
                    fileName: null,
                    originalFileName: "certificate_" + this.certificateNo + " (" + moment(new Date).format('YYYY-MM-DD') + ")." + fileExt,
                    fileCode: null,
                    category: this.certificateCategory,
                    fileNo: null,
                    filePath: null,
                    imgSrc: data,
                    isAdditional: true,
                    hasEdit: false,
                });

                this.certificateNo++;
                this.setCertificateModal = false;
            });
        },
        scanCertificate(){
            try {
                this.isLoading = true;
                PMCService.callWebScanAdapter();
            } catch (error) {
                this.isLoading = false;
                MessageService.showError("PMC 未開啟或異常", "PMC ");
                
            }
        },
        addAttachment(){
            this.attachmentList.push({
                id: this.attachmentNo,
                fileName: null,
                fileCode: null,
                category: this.attachmentCategory,
                fileNo: null,
                imgSrc: null,
                file: null,
                needSeal: false,
                isSelecting: false,
                canAcctUpload: false,
                isAdditional: true,
                hintText: null
            });
            this.attachmentNo++;
        },
        openSetAttachmentModal(attachment){
            this.setAttachmentModal = true;
            this.otherAttachment = '';
            this.setAttachmentType = -1;
            this.selectedAttachment = attachment;
        },
        selectAttachment(index){
            this.setAttachmentType = index;
        },
        setAttachment(){
            let fileName = this.setAttachmentType == this.attachmentOptions.length ? this.otherAttachment : this.attachmentOptions[this.setAttachmentType].fileName;
            let fileCode = this.setAttachmentType == this.attachmentOptions.length ? "OTHER_ATTACHMENT" : this.attachmentOptions[this.setAttachmentType].fileCode;
            let hintText = this.setAttachmentType == this.attachmentOptions.length ? null : this.attachmentOptions[this.setAttachmentType].hintText;

            let canSet = true;
            if(!ValidateUtil.isEmpty(this.certificateList)){
                for(let certificate of this.certificateList){
                    if(fileName && fileName == certificate.fileName){
                        canSet = false;
                        MessageService.showInfo("不可設定已有相同名稱的證件/附件");
                        break;
                    }
                }
            }

            if(canSet && !ValidateUtil.isEmpty(this.attachmentList)){
                for(let attachment of this.attachmentList){
                    if(fileName && fileName == attachment.fileName){
                        canSet = false;
                        MessageService.showInfo("不可設定已有相同名稱的證件/附件");
                        break;
                    }
                }
            }

            if(fileCode && fileCode == this.onlySealFileCode 
               && this.selectedAttachment.originalFileName && !this.checkIsWord(this.selectedAttachment)){
                canSet = false;
                MessageService.showInfo("欲套用專用章檔案只可上傳 Word 檔");
            }

            if(canSet){
                this.selectedAttachment.fileName = fileName;
                this.selectedAttachment.fileCode = fileCode;
                this.selectedAttachment.hintText = hintText;
                this.selectedAttachment.hasEdit = true;
                this.selectedAttachment.needSeal = (this.onlySealFileCode && this.onlySealFileCode == fileCode);
            }

            this.setAttachmentModal = false;
        },
        uploadFile(attachment, index) {
            this.uploadingAttachment = attachment;
            this.uploadingAttachment.isSelecting = true;
            this.uploadingAttachment.hasEdit = true;
            window.addEventListener('focus', () => {
                this.uploadingAttachment.isSelecting = false
            }, { once: true });
      
            this.$refs.uploaders[index].click();
        },
        onFileChanged(e) {
            this.uploadingAttachment.file = e.target.files[0];
            // 取出檔案名稱
            this.uploadingAttachment.originalFileName = this.uploadingAttachment.file.name;
            this.$forceUpdate(); // 強制頁面刷新

            let reader = new FileReader();
            reader.onload = async (e) =>{
                // 若為強制須掃專用章的附件，需檢查是否為 word，不是的話要擋
                if(this.onlySealFileCode && this.uploadingAttachment.fileCode == this.onlySealFileCode && !this.checkIsWord(this.uploadingAttachment)){
                    // 清空附件
                    for(let attachment of this.attachmentList){
                        if(attachment.id == this.uploadingAttachment.id){
                            this.clearAttachment(attachment);
                            break;
                        }
                    }
                    
                    MessageService.showInfo("欲套用專用章檔案只可上傳 Word 檔");
                }
                else{
                    this.uploadingAttachment.base64 = e.target.result;
                    this.uploadingAttachment.imgSrc = null;
    
                    // 圖片
                    if(this.uploadingAttachment.file.type.indexOf("image") > -1){
                        // 不套浮水印
                        this.uploadingAttachment.imgSrc = e.target.result;
                    }

                    // 若為核算時補件則直接上傳
                    if(this.formPageMode == "accounting" && this.uploadingAttachment.canAcctUpload){
                        let vin = {
                            acceptNum: this.acceptNum,
                            formSeq: this.formSeq,
                            fileNo: this.uploadingAttachment.fileNo,
                            fileCode: this.uploadingAttachment.fileCode,
                            fileName: this.uploadingAttachment.fileName,
                            originalFileName: this.uploadingAttachment.originalFileName,
                            fileExt: this.getFileExt(this.uploadingAttachment.originalFileName),
                            category: this.attachmentCategory,
                            file: this.uploadingAttachment.base64,
                            needSeal: this.uploadingAttachment.needSeal,
                            empNo: this.empNo,
                            region: this.region,
                        };
            
                        AjaxService.post("/tpesForm/uploadFile", vin, 
                        async (response) => {
                            // 驗證是否成功
                            if (!response.restData.success) {              
                                MessageService.showError(response.restData.message,'上傳檔案');
                                return;
                            }
                            
                            // 重新查詢
                            await this.formInit(true);

                            // 提示還需簽核
                            this.dialogHintText = "附件已上傳完成，還需通知主管簽核專用章後才可核算通過";
                            this.viewHintDialog = true;
                        },
                        (error) => {
                            MessageService.showSystemError();
                            
                        });
                    }
                }
            };
            reader.readAsDataURL(this.uploadingAttachment.file);
        },
        downloadFile(attachment){
            AjaxService.postFile('/tpesForm/downloadFile',
                {
                    fileNo: attachment.fileNo,
                    isRead: this.isRead,
                },
                (response) => {
                    // 驗證是否成功
                    if (!response.success) {              
                        MessageService.showError(response.message,'下載檔案');
                        return;
                    }
                },
                (error) => {
                    MessageService.showSystemError();
                    
                }
            );
        },
        viewPDFFile(attachment){
            AjaxService.postFile('/tpesForm/getFile',
                {
                    fileNo: attachment.fileNo,
                    isRead: this.isRead,
                },
                (response) => {
                    // 驗證是否成功
                    if (!response.restData.success) {              
                        MessageService.showError(response.restData.message,'取得檔案');
                        return;
                    }
                    
                    if(response.restData.base64){
                        let pdfWindow = window.open("")
                        pdfWindow.document.write(
                            "<iframe width='100%' height='100%' src='data:application/pdf;base64, " +
                            encodeURI(response.restData.base64) + "'></iframe>"
                        )
                    }
                    else{
                        MessageService.showError('檔案無內容','取得檔案');
                    }
                },
                (error) => {
                    MessageService.showSystemError();
                    
                }
            );
        },
        viewImage(image){
            this.viewImageTitle = image.fileName;
            if(image.imgSrc.indexOf("data:image") > -1){
                this.viewImageSrc = image.imgSrc;
            }
            else{
                this.viewImageSrc = this.imgSrcPrefix + image.imgSrc;
            }
            this.viewImageDialog = true;
        },
        hideFiveSec(){
            this.showModeSelect = false;
            setTimeout(() => this.showModeSelect = true, 5000);
        },
        validateCertifate(){
            // 證件 (拍攝)
            if(!ValidateUtil.isEmpty(this.certificateList)){
                for(let indexA in this.certificateList){
                    if(ValidateUtil.isEmpty(this.certificateList[indexA].fileName)){
                        MessageService.showInfo("尚有證件/附件未設定類型");
                        return false;
                    }

                    for(let indexB in this.certificateList){
                        if(indexA != indexB && this.certificateList[indexA].fileName == this.certificateList[indexB].fileName){
                            MessageService.showInfo("證件/附件不可有相同的名稱");
                            return false;
                        }
                    }
                }
            }

            // 附件 (上傳)
            if(!ValidateUtil.isEmpty(this.attachmentList)){
                for(let indexA in this.attachmentList){
                    if(ValidateUtil.isEmpty(this.attachmentList[indexA].fileName)){
                        MessageService.showInfo("尚有證件/附件未設定類型");
                        return false;
                    }

                    for(let indexB in this.attachmentList){
                        if(indexA != indexB && this.attachmentList[indexA].fileName == this.attachmentList[indexB].fileName){
                            MessageService.showInfo("證件/附件不可有相同的名稱");
                            return false;
                        }
                    }
                }
            }

            // 若有需套用專用章的附件，但核算時不可補件，需在儲存時驗證是否已有檔案或已上傳
            if(!ValidateUtil.isEmpty(this.onlySealFileCode) && this.onlySealFileCode != this.acctUploadFileCode){
                let isPass = false;

                if(!ValidateUtil.isEmpty(this.attachmentList)){
                    for(let attachment of this.attachmentList){
                        if(attachment.fileCode == this.onlySealFileCode && (!ValidateUtil.isEmpty(attachment.fileNo) || !ValidateUtil.isEmpty(attachment.base64))){
                            isPass = true;
                        }
                    }
                }

                if(!isPass){
                    for(let attachmentOption of this.attachmentOptions){
                        if(attachmentOption.fileCode == this.onlySealFileCode){
                            MessageService.showInfo("尚需上傳 " + attachmentOption.fileName);
                            break;
                        }
                    }
                }

                return isPass;
            }

            return true;
        },
        async save(){
            if(!this.validateCertifate()){
                return;
            }

            // 驗證簽名，只有 NCPS 要驗
            if(this.isNeedSign && this.applyType == "NCPS" && (!this.customerSign || !this.customerSign.imgSrc)){
                MessageService.showInfo("需簽名後才可儲存");
                return;
            }

            let fileListObj = this.setFileList();

            let vin = {
                acceptNum: this.acceptNum,
                formSeq: this.formSeq,
                addFileList: fileListObj.addFileList,
                modifyFileList: fileListObj.modifyFileList,
                deleteFileList: fileListObj.deleteFileList,
                isAddAttachment: this.isAddAttachment,
                empNo: this.empNo,
                region: this.region,
                empName: this.empName,
            };

            AjaxService.post("/tpesForm/save", vin, 
            async (response) => {
                // 驗證是否成功
                if (!response.restData.success) {              
                    MessageService.showError(response.restData.message,'儲存表單');
                    return;
                }

                this.isSavedForm = true;

                MessageService.showSuccess("儲存成功");

                if(this.restrictMode){
                    // 當點擊儲存按鈕，則通知父層可關閉
                    this.$emit("saveFile");
                }
                else{
                    // 開啟滿意度調查頁
                    await this.openPortal();

                    // 清空證件及附件
                    this.certificateList = [];
                    this.attachmentList = [];
                    
                    // 若表單簽名頁還開啟就須關閉 (關閉會重新查詢一次)
                    if(this.formSignPage){
                        this.formSignPage.close();
                        this.formSignPage = null;
                    }
                    // 重新查詢一次
                    else{
                        this.formInit(true);
                    }

                    // 擋頁
                    this.isBlocking = true;
                    if(this.formAnswered){
                        this.blockingMsg = "已儲存成功<br/>用戶已填寫服務滿意度調查問卷";
                    }
                    else{
                        this.blockingMsg = "已儲存成功<br/>請提醒用戶填寫服務滿意度調查問卷";
                    }

                    if(this.usePmc){
                        try {
                            // 將畫面顯示改為延伸
                            PMCService.callDualScreenAdapterExtend();
                        } catch (error) {
                            MessageService.showError("PMC 未開啟或異常", "PMC ");
                            
                        }
                    }
                }
            },
            (error) => {
                MessageService.showSystemError();
                
            });
        },
        setFileList(){
            let addFileList = [];
            let modifyFileList = [];
            let deleteFileList = [];

            // 整理有變更的證件及附件
            // 新增/修改 證件
            if(!ValidateUtil.isEmpty(this.certificateList)){
                for(let certificate of this.certificateList){
                    // 新增
                    if(ValidateUtil.isEmpty(certificate.fileNo) && !ValidateUtil.isEmpty(certificate.imgSrc)){
                        addFileList.push({
                            category: this.certificateCategory,
                            fileCode: certificate.fileCode,
                            fileName: certificate.fileName,
                            originalFileName: certificate.originalFileName,
                            fileExt: this.getFileExt(certificate.originalFileName),
                            base64: certificate.imgSrc.split(",")[1],
                            formSeq: this.formSeq
                        });
                    }
                    // 修改
                    else if(!ValidateUtil.isEmpty(certificate.fileNo) && certificate.hasEdit){
                        modifyFileList.push({
                            fileNo: certificate.fileNo,
                            category: this.certificateCategory,
                            fileCode: certificate.fileCode,
                            fileName: certificate.fileName,
                            originalFileName: certificate.originalFileName,
                            fileExt: this.getFileExt(certificate.originalFileName),
                            base64: ValidateUtil.isEmpty(certificate.imgSrc) ? null : certificate.imgSrc.split(",")[1],
                            formSeq: this.formSeq
                        });
                    }
                }
            }
            // 刪除證件 (相同的 fileNo 還存在就不刪，其餘皆刪)
            if(!ValidateUtil.isEmpty(this.oriCertificateList)){
                for(let oriCertificate of this.oriCertificateList){
                    let isDelete = true;
                    if(!ValidateUtil.isEmpty(this.certificateList)){
                        for(let certificate of this.certificateList){
                            if(!ValidateUtil.isEmpty(oriCertificate.fileNo) && oriCertificate.fileNo == certificate.fileNo){
                                isDelete = false;
                                break;
                            }
                        }
                    }

                    if(isDelete){
                        deleteFileList.push({
                            fileNo: oriCertificate.fileNo,
                            fileName: oriCertificate.fileName,
                            filePath: oriCertificate.filePath
                        });
                    }
                }
            }

            // 新增/修改 附件
            if(!ValidateUtil.isEmpty(this.attachmentList)){
                for(let attachment of this.attachmentList){
                    // 新增
                    if(ValidateUtil.isEmpty(attachment.fileNo) && !ValidateUtil.isEmpty(attachment.base64)){
                        addFileList.push({
                            category: this.attachmentCategory,
                            fileCode: attachment.fileCode,
                            fileName: attachment.fileName,
                            originalFileName: attachment.originalFileName,
                            fileExt: this.getFileExt(attachment.originalFileName),
                            base64: attachment.base64.split(",")[1],
                            formSeq: this.formSeq,
                            needSeal: attachment.needSeal,
                        });
                    }
                    // 修改
                    else if(!ValidateUtil.isEmpty(attachment.fileNo) && attachment.hasEdit){
                        modifyFileList.push({
                            fileNo: attachment.fileNo,
                            category: this.attachmentCategory,
                            fileCode: attachment.fileCode,
                            fileName: attachment.fileName,
                            originalFileName: attachment.originalFileName,
                            fileExt: this.getFileExt(attachment.originalFileName),
                            base64: ValidateUtil.isEmpty(attachment.base64) ? null : attachment.base64.split(",")[1],
                            formSeq: this.formSeq,
                            needSeal: attachment.needSeal,
                        });
                    }
                }
            }
            // 刪除附件 (相同的 fileNo 還存在就不刪，其餘皆刪)
            if(!ValidateUtil.isEmpty(this.oriAttachmentList)){
                for(let oriAttachment of this.oriAttachmentList){
                    let isDelete = true;
                    if(!ValidateUtil.isEmpty(this.attachmentList)){
                        for(let attachment of this.attachmentList){
                            if(!ValidateUtil.isEmpty(oriAttachment.fileNo) && oriAttachment.fileNo == attachment.fileNo){
                                isDelete = false;
                                break;
                            }
                        }
                    }

                    if(isDelete){
                        deleteFileList.push({
                            fileNo: oriAttachment.fileNo,
                            fileName: oriAttachment.fileName,
                            filePath: oriAttachment.filePath
                        });
                    }
                }
            }

            let result = {
                addFileList: addFileList,
                modifyFileList: modifyFileList,
                deleteFileList: deleteFileList,
            };

            return result;
        },
        getFileExt(fileName){
            let fileExt = null;
            if(!ValidateUtil.isEmpty(fileName)){
                let fileNameArr = fileName.split('.');
                fileExt = "." + fileNameArr[fileNameArr.length - 1];
            }
            return fileExt;
        },
        checkIsWord(attachment){
            let isWord = false;

            if(attachment){
                let fileExt = this.getFileExt(attachment.originalFileName);
                isWord = (fileExt == ".doc" || fileExt == ".docx");
            }

            return isWord;
        },
        checkNeedSeal(needSealIndex, needSeal){
            // 各案件只能有一個附件套印專用章
            // 若勾選套印則取消勾選其餘附件
            if(needSeal){
                for(let index in this.attachmentList){
                    if(index != needSealIndex && this.attachmentList[index].needSeal){
                        this.attachmentList[index].needSeal = false;
                        this.attachmentList[index].hasEdit = true;
                    }
                }
            }

            this.attachmentList[needSealIndex].hasEdit = true;
        },
        retrunOrder(){
            this.$emit("returnOrder", this.accountingMemo);
        },
        accountingSubmit(){
            // 檢查若有專用章附件但尚未簽核則不可以核算通過
            if(this.isAttachmentNotSealed){
                MessageService.showInfo("專用章尚未簽核通過");
            }
            // 檢查證件規範
            else if(!this.checkNeedScanFile(true)){
                let msg = "尚需掃描/上傳 ";

                if(this.needScanFileHint){
                    msg += this.needScanFileHint
                }

                if(this.needScanAttachHint){
                    if(this.needScanFileHint){
                        msg += "、"
                    }

                    msg += this.needScanAttachHint
                }

                MessageService.showInfo(msg);
            }
            // 通過
            else{
                this.$emit("accountingSubmit", this.accountingMemo);
            }
        },
        saveComments(){
            // 將待審核備註一併傳回給父層
            this.$emit("saveComments", this.accountingMemo);
        },
        cancel(){
            // 驗證是否已簽名
            if(ValidateUtil.isEmpty(this.cancelSign.imgSrc)){
                MessageService.showInfo("尚未簽名", "提示");
                return;
            }

            let fileListObj = this.setFileList();

            let vin = {
                formSeq: this.formSeq,
                acceptNum: this.acceptNum,
                cancelSignBase64: this.cancelSign.imgSrc.split(",")[1],
                cancelReason: this.cancelReason,
                empNo: this.empNo,
                region: this.region,
                addFileList: fileListObj.addFileList,
                modifyFileList: fileListObj.modifyFileList,
                deleteFileList: fileListObj.deleteFileList,
            };

            AjaxService.post("/tpesForm/custCancelForm", vin, 
            (response) => {
                // 驗證是否成功
                if (!response.restData.success) {
                    MessageService.showError(response.restData.message,'取消表單');
                    return;
                }

                MessageService.showSuccess("取消成功");

                // 擋頁
                this.isBlocking = true;
                this.blockingMsg = "已取消成功";

                // 若表單簽名頁還開啟就須關閉
                if(this.formSignPage){
                    this.formSignPage.close();
                    this.formSignPage = null;
                }

                if(this.usePmc){
                    try {
                        // 將畫面顯示改為延伸
                        PMCService.callDualScreenAdapterExtend();
                    } catch (error) {
                        MessageService.showError("PMC 未開啟或異常", "PMC ");
                        
                    }
                }

                // 移除關閉頁面的 listener
                window.removeEventListener("beforeunload", this.confirmClosePage);
            },
            (error) => {
                MessageService.showSystemError();
                
            });
        },
        addWaterMark(originImageSrc){
            let originImage = new Image();

            return new Promise((resolve, reject) => {
                if(!originImageSrc) {
                    reject({
                      status: 'fail',
                      message: '取得影像失敗'
                    })
                  }

                originImage.onload = function() {
                    let canvas = document.createElement('canvas');
    
                    canvas.width = originImage.width;
                    canvas.height = originImage.height;
    
                    // 浮水印日期
                    let dateString = moment(new Date).format('YYYY/MM/DD HH:mm:ss');
                    let context = canvas.getContext("2d");
                    context.drawImage(originImage, 0, 0);
                    let imgData = context.getImageData(0,0,canvas.width,canvas.height);
                    let waterMarkCanvas = document.createElement("canvas");
                    //設定浮水印畫布的高跟寬
                    waterMarkCanvas.width = canvas.width;
                    waterMarkCanvas.height = canvas.height;
                    let waterMarkContext = waterMarkCanvas.getContext("2d");
                    waterMarkContext.putImageData(imgData, 0, 0);
                    waterMarkContext.font = "30px Arial ";
                    waterMarkContext.fillStyle = "#ff0000";
                    waterMarkContext.fillText(dateString, waterMarkCanvas.width - 290, 30);
                    waterMarkContext.fillText("台電申請專用", waterMarkCanvas.width - 200, 60);
                    let waterMarkImage = waterMarkCanvas.toDataURL("image/jpeg");

                    if(!waterMarkImage) {
                        reject({
                          status: 'fail',
                          message: '取得影像失敗'
                        })
                    }
                    resolve({
                        status: 'success',
                        data: waterMarkImage
                    });
                };
    
                originImage.src = originImageSrc;
            });
        },
        getScanDataList(data){
            this.scanDataList = data;
            
            if(!ValidateUtil.isEmpty(this.scanDataList)){
                for(let scanData of this.scanDataList){
                    this.addCertificate(scanData.BASE64STR);
                }
            }

            this.isLoading = false;
        },
        showScanErrorMsg(msg){
            this.isLoading = false;
            MessageService.showInfo("PMC 回傳: " + msg);
        },
        checkNeedScanFile(onlyForCheck){
            this.needScanFileHint = "";

            this.needScanFileList = Array.from(this.oriNeedScanFileList);

            // 證件
            if(!ValidateUtil.isEmpty(this.needScanFileList)){
                for (let index = 0 ; index < this.needScanFileList.length ; index++) {

                    let needScanFile = this.needScanFileList[index];

                    if(!ValidateUtil.isEmpty(this.certificateList) && needScanFile != null){
                        for (let certificate of this.certificateList) {
                            // 若已有掃描的證件，將 file 從 List 移除，最後剩下來的就是還沒掃描的
                            if(!ValidateUtil.isEmpty(needScanFile.fileCode) 
                                && certificate.fileCode == needScanFile .fileCode
                                && !ValidateUtil.isEmpty(certificate.fileNo)){

                                this.needScanFileList.splice(index, 1);
                                index--;
                                break;
                            }
                        }
                    }
                }
            }

            // 附件
            this.onlySealFileCode = null;
            this.acctUploadFileCode = null;
            if(!ValidateUtil.isEmpty(this.needScanFileList)){

                let isUploadedSpecificFile = false;
                let acctUploadFileOption = {};
                let acctUploadFileSealFlag = null;

                for (let index = 0 ; index < this.needScanFileList.length ; index++) {

                    let needScanFile = this.needScanFileList[index];

                    if(needScanFile != null && needScanFile.category == this.attachmentCategory){
                        // 若為指定套印專用章的附件則取出限制的 fileCode
                        if(needScanFile.sealFlag == "Y"){
                            this.onlySealFileCode = needScanFile.fileCode;
                        }

                        // 若為可於核算時補件之附件則檢查是否已上傳，若無則新增欄位並開啟上傳按鈕
                        if(needScanFile.acctUploadFlag == "Y"){
                            this.acctUploadFileCode = needScanFile.fileCode;
                            acctUploadFileSealFlag = needScanFile.sealFlag;

                            for(let attachmentOption of this.attachmentOptions){
                                if(attachmentOption.fileCode == this.acctUploadFileCode){
                                    acctUploadFileOption = attachmentOption;
                                    break;
                                }
                            }
                        }
                    }

                    if(!ValidateUtil.isEmpty(this.attachmentList) && needScanFile != null){
                        for (let attachment of this.attachmentList) {
                            // 若為核算可補件附件，檢查是否已上傳
                            if(!onlyForCheck && !ValidateUtil.isEmpty(this.acctUploadFileCode) && this.acctUploadFileCode == attachment.fileCode && !ValidateUtil.isEmpty(attachment.fileNo)){
                                isUploadedSpecificFile = true;
                                attachment.canAcctUpload = true;
                                attachment.needSeal = (acctUploadFileSealFlag == "Y");
                            }

                            // 若已有掃描的附件，將 file 從 List 移除，最後剩下來的就是還沒掃描的
                            if(!ValidateUtil.isEmpty(needScanFile.fileCode) 
                                && attachment.fileCode == needScanFile.fileCode
                                && !ValidateUtil.isEmpty(attachment.fileNo)
                                && !ValidateUtil.isEmpty(attachment.originalFileName)){
        
                                this.needScanFileList.splice(index, 1);
                                index--;
                                break;
                            }
                        }
                    }
                }
                
                // 若於核算時，規則有核算時可補件之附件則檢查是否已上傳，若無則新增欄位並開啟上傳按鈕
                if(!onlyForCheck && this.formPageMode == "accounting" && !ValidateUtil.isEmpty(this.acctUploadFileCode) && !isUploadedSpecificFile){
                    this.attachmentList.push({
                        id: this.attachmentNo,
                        fileName: acctUploadFileOption.fileName,
                        fileCode: acctUploadFileOption.fileCode,
                        category: this.attachmentCategory,
                        originalFileName: null,
                        fileNo: null,
                        filePath: null,
                        imgSrc: null,
                        base64: null,
                        hasEdit: false,
                        needSeal: acctUploadFileSealFlag == "Y",
                        canOnlyView: false,
                        isSelecting: false,
                        canAcctUpload: true,
                        hintText: acctUploadFileOption.hintText,
                    });
                    this.attachmentNo++;
                }

            }

            // 拍攝區提示整理
            if(!ValidateUtil.isEmpty(this.needScanFileList)){
                for (let needScanFile of this.needScanFileList) {
                    for(let certificateOption of this.certificateOptions){
                        // 放入缺少的證件
                        if(certificateOption.fileCode == needScanFile.fileCode 
                            && needScanFile.category == this.certificateCategory){
                            this.needScanFileHint = this.needScanFileHint ? this.needScanFileHint + "、" + certificateOption.fileName : certificateOption.fileName;
                        }
                    }
                }
            }

            // 上傳區提示整理
            this.needScanAttachHint = "";
            if(!ValidateUtil.isEmpty(this.needScanFileList)){
                for (let needScanFile of this.needScanFileList) {
                    for(let attachmentOption of this.attachmentOptions){
                        // 放入缺少的附件
                        if(attachmentOption.fileCode == needScanFile.fileCode 
                            && needScanFile.category == this.attachmentCategory){
                            this.needScanAttachHint = this.needScanAttachHint ? this.needScanAttachHint + "、" + attachmentOption.fileName : attachmentOption.fileName;
                        }
                    }
                }
            }

            // 若為儲存表單，跳出尚未上傳的證件/附件提示 modal
            if(this.isSavedForm && (this.needScanFileHint || this.needScanAttachHint)){
                let needScanAttachHint = (this.needScanFileHint && this.needScanAttachHint) ? "、" + this.needScanAttachHint : this.needScanAttachHint;
                this.dialogHintText = "尚需拍攝/上傳 " + this.needScanFileHint + needScanAttachHint;
                this.viewHintDialog = true;
            }

            return ValidateUtil.isEmpty(this.needScanFileList);
        },
        chooseCertificateType(certificate){
            if(!ValidateUtil.isEmpty(certificate.fileName)){
                for(let certificateOption of this.certificateOptions){
                    if(certificateOption.fileName == certificate.fileName){
                        certificate.fileCode = certificateOption.fileCode;
                        break;
                    }
                }
            }
        },
        querySign(){
            this.customerSign = {};
            this.cancelSign = {};

            let param = {
                formSeq: this.formSeq,
            }

            AjaxService.post("/tpesForm/querySign", param, 
            (response) => {
                // 驗證是否成功
                if (!response.restData.success) {              
                    MessageService.showError(response.restData.message,'取得簽名圖片');
                    return;
                }

                // 簽名
                if(!ValidateUtil.isEmpty(response.restData.customerSign)){
                    this.customerSign = response.restData.customerSign;
                }

                // 取消簽名
                if(!ValidateUtil.isEmpty(response.restData.cancelSign)){
                    this.cancelSign = response.restData.cancelSign;
                }

            },
            (error) => {
                MessageService.showSystemError();
                
            });
        },
        async openPortal() {
            let acceptNum = this.acceptNum
            await this.checkAnswered(acceptNum);
            if(!this.formAnswered){
                // 開啟滿意度調查頁
                let config = 'statusbar=no,scrollbars=yes,status=no,location=no';
                let routeData = this.$router.resolve({
                  name: 'Satisfaction-Answer', // Router Name
                });
                this.windowRef = window.open(routeData.href + "?acceptNum=" + this.acceptNum, '_blank', config);
                this.windowRef.document.title = 'TPES-問卷';
                // this.windowRef.addEventListener("beforeunload", this.closePortal);
            }
        },
        closeSurveyPortal(answered) {
          if (answered){
            MessageService.showSuccess('客戶問卷填寫')
          } else {
            MessageService.showInfo('客戶放棄問卷填寫','問卷調查')
          }
        },
        closePortal() {
          if (this.windowRef) {
            let answered = this.windowRef.document.getElementById('answered')
            // this.windowRef.close();
            // this.windowRef = null;
            if (answered.value == 'true'){
              MessageService.showSuccess('客戶問卷填寫')
            } else {
              MessageService.showInfo('客戶放棄問卷填寫','問卷調查')
            }
          }
        },
        clearAttachment(attachment){
            attachment.originalFileName = null;
            attachment.imgSrc = null;
            attachment.file = null;
            attachment.base64 = null;
            attachment.needSeal = this.uploadingAttachment.needSeal;
            attachment.hasEdit = true;
            attachment.canAcctUpload = (this.acctUploadFileCode == attachment.fileCode);

            // 強制頁面刷新
            this.$forceUpdate();
        },
        //Action:檢查該受理號碼是否填寫過問卷
        async checkAnswered(acceptNum) {
          const data = await checkQuestionnaireAnswered(acceptNum)
          // 驗證是否成功
          if (!data.restData.success) {              
            MessageService.showError(data.restData.message,'檢查表單是否填過問卷');
            return;
          }
          // MessageService.showSuccess('檢查表單是否填過問卷成功' + "✓")
          this.formAnswered = data.restData.answered
        },
        confirmDeleteSealAttachment(){
            // 兩個附件都刪除
            for(let index in this.attachmentList){
                if(this.attachmentList[index].fileNo == this.sealFileNo){
                    this.attachmentList.splice(index, 1);
                    break;
                }
            }

            for(let index in this.attachmentList){
                if(this.attachmentList[index].fileNo == this.sealedFileNo){
                    this.attachmentList.splice(index, 1);
                    break;
                }
            }

            this.deleteSealDialog = false;
        },
        confirmClosePage(e){
            e.preventDefault(); 
            e.returnValue = '尚未取消表單，確定要離開嗎?';
        },
        closeAccountingDialog(){
            this.$emit("closeAccountingDialog");
        }
    }
}