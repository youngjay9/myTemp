<template>
  <v-app>
    <v-container style="max-width: 100%">
      <v-row v-show="!isSign" justify="center">
        <tui-image-editor :key="tuiKey" ref="tuiImageEditor" :include-ui="true" :options="options" />
      </v-row>
      <!-- <hr style="margin-top: 30px;margin-bottom: 30px;">
      <v-row justify="center">
        <v-btn style="width:200px; margin: 5px;" depressed color="primary" @click="downloadFile()">DOWNLOAD</v-btn>
      </v-row> -->
      <div v-if="isCanSign && !isSign">
        <v-btn 
          fab
          depressed 
          large 
          color="primary" 
          class="mx-2 fixed-save-btn"
          width="100"
          height="100"
          @click="isSign = true"
        >
          <div style="display:block;">
            <v-icon size="40" class="cal-btn-icon"> 
              mdi-pencil
            </v-icon>
            <span style="display:block; padding-top:20%; font-size: 18px">用戶簽名</span>             
          </div>
        </v-btn>
      </div>
      <div v-if="isRead && !isSign">
        <v-btn 
          fab
          depressed 
          large 
          color="primary" 
          class="mx-2 fixed-save-btn"
          width="100"
          height="100"
          @click="downloadImg()"
        >
          <div style="display:block;">
            <v-icon size="40" class="cal-btn-icon"> 
              mdi-download
            </v-icon>
            <span style="display:block; padding-top:20%; font-size: 20px">下載</span>             
          </div>
        </v-btn>
      </div>
      <div v-if="isSign">
        <v-row justify="center">
          <span class="sign-title mb-3">用戶簽名</span>
          <VueSignaturePad
            ref="signaturePad"
            width="100%"
            height="80vh"
            :custom-style="signaturePadStyle"
            :options="signatureOptions"
          />
          <span class="hint-text">您的電子簽名僅使用於本表單的各簽名處</span>
        </v-row>
        <v-row justify="center" class="mt-5">
          <v-btn class="big-btn" @click="isSign = false">
            <span class="big-btn-text">返回瀏覽表單</span>
            <v-icon
              right
              dark
              size="3vh"
            >
              mdi-arrow-left
            </v-icon>
          </v-btn>
          <v-btn class="ml-12 big-btn" color="error" @click="clearSign()">
            <span class="big-btn-text">清除重簽</span>
            <v-icon
              right
              dark
              size="3vh"
            >
              mdi-eraser
            </v-icon>
          </v-btn>
          <v-btn class="ml-12 big-btn" color="success" @click="save()">
            <span class="big-btn-text">確認儲存</span>
            <v-icon
              right
              dark
              size="3vh"
            >
              mdi-check
            </v-icon>
          </v-btn>
        </v-row>
      </div>
    </v-container>
  </v-app>
</template>

<script src="./imageEditorPage.js" />

<style scoped>
    .marginLeft {
        margin-left: 100px !important;
    }

    .tui-image-editor-help-menu {
        display: none !important;
    }
    .sign-title {
      width: 100%;
      font-size: 36px;
      font-weight: bold;
      text-align: center;
    }
    .big-btn{
      height: 10vh !important;
      width: 12vw !important;
    }
    .big-btn-text{
      font-size: 1.4vw;
    }
    .hint-text{
      color: red;
      font-size: 32px;
    }
    .fixed-save-btn {
      position: fixed;
      right: 20px;
      z-index: 10;
      bottom: 20px;
    }
</style>