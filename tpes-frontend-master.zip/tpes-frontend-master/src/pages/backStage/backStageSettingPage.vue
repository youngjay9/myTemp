<template>
  <v-app>
    <v-container>
      <h2>後台資訊設定區</h2>
    </v-container>
  </v-app>
</template>

<script>

export default {
    name: 'BackStageSetting',
    props: {
    
    },
    data() {
        return {
            
        }
    },
    methods: {
        
    }
}
</script>