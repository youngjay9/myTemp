const blockCount = 0;
const hasLoader = false;

export default
{
    blockCount,
    hasLoader
}