<template>
  <v-app> <!-- <div id="app"> -->
    <router-view />
    <!-- 通知設定 -->
    <notifications
      group="topRight"
      position="top center"
      :duration="5000"
      :max="10"
      animation-name="v-fade-right"
    />
    <!-- 新版通知設定 可參考message.service.showNoticeInfo_New 使用 -->
    <fet-snackbar
      v-model="show"
      :type="color"
      :dismissible="false"
      v-bind="{
        [direction.split(' ')[0]]: true,
        [direction.split(' ')[1]]: true,
        timeout: timeout
      }"
    >
      {{ message }}
    </fet-snackbar>
    <!-- loading -->
    <v-overlay :value="isLoading" z-index="5000">
      <v-progress-circular indeterminate size="64" />
    </v-overlay>
  </v-app>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  
  data() {
    return {
      //for snack bar
      timeout: 5000,
      show: false,
      title: null,
      message: null,
      color: null,
      direction: 'top rignht',
      // directions: [
      //   'top left',
      //   'top center',
      //   'top right',
      //   'bottom left',
      //   'bottom center',
      //   'bottom right',
      // ],
    }
  },
  computed: {
    ...mapGetters([
      'isLoading',
    ]),
  },
  created: function() {
    this.$store.watch(() => {
      const message = this.$store.state.app.notifySnackbar.message;
      if (message) {
        this.show = true;
        this.message = message;
        this.timeout = this.$store.state.app.notifySnackbar.timeout;
        this.title = this.$store.state.app.notifySnackbar.title;
        this.color = this.$store.state.app.notifySnackbar.color;
        this.direction = this.$store.state.app.notifySnackbar.direction;
        this.$store.dispatch('app/resetNotifySnackbar');
      }
    });
  },
}

</script>

<style lang="scss">
@import '@/scss/overrides.scss';

/* Remove in 1.2 */
.v-datatable thead th.column.sortable i {
  vertical-align: unset;
}
</style>