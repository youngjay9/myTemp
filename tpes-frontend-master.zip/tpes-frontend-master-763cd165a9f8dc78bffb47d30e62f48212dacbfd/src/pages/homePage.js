import AjaxService from "@/assets/services/ajax.service";
import ValidateUtil from "@/assets/services/validateUtil";
import MessageService from "@/assets/services/message.service";

export default {
    mounted(){ // 在這裡做初始化, 勿刪
        this.init();
    },
    data(){
        return {
            //角色為受理人員
            general: true,
            //角色為核算員
            accounting: false,
            //角色為簽核人員
            signOff: false,
            roleList : [],
            numberOf:{},
            showCounts:{
                myForm: false,
                myReturnForm: false,
                myReturnMedia: false,
                myRead:false,
                myReadApply:false,
                myAccounting: false,
                hasAccounting:false,
                hasCalculate:false,
                mySignOffSeal: false,
                mySignOffReadApply: false,
                mySignOffReadList:false,
                mySignOffReturnReport: false,
                mySignOffMedia: false,
            }
        }
    },
    methods: {
        init(){            
            this.queryFrontPageInit();
        },
        /**
         * Ajax Start
         * 
         */
        // Action:查詢首頁初始化
         queryFrontPageInit(){
            AjaxService.post('/frontPage/queryFrontPageInit',{},
            (response) => {
                // 驗證是否成功
                if (!response.restData.success) {              
                    MessageService.showError(response.resultMessage.returnMessage,'查詢首頁初始化');
                    return;
                }

                // 將取得的資料放進前端參數中
                this.roleList = response.restData.authRolePrivilegeMapVoList;
                this.numberOf = response.restData.numberOfVo;

                // 驗證權限開啟對應的區塊
                this.checkAuth(this.roleList);

            },
            // eslint-disable-next-line no-unused-vars
            (response) => {                
                MessageService.showSystemError();
            });
         },

         /**
         * Ajax End
         * 
         */

         /**
          * 
          * 資料整理 Start
          * 
          */
          checkAuth(roleList){
            for(let index in roleList){
                // 判斷我的表單區
                if(roleList[index].privilegeCode === 'P001'){
                    this.showCounts.myForm = true;
                }
                // 判斷我的退件區-案件
                if(roleList[index].privilegeCode === 'P002'){
                    this.showCounts.myReturnForm = true;
                }
                // 判斷我的退件區-多媒體
                if(roleList[index].privilegeCode === 'P003'){
                    this.showCounts.myReturnMedia = true;
                }
                // 判斷我的調閱區
                if(roleList[index].privilegeCode === 'P005'){              
                    this.showCounts.myRead = true;
                    // 判斷若為受理部門/受理部門主管/非核算課之其他TPES人員才需顯示申請中區塊
                    if(roleList[index].roleCode === 'AUTH02' || roleList[index].roleCode === 'AUTH04' || roleList[index].roleCode === 'AUTH17'){
                       this.showCounts.myReadApply = true; 
                    }
                    
                } 
                // 判斷我的核算區
                if(roleList[index].privilegeCode === 'P014' || roleList[index].privilegeCode === 'P015' || roleList[index].privilegeCode === 'P016'){            
                    this.showCounts.myAccounting = true;
                    // 判斷是否為核算員或核算課長權限
                    if(roleList[index].privilegeCode === 'P014' && roleList[index].roleCode === 'AUTH15' || roleList[index].roleCode === 'AUTH07' || roleList[index].roleCode === 'AUTH01'){
                        this.showCounts.hasAccounting = true;
                    }
                    // 判斷是否為檢算員權限
                    if(roleList[index].privilegeCode === 'P014' && roleList[index].roleCode === 'AUTH20'){
                        this.showCounts.hasCalculate = true;
                    }
                } 
                // 判斷我的簽核區-專用章待簽核
                if(roleList[index].privilegeCode === 'P009'){            
                    this.showCounts.mySignOffSeal = true;
                }
                // 判斷我的簽核區-調閱申請待簽核
                if(roleList[index].privilegeCode === 'P008'){            
                    this.showCounts.mySignOffReadApply = true;
                }
                // 判斷我的簽核區-退件報表待簽核
                if(roleList[index].privilegeCode === 'P025'){            
                    this.showCounts.mySignOffReturnReport = true;
                }
                // 判斷我的簽核區-調閱清單待簽核
                if(roleList[index].privilegeCode === 'P026'){            
                    this.showCounts.mySignOffReadList = true;
                } 
                // 判斷我的簽核區-多媒體待簽核
                if(roleList[index].privilegeCode === 'P010' || roleList[index].privilegeCode === 'P011' || roleList[index].privilegeCode === 'P012'){
                    this.showCounts.mySignOffMedia = true;
                }
            }
          },



          /**
          * 
          * 資料整理 End
          * 
          */
    },
}