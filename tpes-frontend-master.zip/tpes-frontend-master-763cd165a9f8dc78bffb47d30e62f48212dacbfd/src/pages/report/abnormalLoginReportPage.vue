<template>
  <v-app>
    <v-container>
      <h2 class="font-bold">異常管控報表</h2>
      <div class="ml-10">
        <div class="font-18px font-bold">
          <v-row align="center">
            <v-col cols="1" sm="2" xl="1">
              登入日期
            </v-col>
            <v-col cols="3" sm="5" xl="3" class="d-flex">
              <v-menu
                v-model="openStartDate"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="startDate"
                    append-icon="mdi-calendar"
                    placeholder="YYYY-MM-DD"
                    outlined
                    dense
                    hide-details
                    v-bind="attrs"
                    clearable
                    v-on="on"
                    @click:append="openStartDate = true"           
                  />
                </template>
                <v-date-picker
                  v-model="startDate"
                  @input="openStartDate = false"
                  @change="checkDate()"
                />
              </v-menu>
              <div class="mt-1">~</div>
              <v-menu
                v-model="openEndDate"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="endDate"
                    append-icon="mdi-calendar"
                    placeholder="YYYY-MM-DD"
                    outlined
                    clearable
                    dense
                    hide-details
                    v-bind="attrs"
                    style="padding-top: 0;"
                    v-on="on"
                    @click:append="openEndDate = true"
                  />
                </template>
                <v-date-picker
                  v-model="endDate"
                  @input="openEndDate = false"
                  @change="checkDate()"
                />
              </v-menu>
            </v-col>
            <v-col cols="2" sm="4" xl="2">
              <v-tooltip top>
                <template v-slot:activator="{ on }">
                  <v-btn
                    class="ma-2"
                    fab
                    small
                    color="accent"
                    v-on="on"
                    @click="resetData()"
                  >
                    <v-icon v-text="'mdi-eraser'" />
                  </v-btn>
                </template>
                <span>&nbsp;清空&nbsp;</span>
              </v-tooltip>
              <v-tooltip top>
                <template v-slot:activator="{ on }">
                  <v-btn
                    class="ma-2"
                    fab
                    small
                    color="primary"
                    v-on="on"
                    @click="search('search')"
                  >
                    <v-icon v-text="'mdi-magnify'" />
                  </v-btn>
                </template>
                <span>&nbsp;查詢&nbsp;</span>
              </v-tooltip>
              <v-tooltip top>
                <template v-slot:activator="{ on }">
                  <v-btn
                    class="ma-2"
                    fab
                    small
                    color="primary"
                    v-on="on"
                    @click="validateAndDownload('download')"
                  >
                    <v-icon v-text="'mdi-file-download-outline'" />
                  </v-btn>
                </template>
                <span>&nbsp;下載&nbsp;</span>
              </v-tooltip>
            </v-col>
            <v-col cols="6" />
            <v-col cols="1" />
            <v-col v-if="loginReportDateErrMsg != null" cols="3" style="margin-top:-25px">
              <span class="red--text font-14px">{{ loginReportDateErrMsg }}</span>
            </v-col> 
          </v-row>
          <v-row align="center" class="font-28px font-bold">
            <v-col cols="4" class="red--text">
              異常登入資料定義:
            </v-col>
          </v-row>
          <v-row align="center" class="font-24px font-bold">
            <v-col cols="5" class="red--text">
              ●  異常登入報表: 20:00 ~ 07:00
            </v-col>
          </v-row>
          <v-row align="center" class="font-24px font-bold">
            <v-col cols="5" class="red--text">
              ●  登入失敗: 登入三次失敗
            </v-col>
          </v-row>
        </div>
        
      </div>
      
      <hr class="mt-6 mb-5">
      <v-row>
        <h3 class="font-bold ml-10">異常登入</h3>
      </v-row>
      <v-row>
        <v-col cols="12">    
          <v-data-table
            :headers="headers"
            :items="abnormalItemList"
            :page.sync="dataListPage"
            :items-per-page="10"
            hide-default-footer
            no-data-text="查無資料"
            class="elevation-1"
            disable-sort
            @page-count="dataListPageCount = $event"
          />
        </v-col>
      </v-row>
      <hr class="mt-6 mb-5">
      <v-row>
        <h3 class="font-bold ml-10">登入失敗:登入三次失敗</h3>
      </v-row>
      <v-row>
        <v-col cols="12">    
          <v-data-table
            :headers="headers"
            :items="failItemList"
            :page.sync="dataListPage"
            :items-per-page="10"
            hide-default-footer
            no-data-text="查無資料"
            class="elevation-1"
            disable-sort
            @page-count="dataListPageCount = $event"
          />
        </v-col>
      </v-row>
    </v-container>
  </v-app>
</template>

<script src="./abnormalLoginReportPage.js" />