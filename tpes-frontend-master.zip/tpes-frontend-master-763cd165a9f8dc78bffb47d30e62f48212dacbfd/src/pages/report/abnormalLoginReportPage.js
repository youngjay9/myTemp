import AjaxService from "@/assets/services/ajax.service";
import MessageService from "@/assets/services/message.service";
import ValidateUtil from "@/assets/services/validateUtil";

export default {
    name: 'abnormalLoginReport',
    props: {
    
    },
    mounted(){
      this.init();
    },
    data() {
        return {
          openStartDate: false, //是否開啟查詢調閱日期的datePicker
          openEndDate: false, //是否開啟查詢調閱日期的datePicker
          monthPicker: false,
          headers: [
            { text: '姓名代號', value: 'loginKey', align: 'center' },                  
            { text: '姓名', value: 'loginName', align: 'center' },
            { text: '部門', value: 'loginDept', align: 'center' },
            { text: '時間', value: 'createDate', align: 'center' },
            { text: '狀態', value: 'status', align: 'center' },
            { text: '登入來源', value: 'loginPath', align: 'center' },
            { text: '登入結果', value: 'loginResult', align: 'center' },
          ],
          abnormalItemList: [],
          failItemList: [],
          dataListPage: 1,
          dataListPageCount: 1,
          startDate:'',   //查詢調閱日期(起)
          endDate:'', //查詢調閱日期(迄)
          loginReportDate:{
            start: null,
            end: null,
          },
          loginReportDateErrMsg: null,
          formatArray:[],
        }
    },
    methods: {
      init(){
        this.resetData();
      },
      //清空所有欄位
      resetData() {            
        this.startDate = null;
        this.endDate = null;            
        this.loginReportDateErrMsg = null;
      },
      downloadReport(){
        
        AjaxService.postFile("/report/downloadLoginReport", 
        {
          startDate: (ValidateUtil.isEmpty(this.loginReportDate.start)? null:this.loginReportDate.start),
          endDate: (ValidateUtil.isEmpty(this.loginReportDate.end)? null:this.loginReportDate.end),
        }, 
        (response) => {
          if(response.restData.success){
            MessageService.showSuccess("下載"); 
          }
        },
        (error) => {
          
        });
      },
      // download(fileNo){
      //     let param = {
      //         fileNo: fileNo
      //     };

      //     AjaxService.postFile("/report/downloadReport", param, 
      //         (response) => {
      //             if(response.restData.success){
      //                 MessageService.showSuccess("下載");
      //             }
      //         },
      //         (error) => {
      //             
      //         }
      //     );
      // },
      // signOff(fileNo, roleCode){
      //   let param = {
      //     fileNo: fileNo,
      //     roleCode: roleCode
      //   };

      //   AjaxService.post("/report/readSignOff", param, (response) => {
      //     if(response.restData.success){
      //       MessageService.showSuccess("簽核");
      //       this.queryReport();
      //     }else{
      //       MessageService.showError(response.restDate.message, "簽核");
      //     }
      //   });
      // },
        // 驗證派工日期區間
        checkDate(){
          this.formatArray = [];
          let isValid = true;
          this.loginReportDate.start = null;
          this.loginReportDate.end = null;

          if(!ValidateUtil.isEmpty(this.startDate) && ValidateUtil.isEmpty(this.endDate) || 
              (ValidateUtil.isEmpty(this.startDate) && !ValidateUtil.isEmpty(this.endDate))){
            this.loginReportDateErrMsg = '日期範圍不完整'
            this.formatArray.push("登入日期");
            isValid = false;
          } else {
            this.loginReportDateErrMsg = null;
          }

          if(!ValidateUtil.isEmpty(this.startDate) && !ValidateUtil.isEmpty(this.endDate)){
              this.loginReportDate.start = this.startDate + ' 00:00:00';
              this.loginReportDate.end = this.endDate + ' 23:59:59';
              
              if(!ValidateUtil.validateDateRange(this.loginReportDate.start,this.loginReportDate.end)){
                  this.loginReportDateErrMsg = '日期範圍錯誤'
                  this.formatArray.push("登入日期");
                  isValid = false;
                  
              } else {
                  this.loginReportDateErrMsg = null;
              }
          }

          return isValid;
      },
      validateAndDownload(param){
        // 再次驗證日期範圍格式
        if(this.startDate == null){
          this.loginReportDateErrMsg = '起始日期不得為空';
          return;
        }
        if(this.endDate == null){
          this.loginReportDateErrMsg = '結束日期不得為空';
          return;
        }
        if(!this.checkDate()){
          MessageService.showCheckInfo(null,this.formatArray);
          return;
        }

        // 驗證通過則後端取資料or查詢資料
        if(param == 'download'){
          this.downloadReport();
        }else if(param == 'search'){
          this.search();
        }
        
      },
      search(){
        AjaxService.postFile("/report/queryLoginReport", 
        {
          startDate: (ValidateUtil.isEmpty(this.loginReportDate.start)? null:this.loginReportDate.start),
          endDate: (ValidateUtil.isEmpty(this.loginReportDate.end)? null:this.loginReportDate.end),
        }, 
        (response) => {
          if(response.restData.success){
            this.abnormalItemList = Object.assign(response.restData.logLoginList);
            this.failItemList = Object.assign(response.restData.logLoginFailList);
          }
        },
        (error) => {
          
        });
      },
    }
}