import Cookies from 'js-cookie'
// import { getLanguage } from '@/lang/index'

const state = {
//   sidebar: {
//     opened: Cookies.get('sidebarStatus') ? !!+Cookies.get('sidebarStatus') : true,
//     withoutAnimation: false
//   },
//   device: 'desktop',
//   language: getLanguage(),
//   size: Cookies.get('size') || 'medium',
  drawer: null,
  color: 'primary',
  image: 'https://demos.creative-tim.com/vue-material-dashboard/img/sidebar-2.32103624.jpg',
  showImage: false,
  miniSidebar: false,
  isLoading:false, //app.vue v-overlay control
  notifySnackbar: { //for notify
    show: true,
    title: null,
    message: null,
    color: null,
    direction: 'top right',
    timeout: 5000
  }
}


const mutations = {
  TOGGLE_SIDEBAR: state => {
    state.miniSidebar = !state.miniSidebar
  },
  TOGGLE_LOADING: (state, loading) => {
    state.isLoading = loading
  },
  TOGGLE_NOTIFY_SNACKBAR: (state, notifySnackbar) => {
    state.notifySnackbar = { ...notifySnackbar }
  },
  RESET_NOTIFY_SNACKBAR: (state, notifySnackbar) => {
    state.notifySnackbar = { //for notify
      show: false,
      title: null,
      message: null,
      color: null,
      direction: null,
      timeout: 5000,
    }
  },
  TOGGLE_DRAWER: state => {
    state.drawer = !state.drawer
  },
  TOGGLE_IMAGE: state => {
    state.showImage = !state.showImage
  },
  SET_COLOR: (state, color) => {
    state.color = color
    Cookies.set('color', color)
  },
  SET_DRAWER: (state, drawer) => {
    state.drawer = drawer
  },
  SET_IMAGE: (state, image) => {
    state.image = image
  }
}

const actions = {
  toggleSideBar({ commit }) {
    commit('TOGGLE_SIDEBAR')
  },
  toggleLoading({ commit } , loading) {
    commit('TOGGLE_LOADING' , loading)
  },
  toggleNotifySnackbar({ commit } , notifySnackbar) {
    commit('TOGGLE_NOTIFY_SNACKBAR' , notifySnackbar)
  },
  resetNotifySnackbar({ commit }) {
    commit('RESET_NOTIFY_SNACKBAR')
  },
  toggleDrawer({ commit }) {
    commit('TOGGLE_DRAWER')
  },
  toggleImage({ commit }, { withoutAnimation }) {
    commit('TOGGLE_IMAGE', withoutAnimation)
  },
  setColor({ commit }, color) {
    commit('SET_COLOR', color)
  },
  setDrawer({ commit }, drawer) {
    commit('SET_DRAWER', drawer)
  },
  setImage({ commit }, image) {
    commit('SET_IMAGE', image)
  },
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
