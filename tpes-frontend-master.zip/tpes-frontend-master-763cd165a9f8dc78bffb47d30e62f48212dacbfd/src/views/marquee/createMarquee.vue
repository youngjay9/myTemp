<template>
  <v-container>
    <h2 class="font-bold">{{ pageTitle }}</h2>
    <v-row class="ml-10">
      <v-col class="ml-10 font-18px" cols="12">
        <v-form ref="marqueeForm" v-model="valid" class="ml-10 font-weight-bold">
          <v-row
            :dense="dense"
            :no-gutters="noGutters"
            class="d-flex justify-start mt-3"
          >
            <v-col cols="2" md="2">
              跑馬燈名稱
              <span class="red--text ml-2">*</span>
            </v-col>
            <v-col cols="7" md="6">
              <v-text-field
                v-model="marqueeName"
                :rules="rules.requiredRule.concat(rules.lengthRules)"
                :hide-details="hideDatails"
                color="accent"
                placeholder="請輸入跑馬燈名稱，跑馬燈名稱不能重複"
                :counter="maxCharacter"
                outlined
                required
                dense
              />
            </v-col>
          </v-row>
          <v-row :dense="dense" :no-gutters="noGutters">
            <v-col cols="2" md="2"> 描述註記 </v-col>
            <v-col cols="7" md="6">
              <v-text-field
                v-model="marqueeDesc"
                :rules="rules.lengthRules"
                :hide-details="hideDatails"
                color="accent"
                placeholder="請輸入描述註記"
                :counter="maxCharacter"
                outlined
                dense
                persistent-hint
              />
            </v-col>
          </v-row>
          <v-row :dense="dense" :no-gutters="noGutters">
            <v-col cols="2" md="2">
              上架/下架日期
              <span class="red--text ml-2">*</span>
            </v-col>
            <v-col cols="6" class="d-flex">
              <v-menu
                v-model="startDateMenu"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="startDate"
                    placeholder="上架日期(起)YYYY-MM-DD"
                    :rules="rules.requiredRule"
                    append-icon="mdi-calendar"
                    outlined
                    dense
                    hide-details
                    v-bind="attrs"
                    style="width: 100%"
                    clearable
                    @click:append="startDateMenu = true"
                    @blur="checkDate()"
                    v-on="on"
                  />
                </template>
                <v-date-picker
                  v-model="startDate"
                  @input="startDateMenu = false"
                  @change="checkDate()"
                />
              </v-menu>
              <div class="mt-1">~</div>
              <v-menu
                v-model="endDateMenu"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="endDate"
                    placeholder="下架日期(迄)YYYY-MM-DD"
                    :rules="rules.requiredRule"
                    append-icon="mdi-calendar"
                    outlined
                    dense
                    hide-details
                    v-bind="attrs"
                    style="width: 100%"
                    clearable
                    @click:append="endDateMenu = true"
                    @blur="checkDate()"
                    v-on="on"
                  />
                </template>
                <v-date-picker
                  v-model="endDate"
                  @input="endDateMenu = false"
                  @change="checkDate()"
                />
              </v-menu>
            </v-col>
          </v-row>
          <v-row>
            <v-col
              v-if="errMsg.acceptDate !== null"
              cols="2"
              md="2"
              style="margin-top: -25px"
            >
              <span class="red--text font-14px">*錯誤提示： </span>
            </v-col>
            <v-col cols="6" md="6" style="margin-top: -25px">
              <span class="red--text font-14px">{{ errMsg.acceptDate }}</span>
            </v-col>
          </v-row>
          <v-row 
            v-if="marqueeType !== 'DEFAULT'"
            :dense="dense"
            :no-gutters="noGutters"
          >
            <v-col cols="2" md="2"> 審核附件上傳 </v-col>
            <v-col cols="6" md="6">
              <v-file-input
                v-model="attachedFiles"
                :rules="rules.filesSizeRules"
                type="file"
                color="accent"
                label="點擊上傳檔案"
                outlined
                dense
                accept=".xlsx,.xls,image/*,.doc, .docx,.ppt, .pptx,.txt,.pdf"
                persistent-hint
                prepend-inner-icon="mdi-cloud-upload"
                prepend-icon
                show-size
                counter
                chips
                @keydown="resetAttachedFiles(true)"
              />
            </v-col>
          </v-row>
          <v-row 
            v-if="location !== null && marqueeType == 'DEFAULT'"
            :dense="dense"
            :no-gutters="noGutters"
          >
            <v-col cols="7" md="7" class="red--text ml-2"> *預設跑馬燈送出後將於隔日生效，無審核流程。 </v-col>
          </v-row>          
          <v-row
            v-if="location !== null && marqueeType !== 'DEFAULT' && nullAattachedFiles!=null"
            :dense="dense"
            :no-gutters="noGutters"
          >
            <v-col cols="2" md="2"> 審核附件歷史上傳 </v-col>          
            <v-col v-if=" nullAattachedFiles !=='無檔案上傳'" cols="6" md="6">
              <a @click="downloadAttachedFiles">下載查看附件</a>
            </v-col>
            <v-col v-if="nullAattachedFiles=='無檔案上傳'" cols="6" md="6">
              {{ nullAattachedFiles }}
            </v-col>
          </v-row>
          <v-row :dense="dense" :no-gutters="noGutters">
            <v-col cols="2" md="2">
              樣式預覽
              <span class="red--text ml-2">*</span>
            </v-col>
            <v-col cols="6" md="6">
              <marquee-text
                :duration="animationDuration"
                :repeat="1"
                :background-color="backgroundColor"
                :font-color="fontColor"
                class="marquee"
              >
                {{ marqueeHTML }}
              </marquee-text>
            </v-col>
          </v-row>
          <v-row :dense="dense" :no-gutters="noGutters">
            <v-col cols="2" md="2"> 播放速度 </v-col>
            <v-col cols="6" md="6">
              <v-slider
                v-model="duration"
                :min="min"
                :max="max"
                dense
                color="accent"
                thumb-color="accent"
                track-color="accent lighten-3"
                prepend-icon="mdi-minus"
                append-icon="mdi-plus"
                @click:prepend="decrementDuration('minus')"
                @click:append="incrementDuration('plus')"
              />
            </v-col>
          </v-row>
          <v-row>
            <v-col
              v-if="errMsg.editorData !== null"
              cols="10"
              md="10"
              style="margin-top: -25px"
            >
              <span class="red--text font-14px">
                *錯誤提示：{{ errMsg.editorData }}
              </span>
            </v-col>
          </v-row>
          <v-row :dense="dense" :no-gutters="noGutters">
            <v-col cols="9" md="8">
              <quill
                ref="editor"
                :content="marqueeHTML"
                class="quill-marquee"
                @change="onEditorChange($event)"
              />
            </v-col>
          </v-row>

          <v-row v-if="marqueeType !== 'DEFAULT'" :dense="dense" :no-gutters="noGutters">
            <v-col class="d-flex justify-end" cols="8" md="8">
              <v-btn 
                class="ma-1" 
                outlined 
                color="accent" 
                @click="!!location ? $router.go(-1): resetForm()"
              >
                {{ !!location ? '返回':'清空' }}
              </v-btn>
              <v-btn
                class="ma-1"
                depressed
                color="primary"
                :disabled="isAddButtonDisabled"
                @click="submit(false)"
              >
                暫存
              </v-btn>

              <v-btn
                class="ma-1"
                depressed
                color="success"
                :disabled="isAddButtonDisabled"
                @click="checkSubmitFun()"
              >
                送出審核
              </v-btn>
            </v-col>
          </v-row>
          <v-row v-if="marqueeType == 'DEFAULT'" :dense="dense" :no-gutters="noGutters">
            <v-col class="d-flex justify-end" cols="8" md="8">
              <v-btn
                class="ma-1"
                depressed
                color="info"
                :disabled="!valid"
                @click="submit(false)"
              >
                確認
              </v-btn>
            </v-col>
          </v-row>
        </v-form>
      </v-col>
    </v-row>
    <v-dialog v-model="checkSubmit" max-width="500">
      <v-card>
        <v-card-title
          class="text-h5 lighten-2"
          style="background-color: #c62828; color: white"
        >
          無上傳審核附件
          <v-spacer />
          <v-btn
            color="white"
            icon
            small
            text
            @click="checkSubmit = false"
          >
            <v-icon> mdi-close </v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text class="font-24px">
          <v-row class="mt-6 ml-1 font-bold">
            無上傳審核附件，是否仍要送出?
          </v-row>
        </v-card-text>
        <v-card-actions class="d-end mt-6">
          <v-btn color="normal" @click="checkSubmit = false">
            &emsp;取消&emsp;
          </v-btn>
          <v-btn
            color="primary"
            @click="submit(true)"
          >
            &emsp;確定&emsp;
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

  </v-container>
</template>
<script>
import Quill from "@/components/Quill";
import { fetchInitMarquee, fetchQueryMarquee } from "@/api/marquee";
import { downloadMediaSignOffFile} from '@/api/media';
import ValidateUtil from "@/assets/services/validateUtil";
import MessageService from "@/assets/services/message.service";

export default { 

  components: { Quill , },
  beforeRouteEnter(to, from, next) {
    next(vm => {
      vm.prevRoute = from
      
      if(from.path =="/marquee/marqueeEdit"){
        next(`/marquee/redirect`)
      }
    })
  },
  data() {
    return {  
      prevRoute: null,
      errMsg: {
        acceptDate: null,
        editorData: null
      },
      checkSubmit: false,
      sumitOK: false,
      pageTitle: "跑 馬 燈 製 作",
      startDateMenu: false,
      endDateMenu: false,
      startDate: "",
      endDate: "",
      valid: false,
      maxCharacter: 255,
      duration: 30,
      min: 0,
      max: 60,
      fileNo:null,
      marqueeName: null,
      marqueeHTML: `<p><span style="background-color: rgb(204, 224, 245);">請先輸入跑馬燈內容後，再進行播放速度調整。</span></p>`,
      marqueeText: "",
      marqueeDesc: "",
      marqueeType: "",
      attachedFiles: null,
      nullAattachedFiles: null,
      fontColor: "#000000",
      backgroundColor: "#ffffff",
      dense: false,
      noGutters: false,
      hideDatails: false,
      isSubmited: false,
      location: "",
      rules: {
        requiredRule: [v => !!v || "此欄位為必填欄位"],
        lengthRules: [
          v =>
            (v || "").length <= this.maxCharacter ||
            "Description must be 255 characters or less"
        ],
        /*filesSizeRules: [
          attachedFiles =>
            !attachedFiles ||
            !attachedFiles.some(attachedFiles => attachedFiles.size > 25e6) ||
            "檔案大小超過 25 MB!"
        ] 多檔案使用*/
        filesSizeRules: [
          v => !v || v.size < 25e6 || "檔案大小超過 25 MB!"
        ]
      }
    };
  },
  computed: {
    isAttachedFiles() {
      let isTrue = true;
      if (this.attachedFiles !== null) {
         isTrue = true;
      } else {
        isTrue = false;
      }
      return isTrue;
    },
    editor() {
      return this.$refs.Quill;
    },
    isAddButtonDisabled() {
      return !this.valid || this.isSubmited;
    },
    animationDuration() {      
      return Math.round(600 / this.duration);
    }
  },
  created() {
    this.getQueryString("id");  
    if (this.location !== "" && this.location !== null) {
      this.queryMarqueeById();
    }
   },
  mounted() {       
      
      this.onEditorChange(this.marqueeHTML);
  },
  methods: {
    refresh() { 
        const { fullPath } = this.$route;
        this.$router.replace({
          path: "/marquee/redirect",
          query: { path: fullPath }
      }); 
    
    },
    getQueryString(name) {
      // eslint-disable-next-line no-sparse-arrays
      this.location = decodeURIComponent((new RegExp("[?|&]" + name + "=" + "([^&;]+?)(&|#|;|$)").exec(location.href) || [, ""])[1].replace(/\+/g, "%20")) || null;
    },
    queryMarqueeById() {
      fetchQueryMarquee({ marqueeId: this.location })
        .then(res => {
          if (res.restData.code == "00000") {
                let fileName = null;
                let result = Object.assign({}, res.restData.marquee);
            this.pageTitle = "跑 馬 燈 編 輯";
            MessageService.showInfo(res.restData.message, "成功✓");
            this.marqueeName = result.marqueeName;
            this.content = result.marqueeContentHTML;
            this.marqueeType = result.marqueeType;
            this.marqueeText = result.marqueeContent;
            this.marqueeHTML = result.marqueeContentHTML;
            this.duration = Math.round(600 / result.animationDuration) ;
            this.marqueeDesc = result.memo;
            this.startDate = result.releaseStartDate;
            this.endDate = result.releaseEndDate;
            if(res.restData.signAttachment !== null){
              let resultSign = Object.assign({}, res.restData.signAttachment);
              this.fileNo = resultSign.id;
              fileName = new File(["queryFile"], resultSign.originalFileName,);
              this.attachedFiles = fileName;
              this.nullAattachedFiles = fileName;
            }else{
              this.attachedFiles = null;
              this.nullAattachedFiles = "無檔案上傳";
            }           
            //result.attachedFileName;
          } else if (res.restData.code == "20001") {
            MessageService.showError("查詢失敗", res.restData.message);
            this.$router.push({ path: '/marquee/queryList'})
          }else{
             MessageService.showError("查詢失敗", res.restData.message);
             this.$router.push({ path: '/marquee/queryList'})
          }
        })
        .catch(error => {
          this.isSubmited = false;
          console.error(error);
        });
    },
    filtersHTML(val) {
      if (val != null && val != "") {
        let reg = /<[^>]+>/g;
        return val.replace(reg, "");
      } else {
        return "";
      }
    },
    filtersBr(val) {
      if (val != null && val != "") {
        let reg = /<br>/g;
        return val.replace(reg, "");
      } else {
        return "";
      }
    },
    filtersH_Header(val) {
      if (val != null && val != "") {
        let regS = /<h\d+>/g; //remove <h[0-9]>
        let regE = /<\/h\d+>/g; //remove </h[0-9]>
        return val.replace(regS, "").replace(regE, "");
      } else {
        return "";
      }
    },
    checkDate() {
      this.errMsg.acceptDate = null;
      let hasCheck = true;
      // 1-1 輪播起迄日都有選擇
      if ( !ValidateUtil.isEmpty(this.startDate) && !ValidateUtil.isEmpty(this.endDate)) {
        if (!ValidateUtil.validateDateRange(this.startDate, this.endDate)) {
          this.errMsg.acceptDate =
            "上架日期選擇範圍錯誤，起始日期不得大於結束日期";
          hasCheck = false;
          this.valid = false;
        } else {
          this.errMsg.acceptDate = null;
        }
      // 1-2 判斷輪播起迄日只有其中一欄有選擇日期
      } else if ( !ValidateUtil.isEmpty(this.startDate) || !ValidateUtil.isEmpty(this.endDate) ) {
        this.errMsg.acceptDate = "上架日期未選擇完整範圍";
        hasCheck = false;
        this.valid = false;
        // 1-3 判斷輪播起迄日欄位皆未選擇
      } else if ( ValidateUtil.isEmpty(this.startDate) || ValidateUtil.isEmpty(this.endDate)) {
        this.errMsg.acceptDate = "上架日期(起-訖)必填";
        hasCheck = false;
        this.valid = false;
      } else {
        this.errMsg.acceptDate = "上架日期(起-訖)必填";
      }
      if(hasCheck) {
        this.valid = true;
      }
      return hasCheck;
    },
    downloadAttachedFiles(){
      downloadMediaSignOffFile({
          mediaSignType: "MEDIA_MARQUEE",
          relatedSeq: this.location
      });
    },
    checkSubmitFun(){
      
      if(this.attachedFiles == null || this.attachedFiles.size <= 0) {
        this.checkSubmit = true;
      }else{
        this.submit(true);
      }

    },
  
    submit(isSign) {    
      if (!this.$refs.marqueeForm.validate()) {
        return
      }
      //if (this.$refs.form.validate()) {
      var formData = new FormData();
      if (this.checkDate() && this.onEditorChange) {
        
        /**多檔案要跑回圈 */
        // if(this.attachedFiles) {
        // for (let file in this.attachedFiles) {
        //   formData.append("attachedFiles", file);
        // }
        
        if (this.attachedFiles) {
          formData.append("attachedFiles", this.attachedFiles);
        }
        formData.append(
          "properties",
          new Blob(
            [
              JSON.stringify({
                marqueeId: this.location,
                fileNo: this.fileNo,
                marqueeName: this.marqueeName,
                marqueeType : this.marqueeType =='' ? 'GENERAL': this.marqueeType  ,
                marqueeContent: this.marqueeText,
                marqueeContentHTML: this.marqueeHTML,
                animationDuration: this.animationDuration,
                memo: this.marqueeDesc,
                region: null,
                releaseStartDate: this.startDate,
                releaseEndDate: this.endDate,
                sign: isSign
              })
            ],
            {
              type: "application/json"
            }
          )
        );
        

        fetchInitMarquee(formData)
          .then(res => {
            
            if (res.restData.code == "00000") {
              MessageService.showInfo(res.restData.message, "成功✓");
              this.isSubmited = true;
              this.location = res.restData.marquee[0].marqueeId
              if(isSign){ //送出審核才進行畫面清空
                this.resetForm();
              }
              this.isSubmited = false;
            } else if (res.restData.code == "20001") {
              MessageService.showError("儲存失敗", res.restData.message);
            }else{
              MessageService.showError(res.restData.message);
            }
          })
          .catch(error => {
            this.isSubmited = false;
            console.error(error);
          });
      }
      this.checkSubmit =  false;
    },
    resetAttachedFiles(){
     

    },
    resetForm() {
      this.isSubmited = false;
      this.marqueeHTML= null;
      this.marqueeName = null;
      this.marqueeDesc = null;
      this.startDate = null;
      this.endDate = null;
      this.attachedFiles = null;
      this.nullAattachedFiles = null;
      this.location = null;
      this.reset();
    },
    validate() {
      this.$refs.marqueeForm.validate();
    },
    reset() {
      this.$refs.marqueeForm.reset();
      this.duration = 30; //重製撥放速度
    },
    resetValidation() {
      this.$refs.marqueeForm.resetValidation();
    },
    decrementDuration() {
      //減慢播放
      this.duration = this.duration - 1 || 0;
       if( this.duration <=1)
      this.duration = 3;
    },
    incrementDuration() {
      //加快播放
      this.duration = this.duration + 1 || 0;
    },
    onEditorChange(val) {
      let hasCheck = true;
      //取代編輯器換行
      this.marqueeHTML = this.filtersBr(val);
      //取得編輯完成純文字
      this.marqueeText = this.filtersHTML(val);
      //取代H Header
      this.marqueeHTML = this.filtersH_Header(val);
      //判斷編輯器內容長度至少大於等於2 初始""\n"
      let s = 0;
        for(var i = 0; i < this.marqueeText.length; i++) {
          if(this.marqueeText.charAt(i).match(/[u0391-uFFE5]/)) {
            s += 2;
          } else {
            s++;
          }
        }
      
      if(s > 255){
        this.errMsg.editorData = "跑馬燈文字超過255長度";
        this.isSubmited = true;
      }
      else if (this.marqueeText.length <= 2) {
        this.errMsg.editorData = "跑馬燈內容必填";
        this.isSubmited = true;
      } else {
        this.errMsg.editorData = null;
        this.isSubmited = false;
      }
      
      return hasCheck;
    }
  }
};
</script>
<style lang="scss" scoped>
.marquee {
  height: 70px;
  font-family: Helvetica, Arial, sans-serif, "Microsoft JhengHei", "微軟正黑體",
    "Helvetica", sans-serif;
}
span.marquee > h1,
h2,
h3,
.h1,
.h2,
.h3 {
  margin-top: 0px;
  margin-bottom: 0px !important;
}
span.marquee > p {
  font-size: 32px !important;
  margin: 0px;
  font-weight: normal !important;
  display: inline;
}
span.marquee {
  font-size: 32px !important;
  margin: 0px;
  font-weight: normal !important;
  display: inline;
}
span.marquee > span {
  font-weight: normal !important;
  font-size: 32px !important;
}
.quill-marquee .ql-editor {
  font-weight: normal !important;
  line-height: 1.42;
  height: 150px;
  font-size: 32px;
}
.marquee .ql-editor p {
  font-weight: normal !important;
  font-size: 32px !important;
}
.marquee .ql-editor.ql-size-small {
  font-size: 0.75em !important;
}
.marquee .ql-editor.ql-size-large {
  font-size: 1.2em !important;
}
.marquee .ql-editor.ql-size-huge {
  font-size: 1.35em !important;
}
</style>

<style>
/*需要覆蓋 全域的粗體樣式以及大小 此處style 不加上scoped申明 加上class .quill-marquee 避免衝突*/
.quill-marquee .ql-editor p {
  font-weight: normal !important;
  font-size: 32px !important;
}
.quill-marquee .ql-container.ql-snow {
  height: auto;
  font-weight: normal !important;
}
.quill-marquee .ql-size-small {
  font-size: 0.75em !important;
}
.quill-marquee .ql-size-large {
  font-size: 1.2em !important;
}
.quill-marquee .ql-size-huge {
  font-size: 1.35em !important;
}
span.quill-marquee > b,
strong {
  font-weight: bolder !important;
  font-size: inherit !important;
}
</style>