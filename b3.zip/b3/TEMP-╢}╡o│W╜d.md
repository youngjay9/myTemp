[[_TOC_]]

***
## 系統、軟體架構

### 	AP



### 	DB



### 	Framework  (以下版本皆為初始化版本，未來視情況統一調整)



### 分層職責 

> 實作程式碼時需注意自己時寫的邏輯，是否有違背以下分層邏輯

#### View (HTML、JSP、JS) 層

> 負責處理UI顯示的資料與邏輯，與呈現有關的資料於此處理

  

#### Controller層



#### Service層



#### DAO層


#### Mapper層


#### 因應使用MyBatis + MP的特別說明 



#### Package分類補充說明


----

## Table

### 命名

  - Table命名需以功能模組名稱<font color='red'>{-XXX_-}</font>開頭，結尾不可使用保留字元<font color='red'>{-List、Set、Map-}</font>，待實際設計Table時，共同討論決議(此專案特殊需求) 

    - 例：XXX活動 > Table Name：<font color='red'>{-XXX_-}</font>campaign

    - 例：XXX客戶 > Table Name：<font color='red'>{-XXX_-}</font>user

  - Table column 若是流水號，請使用資料表名+id

    - 例：
      XXX活動 > Table Name：<font color='red'>{-XXX_-}</font>campaign
      
      XXX活動 id 流水號 > column id Name：<font color='red'>{-XXX_campaign_-}</font>id

  - Table Comment寫法規範

    - 單純描述無限制，若有多種屬性值，需要依照以下範例命名，且中間每個符號或文字皆需空一格空白鍵
    - 文字說明例："描述" + "冒號" + "欄位值" + "=" + "說明" + "分號" + "冒號" + "欄位值" + "=" + "說明" + "分號"

      例：

      狀態 : 0 = 啟用 ; 1 = 停用 ; 2 = 停用 ; draft = 停用

### 特別注意事項



----

## Java

### 編碼

  - 一律使用 UTF-8

### 命名

  - Class命名必須用首字母<font color='red'>{-大-}</font>寫駝峰式(StudlCaps)

  - Class常數必須全部用大寫字母命名，多個單字之間用(<font color='red'> {-_-} </font>)下底線連接

  - Controller Method命名必須用首字母<font color='red'>{-小-}</font>寫駝峰式(camelCase)

    - [Controller Method、Annotation Path、Security Path、Job，說明](https://docs.google.com/spreadsheets/d/1p_6ELNhTZur3oBABEwER6GD4LYuTxZGCXN86H-QmZoE/edit?usp=sharing)

    - private Method不在以上命名限制內，但依舊必須用首字母小寫駝峰式(camelCase)，且命名須能充分表達該商業邏輯的意義

  - Service Class命名方式

    - 商業邏輯名稱 + <font color='red'>{-Service-}</font>不可新增interface，<font color='red'>{+若有需要另外提出討論+}</font>

      例：Ticket<font color='red'>{-Service-}</font>

  - Service or DAO Method命名無Controller Method的命名限制，但依舊必須用首字母小寫駝峰式(camelCase)，且命名須能充分表達該商業邏輯的意義

  - Dao命名方式：
    <font color='red'>{-大寫 I-}</font> + 駝峰式&字首大寫 + <font color='red'>{-Dao-}</font>
    例：<font color='red'>{-I-}</font>XmlSqlScript<font color='red'>{-Dao-}</font>
    
  - Mapper命名方式：
    字首大寫 + 駝峰式 +<font color='red'>{- ExtendMapper-}</font>
    例：<font color='red'>{-X-}</font>mlSqlScript<font color='red'>{-ExtendMapper-}</font>
    
  - Entity命名方式：
    字首大寫 + 駝峰式
    例：<font color='red'>{-T-}</font>icketInfo
    
  - Mapper SQL ID命名方式：

    - 查詢以<font color='red'>{-select-}</font>開頭
      例：<font color='red'>{-select-}</font>ByPrimaryKey

    - 新增以<font color='red'>{-insert-}</font>開頭
      例：<font color='red'>{-insert-}</font>Selective

    - 修改以<font color='red'>{-update-}</font>開頭
      例：<font color='red'>{-update-}</font>ByPrimaryKeySelective

    - 刪除以<font color='red'>{-delete-}</font>開頭。
      例：<font color='red'>{-delete-}</font>ByPrimaryKey
    
  - Java Vo / Bean 命名方式：
    字首大寫 + 以<font color='red'>{-Vo-}</font>結尾
    例：<font color='red'>{-T-}</font>icket<font color='red'>{-Vo-}</font>.java

  - 變數 命名方式，首字母小寫駝峰式(camelCase)：

    - 布林 以<font color='red'>{-is-}</font>開頭

      例：boolean <font color='red'>{-is-}</font>Success = true;
      
    - 字串 以<font color='red'>{-str-}</font>開頭

      例：String <font color='red'>{-str-}</font>Name;

    - 數值 Integer & int 以<font color='red'>{-int-}</font>開頭

      例：int <font color='red'>{-int-}</font>Age;

    - 數值 BigDecimail 以<font color='red'>{-bd-}</font>開頭

      例：BigDecimal <font color='red'>{-bd-}</font>Price;

    - 數值 Long 以<font color='red'>{-lg-}</font>開頭

      例：Long <font color='red'>{-lg-}</font>Price;

    - 時間 LocalDateTime & LocalDate & LocalTime 以<font color='red'>{-dt-}</font>開頭

      例：LocalDateTime <font color='red'>{-dt-}</font>Brithy;

    - 集合 Collection interface 以下僅列常用，若有特殊需求沒在以下列出，請另外提出討論

      - list 以<font color='red'>{-Ls-}</font>結尾

        例：List<Object> objects<font color='red'>{-Ls-}</font> = new ArrayList<>();

      - set 以<font color='red'>{-Set-}</font>結尾

        例：Set<Object> object<font color='red'>{-Set-}</font> = new HashSet<>();

    - 集合 Map interface 以下僅列常用，若有特殊需求沒在以下列出，請另外提出討論

      - HashMap 以<font color='red'>{-Mp-}</font>結尾

        例：Map<String ,String> object<font color='red'>{-Mp-}</font> = new HashMap<>();

  - Mybatis-Plus ActiveRecord模式 命名方式，首字母小寫駝峰式(camelCase)：

    - 查詢物件 以<font color='red'>{-query-}</font>開頭

      例：

      Operator <font color='red'>{-query-}</font>Operator = new Operator();
      List<Operator> operatorLs = <font color='red'>{-query-}</font>Operator.selectAll();

  - Mybatis-Plus LambdaQueryWrapper模式 命名方式，首字母小寫駝峰式(camelCase)：

    - 查詢物件 以<font color='red'>{-物件名稱-}</font>開頭 + <font color='blue'>{+LambdaQueryWrapper+}</font>

      例：

      Operator queryOperator = new Operator();

      LambdaQueryWrapper<Operator> <font color='red'>{-operator-}</font><font color='blue'>{+LambdaQueryWrapper+}</font> = new LambdaQueryWrapper<>();
      <font color='red'>{-operator-}</font><font color='blue'>{+LambdaQueryWrapper+}</font>.eq(Operator::getName, "test");
      queryOperator.selectList(<font color='red'>{-operator-}</font><font color='blue'>{+LambdaQueryWrapper+}</font>);

  - Mybatis-Plus ActiveRecord模式 命名方式，首字母小寫駝峰式(camelCase)：

    - 查詢物件 以<font color='red'>{-query-}</font>開頭

      例：

      Operator queryOperator = new Operator();
      
      List<Operator> operatorLs = queryOperator.selectAll();

### 排版

  - 程式碼必須用 Tab(4個半形空白)做縮排，不是空白

  - 若非閱讀上的困難，程式碼勿強行換行

  - method 開始左大括弧不換下一行，結束右大括弧必須要換到程式碼下一行

    > 正確排版

    ```java
    public String queryTicket(Model model, TicketQueryVo ticketQueryVo) {
    	return Const.Layout.INDEX;
    }
    ```
    > 專案禁用排版1
    ```java
    public String queryTicket(Model model, TicketQueryVo ticketQueryVo)
    {
    	return Const.Layout.INDEX;
    }
    ```
    > 專案禁用排版2
    ```java
    public String queryTicket(Model model, TicketQueryVo ticketQueryVo){
    	return Const.Layout.INDEX;}
    
  - 禁止使用IDE工具自帶的formate
  
- Coding Style

  - Null or Empty or Whitespace only 的判斷

       > 字串 正確寫法

      ````java
      //字串
      String strName = new User().getName();
      if(StringUtils.isBlank(strName)){
          System.out.println(strName);
      }
      if(StringUtils.isNotBlank(strName)){
          System.out.println(strName);
      }
      ````

       > 字串 專案禁用寫法

       ````java
       //字串
       String strName = new User().getName();
       if(strName == ""){
           System.out.println(strName);
       }
       if(strName != ""){
           System.out.println(strName);
       }
       ````

       > 物件 正確寫法

       ````java
       //物件
       User user = new User();
       if(user != null){
           String strName = User.getName();
           if(StringUtils.isNotBlank(strName)){
           	System.out.println(strName);
       	}
       }
       ````

       >物件  專案禁用寫法

       ````java
       //物件
       User user = new User();
       if(!Objects.isNull(user)){
           String strName = User.getName();
           if(!Objects.isNull(strName)){
               if(strName != ""){
                   System.out.println(strName);
               }
       	}
       }
       ````

  - 不可重複嵌套三元運算子，只能一層；意即不可以在裡面的判斷式再放一個三元運算子

    > 正確寫法

    ```java
    String strName = "peiven";
    if ("peiven".equals(strName) ? true : false){
    	System.out.println(strName);
    }
    if ("owen".equals(strName) ? true : false){
    	System.out.println(strName);
    }
    ```

    > 專案禁用寫法

    ```java
    String strName = "peiven";
    if ("peiven".equals(strName) ? true : "owen".equals(strName) ? true : false : "null"){
    	System.out.println(strName);
    }
    ```

  - 判斷式內不可使用method return值做條件
    > 正確寫法

    ```java
    boolean isDelUser = userServiceImpl.delUserById();
    if (isDelUser){
    	System.out.println("delete success");
    }
    ```
    > 專案禁用寫法

    ```java
    if (userServiceImpl.delUserById()){
    	System.out.println("delete success");
    }
    ```

- 註解

  - 註解一定要寫，Class & Method，請用以下格式註解

    ```java
        /**
         * <p>
         * 依照頁面傳入 id 查詢 Template
         * </P>
         *
         * @param mav    - ModelAndView 物件
         * @param htmlId - HTML模版流水號 <code>{@link UiHtmlTemplateVo#getHtmlId()}</code>
         * @return ModelAndView - 頁面所需資料
         */
        @RequestMapping(value = "/r")
        public ModelAndView queryTemplate(ModelAndView mav, @RequestParam(name = "id", required = false) String htmlId) {
            return mav;
        }
    ```

  - 其他程式內幫助閱讀的註解可用單行註解即可

    ```java
    //新增或修改是否成功，預設值:true (true=成功 / false=失敗)
    boolean isSuccess = true;
    
    //回傳的訊息(成功或失敗的訊息)
    String strMessage;
    
    //檢查頁面輸入資料
    strMessage = checkParam(uiHtmlTemplate);
    ```

- Log

  - 請使用LogHandler.java元件紀錄Log

  - 務必於每個Method的進入點、處理值、回傳值及結束點，寫上Log，提供一個完整流程的Log，使用的是LogHandler.java內的fetInfo

    ```java
    /**
     * <p>
     * 依照頁面傳入 id 查詢 Template
     * </P>
     *
     * @param clazz
     * @param stackTrace
     * @param status LOG_START(Method Start), LOG_VALUE(In/Output Value), LOG_END(Method End) 
     * @param message
     * @param value
     */
    public static void fetInfo(Class<?> clazz, StackTraceElement[] stackTrace, String status, Object message, Object value) {
    ```

  - Log寫入範例

    ```java
    public ResultBean delUsers(@RequestParam(value = "deleteUsers") List<Integer> fetUsersIds, Authentication authentication) {
       // 取得 LOG 所需變數
       StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
    
       //Log紀錄delUsers開始
       LogHandler.fetInfo(this.getClass(), stackTrace, SysConst.LOG_START, "取得使用者列表總筆數");
    
       //Log紀錄Call userService.deleteUsers input fetUsersIds的值
       LogHandler.fetInfo(this.getClass(), stackTrace, SysConst.LOG_VALUE, "fetUsersIds", fetUsersIds);
    
       String returnMsg = userService.deleteUsers(fetUsersIds, loginAccount);
    
       //Log紀錄userService.deleteUsers output returnMsg的值
       LogHandler.fetInfo(this.getClass(), stackTrace, SysConst.LOG_VALUE, "returnMsg", returnMsg);
    
       //Log紀錄delUsers結束
       LogHandler.fetInfo(this.getClass(), stackTrace, SysConst.LOG_END, "取得使用者列表總筆數");
       return resultGenerator.getSuccessResult(returnMsg);
    }
    
    ```
  
- Error Handing

  - 目前往外拋出的異常皆會由GlobalExceptionHandlingControllerAdvice接走最後的Exception，此步驟的異常會直接轉導到404 Error，此部分目前暫時未完全定義完成，待討論

----

## JavaScript

### 編碼

  - 一律使用UTF-8

### 命名

  - 變數命名採用首字母小寫駝峰式(camelCase)

  - 屬性命名採用首字母小寫駝峰式(camelCase)

  - 常數用一般方式宣告，採用全部大寫字母命名，多個單字之間用(<font color='red'>{- _ -}</font>)下底線連接

  - 布林值變數和 function 回傳布林值永遠設 true 或 false，不要用 0，除非這個變數有可能是數字

  - 一律使用let宣告，不可使用var，除非特殊需求請提出討論

    例：

    ````javascript
    /*[- */ 使用let /* -]*/
    let ctxPath = /*[[@{/}]]*/ '';
    
    /*[- */ 不可使用var /* -]*/
    var ctxPath = /*[[@{/}]]*/ '';
    ````


### 排版

  - 程式碼必須用 Tab(4個半形空白)做縮排，不是空白

  - function開始左大括弧不換下一行，結束右大括弧必須要換到程式碼下一行

    例：

    > 正確寫法

    ````javascript
    $("#submit").click(function() {
        $("#name").val($("#templateTempName").val());
        $("#targetForm").submit();
    });
    ````

    > 專案禁用寫法

    ````javascript
    $("#submit").click(function()
    {
        $("#name").val($("#templateTempName").val());
        $("#targetForm").submit();
    });
    ````

  - function不需強制換行

    ````javascript
    $("#submit").click(
        function() {
            $("#name").val($("#templateTempName").val());
            $("#targetForm").submit();
        }
    );
    ````


### 註解

  - 使用Thymeleaf的時候：

    - HTML區塊：
      - 顯示註解：

    ````html
    <!-- 與使用JSP or 純HTML的用法相同 -->
    ````

    - 隱示註解：

    ````html
    <!--/* 單行隱示註解 */-->
    
    <!--/*
    多行隱示註解
    多行隱示註解
    多行隱示註解
    */-->
    ````

  - JavaScript區塊：

    - 顯示註解(原始碼可以看到註解內容)：
    
    ````javascript
    //與使用JSP or 純HTML的用法相同
    ````

      - 隱示註解(原始碼無法看到註解內容)：
    
    ````javascript
    /*[- */ 單行隱示註解 /* -]*/
    
    /*[- */
    多行隱示註解
    多行隱示註解
    多行隱示註解
    /* -]*/
    ````

  - 使用JSP or 純HTML的時候：

    - HTML區塊：

    ````html
    <!-- 單行註解 -->
    
    <!-- 
    多行註解
    多行註解
    多行註解
    -->
    ````

    - JavaScript區塊：

    ````javascript
    //單行註解
    
    /*
     * 多行註解
     * 多行註解
     */
    ````

- JavaScript程式碼位置

  - 因應使用Thymeleaf Layout plugin的限制，import JavaScript請放在最外層index.html`<head></head>`裡面，若非Plugin的因素，需放在HTML最後的`</Body>`外`</HTML>`內，<font color='red'>{-另外，若有特殊需求示在特定頁面才會使用到，另外提出討論-}</font>

----

## 測試資料規範(PT、SIT)

- 規範目的：
  	- 避免後期大量測試時，各個測試人員之間，發生資料錯亂導致須另外花時間釐清資料問題
- 方式：
  	- 建立資料以自己的英文名字為prefix後面加上功能名稱與3碼(001)編號開始(駝峰寫法開頭小寫)，以下以使用者與群組列為例，要測試的時候請盡量自行建立測試群組與使用者，若非必要勿使用他人建立的測試資料，若需使用，請與建立人協調後使用
- 範例：
   - 使用者帳號為系統唯一登入值，且包含要發送email，基本上不會有不存在的假mail，但若要略過發送mail，僅是做CRUD的測試，則使用使用以下編碼方式
      - 新增User測試資料
      
         使用者帳號：peiven、owen、sky
         
         使用者帳號：<font color='red'>{-peiven-}</font>User<font color='red'>{-001-}</font>
         
         使用者帳號：<font color='red'>{-owen-}</font>User<font color='red'>{-002-}</font>
         
         使用者帳號：<font color='red'>{-sky-}</font>User<font color='red'>{-003-}</font>
      
       使用者姓名：<font color='red'>{-peiven-}</font>User<font color='red'>{-001-}</font>
      
       使用者姓名：<font color='red'>{-owen-}</font>User<font color='red'>{-002-}</font>
      
       使用者姓名：<font color='red'>{-sky-}</font>User<font color='red'>{-003-}</font>
      
     - 群組管理內的新增群組
     
       群組名稱：<font color='red'>{-peiven-}</font>Group<font color='red'>{-001-}</font>業務部
     
       群組名稱：<font color='red'>{-owen-}</font>Group<font color='red'>{-001-}</font>業務部
     
       群組名稱：<font color='red'>{-sky-}</font>Group<font color='red'>{-001-}</font>行銷部
     
       群組名稱：<font color='red'>{-sky-}</font>Group<font color='red'>{-002-}</font>業務部
     
       群組名稱：<font color='red'>{-owen-}</font>Group<font color='red'>{-001-}</font>產品部
     
       群組名稱：<font color='red'>{-owen-}</font>Group<font color='red'>{-002-}</font>產品部
     
     - 活動管理內的新增活動
     
       活動名稱：<font color='red'>{-peiven-}</font>Campaign<font color='red'>{-001-}</font>AAA簽到
       
       活動名稱：<font color='red'>{-sky-}</font>Campaign<font color='red'>{-002-}</font>BBB卷
       
       活動名稱：<font color='red'>{-owen-}</font>Campaign<font color='red'>{-001-}</font>CCC簽到
       
       活動名稱：<font color='red'>{-sky-}</font>Campaign<font color='red'>{-002-}</font>DDD電影票
       
       活動名稱：<font color='red'>{-peiven-}</font>Campaign<font color='red'>{-001-}</font>EEE卷

## 版本紀錄

  - 此規範仍有不完整之處，若有任何建議皆可提出討論

| Version | Name              | Date       |
| ------- | ----------------- | ---------- |
| 0.0.1   | XXXXXXXXXXXXXXXXX | 2021/10/01 |