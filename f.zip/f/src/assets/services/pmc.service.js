import WS from '@/assets/services/pmc.ws';
import EventBus from './eventBus';
class PMCService {
    constructor(){
        this.ws = WS;
        this.ws.Connect();
    }
     
    uuidv4 () {
        return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
          (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
    }

    //證件拍攝器
    async callWebScanAdapter () {
        //var message = document.getElementById("txtMessage").value;
        var uuid = this.uuidv4();
    
        var message = JSON.stringify({
            'REQUEST_UUID': uuid,
            'DeviceName': 'WebScanAdapter'
        });
        this.ws.SendMessage(message, function (code, message, data) {
            // call back function here
            
            
            // parse json
            var json = JSON.parse(data);
        
            // check request UUID = response UUID
            if(uuid === json.REQUEST_UUID){
                
            } else {
                console.error.log('-->request UUID = response UUID check fail.')
            }
        
            
            
            
            

            if(json.RESULT_CODE === 'FAIL') {
                // $.gritter.add({
                //     // (string | mandatory) the heading of the notification
                //     title: '錯誤!',
                //     // (string | mandatory) the text inside the notification
                //     text: 'PMC回傳:'+json.RESULT_MESSAGE,
                //     // (string | optional) the image to display on the left
                //     image: 'images/error.png',
                //     // (bool | optional) if you want it to fade out on its own or just sit there
                //     sticky: false,
                //     // (int | optional) the time you want it to be alive for before fading out
                //     time: ''
                // });

                EventBus.publish("scan-error", json.RESULT_MESSAGE);
            }
            
            if(json.DeviceName === 'WebScanAdapter') {
                for (var i = 0; i < json.ADAPTER_DATA.length; i++) {
                    var adapterdata = json.ADAPTER_DATA[i];
                    
                    
                    
                    var img = document.createElement('img');
                    img.src = 'data:image/jpg;base64,' + adapterdata.BASE64STR;
                    img.style.cssText = 'max-width:300px;max-height:400px;'
                }
            }
            EventBus.publish("scan-data-list", json.ADAPTER_DATA);
        });
    }

    cleanImg () {
        const myNode = document.getElementById('scanimage');
        myNode.innerHTML = '';
    }

    //開啟新網頁(Chrome)
    callBrowserAdapter (url) {
        var uuid = this.uuidv4();
        
        var timestamp = Date.now();
    
        var message = JSON.stringify({
            'REQUEST_UUID': uuid,
            'DeviceName': 'BrowserAdapter',
            'Action':'Chrome',
            'URL': url,
            'urlDecodeFlag': 'false',
            'timestamp': timestamp.toString()
        });

        this.ws.SendMessage(message, function (code, message, data) {
            // call back function here
            
            
            // parse json
            var json = JSON.parse(data);
    
            // check request UUID = response UUID
            if(uuid === json.REQUEST_UUID){
                
            } else {
                console.error.log('-->request UUID = response UUID check fail.')
            }
    
            
            
            
            
        });
    }

    //切換延伸螢幕
    callDualScreenAdapterExtend () {
        this.callDualScreenAdapter('SwitchMonitorToExtend');
    }

    //切換同步螢幕
    callDualScreenAdapterClone () {
        this.callDualScreenAdapter('SwitchMonitorToClone');
    }

    //DualScreenAdapter
    callDualScreenAdapter (action) {
        var uuid = this.uuidv4();
    
        var message = JSON.stringify({
            'REQUEST_UUID': uuid,
            'DeviceName': 'DualScreenAdapter',
            'Action': action
        });
        
        this.ws.SendMessage(message, function (code, message, data) {
            // call back function here
            
            
            // parse json
            var json = JSON.parse(data);
    
            // check request UUID = response UUID
            if(uuid === json.REQUEST_UUID){
                
            } else {
                console.error.log('-->request UUID = response UUID check fail.')
            }
    
            
            
            
            
        });
    }
}

export default new PMCService();