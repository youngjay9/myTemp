import axios from 'axios'
import store from '@/store'
import MessageService from '@/assets/services/message.service.js';
import EventBus from '@/assets/services/eventBus.js';
import LoadingConfig from '@/assets/constant/loadingConfig.js';

//檢查回傳JSON是否為BLOB
const isJsonBlob = (data) => data instanceof Blob && data.type === "application/json";

// 將blob物件轉化為json（檔案型別呼叫ajax 取後端的返回值做特殊處理）
const fileToJson = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = res => {
      const data = JSON.parse(res.target.result) // 解析成json物件
      
      resolve(data)
    } // 成功回傳
    reader.onerror = err => {
      reject(err)
    } // 失敗回傳
    reader.readAsText(file, 'utf-8') // 按照utf-8編碼解析
  })
}

// create an axios instance
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url
  // `xsrfCookieName` is the name of the cookie to use as a value for xsrf token
  xsrfCookieName: 'XSRF-TOKEN', // default
  // `xsrfHeaderName` is the name of the http header that carries the xsrf token value
  xsrfHeaderName: 'X-XSRF-TOKEN', // default
  headers: { 
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*', 
  }, //body content type
  withCredentials: true, // send cookies when cross-domain requests
  timeout: 50000 // request timeout
})

// request interceptor
service.interceptors.request.use(
  config => {
    // ** do something before request is sent **//

    // 使用 Vuetify 的 <v-overlay> <v-progress-circular> 開啟Loading畫面
    // EventBus.publish('toggleLoading', true); /* 開啟loading小圈圈 */
    store.dispatch('app/toggleLoading' , true)
    LoadingConfig.hasLoader = true;

    // if (store.getters.token) {
    //   // let each request carry token
    //   // ['X-Token'] is a custom headers key
    //   // please modify it according to the actual situation
    //   config.headers['X-Token'] = getToken()
    // }
    return config
  },
  error => {
    // do something with request error

    //送出請求錯誤後 關閉loading
    LoadingConfig.blockCount--;
    if(LoadingConfig.blockCount <= 0){
    // 3 關掉loading 小圈圈
      LoadingConfig.blockCount = 0;
      if(LoadingConfig.hasLoader){
        // EventBus.publish('toggleLoading', false); /* 關閉loading小圈圈 */
        store.dispatch('app/toggleLoading' , false)
        LoadingConfig.hasLoader = false;
      }
    }
    MessageService.showError('送出請求發生錯誤');

    return Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  /**
   * If you want to get http information such as headers or status
   * Please return  response => response
  */

  /**
   * Determine the request status by custom code
   * Here is just an example
   * You can also judge the status by HTTP Status Code
   */
  response => {

    LoadingConfig.blockCount--;
    if(LoadingConfig.blockCount <= 0){
    // 3 關掉loading 小圈圈
      LoadingConfig.blockCount = 0;
      if(LoadingConfig.hasLoader){
        // EventBus.publish('toggleLoading', false); /* 關閉loading小圈圈 */
        store.dispatch('app/toggleLoading' , false)
        LoadingConfig.hasLoader = false;
      }
    }
    const { data, headers } = response
    
    const res = response.data
    // if the custom code is not 20000, it is judged as an error.
    if (res.restData && res.restData.csrf) {
      service.defaults.headers.common['X-XSRF-TOKEN'] = res.restData.csrf;
      // 將 token 同時塞到 cookie 供 ajax service 使用
      // document.cookie = 'XSRF-TOKEN=' + res.restData.csrf;
    }
    
    if(headers['content-disposition']){ //判斷檔案回傳
      // 1. 處理正常回傳 
      if (response && response.headers && response.data) {
        downloadFile(response)
      }
      
    }else if (isJsonBlob(res)) { //正常回傳
      // 認 Header 的 content-type，判斷要跳訊息還是要下載檔案
      const contentType = response.headers['content-type'];
      if (contentType.indexOf('json') !== -1) {
        let fr = new FileReader();
        fr.onload = function() {
          let data
          data = JSON.parse(this.result)  
          if (data.restData.code === '401') {
            // to re-login
            store.dispatch('user/resetToken').then(() => {
              location.reload()
            })
          }
        };
        fr.readAsText(res)

        return data
      }
    
      MessageService.showSystemError()
      return Promise.reject(new Error(res.rtnMsg || 'Error'))
    }else if (res.rtnCode !== '00000') { //正常回傳

      MessageService.showSystemError()
      // 50008: Illegal token; 50012: Other clients logged in; 50014: Token expired;
      // if (res.code === '400' || res.code === 50012 || res.code === 50014) {
      //   // to re-login
      //   store.dispatch('user/resetToken').then(() => {
      //     location.reload()
      //   })
      // }
      return Promise.reject(new Error(res.rtnMsg || 'Error'))
    } else {
      // 401:HTTP.UNAUTHORIZED , 50008: Illegal token; 50012: Other clients logged in; 50014: Token expired;
      if (res.restData.code === '401' || res.restData.code === 50012 || res.restData.code === 50014) {
        // to re-login
        store.dispatch('user/resetToken').then(() => {
          location.reload()
        })
      }
      return res
    }
  },
  error => {
    //送出請求錯誤後 關閉loading
    LoadingConfig.blockCount--;
    if(LoadingConfig.blockCount <= 0){
    // 3 關掉loading 小圈圈
      LoadingConfig.blockCount = 0;
      if(LoadingConfig.hasLoader){
        // EventBus.publish('toggleLoading', false); /* 關閉loading小圈圈 */
        store.dispatch('app/toggleLoading' , false)
        LoadingConfig.hasLoader = false;
      }
    }
    if (error.response) {
      // Http error code 的處理
      switch (error.response.status) {
        case 404:
          // go to 404 page
          MessageService.showError('你要找的頁面不存在');
          break
        case 500:
          MessageService.showSystemError();
          break
        default:
          
          MessageService.showSystemError();
      }
    } else {
      MessageService.showError('接收伺服器回應發生錯誤' ,'');
    }
    return Promise.reject(error)
  }
)
//fix xss
function downloadFile(response) {
  const { headers } = response
  if (response && response.headers && response.data) { 
    const fileName = headers['content-disposition'].replace(/\w+;filename=(.*)/, '$1')
    // 下載檔案
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', decodeURI(fileName)); //or any other extension
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  }
}

export default service
