<template>
  <v-app>
    <!-- 擋件區 -->
    <div v-if="isBlocking" class="blocking-area">
      <span class="blocking-text" v-html="blockingMsg" />
    </div>
    <!-- loading -->
    <v-overlay :value="isLoading" z-index="5000">
      <v-progress-circular indeterminate size="64" />
    </v-overlay>
    <v-container>
      <v-row>
        <v-col v-show="showModeSelect" cols="3">
          <v-select
            v-model="formPageMode"
            :items="modeList"
            item-text="name"
            item-value="value"
            label="模式 (prototype only)"
          />
        </v-col>
        <v-col v-show="showModeSelect" cols="2">
          <v-btn depressed color="primary" @click="hideFiveSec()">
            隱藏5秒
          </v-btn>
        </v-col>
        <v-expansion-panels v-model="panel" flat accordion value="0" multiple>
          <v-expansion-panel>
            <v-expansion-panel-header class="panel-header mb-3">
              <v-col cols="12">
                <h2>表單及簽名</h2>
              </v-col>
            </v-expansion-panel-header>
            <v-expansion-panel-content>
              <v-row>
                <v-col cols="6" class="d-center">
                  <v-btn v-if="isFormSignPageOpened" depressed color="primary" class="big-btn" @click="closeFormSignPage()">
                    <span class="pt-3">
                      <v-icon dark size="7vh">
                        mdi-close
                      </v-icon>
                      <br>
                      <div class="big-btn-text mt-2">關閉視窗</div>
                    </span>
                  </v-btn>
                  <v-btn v-else depressed color="primary" class="big-btn" @click="openFormSignPage()">
                    <span class="pt-3">
                      <v-icon dark size="7vh">
                        mdi-file-document-outline
                      </v-icon>
                      <br>
                      <div v-if="formPageMode==='accounting' || formPageMode=='view' || formPageMode == 'viewDownload' || formPageMode == 'cancel_view' || (formPageMode == 'edit' && applyType != 'NCPS')" class="big-btn-text mt-2">檢視表單</div>
                      <div v-else-if="formPageMode==='cancel'" class="big-btn-text mt-2">取消表單簽名</div>
                      <div v-else class="big-btn-text mt-2">開啟表單及簽名</div>
                    </span>
                  </v-btn>
                </v-col>
                <v-col cols="6">
                  <div class="sign-preview-area ma-auto">
                    <div class="h-10">簽名預覽</div>
                    <div class="h-90 d-center">
                      <img v-if="(formPageMode == 'cancel' || formPageMode == 'cancel_view') && cancelSign.imgSrc" style="width: 100%; max-height: 100%" :src="cancelSign.imgSrc">
                      <img v-else-if="formPageMode != 'cancel' && formPageMode != 'cancel_view' && customerSign.imgSrc" style="width: 100%; max-height: 100%" :src="customerSign.imgSrc">
                      <div v-else-if="applyType != 'NCPS' && formPageMode != 'cancel' && formPageMode != 'cancel_view'" class="not-scan-area">
                        <span>無需簽名</span>
                      </div>
                      <div v-else class="not-scan-area">
                        <span>尚未簽名</span>
                      </div>
                    </div>
                  </div>
                  <div class="w-60 t-center ma-auto">
                    <v-btn color="info" text @click="querySign()">
                      重新整理
                      <v-icon
                        right
                        dark
                      >
                        mdi-refresh
                      </v-icon>
                    </v-btn>
                  </div>
                </v-col>
              </v-row>
            </v-expansion-panel-content>
          </v-expansion-panel>
          <v-expansion-panel>
            <v-expansion-panel-header class="panel-header mb-3">
              <v-col cols="12">
                <h2 v-if="formPageMode == 'edit'">證件/附件 拍攝區</h2>
                <h2 v-else-if="certificateList == null || certificateList.length == 0">
                  證件/附件 拍攝區 (無資料)
                </h2>
                <h2 v-else-if="formPageMode == 'cancel'">
                  證件/附件 拍攝區 <span class="cancel-text">(若確定取消將在兩年後刪除)</span>
                </h2>
                <h2 v-else>
                  證件/附件 拍攝區
                </h2>
              </v-col>
            </v-expansion-panel-header>
            <v-expansion-panel-content>
              <v-container>
                <v-row v-if="isNeedScanCertificate && (formPageMode == 'edit' || formPageMode == 'accounting')" class="mb-2">
                  <v-col cols="12">
                    <span class="hint-text">提示：需至少拍攝一項證件</span>
                  </v-col>
                </v-row>
                <v-row v-if="isNeedScanAttachment && (formPageMode == 'edit' || formPageMode == 'accounting')" class="mb-2">
                  <v-col cols="12">
                    <span class="hint-text">提示：需至少拍攝/掃描一項附件</span>
                  </v-col>
                </v-row>
                <v-row v-if="needScanFileHint && (formPageMode == 'edit' || formPageMode == 'accounting')" class="mb-2">
                  <v-col cols="12">
                    <span class="hint-text">提示：尚需拍攝/上傳 {{ needScanFileHint }}</span>
                  </v-col>
                </v-row>
                <v-row>
                  <v-col v-for="(certificate, index) in certificateList" :key="certificate.id" cols="3" class="mb-2">
                    <v-row>
                      <v-col cols="12" style="text-align: center;">
                        <v-btn
                          v-if="certificate.isAdditional && !certificate.fileName"
                          depressed
                          color="primary"
                          @click="openSetCertificateModal(certificate)"
                        >
                          設定類型
                          <v-icon
                            right
                            dark
                          >
                            mdi-lead-pencil
                          </v-icon>
                        </v-btn>
                        <div v-else-if="formPageMode == 'edit'" class="d-center">
                          <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                              <h3>
                                <a 
                                  v-bind="attrs"
                                  v-on="on"
                                  @click="openSetCertificateModal(certificate)"
                                >
                                  {{ certificate.fileName }}
                                </a>
                              </h3>
                            </template>
                            <span>修改類型</span>
                          </v-tooltip>
                        </div>
                        <h3 v-else>{{ certificate.fileName }}</h3>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col cols="12">
                        <div class="img-area d-center">
                          <img v-if="certificate.imgSrc" style="width: 100%; max-height: 100%" :src="certificate.imgSrc">
                          <div v-else class="not-scan-area">
                            <span>尚未掃描</span>
                          </div>
                        </div>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col v-if="isCanEditFile" cols="6" class="t-center">
                        <v-btn depressed color="error" @click="deleteCertificate(index)">
                          刪除
                          <v-icon
                            right
                            dark
                          >
                            mdi-delete
                          </v-icon>
                        </v-btn>
                      </v-col>
                      <v-col v-if="formPageMode == 'accounting' || formPageMode=='view' || formPageMode == 'viewDownload' || formPageMode=='cancel' || formPageMode == 'cancel_view' || isCanEditFile" :cols="(isCanEditFile ? 6 : 12)" class="t-center">
                        <v-btn depressed color="normal" :disabled="!certificate.imgSrc" @click="viewImage(certificate)">
                          檢視
                          <v-icon
                            right
                            dark
                          >
                            mdi-eye
                          </v-icon>
                        </v-btn>
                      </v-col>
                    </v-row>
                  </v-col>
                  <v-col v-if="isCanEditFile" cols="3" class="add-attachment-area d-center">
                    <v-row>
                      <v-col cols="12" class="d-center">
                        <v-tooltip top>
                          <template v-slot:activator="{ on, attrs }">
                            <v-btn
                              class="mx-2"
                              fab
                              dark
                              depressed
                              color="primary"
                              v-bind="attrs"
                              v-on="on"
                              @click="scanCertificate()"
                            >
                              <v-icon dark>
                                mdi-scanner
                              </v-icon>
                            </v-btn>
                          </template>
                          <span>掃描證件</span>
                        </v-tooltip>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </v-container>
            </v-expansion-panel-content>
          </v-expansion-panel>

          <v-expansion-panel>
            <v-expansion-panel-header class="panel-header mb-3">
              <v-col cols="12">
                <h2 v-if="formPageMode == 'edit'">證件/附件 上傳區</h2>
                <h2 v-else-if="attachmentList == null || attachmentList.length == 0">
                  證件/附件 上傳區 (無資料)
                </h2>
                <h2 v-else-if="formPageMode == 'cancel'">
                  證件/附件 上傳區 <span class="cancel-text">(若確定取消將在兩年後刪除)</span>
                </h2>
                <h2 v-else>
                  證件/附件 上傳區
                </h2>
              </v-col>
            </v-expansion-panel-header>
            <v-expansion-panel-content>
              <v-container>
                <v-row v-if="needScanAttachHint && (formPageMode == 'edit' || formPageMode == 'accounting')" class="mb-2">
                  <v-col cols="12">
                    <span class="hint-text">提示：尚需上傳 {{ needScanAttachHint }}</span>
                  </v-col>
                </v-row>
                <v-row>
                  <v-col v-for="(attachment, index) in attachmentList" :key="attachment.id" cols="3" class="mb-2">                    
                    <v-row>
                      <v-col cols="12" style="text-align: center;">
                        <v-btn
                          v-if="attachment.isAdditional && !attachment.fileName"
                          depressed
                          color="primary"
                          @click="openSetAttachmentModal(attachment)"
                        >
                          設定類型
                          <v-icon
                            right
                            dark
                          >
                            mdi-lead-pencil
                          </v-icon>
                        </v-btn>
                        <div v-else-if="formPageMode == 'edit' && !attachment.canOnlyView" class="d-center">
                          <v-tooltip top>
                            <template v-slot:activator="{ on, attrs }">
                              <h3>
                                <a 
                                  v-bind="attrs"
                                  v-on="on"
                                  @click="openSetAttachmentModal(attachment)"
                                >
                                  {{ attachment.fileName }}
                                </a>
                              </h3>
                            </template>
                            <span>修改類型</span>
                          </v-tooltip>
                        </div>
                        <h3 v-else>{{ attachment.fileName }}</h3>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col>
                        <div class="img-area d-center">
                          <img v-if="attachment.imgSrc" style="max-width: 100%; max-height: 100%" :src="attachment.imgSrc">
                          <div v-else-if="attachment.originalFileName" class="t-center">
                            <v-icon x-large class="mb-2">
                              mdi-file-document-outline
                            </v-icon><br>
                            {{ attachment.originalFileName }}
                          </div>
                          <div v-else-if="formPageMode == 'view' || formPageMode == 'cancel_view'">
                            <span>附件檔名</span>
                          </div>
                          <div v-else class="not-scan-area">
                            <div class="t-center">
                              尚未上傳
                              <!-- 提示訊息 (目前只顯示專用章附件) -->
                              <div v-if="attachment.hintText && onlySealFileCode == attachment.fileCode" class="t-left mt-2" style="color: red">
                                提示: {{ attachment.hintText }}
                              </div>
                            </div>
                          </div>
                        </div>
                      </v-col> 
                                           
                    </v-row>
                    <v-row>
                      <v-col cols="12" class="d-center">
                        <v-checkbox 
                          v-if="onlySealFileCode && onlySealFileCode == attachment.fileCode && attachment.category == attachmentCategory"
                          v-model="attachment.needSeal" 
                          :disabled="true"
                          class="mt-0" 
                          label="套印專用章" 
                          color="success" 
                          hide-details
                          @change="checkNeedSeal(index, attachment.needSeal)"
                        />
                      </v-col>
                    </v-row>
                    <input
                      ref="uploaders"
                      class="d-none"
                      type="file"
                      @change="onFileChanged"
                    >
                    <v-row v-if="(isCanEditFile && !attachment.canOnlyView)">
                      <v-col cols="6" class="t-center">
                        <v-btn depressed color="error" @click="deleteAttachment(attachment, index)">
                          刪除
                          <v-icon
                            right
                            dark
                          >
                            mdi-delete
                          </v-icon>
                        </v-btn>
                      </v-col>
                      <v-col cols="6" class="t-center">
                        <v-btn depressed color="primary" :loading="attachment.isSelecting" :disabled="!attachment.fileName" @click="uploadFile(attachment, index)">
                          上傳
                          <v-icon
                            right
                            dark
                          >
                            mdi-cloud-upload
                          </v-icon>
                        </v-btn>
                      </v-col>
                    </v-row>
                    <!-- 核算補件專用 -->
                    <v-row v-else-if="formPageMode == 'accounting' && attachment.canAcctUpload" class="d-center">
                      <div v-if="attachment.base64 != null || (attachment.fileNo != null && attachment.originalFileName != null)" class="d-center">
                        <v-col cols="6" class="t-center">
                          <v-btn depressed color="error" @click="clearAttachment(attachment)">
                            清空
                            <v-icon
                              right
                              dark
                            >
                              mdi-delete
                            </v-icon>
                          </v-btn>
                        </v-col>
                        <v-col cols="6" class="t-center">
                          <v-btn depressed color="primary" :disabled="!attachment.filePath" @click="downloadFile(attachment)">
                            下載
                            <v-icon
                              right
                              dark
                            >
                              mdi-cloud-download
                            </v-icon>
                          </v-btn>
                        </v-col>
                      </div>
                      <v-col v-else cols="12" class="t-center">
                        <v-btn depressed color="primary" :loading="attachment.isSelecting" @click="uploadFile(attachment, index)">
                          上傳
                          <v-icon
                            right
                            dark
                          >
                            mdi-cloud-upload
                          </v-icon>
                        </v-btn>
                      </v-col>
                    </v-row>
                    <!-- 檢視及下載 -->
                    <v-row v-else-if="formPageMode == 'accounting' || formPageMode=='view' || formPageMode == 'viewDownload' || formPageMode=='cancel' || formPageMode == 'cancel_view' || attachment.canOnlyView">
                      <v-col v-if="attachment.imgSrc" cols="12" class="t-center">
                        <v-btn depressed color="normal" @click="viewImage(attachment)">
                          檢視
                          <v-icon
                            right
                            dark
                          >
                            mdi-eye
                          </v-icon>
                        </v-btn>
                      </v-col>
                      <v-row v-else-if="attachment.fileExt == '.pdf'">
                        <v-col cols="6" class="t-center">
                          <v-btn depressed :disabled="!attachment.filePath" @click="viewPDFFile(attachment)">
                            列印
                            <v-icon
                              right
                              dark
                            >
                              mdi-printer
                            </v-icon>
                          </v-btn>
                        </v-col>
                        <v-col cols="6" class="t-center">
                          <v-btn depressed color="primary" :disabled="!attachment.filePath" @click="downloadFile(attachment)">
                            下載
                            <v-icon
                              right
                              dark
                            >
                              mdi-cloud-download
                            </v-icon>
                          </v-btn>
                        </v-col>
                      </v-row>
                      <v-col v-else cols="12" class="t-center mt-3">
                        <v-btn depressed color="primary" :disabled="!attachment.filePath" @click="downloadFile(attachment)">
                          下載
                          <v-icon
                            right
                            dark
                          >
                            mdi-cloud-download
                          </v-icon>
                        </v-btn>
                      </v-col>
                    </v-row>
                  </v-col>
                  <v-col v-if="isCanEditFile" cols="3" class="add-attachment-area d-center">
                    <v-row>
                      <v-col cols="12" class="d-center">
                        <v-tooltip top>
                          <template v-slot:activator="{ on, attrs }">
                            <v-btn
                              class="mx-2"
                              fab
                              dark
                              depressed
                              color="primary"
                              v-bind="attrs"
                              v-on="on"
                              @click="addAttachment()"
                            >
                              <v-icon dark>
                                mdi-plus
                              </v-icon>
                            </v-btn>
                          </template>
                          <span>新增附件</span>
                        </v-tooltip>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-row>
              </v-container>
            </v-expansion-panel-content>
          </v-expansion-panel>

          <v-expansion-panel v-if="formPageMode == 'accounting'">
            <v-expansion-panel-header class="panel-header mb-3">
              <v-col cols="12">
                <h2>核算備註區</h2>
              </v-col>
            </v-expansion-panel-header>
            <v-expansion-panel-content>
              <v-row>
                <v-col cols="12" class="d-center">
                  <v-textarea
                    v-model="accountingMemo"
                    class="accouting-textarea"                   
                    outlined
                    placeholder="點選 [儲存備註並關閉]、[退件]、[核算通過] 都會進行儲存"
                    :no-resize="true"
                    counter="100"
                    auto-grow
                    rows="4"
                  />
                </v-col>
              </v-row>
            </v-expansion-panel-content>
          </v-expansion-panel>

          <v-expansion-panel v-if="formPageMode == 'cancel'">
            <v-expansion-panel-header class="panel-header mb-3">
              <v-col cols="12">
                <h2>取消原因</h2>
              </v-col>
            </v-expansion-panel-header>
            <v-expansion-panel-content>
              <v-row>
                <v-col cols="12" class="d-center">
                  <v-textarea
                    v-model="cancelReason"
                    class="accouting-textarea"                   
                    outlined
                    placeholder="請輸入原因"
                    :no-resize="true"
                    counter="100"
                    auto-grow
                    rows="4"
                  />
                </v-col>
              </v-row>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
      </v-row>
      <div v-if="formPageMode == 'edit'" class="d-end">
        <v-btn 
          fab
          depressed 
          large 
          color="success" 
          class="mx-2"
          :class="{'fixed-save-btn': !restrictMode, 'fixed-save-btn-in-modal': restrictMode}"
          width="100"
          height="100"
          @click="save()"
        >
          <div style="display:block;">
            <v-icon size="40" class="cal-btn-icon"> 
              mdi-check
            </v-icon>
            <span style="display:block; padding-top:20%; font-size: 20px">儲存</span>             
          </div>
        </v-btn>
      </div>
      <v-row v-if="formPageMode == 'accounting'">
        <v-col cols="12" class="t-right">
          <v-btn depressed large color="#E98B2A" @click="saveComments()">
            <span style="font-size: 18px; color: white">儲存備註並關閉</span>
            <v-icon
              right
              dark
              style="font-size: 24px; color: white"
            >
              mdi-content-save
            </v-icon>
          </v-btn>
          <v-btn depressed large color="error" class="ml-3" @click="retrunOrder()">
            <span style="font-size: 18px">退件</span>
            <v-icon
              right
              dark
              style="font-size: 24px"
            >
              mdi-close
            </v-icon>
          </v-btn>
          <v-btn
            v-if="isAttachmentNotSealed" 
            depressed 
            large 
            color="primary" 
            class="ml-3"
            @click="closeAccountingDialog()"
          >
            <span style="font-size: 18px">關閉視窗</span>
            <v-icon
              right
              dark
              style="font-size: 24px"
            >
              mdi-close
            </v-icon>
          </v-btn>
          <v-btn
            v-else
            depressed 
            large 
            color="success" 
            class="ml-3"
            @click="accountingSubmit()"
          >
            <span style="font-size: 18px">核算通過</span>
            <v-icon
              right
              dark
              style="font-size: 24px"
            >
              mdi-check
            </v-icon>
          </v-btn>
        </v-col>
      </v-row>
      <div v-if="formPageMode == 'cancel'" class="d-end">
        <v-btn 
          fab
          depressed 
          large 
          color="error" 
          class="mx-2"
          :class="{'fixed-save-btn': !restrictMode, 'fixed-save-btn-in-modal': restrictMode}"
          width="100"
          height="100"
          @click="cancel()"
        >
          <div style="display:block;">
            <v-icon size="40" class="cal-btn-icon"> 
              mdi-close
            </v-icon>
            <span style="display:block; padding-top:20%; font-size: 18px">確定取消</span>             
          </div>
        </v-btn>
      </div>
    </v-container>

    <!-- 檢視圖片 modal -->
    <v-dialog
      v-model="viewImageDialog"
      transition="dialog-bottom-transition"
      width="70vw"
    >
      <v-card>
        <v-card-title class="text-h5 lighten-2" style="background-color:#363636; color:white;">
          {{ viewImageTitle ? viewImageTitle : "檢視" }}
        </v-card-title>
        
        <v-card-text class="d-center">
          <img style="max-width: 100%; max-height: 100%" :src="viewImageSrc">
        </v-card-text>

        <v-card-actions>
          <v-spacer />
          <v-btn
            color="primary"
            text
            @click="viewImageDialog = false"
          >
            關閉
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- 設定證件 modal -->
    <v-dialog 
      v-model="setCertificateModal" 
      transition="dialog-bottom-transition"
      width="70vw"
    >
      <v-card>
        <v-card-title class="text-h5 lighten-2" style="background-color:#363636; color:white;">
          請選擇證件/附件類別
        </v-card-title>
        <v-card-text>
          <v-row class="ma-3">
            <div v-for="(option, index) in certificateOptions" :key="option.fileCode">
              <v-chip
                v-if="setCertificateType === index"
                label 
                x-large 
                class="ma-2" 
                color="success"
                text-color="white"
              >
                <span>{{ option.fileName }}</span>
              </v-chip>
              <v-chip 
                v-else 
                label 
                x-large 
                class="ma-2" 
                :disabled="selectedCertificate.fileCode == option.fileCode"
                :color="(option.color) ? option.color : 'normal'"
                @click="selectCertificate(index);setCertificate()"
              >
                <span>{{ option.fileName }}</span>
              </v-chip>
            </div>
          </v-row>
          <v-row class="ma-3">
            <v-chip
              v-if="setCertificateType === certificateOptions.length"
              label 
              x-large 
              class="ma-2" 
              color="success"
              text-color="white"
            >
              <span>其他證件/附件:&emsp;</span>
              <v-text-field v-model="otherCertificate" class="chip-text-field" placeholder="請輸入證件/附件類別" />
            </v-chip>
            <v-chip v-else label x-large class="ma-2" @click="selectCertificate(certificateOptions.length)">
              <span>其他證件/附件</span>
            </v-chip>
          </v-row>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn
            @click="setCertificateModal = false"
          >
            &emsp;關閉&emsp;
          </v-btn>
          <v-btn
            color="success"
            :disabled="setCertificateType == -1 || (setCertificateType === certificateOptions.length && !otherCertificate)"
            @click="setCertificate()"
          >
            &emsp;確定&emsp;
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- 設定附件 modal -->
    <v-dialog 
      v-model="setAttachmentModal" 
      transition="dialog-bottom-transition"
      width="50vw"
    >
      <v-card>
        <v-card-title class="text-h5 lighten-2" style="background-color:#363636; color:white;">
          請選擇證件/附件類別
        </v-card-title>
        <v-card-text>
          <v-row class="ma-3">
            <div v-for="(option, index) in attachmentOptions" :key="option.fileName">
              <v-chip
                v-if="setAttachmentType === index"
                label 
                x-large 
                class="ma-2" 
                color="success"
                text-color="white"
              >
                <span>{{ option.fileName }}</span>
              </v-chip>
              <v-chip 
                v-else 
                label 
                x-large 
                class="ma-2" 
                :color="(option.color) ? option.color : 'normal'"
                @click="selectAttachment(index);setAttachment();"
              >
                <span>{{ option.fileName }}</span>
              </v-chip>
            </div>
          </v-row>
          <v-row class="ma-3">
            <v-chip
              v-if="setAttachmentType === attachmentOptions.length"
              label 
              x-large 
              class="ma-2" 
              color="success"
              text-color="white"
            >
              <span>其他證件/附件:&emsp;</span>
              <v-text-field v-model="otherAttachment" class="chip-text-field" placeholder="請輸入證件/附件類別" />
            </v-chip>
            <v-chip v-else label x-large class="ma-2" @click="selectAttachment(attachmentOptions.length)">
              <span>其他證件/附件</span>
            </v-chip>
          </v-row>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn
            @click="setAttachmentModal = false"
          >
            &emsp;關閉&emsp;
          </v-btn>
          <v-btn
            color="success"
            :disabled="setAttachmentType == -1 || (setAttachmentType === attachmentOptions.length && !otherAttachment)"
            @click="setAttachment()"
          >
            &emsp;確定&emsp;
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- 提示訊息 modal -->
    <v-dialog
      v-model="viewHintDialog"
      transition="dialog-bottom-transition"
      width="50vw"
    >
      <v-card>
        <v-card-title class="text-h5 lighten-2" style="background-color:#363636; color:white;">
          提示
        </v-card-title>
        
        <v-card-text class="d-center">
          <h3 class="mt-5" v-html="dialogHintText" />
        </v-card-text>

        <v-card-actions>
          <v-spacer />
          <v-btn
            color="primary"
            text
            @click="viewHintDialog = false"
          >
            關閉
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- 刪除專用章附件 modal -->
    <v-dialog
      v-model="deleteSealDialog"
      transition="dialog-bottom-transition"
      width="50vw"
    >
      <v-card>
        <v-card-title class="text-h5 lighten-2" style="background-color:#363636; color:white;">
          提示
        </v-card-title>
        
        <v-card-text>
          <h3 class="mt-5">
            檢測到已有套印專用章之附件，若刪除專用章附件也會一併刪除，確認要刪除嗎?
          </h3>
        </v-card-text>

        <v-card-actions>
          <v-spacer />
          <v-btn
            @click="deleteSealDialog = false"
          >
            &emsp;關閉&emsp;
          </v-btn>
          <v-btn
            color="primary"
            @click="confirmDeleteSealAttachment()"
          >
            &emsp;確認刪除&emsp;
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-app>
</template>

<script src="./FormPage.js">
</script>

<style scoped>
    .marginLeft {
      margin-left: 100px !important;
    }
    .h-10{
      height: 10%;
    }
    .h-90{
      height: 90%;
    }
    .h-100{
      height: 100%;
    }
    .w-60{
      width: 60%
    }
    .w-100{
      width: 100%;
    }
    .row + .row{
      margin-top: 0;
    }
    .panel-header{
      border-bottom: 3px solid rgba(0, 0, 0, 0.54);
    }
    .d-center{
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .d-end {
      display: flex;
      justify-content: flex-end;
    }
    .t-center{
      text-align: center;
    }
    .t-right{
      text-align: right;
    }
    .t-center >>> input {
      text-align: center
    }
    .h3 >>> input{
      font-size: 1.5625rem !important;
      line-height: 1.4em !important;
      margin-top: 20px;
      margin-bottom: 4px;
    }
    .big-btn{
      height: 20vh !important;
      width: 20vw !important;
    }
    .big-btn-text{
      font-size: 5vh;
    }
    .sign-preview-area{
      width: 60%;
      height: 90%;
      border: 1px solid rgb(207, 207, 207);
      border-radius: 8px;
      text-align: center;
    }
    .img-area {
      height: 30vh;
      width: 100%;
      border: 1px solid rgb(207, 207, 207);
      border-radius: 8px;
    }
    .not-scan-area{
      width: 100%;
      height: 100%;
      background-color: rgba(230, 230, 230, 0.116);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .add-attachment-area{
      min-height: 30vh;
    }
    .chip-text-field >>> .v-text-field__slot input{
      color: white !important;
      font-size: 18px;
      margin-top: 5px !important;
    }
    .chip-text-field >>> .v-text-field__slot input::placeholder{
      color: white !important;
      opacity: 0.8;
    }
    .blocking-area{
      background-color: black;
      opacity: 0.8;
      font-size: 32px;
      z-index: 100;
      width: 100%;
      height: 100%;
      top: 0px;
      left: 0px;
      position: absolute;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .blocking-text{
      font-size: 60px;
      font-weight: bold;
      color: white;
      text-align: center;
    }

    .cancel-text{
      color: #db6154;
    }

    .hint-text{
      color: red;
      font-size: 24px;
    }

    .fixed-save-btn {
      position: fixed;
      right: 20px;
      z-index: 10;
      bottom: 20px;
    }

    @media (min-width: 700px) {
      .fixed-save-btn-in-modal {
        position: fixed;
        right: 10vw;
        z-index: 10;
        bottom: 7vh;
      }
    }

    @media (min-width: 1500px) {
      .fixed-save-btn-in-modal {
        position: fixed;
        right: 15vw;
        z-index: 10;
        bottom: 7vh;
      }
    }

    @media (min-width: 1700px) {
      .fixed-save-btn-in-modal {
        position: fixed;
        right: 18vw;
        z-index: 10;
        bottom: 7vh;
      }
    }

    @media (min-width: 1900px) {
      .fixed-save-btn-in-modal {
        position: fixed;
        right: 21vw;
        z-index: 10;
        bottom: 7vh;
      }
    }
</style>