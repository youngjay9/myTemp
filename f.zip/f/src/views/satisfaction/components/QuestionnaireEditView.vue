<template>
  <v-container>
    <h2 class="font-bold">滿 意 度 問 卷 {{ getTitleAction }}</h2>
    <v-row class="justify-end">
      <v-col class="ml-10 font-24px" cols="12">
        <v-form ref="questionnaireForm" v-model="valid" lazy-validation>
          <v-row align="center">
            <div class="form-create-wrap font-weight-bold">
              <div v-if="!loading" class="wrap">
                <div class="content-wrap">
                  <div class="item title" :class="{'title-focus': focusIndex === 'title'}" @click="focusTitle($event)">
                    <v-row>
                      <v-col md="3">
                        <v-subheader class="justify-center text-md-body-1 font-weight-bold">
                          問 卷 標 題
                          <span class="red--text">*</span>
                        </v-subheader>
                      </v-col>
                      <v-col>
                        <v-text-field
                          v-model="questionnaire.questionnaireName"
                          :rules="rules.requiredRule"
                          color="accent"
                          outlined
                          placeholder="問卷標題"
                          counter="40"
                        />
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="3">
                        <v-subheader class="justify-center text-md-body-1 font-weight-bold">
                          問 卷 描 述
                        </v-subheader>
                      </v-col>
                      <v-col>
                        <v-text-field 
                          v-model="questionnaire.memo"
                          color="accent"
                          outlined
                          placeholder="問卷描述"
                          counter="40"
                        />
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="3">
                        <v-subheader class="justify-center text-md-body-1 font-weight-bold">
                          上 架 日 期
                          <span class="red--text">*</span>
                        </v-subheader>
                      </v-col>
                      <v-col md="4">
                        <v-menu
                          v-model="releaseDateStartMenu"
                          :close-on-content-click="false"
                          transition="scale-transition"
                          offset-y
                          min-width="auto"
                        >
                          <template v-slot:activator="{ on }">
                            <v-text-field
                              v-model="questionnaire.releaseStartDate"
                              :rules="rules.requiredRule"
                              append-icon="mdi-calendar"
                              placeholder="上架日期(起)YYYY-MM-DD"
                              color="accent"
                              outlined
                              dense
                              class="font-weight-bold"
                              readonly
                              hide-details
                              :clearable="true"
                              @click:append="releaseDateStartMenu = true"
                              v-on="on"
                            />
                          </template>
                          <v-date-picker
                            v-model="questionnaire.releaseStartDate"
                            scrollable
                            :min="questionnaire.releaseStartDate||nowDate"
                            @input="releaseDateStartMenu = false"
                          />
                        </v-menu>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col md="3">
                        <v-subheader class="justify-center text-md-body-1 font-weight-bold">
                          審 核 附 件 上 傳
                        </v-subheader>
                      </v-col>
                      <v-col>
                        <v-file-input
                          v-model="attachmentFile"
                          :hide-details="hideDatails"
                          placeholder="請選擇上傳附件"
                          color="accent"
                          outlined
                          dense
                          persistent-hint
                          prepend-inner-icon="mdi-cloud-upload"
                          prepend-icon
                          accept=".xlsx,.xls,image/*,.doc, .docx,.ppt, .pptx,.txt,.pdf ,application/vnd.ms-excel"
                          show-size
                          @change="onUpload"
                        />
                        <div v-if="!!dataURL" class="t-center">
                          <v-icon x-large class="mb-2">
                            mdi-file-document-outline
                          </v-icon><br>
                        </div>
                      </v-col>
                    </v-row>
                    <div v-if="!questionnaire.questions.length" class="add-list" color="primary">
                      <v-btn
                        class="ma-2"
                        fab
                        color="#68cbd8"
                        @click="addListFn"
                      >
                        <v-icon v-text="'mdi-plus'" />
                      </v-btn>
                    </div>
                  </div>
                  <v-col class="q-wrap">
                    <span class="annotation-red">※提醒，拖曳<v-icon v-text="'mdi-swap-vertical'" />可改變題目順序</span>
                    <draggable 
                      :list="questionnaire.questions"
                      :options="{group:'question'}"
                      @start="drag=true" 
                      @end="onEnd"
                    >
                      <template v-for="question, idxQ in questionnaire.questions">
                        <v-col id="items" :key="idxQ" class="q-li" :class="{'q-li-focus': focusIndex === idxQ}" @click="focusItem($event, idxQ)">
                          <div class="drap-area">
                            <v-icon v-text="'mdi-swap-vertical'" /> <span class="annotation font-24px">第 {{ idxQ+1 }} 題</span>
                          </div>
                          
                          <div class="q-item-wrap">
                            <div class="q-item q-title-wrap">
                              <div class="q-title">
                                <v-text-field 
                                  v-model="question.title" 
                                  :rules="rules.requiredRule"
                                  placeholder="問題名稱" 
                                  color="#68cbd8" 
                                  outlined
                                />
                              </div>
                            </div>
                            <div class="q-item">
                              <v-radio-group
                                disabled
                                row
                              >
                                <v-radio
                                  v-for="answer, idxAns in question.answers" 
                                  :key="idxAns"
                                  :label="answer.label"
                                  :value="answer.value"
                                />
                              </v-radio-group>
                            </div>
                            <div v-if="focusIndex === idxQ" class="q-item option-wrap">
                              <v-divider class="mt-6 mb-5" />
                              <ul class="option-list">
                                <li>
                                  <v-icon @click="copyListFn(idxQ)" v-text="'mdi-plus'" />
                                </li>
                                <li>
                                  <v-icon @click="deleteListFn(idxQ)" v-text="'mdi-delete'" />
                                </li>
                              </ul>
                            </div>
                          </div>
                        </v-col>
                      </template>
                    </draggable>
                  </v-col>
                </div>
                <!-- <v-btn v-if="questionnaire.questions.length" class="primary form-sidebar" @click="addListFn">
                  <v-icon v-text="'mdi-plus'" />
                </v-btn> -->
              </div>
              <v-col class="d-flex justify-end">
                <v-btn
                  class="ma-1"
                  outlined
                  color="accent"
                  @click="isEdit ? $router.go(-1): reset()"
                >
                  {{ isEdit ? '返回':'清空' }}
                </v-btn>
                <v-btn
                  class="ma-1"
                  depressed
                  color="primary"
                  @click="submit(false)"
                >
                  暫存
                </v-btn>
                <v-btn
                  class="ma-1"
                  depressed
                  color="success"
                  @click="checkSubmitFun"
                >
                  送出審核
                </v-btn>
              </v-col>
            </div>
          </v-row>
        </v-form>
      </v-col>
    </v-row>
    <v-dialog v-model="checkSubmit" max-width="500">
      <v-card>
        <v-card-title
          class="text-h5 lighten-2"
          style="background-color: #c62828; color: white"
        >
          無上傳審核附件
          <v-spacer />
          <v-btn
            color="white"
            icon
            small
            text
            @click="checkSubmit = false"
          >
            <v-icon> mdi-close </v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text class="font-24px">
          <v-row class="mt-6 ml-1 font-bold">
            無上傳審核附件，是否仍要送出?
          </v-row>
        </v-card-text>
        <v-card-actions class="d-end mt-6">
          <v-btn color="normal" @click="checkSubmit = false">
            &emsp;取消&emsp;
          </v-btn>
          <v-btn
            color="primary"
            @click="submit(true)"
          >
            &emsp;確定&emsp;
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
  import draggable from 'vuedraggable'
  import MessageService from "@/assets/services/message.service";
  import { initQuestionnaireAnswer , fetchEditQuestionnaire } from '@/api/questionnaire'
  import { getFileExtension } from '@/utils/validate'
  import isEmpty from 'lodash/isEmpty'

  // let lineEndOptions = Array.apply(null, Array(9)).map((item, i) => {
  //   return i + 2
  // })

  const defaultForm = {
    questionnaireName: null,
    questionnaireId: null,
    memo: null,
    releaseStartDate: null, 
    questions: null
  }

  const defaultFile = { //sign AttachmentFile
    originalFileName: null,
    imgSrc: null,
    base64: null,
  }
  //固定的答案 
  const defaultAnswers =  [ 
    { label: '非常滿意', value: '5' },
    { label: '滿意', value: '4' },
    { label: '普通', value: '3' },
    { label: '不滿意', value: '2' },
    { label: '非常不滿意', value: '1' },
  ]

  const defaultQuestion = {
    question_id: null,
    title:'',
    type: 'radio',
    required: true,
    answers: null
  }

  export default {
    
    components: { draggable },
    props: {
      isEdit: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        reader: null,
        nowDate: new Date().toISOString().slice(0,10),
        drag: false,
        valid: false,
        rules: {
          requiredRule: [v => !!v || '此欄位為必填欄位'],
          lengthRules: [v => (v && v.length <= this.maxCharacter) || `不能超過 ${this.maxCharacter} 個字`],
          videoSizeRules: [v => !!v || v.size < 50e6 || '檔案大小超過 50 MB!',],
          iamgeSizeRules: [v => !!v || v.size < 10e6 || '檔案大小超過 10 MB!',],
          filesSizeRules: [ v => !v || v.size < 25e6 || "檔案大小超過 30 MB!" ],
        },

        auth: false,  
        loading: false,
        hideDatails: false,
        checkSubmit: false,
        //日曆
        releaseDateStartMenu: false,
        //日曆 end

        //API post Data
        postForm: Object.assign({}, defaultForm),

        //審核附件
        attachmentFile: null,
        attachmentList: [],
        dataURL: null,
        signAttachmentFile: null,
        signAttachmentFileId: null,

        questionnaire: {
          questionnaireName: '',
          memo: '',
          releaseStartDate: null,
          questions: [{
            question_id: 1,
            title:'',
            type: 'radio',
            required: true, //預設此題必答
            answers: Object.assign([], defaultAnswers), //塞入預設答案
            }
          ]
        }, // 呈現用送出用
        
        // selectOptions: ['單選題', '多選題', '下拉列表', '線性量表', '矩陣量表', '優先級', '文本題'],
        type: 'radio',
        langCode: ['zh'],
        langList: ['中文'],
        // selectOptions: ['單選題', '多選題', '下拉列表', '線性量表', '矩陣量表', '優先級', '文本題'],
        // langCode: ['cn', 'en', 'kr', 'jp', 'fr', 'de', 'ru', 'sp', 'po', 'it', 'nl', 'id', 'tr', 'thai', 'zh', 'fa', 'ro', 'ar'],
        // langList: ['中文', '英語', '韓語', '日語', '法語', '德語', '俄語', '西班牙語', '葡萄牙語', '意大利語',
        //   '荷蘭語', '印度語', '土耳其語', '泰語', '繁體中文', '波斯語', '羅馬尼亞語', '阿拉伯語'],
        focusIndex: 0
      }
    },
    computed: {
      getTitleAction() {
        return this.isEdit ? '編 輯':'製 作'
      },
    },
    mounted() { //initial data
      this.init()
      
      if (this.isEdit) {
        const id = this.$route.params && this.$route.params.id
        
        this.fetchQuestionnaire(id)
      }
    },
    methods: {
      onEnd () {
        this.drag = false
      },
      onMove ({relatedContext, draggedContext}) {
        let relatedIndex = relatedContext.index
        let index = draggedContext.index
        relatedContext.element.question_id = index + 1
        draggedContext.element.question_id = relatedIndex + 1
      },
      focusTitle (event) {
        let classList = event.target.classList
        if (classList.contains('add-list')) return
        this.focusIndex = 'title'
      },
      focusItem (event, i) {
        let classList = event.target.classList
        if (classList.contains('icon-copy') || this.focusIndex === i) return
        this.focusIndex = i
      },
      // addRadioFn (i, j) {
      //   let list = this.questionnaire.questions[i].content[j].answer
      //   this.addFormFn(list)
      // },
      // deleteRadioFn (i, j, k) {
      //   this.questionnaire.question[i].content[j].answer.splice(k, 1)
      // },
      // addFormFn (list) {
      //   let index = list.length ? parseInt(list[list.length - 1].description.substr(2)) + 1 : '1'
      //   let text = index ? '選項' + index : '選項1'
      //   list.push({answer_id: list.length + 1, description: text})
      //   this.$nextTick(() => {
      //     let input = document.querySelectorAll('.radio-input')
      //     input[input.length - 1].focus()
      //   })
      // },
      reset() {
        this.$refs.questionnaireForm.reset()
        this.postForm = Object.assign({}, defaultForm)
        this.init()
      },

      //初始化 
      init () {
        this.questionnaire = {
          questionnaireName: '',
          memo: '',
          releaseStartDate: null,
          questions: [{
            question_id: 1,
            title:'',
            type: 'radio',
            required: true, //預設此題必答
            answers: Object.assign([], defaultAnswers), //塞入預設答案
            }
          ]
        }
        // init file reader
        this.reader = new FileReader();
        this.reader.onload = () => {
          // preview data url
          this.dataURL = this.reader.result
          // assign file 
          this.signAttachmentFile = Object.assign({} , defaultFile)
          this.signAttachmentFile.id = this.signAttachmentFileId 
          this.signAttachmentFile.category = "MEDIA_ATTACHMENT"
          this.signAttachmentFile.fileName = this.attachmentFile.name.substr(0,this.attachmentFile.name.lastIndexOf("."))
          this.signAttachmentFile.originalFileName = this.attachmentFile.name
          this.signAttachmentFile.fileExt = getFileExtension(this.attachmentFile.name)
          this.signAttachmentFile.fileSize = this.attachmentFile.size
          this.signAttachmentFile.base64 = this.dataURL.split(",")[1]
        }
      },
      copyListFn (index) {
        // let data = JSON.parse(JSON.stringify(this.questionnaire.questions[index]))
        let newQuestion = Object.assign({}, defaultQuestion) //塞入預設題目
        newQuestion.question_id = this.questionnaire.questions.length + 1 
        newQuestion.answers = Object.assign([], defaultAnswers) //塞入預設答案

        this.questionnaire.questions.splice(index+1, 0, newQuestion)
        this.focusIndex = this.questionnaire.questions.length - 1
        
      },
      addListFn () {
        let newQuestion = Object.assign({}, defaultQuestion) //塞入預設題目

        newQuestion.question_id = this.questionnaire.questions.length + 1 
        newQuestion.answers = Object.assign([], defaultAnswers) //塞入預設答案
        
        this.questionnaire.questions.push(newQuestion)
        this.focusIndex = this.questionnaire.questions.length - 1
        
      },
      deleteListFn (i) {
        this.questionnaire.questions.splice(i, 1)
        this.focusIndex = i === 0 && this.questionnaire.questions.length > 0 ? i : i - 1
      },
      //附件上傳
      onUpload() {
        this.dataURL = null
        this.signAttachmentFile = null
        if (this.attachmentFile instanceof Blob){
          this.reader.readAsDataURL(this.attachmentFile)    
        }else{
          this.signAttachmentFile = this.attachmentFile
          this.dataURL = null
        }
      },
      checkSubmitFun(){
        if(this.signAttachmentFile == null || this.signAttachmentFile.size <= 0) {
          this.checkSubmit = true;
        }else{
          this.submit(true);
        }
      },
      // 送出問卷製作儲存
      submit(isSign) {
        //填答時先將資料Assign 進 postForm
        Object.keys(this.questionnaire).filter(key => key in this.postForm).forEach(key => this.postForm[key] = this.questionnaire[key]);

        //API post data 
        const postData = { 
          questionnaire : this.postForm,
          signAttachment : isEmpty(this.signAttachmentFile) ? null : this.signAttachmentFile,
          sign : isSign ? true : false, //是否暫存
        }
        
        if (this.$refs.questionnaireForm.validate()) {
          this.submitForm(postData)
        }else{
          this.$nextTick(() => {
            const el = this.$el.querySelector(".error--text:first-of-type");
            this.$vuetify.goTo(el);
            return;
          });
        }
      },

      /**
       * @param {Object} questionnaire
       * @returns {Object}
       */
      hasResult (questionnaire) {
        // 驗證questionnaire是否有資料
        if(isEmpty(questionnaire)){
            MessageService.showInfo('查無相關資料')
            return
        }
        return true
      },

      /**
       * 
       * Ajax start 
       * 
       **/
      
      //Action:問卷預覽頁面初始化
      async submitForm(postData) {
        const data = await initQuestionnaireAnswer(postData)
        // 驗證是否成功
        if (!data.restData.success) {              
            MessageService.showError(data.restData.message,'儲存問卷作答資料');
            return;
        }
        this.checkSubmit =  false;
        this.postForm.questionnaireId = data.restData.questionnaireId
        if(postData.sign) { //送出審核才進行畫面清空
          MessageService.showSuccess('問卷已送出審核，請至查詢頁面確認審核狀態。')
          this.reset() //重置表單
        } else {
          MessageService.showSuccess('問卷資料已暫存。')
        }
      },

      //Action:問卷預覽頁面初始化
      async fetchQuestionnaire(id) {
        const data = await fetchEditQuestionnaire(id)
        // 驗證是否成功
        if (!data.restData.success) {              
            MessageService.showError(data.restData.message,'查詢問卷詳細資料');
            return;
        }
        // 驗證是否有資料
        if(this.hasResult(data.restData.questionnaire)){
          this.questionnaire = data.restData.questionnaire
          //塞入假檔案for 畫面呈現
          let tmpfile = data.restData.signAttachment.originalFileName
          this.attachmentFile = new File(["tmp"], tmpfile , {type:"text/plain", lastModified: new Date().getTime()});
          
          this.signAttachmentFile = data.restData.signAttachment
          this.signAttachmentFileId = data.restData.signAttachment.id
          this.$nextTick(() => {this.stepEl = 1});
        }
      },
    }
  }
</script>

<style lang="scss">
  .form-create-wrap {
    $green: #4ca2ae;
    $grey: rgba(0,0,0,.5);
    position: relative;
    width: 80%;
    min-width: 400px;
    margin: 30px auto;
    @media (min-width: 520px) {
      width: 100%;
    }
    .wrap {
      width: 780px;
      min-height: 100px;
      margin: 0 auto;
      @media (max-width: 920px) {
        width: 100%;
      }
      display: flex;
      .content-wrap {
        flex: 1;
        background-color: #fff;
        box-shadow: 0 0 2px rgba(0,0,0,.12), 0 2px 4px rgba(0,0,0,.1);
        margin-right: 10px;
      }
      .form-sidebar {
        flex: 1;
        flex-grow: 0;
        align-self: flex-end;
        display: inline-block;
        background-color: #fff;
        box-shadow: 0 0 2px rgba(0,0,0,.12), 0 2px 4px rgba(0,0,0,.24);
        .sidebar-li {
          cursor: pointer;
          padding: 10px 12px;
        }
      }
    }
    .item {
      padding: 16px 24px 24px 42px;
      .li-right {
        text-align: right;
      }
      .li-left {
        text-align: left;
        .q-select {
          display: inline-block;
          width: 120px;
        }
      }
    }
    .title-focus {
      border-left-color: $green !important;
    }
    .title {
      border-left: 3px solid transparent;
      position: relative;
      .add-list {
        width: 50px;
        height: 50px;
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        bottom: -15px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        // i {
        //   color: $green;
        //   font-size: 22px;
        // }
      }
    }
    .q-wrap {
      .q-li-focus {
        border-left-color: $green !important;
        box-shadow: 0 -2px 2px 0 rgba(0,0,0,0.2), 0 2px 6px 0 rgba(0,0,0,0.24);
      }
      .q-li {
        border-left: 3px solid transparent;
      }
      .q-title-wrap {
        display: flex;
        align-items: center;
        margin-bottom: 25px !important;
        .q-index {
          flex: 1;
          flex-grow: 0;
          margin-right: 10px;
        }
        .q-title {
          flex: 1;
          flex-grow: 2;
          .li {
            margin-bottom: 0;
          }
        }
        .q-select {
          flex: 1;
          flex-shrink: 0;
        }
      }
      .drap-area {
        padding: 5px;
        cursor: move;
        .icon-tuozhuai {
          color: lightgray;
          font-size: 20px;
          margin-left: 37px;
        }
      }
      .q-item-wrap {
        padding:  16px 24px 24px 42px;
      }
      .q-item {
        // margin-bottom: 10px;
        /*overflow: hidden;*/
        .q-radio {
          margin: 15px auto;
          display: flex;
          align-items: center;
          .icon-radio {
            width: 15px;
            height: 15px;
            border: 2px solid transparent;
            margin-right: 15px;
          }
          .icon-cirle {
            border-radius: 50%;
            border: 2px solid lightgray;
          }
          .icon-square {
            border: 2px solid lightgray;
            border-radius: 0;
          }
          input {
            flex: 2;
            margin-right: 15px;
            border: 1px solid transparent;
            padding-bottom: 3px;
            &:focus {
              border-bottom: 1px solid lightgray;
            }
          }
          i {
            flex: 1;
            flex-grow: 0;
            color: rgba(0,0,0,0.3);
            cursor: pointer;
          }
          .radio-add {
            color: $green;
            font-weight: bold;
            cursor: pointer;
            flex: 0;
          }
        }
      }
      .line-wrap {
        .q-item-line {
          display: flex;
          align-items: center;
          .el-select {
            width: 70px;
            .el-input {
              border: none !important;
            }
          }
          .line-tip {
            padding: 15px;
          }
        }
        .q-radio {
          input {
            border-bottom: 1px solid lightgray !important;
            flex: 0;
          }
        }
      }
      .text-wrap {
        color: $grey;
        border-bottom: 1px dotted lightgray;
        padding-bottom: 5px;
        width: 60%;
        text-align: left;
      }
      .square-wrap {
        display: flex;
        .square-li {
          flex: 1
        }
      }
      .option-wrap {
        overflow: hidden;
        // border-top: 1px solid lightgray;
        .option-list {
          float: right;
          li {
            float: left;
            list-style: none;
            margin: 20px 0 0 25px;
            .icon-copy {
              font-size: 20px;
            }
            i {
              cursor: pointer;
            }
          }
          .lang-li {
            margin: 15px 8px;
            display: flex;
            align-items: center;
            span {
              margin-left: 10px;
              cursor: pointer;
              color: $green;
              font-weight: bold;
            }
            .el-select {
              width: 120px;
            }
          }
        }
      }
      .lang-wrap {
        border-top: 1px dotted lightgray;
        padding-top: 20px;
        .lang-li-wrap {
          display: flex;
          .li-text {
            margin-right: 15px;
            i {
              display: block;
              margin-top: 20px;
              cursor: pointer;
            }
          }
          .li-content {
            flex: 1;
          }
        }
      }
    }
    .li {
      position: relative;
      margin-bottom: 15px;
      height: 100%;
      &:after {
        content: '';
        width: 100%;
        height: 1px;
        position: absolute;
        bottom: -1px;
        left: 0;
        transform: scaleX(0);
        background-color: $green;
        transition-duration: 0.3s;
        transition-timing-function: ease;
        transition-delay: 0s;
      }
      &:hover:after {
        border-bottom: 1px solid transparent;
        transform: scaleX(1);
      }
      .form-title {
        font-size: 24px;
        &::-webkit-input-placeholder {
          font-size: 24px;
        }
      }
      .title-area {
        font-size: 20px;
        &::-webkit-input-placeholder {
          font-size: 20px;
        }
      }
      .q-area {
        font-size: 18px;
        &::-webkit-input-placeholder {
          font-size: 18px;
        }
      }
    }
    textarea {
      background-color: transparent;
      border: none;
      resize: none;
      display: block;
      width: 100%;
      height: 35px;
    }
    .expand-area {
      position: relative;
      textarea {
        position: absolute;
        top: 0;
        left: 0;
        height: 100%;
        overflow: hidden;
      }
      pre {
        display: block;
        visibility: hidden;
        min-height: 100px;
        margin: 0;
      }
    }
    .add-lang {
      .li-item {
        display: flex;
        align-items: center;
        .label {
          margin-right: 15px;
        }
      }
    }
    input::-webkit-input-placeholder, textarea::-webkit-input-placeholder {
      color: $grey;
    }
    .el-tabs__item.is-active, .el-tabs__new-tab:hover {
      color: $green;
    }
  }
</style>
