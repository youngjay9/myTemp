<template>
  <div class="home">
    <UsageView/>
  </div>
</template>

<script>
// @ is an alias to /src
import UsageView from '@/components/usageView.vue'

export default {
  name: 'ScheduleView',
  components: {
    UsageView
}
}
</script>
