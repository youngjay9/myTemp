<template>
   <div id="about">
       
   </div>
</template>

<!-- <script>
import UsageView from "../components/usageView.vue";
export default {
  name: 'UsageView',
  components: {
    UsageView
  }
}
</script> -->
