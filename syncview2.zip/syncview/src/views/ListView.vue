<template>
   <topo-view></topo-view>
</template>

<script>
import TopoView from '@/components/TopoView.vue'

export default {
  name: 'ListView',
  components: {
    TopoView
}
}
</script>