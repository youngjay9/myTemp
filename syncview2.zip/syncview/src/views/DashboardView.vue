<template>
  <div class="dashboard">
    <v-conatin>
      <v-row>
        <v-col>
           <CabinetView />
        </v-col>
        <v-col>
           <PieView/>
        </v-col>
      </v-row>
    </v-conatin>
    
  </div>
</template>

<script>
import PieView from '@/components/PieView.vue'
import CabinetView from '@/components/CabinetView.vue'

export default {
  name: 'DashboardView',
  components: {
    PieView,
    CabinetView
}
}
</script>