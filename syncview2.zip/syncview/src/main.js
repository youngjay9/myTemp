import Vue from 'vue'
import App from './App.vue'
import vuetify from './plugins/vuetify'
import store from './store'
import router from './router'
import * as echarts from 'echarts'

Vue.prototype.$echarts = echarts
Vue.config.productionTip = false

new Vue({
  vuetify,
  store,
  router,
  render: h => h(App),
  data(){
    return {
      menus: [
      //   { value: 1, rounterName: 'Home', title: '首頁'},
      //   { value: 2, rounterName: 'char', title: '圖表'},
      //   { value: 3, rounterName: 'list', title: '清單'},
      //   { value: 3, rounterName: 'about', title: '關於'}
      ]
    }
  }
}).$mount('#app')
