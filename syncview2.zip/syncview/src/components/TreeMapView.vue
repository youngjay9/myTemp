<template>
  <div id="treeMap" :style="{ width: '1000px', height: '500px' }"></div>
</template>

<script>
import axios from 'axios'
export default {
  name: "TreeMapView",
  data() {
    return {
        children: []
    };
  },
  mounted() {
    this.getAllServices();
    this.drawTreeMap();
  },
  methods: {
    getAllServices() {
      let self = this;
      axios({
        methods: "get",
        url: "http://localhost:8081/iims/api/hello",
      }).then((resp) => {
        self.children = resp.data;
      });
    },
    convert(source, target, basePath) {
      for (let key in source) {
        let path = basePath ? basePath + "." + key : key;
        if (!key.match(/^\$/)) {
          target.children = target.children || [];
          const child = {
            name: path,
          };
          target.children.push(child);
          this.convert(source[key], child, path);
        }
      }
      if (!target.children) {
        target.value = source.$count || 1;
      } else {
        target.children.push({
          name: basePath,
          value: source.$count,
        });
      }
    },
    drawTreeMap() {
      let treeMap = this.$echarts.init(document.getElementById("treeMap"));
      treeMap.setOption(
        ({
          title: {
            text: "ECharts Options",
            subtext: "2016/04",
            left: "leafDepth",
          },
          tooltip: {},
          series: [
            {
              name: "option",
              type: "treemap",
              visibleMin: 300,
              data: self.children,
              leafDepth: 2,
              levels: [
                {
                  itemStyle: {
                    borderColor: "#555",
                    borderWidth: 4,
                    gapWidth: 4,
                  },
                },
                {
                  colorSaturation: [0.3, 0.6],
                  itemStyle: {
                    borderColorSaturation: 0.7,
                    gapWidth: 2,
                    borderWidth: 2,
                  },
                },
                {
                  colorSaturation: [0.3, 0.5],
                  itemStyle: {
                    borderColorSaturation: 0.6,
                    gapWidth: 1,
                  },
                },
                {
                  colorSaturation: [0.3, 0.5],
                },
              ],
            },
          ],
        })
      );
    },
  },
};

</script>
