<template>
  <div id="myChartBar" :style="{width: auto, height: '200px'}"></div>
</template>

<script>
export default {
  name: 'BarView',
  data () {
    return {
      msg: 'Welcome to kalacloud.com'
    }
  },
  mounted(){
    this.drawLine();
  },
  methods: {
    drawLine(){
        // 基于刚刚准备好的 DOM 容器，初始化 EChart 实例
        let myChart = this.$echarts.init(document.getElementById('myChartBar'))
        // 绘制图表
        myChart.setOption({
            title: { text: 'API 服務使用頻率' },
            tooltip: {},
            xAxis: {
                data: ["IIMS","IGMS","DCIM","Render","Grafana"]
            },
            yAxis: {},
            series: [{
                name: '数量',
                type: 'bar',
                data: [6, 5, 33, 20, 79]
            }]
        });
    }
  }
}
</script>