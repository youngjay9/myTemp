<template>
  <div id="topo" :style="{ width: '1000px', height: '500px' }"></div>
</template>

<script>
export default {
  name: "topoView",
  data() {
    return {};
  },
  mounted() {
    this.drawTopo();
  },
  methods: {
    drawTopo() {
      let topo = this.$echarts.init(document.getElementById("topo"));
      topo.setOption({
        title: {
          text: "",
        },
        tooltip: {},
        animationDurationUpdate: 1500,
        animationEasingUpdate: "quinticInOut",
        label: {
          normal: {
            show: true,
            textStyle: {
              fontSize: 12,
            },
          },
        },
        legend: {
          x: "center",
          show: false,
          data: ["前端", "後端", "平行"],
        },
        series: [
          {
            type: "graph",
            layout: "force",
            symbolSize: 45,
            focusNodeAdjacency: true,
            roam: true,
            categories: [
              {
                name: "前端",
                itemStyle: {
                  normal: {
                    color: "#009800",
                  },
                },
              },
              {
                name: "平行",
                itemStyle: {
                  normal: {
                    color: "#4592FF",
                  },
                },
              },
              {
                name: "後端",
                itemStyle: {
                  normal: {
                    color: "#3592F",
                  },
                },
              },
            ],
            label: {
              normal: {
                show: true,
                textStyle: {
                  fontSize: 12,
                },
              },
            },
            force: {
              repulsion: 1000,
            },
            edgeSymbolSize: [4, 50],
            edgeLabel: {
              normal: {
                show: true,
                textStyle: {
                  fontSize: 10,
                },
                formatter: "{c}",
              },
            },
            data: [
              {
                name: "Clarify01p",
                draggable: true,
              },
              {
                name: "ENCS",
                category: 1,
                draggable: true,
              },
              {
                name: "IDC-CRMODSTA01P",
                category: 1,
                draggable: true,
              },
              {
                name: "IDC-CRMODSTA02P",
                category: 1,
                draggable: true,
              },
              {
                name: "IDC-PKIRA01P",
                category: 1,
                draggable: true,
              },
              {
                name: "IDC-RENWEB01P",
                category: 1,
                draggable: true,
              },
              {
                name: "MCH",
                category: 1,
                draggable: true,
              },
              {
                name: "PC-AIRTS-03",
                category: 1,
                draggable: true,
              },
              {
                name: "PC-IMGSTOR01",
                category: 1,
                draggable: true,
              },
              {
                name: "PC-NICESC01",
                category: 1,
                draggable: true,
              },
              {
                name: "RBT",
                category: 1,
                draggable: true,
              },
              {
                name: "arbor01p",
                category: 1,
                draggable: true,
              },
              {
                name: "bkup01p",
                category: 1,
                draggable: true,
              },
            ],
            links: [
              {
                source: 0,
                target: 1,
                category: 0,
                value: "前端",
              },
              {
                source: 0,
                target: 2,
                value: "前端",
              },
              {
                source: 0,
                target: 3,
                value: "房东",
              },
              {
                source: 0,
                target: 4,
                value: "朋友",
              },
              {
                source: 1,
                target: 2,
                value: "表亲",
              },
              {
                source: 0,
                target: 5,
                value: "朋友",
              },
              {
                source: 4,
                target: 5,
                value: "姑姑",
              },
              {
                source: 2,
                target: 8,
                value: "叔叔",
              },
              {
                source: 0,
                target: 12,
                value: "朋友",
              },
              {
                source: 6,
                target: 11,
                value: "爱人",
              },
              {
                source: 6,
                target: 3,
                value: "朋友",
              },
              {
                source: 7,
                target: 5,
                value: "朋友",
              },
              {
                source: 9,
                target: 10,
                value: "朋友",
              },
              {
                source: 3,
                target: 10,
                value: "朋友",
              },
              {
                source: 2,
                target: 11,
                value: "同学",
              },
            ],
            lineStyle: {
              normal: {
                opacity: 0.9,
                width: 1,
                curveness: 0,
              },
            },
          },
        ],
      });
    },
  },
};
</script>
