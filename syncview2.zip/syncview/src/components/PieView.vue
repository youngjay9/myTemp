<template>
  <div id="pieGraph" :style="{width: '600px', height: '300px'}"></div>
</template>

<script>
export default {
    name: 'PieView',
    data() {
        return {}
    },
    mounted(){
        this.drawPie();
    },
    methods: {
        drawPie() {
            let pieGraph = this.$echarts.init(document.getElementById('pieGraph'));
            pieGraph.setOption({
                title: {
                    text: '某站點使用者存取來源',
                    subtext: '純屬虛構',
                    x: 'center'
                },
                tooltip: {
                    trigger: 'item',
                    formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                series: [
                    {
                        name: '存取來源',
                        type: 'pie',
                        radius: '55%',
                        center: ['50%', '60%'],
                        data: [
                            { value: 335, name: '直接存取' },
                            { value: 310, name: '郵件行銷' },
                            { value: 234, name: '聯盟廣告' },
                            { value: 135, name: '視訊廣告' },
                            { value: 1548, name: '搜尋引擎' }
                        ],
                        itemStyle: {
                            emphasis: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            })
        }
    }
}
</script>