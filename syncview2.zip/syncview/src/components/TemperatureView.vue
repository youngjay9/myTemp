<template>
    <div>
        <div id="main" style="width: 400px; height: 400px;"></div>
    </div>
</template>

<script>
export default {
    name: 'TemperatureView'
    
}

</script>