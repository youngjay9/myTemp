<template>
  <div>
    
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'HelloWorld',
  data () {
    return {
      services: ''
    }
  },
  mounted(){
    this.getAllServices();
  },
  methods: {
     getAllServices: function(){
      let self = this;
      axios({
        methods: 'get',
        url: 'http://132.145.121.108:8081/render/api/serviceAbnormalTop10'
      })
      .then((resp) => {
        self.services = resp.data;
      });
    }
  }
}
</script>