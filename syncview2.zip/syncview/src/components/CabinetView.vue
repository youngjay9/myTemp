<template>
  <div id="CabinetView" :style="{ width: auto, height: '500px' }"></div>
</template>
<script>
export default {
  name: "CabinetView",
  data() {
    return {
      deviceData: [
        ["機櫃", "伺服器","網路設備","儲存設備"],
        [22, 30, 33, 44],
      ]
    };
  },
    mounted(){
    this.drawCabinet();
  },
  methods: {
    drawCabinet() {
      let myChart = this.$echarts.init(document.getElementById("CabinetView"));
      myChart.setOption({
        backgroundColor: "#061326",
        title: {
          text: "",
          textStyle: {
            fontSize: 12,
            fontWeight: "normal",
            color: "#65aaf1", //标题颜色
          },
          left: "2%",
        },
        color: ["#004558"],
        tooltip: {
          trigger: "axis",
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: "shadow", // 默认为直线，可选为：'line' | 'shadow'
          },
          formatter: "{b} :{c}",
        },
        xAxis: [
          {
            type: "category",
            data: this.deviceData[0],
            axisTick: {
              alignWithLabel: true,
            },
            nameTextStyle: {
              color: "#82b0ec",
            },
            axisLine: {
              show: false,
              lineStyle: {
                color: "#82b0ec",
              },
            },
            axisLabel: {
              textStyle: {
                color: "#8fd5f3",
              },
              margin: 30,
            },
          },
        ],
        yAxis: [
          {
            show: false,
            type: "value",
            axisLabel: {
              textStyle: {
                color: "#fff",
              },
            },
            splitLine: {
              lineStyle: {
                color: "#0c2c5a",
              },
            },
            axisLine: {
              show: false,
            },
          },
        ],
        series: [
          {
            name: "",
            type: "pictorialBar",
            symbolSize: [40, 10],
            symbolOffset: [0, -6],
            symbolPosition: "end",
            z: 12,
            // "barWidth": "0",
            label: {
              normal: {
                show: true,
                position: "top",
                // "formatter": "{c}%"
                fontSize: 25,
                fontWeight: "bold",
                color: "#34DCFF",
              },
            },
            color: "#1abcf1",
            data: this.deviceData[1],
          },
          {
            name: "",
            type: "pictorialBar",
            symbolSize: [40, 10],
            symbolOffset: [0, 7],
            // "barWidth": "20",
            z: 12,
            color: "#2DB1EF",
            data: this.deviceData[1],
          },
          {
            name: "",
            type: "pictorialBar",
            symbolSize: [50, 15],
            symbolOffset: [0, 12],
            z: 10,
            itemStyle: {
              normal: {
                color: "transparent",
                borderColor: "#2EA9E5",
                borderType: "solid",
                borderWidth: 1,
              },
            },
            data: this.deviceData[1],
          },
          {
            name: "",
            type: "pictorialBar",
            symbolSize: [70, 20],
            symbolOffset: [0, 18],
            z: 10,
            itemStyle: {
              normal: {
                color: "transparent",
                borderColor: "#19465D",
                borderType: "solid",
                borderWidth: 2,
              },
            },
            data: this.dd,
          },
          {
            type: "bar",
            //silent: true,
            barWidth: "40",
            barGap: "10%", // Make series be overlap
            barCateGoryGap: "10%",
            itemStyle: {
              normal: {
                color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 0.7, [
                  {
                    offset: 0,
                    color: "#087cf9",
                  },
                  {
                    offset: 1,
                    color: "#09408a",
                  },
                ]),
                opacity: 0.8,
              },
            },
            data: this.deviceData[1],
          },
        ],
      });
    },
  },
};
</script>
