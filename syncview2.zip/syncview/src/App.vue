<template>
  <div id="app">
  <v-app id="inspire">
    <v-app-bar
      app
      color="white"
      flat
    >
      <v-avatar
        :color="$vuetify.breakpoint.smAndDown ? 'grey darken-1' : 'transparent'"
        size="32"
      ></v-avatar>

      <v-tabs
        centered
        class="ml-n9"
        color="grey darken-1"
      >
        <v-tab
          v-for="link in links"
          :key="`${link.id}`" 
          :to="`${link.path}`"
        >{{ link.pageName }}
          <!-- <router-link :to="`${link.path}`" >{{ link.pageName }}</router-link> -->
        </v-tab>
      </v-tabs>

      <v-avatar
        class="hidden-sm-and-down"
        color="grey darken-1 shrink"
        size="32"
      ></v-avatar>
    </v-app-bar>

    <v-main class="grey lighten-3">
      <v-container>
            <v-sheet
              min-height="70vh"
              rounded="lg"
            >
              <router-view />
            </v-sheet>

      </v-container>
    </v-main>
  </v-app>
  </div>
</template>

<script>
  export default {
    components: {
},
    data: () => ({
      links: [
        {id: 1,pageName: '首頁',path: '/'},
        {id: 2,pageName: '圖表',path: '/dashboard'},
        {id: 3,pageName: '清單',path: '/list'},
        {id: 4,pageName: '行程',path: '/schedule'},
        {id: 4,pageName: '關於',path: '/about'}
      ],
    }),
  }
</script>
<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
