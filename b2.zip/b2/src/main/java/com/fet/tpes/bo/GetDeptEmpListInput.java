package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class GetDeptEmpListInput extends BaseInputBo {

	private String division;
	private String department;
	private String user;
	private String pwwd; // 密碼 (for codeScan)
	
	// 參數檢查失敗時傳訊息用
	private String errorMsg;
	
	@Override
	public boolean isValid() {
		boolean pass = true;
		
		if(StringUtil.isEmpty(user)) {
			pass = false;
			errorMsg = "input 參數缺少 user";
		}
		else if (StringUtil.isEmpty(pwwd)) {
			pass = false;
			errorMsg = "input 參數缺少 password";
		}
		else if (StringUtil.isEmpty(division)) {
			pass = false;
			errorMsg = "input 參數缺少 division";
		}
		else if (StringUtil.isEmpty(department)) {
			pass = false;
			errorMsg = "input 參數缺少 department";
		}
		
		return pass;
	}

	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPwwd() {
		return pwwd;
	}
	public void setPwwd(String pwwd) {
		this.pwwd = pwwd;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}
