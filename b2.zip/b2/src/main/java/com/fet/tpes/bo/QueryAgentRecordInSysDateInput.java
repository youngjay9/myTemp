package com.fet.tpes.bo;

import java.util.Date;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryAgentRecordInSysDateInput extends BaseInputBo{
	private Date sysDate;
	private String status;	

	@Override
	public boolean isValid() {
		boolean result = true;
		
		if(sysDate == null) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數sysDate為空值");
		} else if(StringUtil.isEmpty(status)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數status為空值");
		} else if(StringUtil.isEmpty(this.getEmpNo())) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數EmpNo為空值");
		} else if(StringUtil.isEmpty(this.getRegion())) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數Region為空值");
		}	
		
		return result;
	}
	
	public Date getSysDate() {
		return sysDate;
	}
	public void setSysDate(Date sysDate) {
		this.sysDate = sysDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
