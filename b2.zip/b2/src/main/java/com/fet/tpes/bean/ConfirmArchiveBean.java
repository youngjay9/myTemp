package com.fet.tpes.bean;

public class ConfirmArchiveBean {

	private String electricNum;
	private String archiveNum;
	private TpesFormBean form;
	
	public String getElectricNum() {
		return electricNum;
	}
	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}
	public String getArchiveNum() {
		return archiveNum;
	}
	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}
	public TpesFormBean getForm() {
		return form;
	}
	public void setForm(TpesFormBean form) {
		this.form = form;
	}
}
