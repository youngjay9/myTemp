package com.fet.tpes.bean;

import java.util.Date;

import com.fet.tpes.entity.CfgCertificateRule;

public class CfgCertificateRuleBean {

	private Integer seq;
	private String category;
	private String formType;
	private String formTypeDesc;
	private String acceptItem;
	private String acceptItemDesc;
	private String identityType;
	private String fileCode;
	private String fileCodeDesc;
	private String signFlag;
	private String sealFlag;
	private String acctUploadFlag;
	private String applyType;
	private String status;
	private Date createDate;
	private String createAuthor;
	private Date updateDate;
	private String updateAuthor;
	
	public CfgCertificateRuleBean(CfgCertificateRule cfgCertificateRule) {
		this.seq = cfgCertificateRule.getSeq();
		this.category = cfgCertificateRule.getCategory();
		this.formType = cfgCertificateRule.getFormType();
		this.formTypeDesc = cfgCertificateRule.getFormTypeDesc();
		this.acceptItem = cfgCertificateRule.getAcceptItem();
		this.acceptItemDesc = cfgCertificateRule.getAcceptItemDesc();
		this.identityType = cfgCertificateRule.getIdentityType();
		this.fileCode = cfgCertificateRule.getFileCode();
		this.fileCodeDesc = cfgCertificateRule.getFileCodeDesc();
		this.signFlag = cfgCertificateRule.getSignFlag();
		this.sealFlag = cfgCertificateRule.getSealFlag();
		this.acctUploadFlag = cfgCertificateRule.getAcctUploadFlag();
		this.applyType = cfgCertificateRule.getApplyType();
		this.status = cfgCertificateRule.getStatus();
		this.createDate = cfgCertificateRule.getCreateDate();
		this.createAuthor = cfgCertificateRule.getCreateAuthor();
		this.updateDate = cfgCertificateRule.getUpdateDate();
		this.updateAuthor = cfgCertificateRule.getUpdateAuthor();
	}
	
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getFormType() {
		return formType;
	}
	public void setFormType(String formType) {
		this.formType = formType;
	}
	public String getFormTypeDesc() {
		return formTypeDesc;
	}
	public void setFormTypeDesc(String formTypeDesc) {
		this.formTypeDesc = formTypeDesc;
	}
	public String getAcceptItem() {
		return acceptItem;
	}
	public void setAcceptItem(String acceptItem) {
		this.acceptItem = acceptItem;
	}
	public String getAcceptItemDesc() {
		return acceptItemDesc;
	}
	public void setAcceptItemDesc(String acceptItemDesc) {
		this.acceptItemDesc = acceptItemDesc;
	}
	public String getIdentityType() {
		return identityType;
	}
	public void setIdentityType(String identify) {
		this.identityType = identify;
	}
	public String getFileCode() {
		return fileCode;
	}
	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}
	public String getFileCodeDesc() {
		return fileCodeDesc;
	}
	public void setFileCodeDesc(String fileCodeDesc) {
		this.fileCodeDesc = fileCodeDesc;
	}
	public String getSignFlag() {
		return signFlag;
	}
	public void setSignFlag(String signFlag) {
		this.signFlag = signFlag;
	}
	public String getSealFlag() {
		return sealFlag;
	}
	public void setSealFlag(String sealFlag) {
		this.sealFlag = sealFlag;
	}
	public String getAcctUploadFlag() {
		return acctUploadFlag;
	}

	public void setAcctUploadFlag(String acctUploadFlag) {
		this.acctUploadFlag = acctUploadFlag;
	}

	public String getApplyType() {
		return applyType;
	}

	public void setApplyType(String applyType) {
		this.applyType = applyType;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateAuthor() {
		return createAuthor;
	}
	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateAuthor() {
		return updateAuthor;
	}
	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}
}
