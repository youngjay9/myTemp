package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryGeneralEmpByListOutput extends BaseOutputBo{
	private List<EmpInfoBean> generalEmpInfoBeanList;

	public List<EmpInfoBean> getGeneralEmpInfoBeanList() {
		return generalEmpInfoBeanList;
	}

	public void setGeneralEmpInfoBeanList(List<EmpInfoBean> generalEmpInfoBeanList) {
		this.generalEmpInfoBeanList = generalEmpInfoBeanList;
	}
}
