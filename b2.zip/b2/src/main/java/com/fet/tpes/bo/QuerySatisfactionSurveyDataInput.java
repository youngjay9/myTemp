package com.fet.tpes.bo;

import java.util.Map;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QuerySatisfactionSurveyDataInput extends BaseInputBo{


	private String startDate;
	private String endDate;
	private Map<String, String> acceptItemMap;

	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isBlank(getStartDate())) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數startDate為空值");
		} else if(StringUtil.isBlank(getEndDate())) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數endDate為空值");
		}

		return result;
	}

	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Map<String, String> getAcceptItemMap() {
		return acceptItemMap;
	}
	public void setAcceptItemMap(Map<String, String> acceptItemMap) {
		this.acceptItemMap = acceptItemMap;
	}
}
