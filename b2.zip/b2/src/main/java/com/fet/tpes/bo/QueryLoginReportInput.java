package com.fet.tpes.bo;

import java.util.Date;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryLoginReportInput extends BaseInputBo{
	private Date startDate;
	private Date endDate;
	
	
	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(startDate == null) {
			result = false;
			LogUtil.error(this.getClass(), "GenLoginReportInput input缺少參數startDate");
		}
		if(endDate == null) {
			result = false;
			LogUtil.error(this.getClass(), "GenLoginReportInput input缺少參數endDate");
		}
		return result;
	}
}
