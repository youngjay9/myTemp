package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class CancelFormInput extends BaseInputBo{
	private Integer formSeq;
	private String agent;
	private String cancelReason;
	private String cancelType;
	private String deptNum;
	private String deptName;
	
	public String getAgent() {
		return agent;
	}
	
	public void setAgent(String agent) {
		this.agent = agent;
	}

	public Integer getFormSeq() {
		return formSeq;
	}

	public void setFormSeq(Integer seq) {
		this.formSeq = seq;
	}

	public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

	public String getCancelType() {
		return cancelType;
	}

	public void setCancelType(String cancelType) {
		this.cancelType = cancelType;
	}

	public String getDeptNum() {
		return deptNum;
	}

	public void setDeptNum(String deptNum) {
		this.deptNum = deptNum;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		
		if(this.formSeq == null) {
			result = false;
			LogUtil.error(this.getClass(), "input 缺少 seq");
		}
		else if(this.getEmpNo() == null) {
			result = false;
			LogUtil.error(this.getClass(), "input 缺少 empNo");
		}
		
		return result;
	}
}
