package com.fet.tpes.bean;

import java.util.Date;

public class AccountingDispatchBean {

	private Integer seq; 
	private String region;
	private String className;
	private String accounting;     // 核算員編號
	private String accountingName; // 核算員姓名
	private String calculate;      // 檢算員編號
	private String calculateName;  // 檢算員姓名
	private String type;
	private String status;
	private String computeDate;   // 計算日
	private String electricNumStart; // 電號起號
	private String electricNumEnd; // 電號迄號
	private String settingUser;
	private String settingUserName;
	private Date createDate;
	private String createAuthor;
	private Date updateDate;
	private String updateAuthor;
	
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getAccounting() {
		return accounting;
	}
	public void setAccounting(String accounting) {
		this.accounting = accounting;
	}
	public String getAccountingName() {
		return accountingName;
	}
	public void setAccountingName(String accountingName) {
		this.accountingName = accountingName;
	}
	public String getCalculate() {
		return calculate;
	}
	public void setCalculate(String calculate) {
		this.calculate = calculate;
	}
	public String getCalculateName() {
		return calculateName;
	}
	public void setCalculateName(String calculateName) {
		this.calculateName = calculateName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getElectricNumStart() {
		return electricNumStart;
	}
	public void setElectricNumStart(String electricNumStart) {
		this.electricNumStart = electricNumStart;
	}
	public String getElectricNumEnd() {
		return electricNumEnd;
	}
	public void setElectricNumEnd(String electricNumEnd) {
		this.electricNumEnd = electricNumEnd;
	}
	public String getSettingUser() {
		return settingUser;
	}
	public void setSettingUser(String settingUser) {
		this.settingUser = settingUser;
	}
	public String getSettingUserName() {
		return settingUserName;
	}
	public void setSettingUserName(String settingUserName) {
		this.settingUserName = settingUserName;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateAuthor() {
		return createAuthor;
	}
	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateAuthor() {
		return updateAuthor;
	}
	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}
	public String getComputeDate() {
		return computeDate;
	}
	public void setComputeDate(String computeDate) {
		this.computeDate = computeDate;
	}
	
	
}
