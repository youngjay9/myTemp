package com.fet.tpes.bean.material;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fet.tpes.bean.program.ProgramBean;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/11/9 下午 04:39
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RelatedInfoBean extends ProgramBean {

}
