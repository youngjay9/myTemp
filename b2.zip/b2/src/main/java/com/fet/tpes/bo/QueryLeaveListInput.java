package com.fet.tpes.bo;

import java.util.Date;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryLeaveListInput extends BaseInputBo {
	private String division;
	private String group;
	private String section;
	private String applicant;
	private String applicantName;
	private Date startDate;
	private Date endDate;
	private String agent;
	private String agentName;
	private String status;
	private String dataSource;
	private boolean needQueryOtherGroupLeave;

	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getApplicant() {
		return applicant;
	}
	public void setApplicant(String applicant) {
		this.applicant = applicant;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getAgent() {
		return agent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public boolean isNeedQueryOtherGroupLeave() {
		return needQueryOtherGroupLeave;
	}
	public void setNeedQueryOtherGroupLeave(boolean needQueryOtherGroupLeave) {
		this.needQueryOtherGroupLeave = needQueryOtherGroupLeave;
	}
	@Override
	public boolean isValid() {
		return true;
	}
}
