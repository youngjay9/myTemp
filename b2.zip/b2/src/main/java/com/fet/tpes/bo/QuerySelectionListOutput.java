package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.CfgSystemProperties;

public class QuerySelectionListOutput extends BaseOutputBo{
	private List<CfgSystemProperties> configList;

	public List<CfgSystemProperties> getConfigList() {
		return configList;
	}

	public void setConfigList(List<CfgSystemProperties> configList) {
		this.configList = configList;
	}
	
	
}
