package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;
import org.apache.commons.lang3.StringUtils;

public class RecordBrowseFormInput extends BaseInputBo{
	private Integer seq;
	private String browser;
	private String browserName;
	private String browsePage;
	private String browseStyle;
	
	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public String getBrowsePage() {
		return browsePage;
	}

	public void setBrowsePage(String browsePage) {
		this.browsePage = browsePage;
	}

	public String getBrowseStyle() {
		return browseStyle;
	}

	public void setBrowseStyle(String browseStyle) {
		this.browseStyle = browseStyle;
	}
	

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getBrowserName() {
		return browserName;
	}

	public void setBrowserName(String browserName) {
		this.browserName = browserName;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(this.seq == null) {
			result = false;
			LogUtil.error(this.getClass(), "RecordBrowseFormInput input缺少參數seq");
		}
		if(StringUtils.isEmpty(this.browsePage)) {
			result = false;
			LogUtil.error(this.getClass(), "RecordBrowseFormInput input缺少參數browsePage");
		}
		if(StringUtils.isEmpty(this.browseStyle)) {
			result = false;
			LogUtil.error(this.getClass(), "RecordBrowseFormInput input缺少參數browseStyle");
		}
		if(StringUtil.isEmpty(this.browser)) {
			result = false;
			LogUtil.error(this.getClass(), "RecordBrowseFormInput input缺少參數browser");
		}
		if(StringUtil.isEmpty(this.browserName)) {
			result = false;
			LogUtil.error(this.getClass(), "RecordBrowseFormInput input缺少參數browserName");
		}
		return result;
	}
}
