package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryDirectArchiveFormInput extends BaseInputBo{
	private List<String> formStatusList;
	private String acceptNum;
	private String electricNum;
	private String archiveNum; 
	
	public List<String> getFormStatusList() {
		return formStatusList;
	}



	public void setFormStatusList(List<String> formStatusList) {
		this.formStatusList = formStatusList;
	}


	
	
	public String getAcceptNum() {
		return acceptNum;
	}



	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}



	public String getElectricNum() {
		return electricNum;
	}



	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}



	


	public String getArchiveNum() {
		return archiveNum;
	}



	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}



	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(this.formStatusList)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryDirectArchiveFormInput input缺少formStatusList");
		}
		return result;
	}
}
