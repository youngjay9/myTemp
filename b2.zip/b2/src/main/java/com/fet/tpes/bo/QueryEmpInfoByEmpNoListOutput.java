package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryEmpInfoByEmpNoListOutput extends BaseOutputBo{
	private List<EmpInfoBean> empInfoBeanList;

	public List<EmpInfoBean> getEmpInfoBeanList() {
		return empInfoBeanList;
	}

	public void setEmpInfoBeanList(List<EmpInfoBean> empInfoBeanList) {
		this.empInfoBeanList = empInfoBeanList;
	}
}
