package com.fet.tpes.bo.pmc;

public class GetPmcComputerListInput {
	
	private String divisionCode;
	private String groupCode;
	private String sectionCode;
	private String hostName;
	private String statusCode;
	private String pmcType;
	
	public String getDivisionCode() {
		return divisionCode;
	}
	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public String getSectionCode() {
		return sectionCode;
	}
	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getPmcType() {
		return pmcType;
	}
	public void setPmcType(String pmcType) {
		this.pmcType = pmcType;
	}
}
