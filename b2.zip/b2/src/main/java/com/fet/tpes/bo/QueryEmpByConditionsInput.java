package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryEmpByConditionsInput extends BaseInputBo{
	
	private String empDivision; // 員工單位
	private String empGroup; // 員工組別
	private String empSection; // 員工課別
	private String empPosSeq; //職位順序  001為該單位主管
	private String status;
	
	public String getEmpDivision() {
		return empDivision;
	}

	public void setEmpDivision(String empDivision) {
		this.empDivision = empDivision;
	}

	public String getEmpGroup() {
		return empGroup;
	}

	public void setEmpGroup(String empGroup) {
		this.empGroup = empGroup;
	}

	public String getEmpSection() {
		return empSection;
	}

	public void setEmpSection(String empSection) {
		this.empSection = empSection;
	}

	public String getEmpPosSeq() {
		return empPosSeq;
	}

	public void setEmpPosSeq(String empPosSeq) {
		this.empPosSeq = empPosSeq;
	}	

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		
		if(StringUtil.isEmpty(empDivision) && StringUtil.isEmpty(empGroup)
			&& StringUtil.isEmpty(empSection) && StringUtil.isEmpty(empPosSeq)
			&& StringUtil.isEmpty(this.getEmpNo()) &&  StringUtil.isEmpty(status)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數empDivision,empGroup,empSection,empPosSeq,empNo,status皆為空值");			
		}			
		return result;
	}

}
