package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AgentApplicationBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryAgentRecordInSysDateOutput extends BaseOutputBo{

	private List<AgentApplicationBean> agentApplicationBeanList;

	public List<AgentApplicationBean> getAgentApplicationBeanList() {
		return agentApplicationBeanList;
	}
	public void setAgentApplicationBeanList(List<AgentApplicationBean> agentApplicationBeanList) {
		this.agentApplicationBeanList = agentApplicationBeanList;
	}
}
