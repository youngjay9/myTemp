package com.fet.tpes.bo;


import com.fet.tpes.bo.base.BaseInputBo;


public class CreateMarqueeInput extends BaseInputBo {
	private String marqueeName;
	private String marqueeType;
	private String marqueeContent;
	private String marqueeContentHTML;
	private String memo;
	private String region;
	private String releaseStartDate;
	private String releaseEndDate;
	private String attachedFileName;
	
	public String getAttachedFileName() {
		return attachedFileName;
	}

	public void setAttachedFileName(String attachedFileName) {
		this.attachedFileName = attachedFileName;
	}

	public String getReleaseEndDate() {
		return releaseEndDate;
	}

	public void setReleaseEndDate(String releaseEndDate) {
		this.releaseEndDate = releaseEndDate;
	}

	public String getMarqueeName() {
		return marqueeName;
	}

	public void setMarqueeName(String marqueeName) {
		this.marqueeName = marqueeName;
	}

	public String getMarqueeType() {
		return marqueeType;
	}

	public void setMarqueeType(String marqueeType) {
		this.marqueeType = marqueeType;
	}

	public String getMarqueeContent() {
		return marqueeContent;
	}

	public void setMarqueeContent(String marqueeContent) {
		this.marqueeContent = marqueeContent;
	}

	public String getMarqueeContentHTML() {
		return marqueeContentHTML;
	}

	public void setMarqueeContentHTML(String marqueeContentHTML) {
		this.marqueeContentHTML = marqueeContentHTML;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getReleaseStartDate() {
		return releaseStartDate;
	}

	public void setReleaseStartDate(String releaseStartDate) {
		this.releaseStartDate = releaseStartDate;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		return result;
	}

}
