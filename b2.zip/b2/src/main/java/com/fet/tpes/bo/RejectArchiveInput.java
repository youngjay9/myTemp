package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.ConfirmArchiveBean;
import com.fet.tpes.bo.base.BaseInputBo;

public class RejectArchiveInput extends BaseInputBo {

	private List<ConfirmArchiveBean> beanList;

	@Override
	public boolean isValid() {
		return true;
	}

	public List<ConfirmArchiveBean> getBeanList() {
		return beanList;
	}
	public void setBeanList(List<ConfirmArchiveBean> beanList) {
		this.beanList = beanList;
	}
}
