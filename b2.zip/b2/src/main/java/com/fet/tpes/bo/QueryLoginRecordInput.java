package com.fet.tpes.bo;

import java.util.Date;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import org.apache.commons.lang3.StringUtils;

public class QueryLoginRecordInput extends BaseInputBo{
	private String abnormalHourStart;
	private String abnormalHourEnd;
	private Date startDate;
	private Date endDate;
	
	
	public String getAbnormalHourStart() {
		return abnormalHourStart;
	}


	public void setAbnormalHourStart(String abnormalHourStart) {
		this.abnormalHourStart = abnormalHourStart;
	}


	public String getAbnormalHourEnd() {
		return abnormalHourEnd;
	}


	public void setAbnormalHourEnd(String abnormalHourEnd) {
		this.abnormalHourEnd = abnormalHourEnd;
	}


	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtils.isEmpty(this.abnormalHourStart)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryLoginRecordInput input缺少參數abnormalHourStart");
		}
		if(StringUtils.isEmpty(this.abnormalHourEnd)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryLoginRecordInput input缺少參數abnormalHourEnd");
		}
		if(startDate == null) {
			result = false;
			LogUtil.error(this.getClass(), "QueryLoginRecordInput input缺少參數startDate");
		}
		if(endDate == null) {
			result = false;
			LogUtil.error(this.getClass(), "QueryLoginRecordInput input缺少參數endDate");
		}
		return result;
	}
}
