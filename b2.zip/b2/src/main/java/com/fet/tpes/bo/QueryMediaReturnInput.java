package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/11/17 下午 02:23
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
public class QueryMediaReturnInput extends BaseInputBo {

	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(getEmpNo());
	}

}
