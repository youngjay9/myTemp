package com.fet.tpes.bo;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QuerySpacificRoleInput extends BaseInputBo {

	private String roleCode;
	private EmpInfoBean empInfo;
	
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(getEmpNo()) && StringUtil.isNotEmpty(getRegion());
	}

	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public EmpInfoBean getEmpInfo() {
		return empInfo;
	}
	public void setEmpInfo(EmpInfoBean empInfo) {
		this.empInfo = empInfo;
	}
}
