package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryDeptByDivisionAndGroupInput extends BaseInputBo{
	
	private String division;
	private String group;
	private String section;

	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(division)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數division為空值");
		} else if(StringUtil.isEmpty(group)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數group為空值");
		}
		
		return result;
	}

}
