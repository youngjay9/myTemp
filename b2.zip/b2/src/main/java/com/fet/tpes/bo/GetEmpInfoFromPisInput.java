package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class GetEmpInfoFromPisInput extends BaseInputBo{
	private String dept;
	private String user;
	private String pwwd; // 密碼 (for codeScan)
	
	
	
	public String getDept() {
		return dept;
	}



	public void setDept(String dept) {
		this.dept = dept;
	}



	public String getUser() {
		return user;
	}



	public void setUser(String user) {
		this.user = user;
	}



	public String getPwwd() {
		return pwwd;
	}



	public void setPwwd(String pwwd) {
		this.pwwd = pwwd;
	}



	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.dept)) {
			result = false;
			LogUtil.error(this.getClass(), "GetEmpInfoFromPisInput input參數缺少dept");
		}
		if(StringUtil.isEmpty(this.user)) {
			result = false;
			LogUtil.error(this.getClass(), "GetEmpInfoFromPisInput input參數缺少user");
		}
		if(StringUtil.isEmpty(this.pwwd)) {
			result = false;
			LogUtil.error(this.getClass(), "GetEmpInfoFromPisInput input參數缺少password");
		}
		return result;
	}
}
