package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

import fr.opensagres.poi.xwpf.converter.core.utils.StringUtils;

public class QueryAccnterInput extends BaseInputBo{
	private String status;
	private String className;
	
	
	
	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getClassName() {
		return className;
	}



	public void setClassName(String className) {
		this.className = className;
	}



	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtils.isEmpty(this.status) && StringUtils.isEmpty(this.className)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryAccnterInput input同時缺少參數status與className");
		}
		return result;
	}
}
