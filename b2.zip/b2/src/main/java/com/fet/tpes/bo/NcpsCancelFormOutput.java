package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class NcpsCancelFormOutput extends BaseOutputBo {
	private String resultString;

	public String getResultString() {
		return resultString;
	}

	public void setResultString(String resultString) {
		this.resultString = resultString;
	}

}
