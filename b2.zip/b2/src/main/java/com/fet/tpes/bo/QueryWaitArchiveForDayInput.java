package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryWaitArchiveForDayInput extends BaseInputBo {
	private List<String> statusList;
	private boolean sendAllDayBefore;

	public List<String> getStatusList() {
		return statusList;
	}

	public void setStatusList(List<String> statusList) {
		this.statusList = statusList;
	}
	
	

	public boolean isSendAllDayBefore() {
		return sendAllDayBefore;
	}

	public void setSendAllDayBefore(boolean sendAllDayBefore) {
		this.sendAllDayBefore = sendAllDayBefore;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if (CollectionUtils.isEmpty(this.statusList)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryWaitArchiveForDayInput input參數缺少statusList");
		}
		return result;
	}

}
