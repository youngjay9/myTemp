package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.CfgMwareProperties;

public class QueryMwarePropertiesOutput extends BaseOutputBo {
	
	private List<CfgMwareProperties>  CfgMwarePropertiesList;

	public List<CfgMwareProperties> getCfgMwarePropertiesList() {
		return CfgMwarePropertiesList;
	}

	public void setCfgMwarePropertiesList(List<CfgMwareProperties> cfgMwarePropertiesList) {
		CfgMwarePropertiesList = cfgMwarePropertiesList;
	}
}
