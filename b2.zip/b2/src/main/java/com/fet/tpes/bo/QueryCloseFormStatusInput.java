package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QueryCloseFormStatusInput extends BaseInputBo {

	private String formType;
	private String acceptItem;
	
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(formType) && StringUtil.isNotEmpty(acceptItem);
	}

	public String getFormType() {
		return formType;
	}
	public void setFormType(String formType) {
		this.formType = formType;
	}
	public String getAcceptItem() {
		return acceptItem;
	}
	public void setAcceptItem(String acceptItem) {
		this.acceptItem = acceptItem;
	}
}
