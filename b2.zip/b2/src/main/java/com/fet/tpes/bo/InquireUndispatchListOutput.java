package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AccountingDispatchBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class InquireUndispatchListOutput extends BaseOutputBo{
	List<String> classNameList;
	List<AccountingDispatchBean> accountingDispatchBeanList;
	
	

	public List<AccountingDispatchBean> getAccountingDispatchBeanList() {
		return accountingDispatchBeanList;
	}

	public void setAccountingDispatchBeanList(List<AccountingDispatchBean> accountingDispatchBeanList) {
		this.accountingDispatchBeanList = accountingDispatchBeanList;
	}

	public List<String> getClassNameList() {
		return classNameList;
	}

	public void setClassNameList(List<String> classNameList) {
		this.classNameList = classNameList;
	}
	
	
}
