package com.fet.tpes.bo;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bean.TpesFormBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.entity.AccountingDispatch;

public class SaveDispatchInput extends BaseInputBo {

	private TpesFormBean form;
	private AccountingDispatch dispatch;
	private EmpInfoBean empInfoBean;
	
	@Override
	public boolean isValid() {
		return form != null;
	}
	
	public TpesFormBean getForm() {
		return form;
	}
	public void setForm(TpesFormBean form) {
		this.form = form;
	}
	public AccountingDispatch getDispatch() {
		return dispatch;
	}
	public void setDispatch(AccountingDispatch dispatch) {
		this.dispatch = dispatch;
	}

	public EmpInfoBean getEmpInfoBean() {
		return empInfoBean;
	}

	public void setEmpInfoBean(EmpInfoBean empInfoBean) {
		this.empInfoBean = empInfoBean;
	}
	
	
}
