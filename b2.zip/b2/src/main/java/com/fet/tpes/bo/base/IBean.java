package com.fet.tpes.bo.base;

import java.io.Serializable;

public interface IBean extends Serializable{
	
}
