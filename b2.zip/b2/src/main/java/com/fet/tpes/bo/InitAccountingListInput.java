package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class InitAccountingListInput extends BaseInputBo{
	
	@Override
	public boolean isValid() {
		boolean result = true;		
		if(StringUtil.isEmpty(this.getRegion())) {
			result = false;
			LogUtil.error(this.getClass(), "InitAccountingListInput input缺少參數region");
		}
		if(StringUtil.isEmpty(this.getEmpNo())) {
			result = false;
			LogUtil.error(this.getClass(), "InitAccountingListInput input缺少參數empNo");
		}
		return result;
	}
}
