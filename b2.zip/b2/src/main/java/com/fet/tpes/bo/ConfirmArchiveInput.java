package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class ConfirmArchiveInput extends BaseInputBo {

	private String electricNum;
	private String archiveNum;
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(electricNum) && StringUtil.isNotEmpty(archiveNum);
	}
	
	public String getElectricNum() {
		return electricNum;
	}
	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}
	public String getArchiveNum() {
		return archiveNum;
	}
	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}
}
