package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryFilesByUploadNoInput extends BaseInputBo {
	private Integer uploadNo;
	
	public Integer getUploadNo() {
		return uploadNo;
	}

	public void setUploadNo(Integer uploadNo) {
		this.uploadNo = uploadNo;
	}

	@Override
	public boolean isValid() {
		return uploadNo != null;
	}	
}
