package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class GetFormFileInput extends BaseInputBo {
	
	private String acceptNum;
	private String fmbhNo;
	private String apitCod;
	private String formType;
	
	@Override
	public boolean isValid() {
		boolean isPass = true;
		
		if(StringUtil.isEmptyOrNull(this.getRegion())) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.acceptNum)) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.apitCod)) {
			isPass = false;
		}
		
		return isPass;
	}

	public String getAcceptNum() {
		return acceptNum;
	}

	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}

	public String getFmbhNo() {
		return fmbhNo;
	}

	public void setFmbhNo(String fmbhNo) {
		this.fmbhNo = fmbhNo;
	}

	public String getApitCod() {
		return apitCod;
	}

	public void setApitCod(String apitCod) {
		this.apitCod = apitCod;
	}

	public String getFormType() {
		return formType;
	}

	public void setFormType(String formType) {
		this.formType = formType;
	}
}
