package com.fet.tpes.bo;

import com.fet.tpes.bean.AgentApplicationBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryNextAgentInfoByEmpOuput extends BaseOutputBo{
	private AgentApplicationBean nextLeaveBean;

	public AgentApplicationBean getNextLeaveBean() {
		return nextLeaveBean;
	}

	public void setNextLeaveBean(AgentApplicationBean nextLeaveBean) {
		this.nextLeaveBean = nextLeaveBean;
	}
}
