package com.fet.tpes.bo;

import java.util.Date;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QueryReadApplyInput extends BaseInputBo {

	private String acceptNum;
	private String electricNum;
	private String custName;
	private String archiveNum;
	private String contractType;
	private String fileReader;
	private String acceptStartDate;
	private String acceptEndDate;
	private String archiveStartDate;
	private String archiveEndDate;
	private Date readApplyStartDate;
	private Date readApplyEndDate;
	
	private String readNum;
	
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(getRegion());
	}
	
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
	public String getElectricNum() {
		return electricNum;
	}
	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getArchiveNum() {
		return archiveNum;
	}
	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getFileReader() {
		return fileReader;
	}

	public void setFileReader(String fileReader) {
		this.fileReader = fileReader;
	}

	public String getAcceptStartDate() {
		return acceptStartDate;
	}
	public void setAcceptStartDate(String acceptStartDate) {
		this.acceptStartDate = acceptStartDate;
	}
	public String getAcceptEndDate() {
		return acceptEndDate;
	}
	public void setAcceptEndDate(String acceptEndDate) {
		this.acceptEndDate = acceptEndDate;
	}
	public String getArchiveStartDate() {
		return archiveStartDate;
	}
	public void setArchiveStartDate(String archiveStartDate) {
		this.archiveStartDate = archiveStartDate;
	}
	public String getArchiveEndDate() {
		return archiveEndDate;
	}
	public void setArchiveEndDate(String archiveEndDate) {
		this.archiveEndDate = archiveEndDate;
	}
	public String getReadNum() {
		return readNum;
	}
	public void setReadNum(String readNum) {
		this.readNum = readNum;
	}

	public Date getReadApplyStartDate() {
		return readApplyStartDate;
	}

	public void setReadApplyStartDate(Date readApplyStartDate) {
		this.readApplyStartDate = readApplyStartDate;
	}

	public Date getReadApplyEndDate() {
		return readApplyEndDate;
	}

	public void setReadApplyEndDate(Date readApplyEndDate) {
		this.readApplyEndDate = readApplyEndDate;
	}


	
}
