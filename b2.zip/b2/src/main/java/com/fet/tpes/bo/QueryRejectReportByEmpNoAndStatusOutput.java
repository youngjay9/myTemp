package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.RejectReportBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryRejectReportByEmpNoAndStatusOutput extends BaseOutputBo{
	private List<RejectReportBean> rejectReportList;

	public List<RejectReportBean> getRejectReportList() {
		return rejectReportList;
	}

	public void setRejectReportList(List<RejectReportBean> rejectReportList) {
		this.rejectReportList = rejectReportList;
	}
	
}
