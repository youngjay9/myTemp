package com.fet.tpes.bo.pmc;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.controller.vo.pmc.PmcVersionVo;

public class UpdatePmcVersionOutput extends BaseOutputBo{
	
	private PmcVersionVo pmcVersion;

	public PmcVersionVo getPmcVersion() {
		return pmcVersion;
	}
	public void setPmcVersion(PmcVersionVo pmcVersion) {
		this.pmcVersion = pmcVersion;
	}
}
