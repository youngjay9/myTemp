package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryEmpRoleByRoleInEmpNoInput extends BaseInputBo{
	
	private String roleCode;

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(roleCode)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數roleCode為空值");
		}		
		return result;
	}

}
