package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import org.apache.commons.lang3.StringUtils;

public class QueryAccounterListInput extends BaseInputBo{
	private String status;
	
	
	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtils.isEmpty(this.status)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryAccounterListInput input缺少參數status");
		}
		return result;
	}
}
