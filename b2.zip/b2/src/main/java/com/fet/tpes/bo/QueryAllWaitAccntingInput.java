package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryAllWaitAccntingInput extends BaseInputBo{	
	private String region;
	private List<String> statusList;	
	private List<String> formStatusList;
	
	
	public String getRegion() {
		return region;
	}


	public void setRegion(String region) {
		this.region = region;
	}


	public List<String> getStatusList() {
		return statusList;
	}


	public void setStatusList(List<String> statusList) {
		this.statusList = statusList;
	}


	public List<String> getFormStatusList() {
		return formStatusList;
	}


	public void setFormStatusList(List<String> formStatusList) {
		this.formStatusList = formStatusList;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.region)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryAllWaitAccntingInput input參數缺少region");
		}
		if(CollectionUtils.isEmpty(this.statusList)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryAllWaitAccntingInput input參數缺少statusList");
		}
		if(CollectionUtils.isEmpty(this.formStatusList)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryAllWaitAccntingInput input參數缺少formStatusList");
		}
		return result;
	}
}
