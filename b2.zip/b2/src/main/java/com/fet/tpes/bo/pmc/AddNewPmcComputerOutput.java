package com.fet.tpes.bo.pmc;

import com.fet.tpes.bo.base.BaseOutputBo;

public class AddNewPmcComputerOutput extends BaseOutputBo {
}
