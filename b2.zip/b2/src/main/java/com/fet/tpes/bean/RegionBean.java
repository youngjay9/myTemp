package com.fet.tpes.bean;

import java.util.List;

public class RegionBean {
	
	private String regionCode;
	private String regionName;
	// 存放該 Region 底下的所有 department
	private List<DepartmentBean> departments;
	
	public String getRegionCode() {
		return regionCode;
	}
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	public List<DepartmentBean> getDepartments() {
		return departments;
	}
	public void setDepartments(List<DepartmentBean> departments) {
		this.departments = departments;
	}
}
