package com.fet.tpes.bo.pmc;

import com.fet.tpes.bean.RegionInfoBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

import java.util.Objects;
import java.util.regex.Pattern;

public class AddNewPmcComputerInput extends BaseInputBo {

	private String computerIp;
	private RegionInfoBean regionInfo;

	public String getComputerIp() {
		return computerIp;
	}

	public void setComputerIp(String computerIp) {
		this.computerIp = computerIp;
	}

	public RegionInfoBean getRegionInfo() {
		return regionInfo;
	}

	public void setRegionInfo(RegionInfoBean regionInfo) {
		this.regionInfo = regionInfo;
	}

	@Override
	public boolean isValid() {
		
		if(StringUtil.isEmpty(computerIp)) {
			return false;
		} else if (Objects.isNull(regionInfo)) {
			return false;
		} else {
			// valid ip
			Pattern PATTERN = Pattern.compile(
			        "^(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");
			
			return PATTERN.matcher(computerIp).matches();
		}
	}
}
