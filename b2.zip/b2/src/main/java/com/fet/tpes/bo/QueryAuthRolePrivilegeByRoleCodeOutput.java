package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AuthRolePrivilegeMapBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryAuthRolePrivilegeByRoleCodeOutput extends BaseOutputBo{
	private List<AuthRolePrivilegeMapBean> authRolePrivilegeMapBeanList;

	public List<AuthRolePrivilegeMapBean> getAuthRolePrivilegeMapBeanList() {
		return authRolePrivilegeMapBeanList;
	}

	public void setAuthRolePrivilegeMapBeanList(List<AuthRolePrivilegeMapBean> authRolePrivilegeMapBeanList) {
		this.authRolePrivilegeMapBeanList = authRolePrivilegeMapBeanList;
	}
}
