package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.entity.TpesFile;

public class RemoveMultiFileInput extends BaseInputBo {

	private List<TpesFile> fileList;
	
	@Override
	public boolean isValid() {
		return true;
	}

	public List<TpesFile> getFileList() {
		return fileList;
	}
	public void setFileList(List<TpesFile> fileList) {
		this.fileList = fileList;
	}

}
