package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.TpesFormBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryWaitArchiveForDayOutput extends BaseOutputBo {
	private List<TpesFormBean> tpesFormBeanList;

	public List<TpesFormBean> getTpesFormBeanList() {
		return tpesFormBeanList;
	}

	public void setTpesFormBeanList(List<TpesFormBean> tpesFormBeanList) {
		this.tpesFormBeanList = tpesFormBeanList;
	}

}
