package com.fet.tpes.bo;

import java.util.List;
import java.util.Map;

import com.fet.tpes.bean.AccountingBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryUnassignedListOutput extends BaseOutputBo{
	private List<AccountingBean> accountingBean;
	private Map<String, String> contractTypeMap;
	private Map<String, String> acceptItemMap;
	private String userType;

	public List<AccountingBean> getAccountingBean() {
		return accountingBean;
	}
	public void setAccountingBean(List<AccountingBean> accountingBean) {
		this.accountingBean = accountingBean;
	}
	public Map<String, String> getContractTypeMap() {
		return contractTypeMap;
	}
	public void setContractTypeMap(Map<String, String> contractTypeMap) {
		this.contractTypeMap = contractTypeMap;
	}
	public Map<String, String> getAcceptItemMap() {
		return acceptItemMap;
	}
	public void setAcceptItemMap(Map<String, String> acceptItemMap) {
		this.acceptItemMap = acceptItemMap;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
}
