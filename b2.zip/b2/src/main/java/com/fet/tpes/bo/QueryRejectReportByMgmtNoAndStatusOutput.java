package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.RejectReportBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryRejectReportByMgmtNoAndStatusOutput extends BaseOutputBo{
	private List<RejectReportBean> rejectReportBeanList;

	public List<RejectReportBean> getRejectReportBeanList() {
		return rejectReportBeanList;
	}

	public void setRejectReportBeanList(List<RejectReportBean> rejectReportBeanList) {
		this.rejectReportBeanList = rejectReportBeanList;
	}
}
