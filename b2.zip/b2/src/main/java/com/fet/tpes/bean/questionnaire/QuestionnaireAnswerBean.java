package com.fet.tpes.bean.questionnaire;

import java.util.List;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/10/26 下午 05:03
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
public class QuestionnaireAnswerBean {

    private Long questionnaireId;
    private String questionnaireName;
    private String region;
    private String acceptNum;
    private List<QuestionAnswerBean> questions;

    public Long getQuestionnaireId() {
        return questionnaireId;
    }

    public void setQuestionnaireId(Long questionnaireId) {
        this.questionnaireId = questionnaireId;
    }

    public String getQuestionnaireName() {
        return questionnaireName;
    }

    public void setQuestionnaireName(String questionnaireName) {
        this.questionnaireName = questionnaireName;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getAcceptNum() {
        return acceptNum;
    }

    public void setAcceptNum(String acceptNum) {
        this.acceptNum = acceptNum;
    }

    public List<QuestionAnswerBean> getQuestions() {
        return questions;
    }

    public void setQuestions(List<QuestionAnswerBean> questions) {
        this.questions = questions;
    }
}
