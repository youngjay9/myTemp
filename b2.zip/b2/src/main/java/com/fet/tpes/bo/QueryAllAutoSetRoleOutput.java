package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.AuthAutosetRole;

public class QueryAllAutoSetRoleOutput extends BaseOutputBo{
	List<AuthAutosetRole> authAutosetRoleList;

	public List<AuthAutosetRole> getAuthAutosetRoleList() {
		return authAutosetRoleList;
	}

	public void setAuthAutosetRoleList(List<AuthAutosetRole> authAutosetRoleList) {
		this.authAutosetRoleList = authAutosetRoleList;
	}
	
	
}
