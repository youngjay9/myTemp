package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryRejectReportByLeaderSignerInput extends BaseInputBo{
	private List<String> signerList;
	
	public List<String> getSignerList() {
		return signerList;
	}
	public void setSignerList(List<String> signerList) {
		this.signerList = signerList;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(signerList)) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數signerList為空值");
		}
		
		return result;
	}

}
