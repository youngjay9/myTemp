package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryReadNumOutput extends BaseOutputBo {

	private String readNum;

	public String getReadNum() {
		return readNum;
	}
	public void setReadNum(String readNum) {
		this.readNum = readNum;
	}
}
