package com.fet.tpes.bean.program;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/11/9 下午 04:43
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProgramItemBean {

    private Long programId;
    private Long materialId;
    private String materialName;

    public Long getProgramId() {
        return programId;
    }

    public void setProgramId(Long programId) {
        this.programId = programId;
    }

    public Long getMaterialId() {
        return materialId;
    }

    public void setMaterialId(Long materialId) {
        this.materialId = materialId;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }
}
