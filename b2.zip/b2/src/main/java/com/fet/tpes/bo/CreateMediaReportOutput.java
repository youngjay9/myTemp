package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;
import org.apache.poi.ss.usermodel.Workbook;

public class CreateMediaReportOutput extends BaseOutputBo {
	private Workbook report;

	public Workbook getReport() {
		return report;
	}
	public void setReport(Workbook report) {
		this.report = report;
	}
}
