package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

import java.util.Optional;

public class DownloadActiveMediaFileInput extends BaseInputBo {
	private String clientIp;

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	@Override
	public boolean isValid() {
		return Optional.ofNullable(getClientIp()).isPresent();
	}
}
