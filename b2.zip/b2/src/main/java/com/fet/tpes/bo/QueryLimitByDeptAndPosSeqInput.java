package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryLimitByDeptAndPosSeqInput extends BaseInputBo{
	private String deptPosSeq;
	
	
	public String getDeptPosSeq() {
		return deptPosSeq;
	}


	public void setDeptPosSeq(String deptPosSeq) {
		this.deptPosSeq = deptPosSeq;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.deptPosSeq)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryLimitByDeptAndPosSeqInput input參數缺少deptPosSeq");			
		}
		return result;
	}
}
