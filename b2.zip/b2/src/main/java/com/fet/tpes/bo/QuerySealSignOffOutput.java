package com.fet.tpes.bo;

import java.util.List;
import java.util.Map;

import com.fet.tpes.bean.SealSignOffBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QuerySealSignOffOutput extends BaseOutputBo {

	private List<SealSignOffBean> signOffList;
	private List<SealSignOffBean> waitSignOffList;
	private Map<String, String> acceptItemMap;

	public List<SealSignOffBean> getSignOffList() {
		return signOffList;
	}
	public void setSignOffList(List<SealSignOffBean> signOffList) {
		this.signOffList = signOffList;
	}
	public List<SealSignOffBean> getWaitSignOffList() {
		return waitSignOffList;
	}
	public void setWaitSignOffList(List<SealSignOffBean> waitSignOffList) {
		this.waitSignOffList = waitSignOffList;
	}
	public Map<String, String> getAcceptItemMap() {
		return acceptItemMap;
	}
	public void setAcceptItemMap(Map<String, String> acceptItemMap) {
		this.acceptItemMap = acceptItemMap;
	}
}
