package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryNextAgentInfoByEmpInput extends BaseInputBo{

	@Override
	public boolean isValid() {
		boolean result = true;
		
		if(StringUtil.isEmpty(this.getEmpNo())){
			result = false;
			LogUtil.error(this.getClass(), "傳入參數 EmpNo 為空值");
		} else if(StringUtil.isEmpty(this.getRegion())){
			result = false;
			LogUtil.error(this.getClass(), "傳入參數 Region 為空值");
		}
		return result;
	}

}
