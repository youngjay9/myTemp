package com.fet.tpes.bo;

import org.apache.poi.ss.usermodel.Workbook;

import com.fet.tpes.bo.base.BaseOutputBo;

public class CreateReportOutput extends BaseOutputBo {

	private Workbook report;

	public Workbook getReport() {
		return report;
	}
	public void setReport(Workbook report) {
		this.report = report;
	}
}
