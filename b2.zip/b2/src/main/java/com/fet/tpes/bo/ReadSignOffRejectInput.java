package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.entity.ReadApply;

public class ReadSignOffRejectInput extends BaseInputBo {

	private ReadApply readApply;
	private String reason;
	private String desc;
	
	@Override
	public boolean isValid() {
		return true;
	}

	public ReadApply getReadApply() {
		return readApply;
	}
	public void setReadApply(ReadApply readApply) {
		this.readApply = readApply;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
}
