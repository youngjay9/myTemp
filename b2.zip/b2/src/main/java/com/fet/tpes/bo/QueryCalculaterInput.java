package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

import fr.opensagres.poi.xwpf.converter.core.utils.StringUtils;

public class QueryCalculaterInput extends BaseInputBo{
	private String status;
	private String accounting;
	
	
	
	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getAccounting() {
		return accounting;
	}



	public void setAccounting(String accounting) {
		this.accounting = accounting;
	}



	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtils.isEmpty(this.status) && StringUtils.isEmpty(this.accounting)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryAccnterInput input同時缺少參數status與accounting");
		}
		return result;
	}
}
