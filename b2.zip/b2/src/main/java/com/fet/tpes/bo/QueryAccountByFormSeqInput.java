package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryAccountByFormSeqInput extends BaseInputBo{
	private Integer formSeq;
	
	@Override
	public boolean isValid() {
		boolean result = true;
		
		if(this.formSeq == null) {
			result = false;
			LogUtil.error(this.getClass(), "input 缺少 formSeq");
		}
		
		return result;
	}

	public Integer getFormSeq() {
		return formSeq;
	}
	public void setFormSeq(Integer formSeq) {
		this.formSeq = formSeq;
	}

}
