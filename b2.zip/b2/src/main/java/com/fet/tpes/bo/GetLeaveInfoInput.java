package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class GetLeaveInfoInput extends BaseInputBo {

	private String user;
	private String pwwd; // 密碼 (for codeScan)
	private String queryDiv;
	private String queryDep;
	private String querySec;
	private String queryBeginDate;
	private String queryEndDate;
	
	// 參數檢查失敗時傳訊息用
	private String errorMsg;
	
	@Override
	public boolean isValid() {
		boolean pass = true;
		
		if (StringUtil.isEmpty(user)) {
			pass = false;
			errorMsg = "input 參數缺少 user";
		}
		else if (StringUtil.isEmpty(pwwd)) {
			pass = false;
			errorMsg = "input 參數缺少 password";
		}
		else if (StringUtil.isEmpty(queryDiv)) {
			pass = false;
			errorMsg = "input 參數缺少 queryDiv";
		}
		else if (StringUtil.isEmpty(queryDep)) {
			pass = false;
			errorMsg = "input 參數缺少 queryDep";
		}
		else if (StringUtil.isEmpty(querySec)) {
			pass = false;
			errorMsg = "input 參數缺少 querySec";
		}
		else if (StringUtil.isEmpty(queryBeginDate)) {
			pass = false;
			errorMsg = "input 參數缺少 queryBeginDate";
		}
		else if (StringUtil.isEmpty(queryEndDate)) {
			pass = false;
			errorMsg = "input 參數缺少 queryEndDate";
		}
		
		return pass;
	}

	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPwwd() {
		return pwwd;
	}
	public void setPwwd(String pwwd) {
		this.pwwd = pwwd;
	}
	public String getQueryDiv() {
		return queryDiv;
	}
	public void setQueryDiv(String queryDiv) {
		this.queryDiv = queryDiv;
	}
	public String getQueryDep() {
		return queryDep;
	}
	public void setQueryDep(String queryDep) {
		this.queryDep = queryDep;
	}
	public String getQuerySec() {
		return querySec;
	}
	public void setQuerySec(String querySec) {
		this.querySec = querySec;
	}
	public String getQueryBeginDate() {
		return queryBeginDate;
	}
	public void setQueryBeginDate(String queryBeginDate) {
		this.queryBeginDate = queryBeginDate;
	}
	public String getQueryEndDate() {
		return queryEndDate;
	}
	public void setQueryEndDate(String queryEndDate) {
		this.queryEndDate = queryEndDate;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}
