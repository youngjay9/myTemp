package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QueryConfigInput extends BaseInputBo {

	private String code;
	private String codeCate;

	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(code) || StringUtil.isNotEmpty(codeCate);
	}

	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCodeCate() {
		return codeCate;
	}
	public void setCodeCate(String codeCate) {
		this.codeCate = codeCate;
	}
}
