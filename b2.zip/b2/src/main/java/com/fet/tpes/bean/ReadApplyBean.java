package com.fet.tpes.bean;

public class ReadApplyBean {

	private String acceptNum;
	private String custName;
	private String electricNum;
	private String contractType;
	private String archiveNum;
	private String acceptDateStr;
	private String archiveDateStr;
	private String validDateStr;
	private String acceptItem;
	private String status;
	private String rejectReason;
	private String readNum;
	private String readDateStr;
	private String applier;
	private String readDept;
	private String readReason;
	private String fileReader;
	private String fileReaderName;
	private String memo;
	private String rejectDesc;
	
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getElectricNum() {
		return electricNum;
	}
	public void setElectricNum(String electricNum) {
		this.electricNum = electricNum;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getArchiveNum() {
		return archiveNum;
	}
	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}
	public String getAcceptDateStr() {
		return acceptDateStr;
	}
	public void setAcceptDateStr(String acceptDateStr) {
		this.acceptDateStr = acceptDateStr;
	}
	public String getArchiveDateStr() {
		return archiveDateStr;
	}
	public void setArchiveDateStr(String archiveDateStr) {
		this.archiveDateStr = archiveDateStr;
	}
	public String getValidDateStr() {
		return validDateStr;
	}
	public void setValidDateStr(String validDateStr) {
		this.validDateStr = validDateStr;
	}
	public String getAcceptItem() {
		return acceptItem;
	}
	public void setAcceptItem(String acceptItem) {
		this.acceptItem = acceptItem;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getReadNum() {
		return readNum;
	}
	public void setReadNum(String readNum) {
		this.readNum = readNum;
	}
	public String getReadDateStr() {
		return readDateStr;
	}
	public void setReadDateStr(String readDateStr) {
		this.readDateStr = readDateStr;
	}
	public String getApplier() {
		return applier;
	}
	public void setApplier(String applier) {
		this.applier = applier;
	}
	public String getReadDept() {
		return readDept;
	}
	public String getFileReader() {
		return fileReader;
	}
	public void setFileReader(String fileReader) {
		this.fileReader = fileReader;
	}
	public String getFileReaderName() {
		return fileReaderName;
	}
	public void setFileReaderName(String fileReaderName) {
		this.fileReaderName = fileReaderName;
	}
	public void setReadDept(String readDept) {
		this.readDept = readDept;
	}
	public String getReadReason() {
		return readReason;
	}
	public void setReadReason(String readReason) {
		this.readReason = readReason;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getRejectDesc() {
		return rejectDesc;
	}
	public void setRejectDesc(String rejectDesc) {
		this.rejectDesc = rejectDesc;
	}
}
