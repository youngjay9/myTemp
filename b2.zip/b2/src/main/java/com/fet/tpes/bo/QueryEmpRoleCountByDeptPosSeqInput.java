package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryEmpRoleCountByDeptPosSeqInput extends BaseInputBo{
	private String deptPosSeq;
	private String dept;
	
	
	
	public String getDeptPosSeq() {
		return deptPosSeq;
	}



	public void setDeptPosSeq(String deptPosSeq) {
		this.deptPosSeq = deptPosSeq;
	}



	public String getDept() {
		return dept;
	}



	public void setDept(String dept) {
		this.dept = dept;
	}



	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.deptPosSeq)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryEmpRoleCountByDeptPosSeqInput input驗證缺少deptPosSeq");
		}
		if(StringUtil.isEmpty(this.dept)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryEmpRoleCountByDeptPosSeqInput input驗證缺少dept");
		}
		return result;
	}
}
