package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class ReportSignOffInput extends BaseInputBo {

	private Integer fileNo;
	private String roleCode;
	
	@Override
	public boolean isValid() {
		return fileNo != null && StringUtil.isNotEmpty(roleCode);
	}

	public Integer getFileNo() {
		return fileNo;
	}
	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
}
