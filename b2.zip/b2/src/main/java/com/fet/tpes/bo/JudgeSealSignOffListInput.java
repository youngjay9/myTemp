package com.fet.tpes.bo;

import java.util.HashMap;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bean.AuthEmpRoleMapBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class JudgeSealSignOffListInput extends BaseInputBo{
	private List<String> statusList;
	private HashMap<String, AuthEmpRoleMapBean> empNoToEmpRoleMap;
	
	public List<String> getStatusList() {
		return statusList;
	}

	public void setStatusList(List<String> statusList) {
		this.statusList = statusList;
	}
	
	

	public HashMap<String, AuthEmpRoleMapBean> getEmpNoToEmpRoleMap() {
		return empNoToEmpRoleMap;
	}

	public void setEmpNoToEmpRoleMap(HashMap<String, AuthEmpRoleMapBean> empNoToEmpRoleMap) {
		this.empNoToEmpRoleMap = empNoToEmpRoleMap;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(this.statusList)) {
			result = false;
			LogUtil.error(this.getClass(), "JudgeSealSignOffListInput input缺少參數statusList");
		}
		if(CollectionUtils.isEmpty(this.empNoToEmpRoleMap)) {
			result = false;
			LogUtil.error(this.getClass(), "JudgeSealSignOffListInput input缺少參數empNoToEmpRoleMap");
		}
		return result;
	}
}
