package com.fet.tpes.bo;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class GetEmpInfoByEmpNoOutput extends BaseOutputBo {

	private EmpInfoBean empInfo;
	private String responseString;

	public EmpInfoBean getEmpInfo() {
		return empInfo;
	}
	public void setEmpInfo(EmpInfoBean empInfo) {
		this.empInfo = empInfo;
	}
	public String getResponseString() {
		return responseString;
	}
	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}
}
