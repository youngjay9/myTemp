package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.ReadReportBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class JudgeReadReportListOutput extends BaseOutputBo{
	private List<ReadReportBean> readReportBeanList;

	public List<ReadReportBean> getReadReportBeanList() {
		return readReportBeanList;
	}

	public void setReadReportBeanList(List<ReadReportBean> readReportBeanList) {
		this.readReportBeanList = readReportBeanList;
	}
	
}
