package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AuthPrivilegeBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryAllAuthPrivilegeOutput extends BaseOutputBo{
	private List<AuthPrivilegeBean> authPrivilegeBeanList;

	public List<AuthPrivilegeBean> getAuthPrivilegeBeanList() {
		return authPrivilegeBeanList;
	}

	public void setAuthPrivilegeBeanList(List<AuthPrivilegeBean> authPrivilegeBeanList) {
		this.authPrivilegeBeanList = authPrivilegeBeanList;
	}
}
