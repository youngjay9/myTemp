package com.fet.tpes.bean;

import java.util.Date;

import com.fet.tpes.entity.CfgRegion;

public class CfgRegionBean {

	private String region;
	private String status;
	private String createAuthor;
	private Date createDate;
	private String updateAuthor;
	private Date updateDate;
	
	public CfgRegionBean() {
		
	}
	
	public CfgRegionBean(CfgRegion cfgRegion) {
		this.region = cfgRegion.getRegion();
		this.status = cfgRegion.getStatus();
		this.createAuthor = cfgRegion.getCreateAuthor();
		this.createDate = cfgRegion.getCreateDate();
		this.updateAuthor = cfgRegion.getUpdateAuthor();
		this.updateDate = cfgRegion.getUpdateDate();
	}
	
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreateAuthor() {
		return createAuthor;
	}
	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getUpdateAuthor() {
		return updateAuthor;
	}
	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	
}
