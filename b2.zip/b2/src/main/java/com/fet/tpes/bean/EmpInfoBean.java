package com.fet.tpes.bean;

public class EmpInfoBean {

	private Integer seq;
	private String empNo;
	private String name;
	private String division;
	private String department;
	private String section;
	private String group;
	private String positionSeq;
	private String region;
	private String roleCode;
	private String businessRegion; // 營業處區碼
	private String status;
	private String createAuthor;
	private String updateAuthor;

	private String empInfoStr;

	public EmpInfoBean() {
	}

	public EmpInfoBean(String empNo, String name) {
		this.empNo = empNo;
		this.name = name;
	}

	public String getEmpNo() {
		return empNo;
	}

	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getPositionSeq() {
		return positionSeq;
	}

	public void setPositionSeq(String positionSeq) {
		this.positionSeq = positionSeq;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getBusinessRegion() {
		return businessRegion;
	}

	public void setBusinessRegion(String businessRegion) {
		this.businessRegion = businessRegion;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreateAuthor() {
		return createAuthor;
	}

	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}

	public String getUpdateAuthor() {
		return updateAuthor;
	}

	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}

	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public String getEmpInfoStr() {
		return empInfoStr;
	}

	public void setEmpInfoStr(String empInfoStr) {
		this.empInfoStr = empInfoStr;
	}

}
