package com.fet.tpes.bean;

import java.util.Date;

public class RejectReportBean {
	private Integer seq;
	private Date rejectDateStart;
	private Date rejectDateEnd;
	private String status;
	private String region;
	private Integer fileNo;
	private String salesPlannerSigner;
	private String salesPlannerSignAgent;
	private String salesPlannerSignDate;
	private String salesPlannerSignerDeptNum;
	private String leaderSigner;
	private String leaderSignAgent;
	private String leaderSignDate;
	private String leaderSignerDeptNum;
	private Date createDate;
	private String createAuthor;
	private Date updateDate;
	private String updateAuthor;
	
	// 判斷是否需要簽核
	private boolean needSalesPlannerSign;
	private boolean needLeaderSign;
	// 供前端顯示
	private String salesPlannerSignDateStr;
	private String leaderSignDateStr;
	private String generateDate;
	
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public Date getRejectDateStart() {
		return rejectDateStart;
	}
	public void setRejectDateStart(Date rejectDateStart) {
		this.rejectDateStart = rejectDateStart;
	}
	public Date getRejectDateEnd() {
		return rejectDateEnd;
	}
	public void setRejectDateEnd(Date rejectDateEnd) {
		this.rejectDateEnd = rejectDateEnd;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getFileNo() {
		return fileNo;
	}
	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}
	public String getSalesPlannerSigner() {
		return salesPlannerSigner;
	}
	public void setSalesPlannerSigner(String salesPlannerSigner) {
		this.salesPlannerSigner = salesPlannerSigner;
	}
	public String getSalesPlannerSignAgent() {
		return salesPlannerSignAgent;
	}
	public void setSalesPlannerSignAgent(String salesPlannerSignAgent) {
		this.salesPlannerSignAgent = salesPlannerSignAgent;
	}
	public String getSalesPlannerSignDate() {
		return salesPlannerSignDate;
	}
	public void setSalesPlannerSignDate(String salesPlannerSignDate) {
		this.salesPlannerSignDate = salesPlannerSignDate;
	}
	public String getLeaderSigner() {
		return leaderSigner;
	}
	public void setLeaderSigner(String leaderSigner) {
		this.leaderSigner = leaderSigner;
	}
	public String getLeaderSignAgent() {
		return leaderSignAgent;
	}
	public void setLeaderSignAgent(String leaderSignAgent) {
		this.leaderSignAgent = leaderSignAgent;
	}
	public String getLeaderSignDate() {
		return leaderSignDate;
	}
	public void setLeaderSignDate(String leaderSignDate) {
		this.leaderSignDate = leaderSignDate;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateAuthor() {
		return createAuthor;
	}
	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateAuthor() {
		return updateAuthor;
	}
	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}
	public boolean isNeedSalesPlannerSign() {
		return needSalesPlannerSign;
	}
	public void setNeedSalesPlannerSign(boolean needSalesPlannerSign) {
		this.needSalesPlannerSign = needSalesPlannerSign;
	}
	public boolean isNeedLeaderSign() {
		return needLeaderSign;
	}
	public void setNeedLeaderSign(boolean needLeaderSign) {
		this.needLeaderSign = needLeaderSign;
	}
	public String getSalesPlannerSignDateStr() {
		return salesPlannerSignDateStr;
	}
	public void setSalesPlannerSignDateStr(String salesPlannerSignDateStr) {
		this.salesPlannerSignDateStr = salesPlannerSignDateStr;
	}
	public String getLeaderSignDateStr() {
		return leaderSignDateStr;
	}
	public void setLeaderSignDateStr(String leaderSignDateStr) {
		this.leaderSignDateStr = leaderSignDateStr;
	}
	public String getGenerateDate() {
		return generateDate;
	}
	public void setGenerateDate(String generateDate) {
		this.generateDate = generateDate;
	}


	public String getSalesPlannerSignerDeptNum() {
		return salesPlannerSignerDeptNum;
	}
	public void setSalesPlannerSignerDeptNum(String salesPlannerSignerDeptNum) {
		this.salesPlannerSignerDeptNum = salesPlannerSignerDeptNum;
	}
	public String getLeaderSignerDeptNum() {
		return leaderSignerDeptNum;
	}
	public void setLeaderSignerDeptNum(String leaderSignerDeptNum) {
		this.leaderSignerDeptNum = leaderSignerDeptNum;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	
	

}
