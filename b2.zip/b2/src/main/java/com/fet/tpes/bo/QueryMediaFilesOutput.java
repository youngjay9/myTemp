package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.TpesMediaFile;

public class QueryMediaFilesOutput extends BaseOutputBo {

	private List<TpesMediaFile> fileList;

	public List<TpesMediaFile> getFileList() {
		return fileList;
	}

	public void setFileList(List<TpesMediaFile> fileList) {
		this.fileList = fileList;
	}
}
