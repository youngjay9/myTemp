package com.fet.tpes.bo;

import com.fet.tpes.bean.AgentApplicationBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryNextLeaveInfoOuput extends BaseOutputBo{
	private AgentApplicationBean agentApplicationBean;

	public AgentApplicationBean getAgentApplicationBean() {
		return agentApplicationBean;
	}

	public void setAgentApplicationBean(AgentApplicationBean agentApplicationBean) {
		this.agentApplicationBean = agentApplicationBean;
	}
}
