package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.TpesFormBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryDirectArchiveFormOutput extends BaseOutputBo{
	private List<TpesFormBean> formBeanList;

	public List<TpesFormBean> getFormBeanList() {
		return formBeanList;
	}

	public void setFormBeanList(List<TpesFormBean> formBeanList) {
		this.formBeanList = formBeanList;
	}
	
	
}
