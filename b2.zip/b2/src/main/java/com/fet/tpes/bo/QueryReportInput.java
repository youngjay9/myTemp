package com.fet.tpes.bo;

import java.util.Date;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QueryReportInput extends BaseInputBo {
	
	private Date rejectStartDate;    // 查詢退件報表需要
	private Date rejectEndDate;      // 查詢退件報表需要
	private Date readApplyStartDate; // 查詢調閱清單報表需要
	private Date readApplyEndDate;   // 查詢調閱清單報表需要

	public Date getRejectStartDate() {
		return rejectStartDate;
	}
	
	public void setRejectStartDate(Date rejectStartDate) {
		this.rejectStartDate = rejectStartDate;
	}
	
	public Date getRejectEndDate() {
		return rejectEndDate;
	}
	
	public void setRejectEndDate(Date rejectEndDate) {
		this.rejectEndDate = rejectEndDate;
	}
	public Date getReadApplyStartDate() {
		return readApplyStartDate;
	}
	
	public void setReadApplyStartDate(Date readApplyStartDate) {
		this.readApplyStartDate = readApplyStartDate;
	}
	
	public Date getReadApplyEndDate() {
		return readApplyEndDate;
	}
	
	public void setReadApplyEndDate(Date readApplyEndDate) {
		this.readApplyEndDate = readApplyEndDate;
	}
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(getRegion());
	}



}
