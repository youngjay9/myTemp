package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryeEmpInfoByListOutput extends BaseOutputBo{
	private List<EmpInfoBean> employeeBeanList;

	public List<EmpInfoBean> getEmployeeBeanList() {
		return employeeBeanList;
	}

	public void setEmployeeBeanList(List<EmpInfoBean> employeeBeanList) {
		this.employeeBeanList = employeeBeanList;
	}
}
