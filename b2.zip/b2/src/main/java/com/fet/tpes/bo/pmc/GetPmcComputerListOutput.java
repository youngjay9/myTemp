package com.fet.tpes.bo.pmc;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.controller.vo.pmc.PmcComputerVo;

public class GetPmcComputerListOutput  extends BaseOutputBo {
	private List<PmcComputerVo> pmcComputerList;

	public List<PmcComputerVo> getPmcComputerList() {
		return pmcComputerList;
	}

	public void setPmcComputerList(List<PmcComputerVo> pmcComputerList) {
		this.pmcComputerList = pmcComputerList;
	}
}
