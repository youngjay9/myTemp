package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.controller.vo.SignAttachmentFileVo;

import java.util.List;

public class DownloadMediaSignOffFileOutput extends BaseOutputBo {
    private List<SignAttachmentFileVo> fileList;

    public List<SignAttachmentFileVo> getFileList() {
        return fileList;
    }

    public void setFileList(List<SignAttachmentFileVo> fileList) {
        this.fileList = fileList;
    }
}
