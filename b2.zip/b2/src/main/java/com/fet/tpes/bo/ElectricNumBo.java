package com.fet.tpes.bo;

public class ElectricNumBo {
	private String electricNumStart;
	private String electricNumEnd;
	
	public String getElectricNumStart() {
		return electricNumStart;
	}
	public void setElectricNumStart(String electricNumStart) {
		this.electricNumStart = electricNumStart;
	}
	public String getElectricNumEnd() {
		return electricNumEnd;
	}
	public void setElectricNumEnd(String electricNumEnd) {
		this.electricNumEnd = electricNumEnd;
	}
	
}
