package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.EmpInfoBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryDeptEmpListOutput extends BaseOutputBo {
	
	private List<EmpInfoBean> empInfoList;

	public List<EmpInfoBean> getEmpInfoList() {
		return empInfoList;
	}
	public void setEmpInfoList(List<EmpInfoBean> empInfoList) {
		this.empInfoList = empInfoList;
	}
}
