package com.fet.tpes.bo;

import com.fet.tpes.bean.AuthEmpRoleMapBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryEmpRoleByEmpInfoOutput extends BaseOutputBo{
	private AuthEmpRoleMapBean settingAuthEmpInfo; // 取出被設定的角色員工資料

	public AuthEmpRoleMapBean getSettingAuthEmpInfo() {
		return settingAuthEmpInfo;
	}

	public void setSettingAuthEmpInfo(AuthEmpRoleMapBean settingAuthEmpInfo) {
		this.settingAuthEmpInfo = settingAuthEmpInfo;
	}

	
}
