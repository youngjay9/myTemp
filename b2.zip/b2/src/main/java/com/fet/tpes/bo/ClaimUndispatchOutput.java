package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class ClaimUndispatchOutput extends BaseOutputBo{

	private boolean canClaimForm;

	public boolean getCanClaimForm() {
		return canClaimForm;
	}

	public void setCanClaimForm(boolean canClaimForm) {
		this.canClaimForm = canClaimForm;
	}
}
