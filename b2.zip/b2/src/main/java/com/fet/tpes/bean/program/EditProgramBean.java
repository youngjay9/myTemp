package com.fet.tpes.bean.program;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/11/9 下午 04:43
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EditProgramBean {

    private Long programId;
    private String programName;
    private String programType;
    private String memo;
    private String releaseStartDate;
    private String releaseEndDate;

    private List<ProgramItemBean> programMaterials;

    public Long getProgramId() {
        return programId;
    }

    public void setProgramId(Long programId) {
        this.programId = programId;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getProgramType() {
        return programType;
    }

    public void setProgramType(String programType) {
        this.programType = programType;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getReleaseStartDate() {
        return releaseStartDate;
    }

    public void setReleaseStartDate(String releaseStartDate) {
        this.releaseStartDate = releaseStartDate;
    }

    public String getReleaseEndDate() {
        return releaseEndDate;
    }

    public void setReleaseEndDate(String releaseEndDate) {
        this.releaseEndDate = releaseEndDate;
    }

    public List<ProgramItemBean> getProgramMaterials() {
        return programMaterials;
    }

    public void setProgramMaterials(List<ProgramItemBean> programMaterials) {
        this.programMaterials = programMaterials;
    }
}
