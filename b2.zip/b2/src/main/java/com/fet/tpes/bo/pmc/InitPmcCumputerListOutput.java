package com.fet.tpes.bo.pmc;

import java.util.List;

import com.fet.tpes.bean.RegionBean;
import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.controller.vo.pmc.PmcStatusVo;
import com.fet.tpes.controller.vo.pmc.PmcTypeVo;

public class InitPmcCumputerListOutput  extends BaseOutputBo{
	
	private List<PmcTypeVo> pmcTypeList;
	private List<PmcStatusVo> pmcStatusList;
	private List<RegionBean> regionList;
	
	public List<PmcTypeVo> getPmcTypeList() {
		return pmcTypeList;
	}
	public void setPmcTypeList(List<PmcTypeVo> pmcTypeList) {
		this.pmcTypeList = pmcTypeList;
	}
	public List<PmcStatusVo> getPmcStatusList() {
		return pmcStatusList;
	}
	public void setPmcStatusList(List<PmcStatusVo> pmcStatusList) {
		this.pmcStatusList = pmcStatusList;
	}
	public List<RegionBean> getRegionList() {
		return regionList;
	}
	public void setRegionList(List<RegionBean> regionList) {
		this.regionList = regionList;
	}
}
