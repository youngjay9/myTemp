package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class CompareAndDeleteEmpInput extends BaseInputBo{
	private String status;
	private List<String> empNoList;
	private String updateAuthor;
	
	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public List<String> getEmpNoList() {
		return empNoList;
	}


	public void setEmpNoList(List<String> empNoList) {
		this.empNoList = empNoList;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.status)) {
			result = false;
			LogUtil.error(this.getClass(), "CompareAndDeleteEmpInput input缺少參數status");
		}		
		return result;
	}


	public String getUpdateAuthor() {
		return updateAuthor;
	}


	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}

}
