package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QueryByDivisionAndDepartmentInput extends BaseInputBo {

	private String empDivision;
	private String deptNum;
	private String status;
	
	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(empDivision) && StringUtil.isNotEmpty(deptNum) && StringUtil.isNotEmpty(status);
	}
	
	public String getEmpDivision() {
		return empDivision;
	}
	public void setEmpDivision(String empDivision) {
		this.empDivision = empDivision;
	}
	public String getDeptNum() {
		return deptNum;
	}
	public void setDeptNum(String deptNum) {
		this.deptNum = deptNum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
