package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class ReplaceKeywordToImageInput extends BaseInputBo {
	private String file;
	private String keyword;
	private String image;
	private String fileExt;
	private Integer width;
	private Integer height;
	private String formType;
	
	@Override
	public boolean isValid() {
		boolean isPass = true;
		
		if(StringUtil.isEmptyOrNull(file)) {
			isPass = false;
			LogUtil.error(this.getClass(), "input 參數缺少 file");
		}
		else if(StringUtil.isEmptyOrNull(keyword)) {
			isPass = false;
			LogUtil.error(this.getClass(), "input 參數缺少 keyword");
		}
		else if(StringUtil.isEmptyOrNull(image)) {
			isPass = false;
			LogUtil.error(this.getClass(), "input 參數缺少 image");
		}
		else if(StringUtil.isEmptyOrNull(fileExt)) {
			isPass = false;
			LogUtil.error(this.getClass(), "input 參數缺少 fileExt");
		}
		
		return isPass;
	}

	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getFileExt() {
		return fileExt;
	}
	public void setFileExt(String fileExt) {
		this.fileExt = fileExt;
	}

	public Integer getWidth() {
		return width;
	}

	public void setWidth(Integer width) {
		this.width = width;
	}

	public Integer getHeight() {
		return height;
	}

	public void setHeight(Integer height) {
		this.height = height;
	}

	public String getFormType() {
		return formType;
	}

	public void setFormType(String formType) {
		this.formType = formType;
	}
}
