package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bean.AuthRolePrivilegeMapBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class CreateRoleAuthPrivilegeInput extends BaseInputBo{
	
	private List<AuthRolePrivilegeMapBean> authRolePrivilegeMapBeanList;
	
	public List<AuthRolePrivilegeMapBean> getAuthRolePrivilegeMapBeanList() {
		return authRolePrivilegeMapBeanList;
	}

	public void setAuthRolePrivilegeMapBeanList(List<AuthRolePrivilegeMapBean> authRolePrivilegeMapBeanList) {
		this.authRolePrivilegeMapBeanList = authRolePrivilegeMapBeanList;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(authRolePrivilegeMapBeanList)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數authRolePrivilegeMapBeanList為空值");
		} else if(StringUtil.isEmpty(this.getEmpNo())) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數EmpNo為空值");
		}
		return result;
	}
}
