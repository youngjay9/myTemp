package com.fet.tpes.bo;

import java.util.List;
import java.util.Map;

import com.fet.tpes.bean.AccountingBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class InitAccountingListOutput extends BaseOutputBo{
	
	private List<AccountingBean> agentAccountingBeanList;
	private List<AccountingBean> ownAccountingBeanList;
	private List<String> authList;	
	private Map<String, String> contractTypeMap;
	private Map<String, String> acceptItemMap;
	
	public List<AccountingBean> getAgentAccountingBeanList() {
		return agentAccountingBeanList;
	}
	public void setAgentAccountingBeanList(List<AccountingBean> agentAccountingBeanList) {
		this.agentAccountingBeanList = agentAccountingBeanList;
	}
	public List<AccountingBean> getOwnAccountingBeanList() {
		return ownAccountingBeanList;
	}
	public void setOwnAccountingBeanList(List<AccountingBean> ownAccountingBeanList) {
		this.ownAccountingBeanList = ownAccountingBeanList;
	}
	public List<String> getAuthList() {
		return authList;
	}
	public void setAuthList(List<String> authList) {
		this.authList = authList;
	}
	public Map<String, String> getContractTypeMap() {
		return contractTypeMap;
	}
	public void setContractTypeMap(Map<String, String> contractTypeMap) {
		this.contractTypeMap = contractTypeMap;
	}
	public Map<String, String> getAcceptItemMap() {
		return acceptItemMap;
	}
	public void setAcceptItemMap(Map<String, String> acceptItemMap) {
		this.acceptItemMap = acceptItemMap;
	}	
}
