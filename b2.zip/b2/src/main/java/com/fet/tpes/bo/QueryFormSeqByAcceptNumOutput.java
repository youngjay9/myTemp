package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryFormSeqByAcceptNumOutput extends BaseOutputBo{
	private Integer seq;

	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	
}
