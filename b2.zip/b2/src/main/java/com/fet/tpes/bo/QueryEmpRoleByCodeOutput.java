package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.AuthEmpRoleMap;

public class QueryEmpRoleByCodeOutput extends BaseOutputBo{
	List<AuthEmpRoleMap> autoEmpRoleOutput;

	public List<AuthEmpRoleMap> getAutoEmpRoleOutput() {
		return autoEmpRoleOutput;
	}

	public void setAutoEmpRoleOutput(List<AuthEmpRoleMap> autoEmpRoleOutput) {
		this.autoEmpRoleOutput = autoEmpRoleOutput;
	}
	
	
}
