package com.fet.tpes.bo.pmc;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.controller.vo.pmc.PmcTypeVo;
import com.fet.tpes.controller.vo.pmc.PmcVersionVo;

public class InitPmcVersionMgmtOutput extends BaseOutputBo{
	
	private List<PmcTypeVo> pmcTypeList;
	private List<PmcVersionVo> pmcVersionList;

	public List<PmcTypeVo> getPmcTypeList() {
		return pmcTypeList;
	}

	public void setPmcTypeList(List<PmcTypeVo> pmcTypeList) {
		this.pmcTypeList = pmcTypeList;
	}

	public List<PmcVersionVo> getPmcVersionList() {
		return pmcVersionList;
	}

	public void setPmcVersionList(List<PmcVersionVo> pmcVersionList) {
		this.pmcVersionList = pmcVersionList;
	}
	
}
