package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryFormByFormSeqInput extends BaseInputBo {

	private List<Integer> seqList;
	private String status;
	
	@Override
	public boolean isValid() {
		return true;
	}
	
	public List<Integer> getSeqList() {
		return seqList;
	}
	public void setSeqList(List<Integer> seqList) {
		this.seqList = seqList;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
