package com.fet.tpes.bean;

import java.util.Date;

public class LogViewFormBean {
	private Integer seq;
	private String region;
	private String acceptNum;
	private String acceptDept;
	private String acceptDeptName;
	private String acceptUser;
	private String acceptUserName;
	private String browser;
	private String browserName;
	private String browsePage;
	private String browseStyle;
	private Date createDate;
	private String createAuthor;
	private Date updateDate;
	private String updateAuthor;
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
	public String getAcceptDept() {
		return acceptDept;
	}
	public void setAcceptDept(String acceptDept) {
		this.acceptDept = acceptDept;
	}
	public String getAcceptDeptName() {
		return acceptDeptName;
	}
	public void setAcceptDeptName(String acceptDeptName) {
		this.acceptDeptName = acceptDeptName;
	}
	public String getAcceptUser() {
		return acceptUser;
	}
	public void setAcceptUser(String acceptUser) {
		this.acceptUser = acceptUser;
	}
	public String getAcceptUserName() {
		return acceptUserName;
	}
	public void setAcceptUserName(String acceptUserName) {
		this.acceptUserName = acceptUserName;
	}
	public String getBrowser() {
		return browser;
	}
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	public String getBrowserName() {
		return browserName;
	}
	public void setBrowserName(String browserName) {
		this.browserName = browserName;
	}
	public String getBrowsePage() {
		return browsePage;
	}
	public void setBrowsePage(String browsePage) {
		this.browsePage = browsePage;
	}
	public String getBrowseStyle() {
		return browseStyle;
	}
	public void setBrowseStyle(String browseStyle) {
		this.browseStyle = browseStyle;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateAuthor() {
		return createAuthor;
	}
	public void setCreateAuthor(String createAuthor) {
		this.createAuthor = createAuthor;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateAuthor() {
		return updateAuthor;
	}
	public void setUpdateAuthor(String updateAuthor) {
		this.updateAuthor = updateAuthor;
	}
	
	
}
