package com.fet.tpes.bo;

import com.fet.tpes.bean.AgentApplicationBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class CreateAgentLeaveInfoInput extends BaseInputBo{
	
	private AgentApplicationBean agentApplicationBean;
	
	public AgentApplicationBean getAgentApplicationBean() {
		return agentApplicationBean;
	}
	
	public void setAgentApplicationBean(AgentApplicationBean agentApplicationBean) {
		this.agentApplicationBean = agentApplicationBean;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if(agentApplicationBean == null) {
			result = false;
			LogUtil.error(this.getClass(), "驗證傳入參數agentApplicationBean為空值");
		}
		return result;
	}


}
