package com.fet.tpes.bean;

import com.fet.tpes.entity.TpesFile;

public class FileVo {

	private TpesFile file;
	private String base64;
	
	public TpesFile getFile() {
		return file;
	}
	public void setFile(TpesFile file) {
		this.file = file;
	}
	public String getBase64() {
		return base64;
	}
	public void setBase64(String base64) {
		this.base64 = base64;
	}
}
