package com.fet.tpes.bo;

import java.util.Optional;

import com.fet.tpes.bo.base.BaseInputBo;

public class DownloadMediaSignOffFileInput extends BaseInputBo {

	private Long relatedSeq;
	private String mediaSignType;

	@Override
	public boolean isValid() {
		return Optional.ofNullable(relatedSeq).isPresent();
	}

	public Long getRelatedSeq() {
		return relatedSeq;
	}

	public void setRelatedSeq(Long relatedSeq) {
		this.relatedSeq = relatedSeq;
	}

	public String getMediaSignType() {
		return mediaSignType;
	}

	public void setMediaSignType(String mediaSignType) {
		this.mediaSignType = mediaSignType;
	}
}
