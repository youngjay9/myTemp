package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/11/17 下午 02:03
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
public class MediaSignOffInput<T> extends BaseInputBo {
	private Long signOffNo;
	private Long actionNo;
	private String actionType;
	private Boolean pass;
	private String rejectReason;
	private String rejectDesc;
	private T mediaData;

	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(getRegion()) && StringUtil.isNotEmpty(actionNo.toString()) && pass != null;
	}

	public Long getSignOffNo() {
		return signOffNo;
	}

	public void setSignOffNo(Long signOffNo) {
		this.signOffNo = signOffNo;
	}

	public Long getActionNo() {
		return actionNo;
	}

	public T getMediaData() {
		return mediaData;
	}

	public void setMediaData(T mediaData) {
		this.mediaData = mediaData;
	}

	public void setActionNo(Long actionNo) {
		this.actionNo = actionNo;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public Boolean getPass() {
		return pass;
	}
	public void setPass(Boolean pass) {
		this.pass = pass;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getRejectDesc() {
		return rejectDesc;
	}
	public void setRejectDesc(String rejectDesc) {
		this.rejectDesc = rejectDesc;
	}
}
