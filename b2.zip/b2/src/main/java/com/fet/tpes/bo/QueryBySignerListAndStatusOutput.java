package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.SealSignOffBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryBySignerListAndStatusOutput extends BaseOutputBo{
	private List<SealSignOffBean> sealSignOffBeanList;

	public List<SealSignOffBean> getSealSignOffBeanList() {
		return sealSignOffBeanList;
	}

	public void setSealSignOffBeanList(List<SealSignOffBean> sealSignOffBeanList) {
		this.sealSignOffBeanList = sealSignOffBeanList;
	}
	
}
