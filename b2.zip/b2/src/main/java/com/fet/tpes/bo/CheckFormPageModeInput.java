package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class CheckFormPageModeInput extends BaseInputBo {

	private String formPageMode;
	private String formStatus;
	private boolean isUpdate;
	
	@Override
	public boolean isValid() {
		boolean isPass = true;
		
		if(StringUtil.isEmptyOrNull(this.formPageMode)) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.formStatus)) {
			isPass = false;
		}
		
		return isPass;
	}

	public String getFormPageMode() {
		return formPageMode;
	}

	public void setFormPageMode(String formPageMode) {
		this.formPageMode = formPageMode;
	}

	public String getFormStatus() {
		return formStatus;
	}

	public void setFormStatus(String formStatus) {
		this.formStatus = formStatus;
	}

	public boolean isUpdate() {
		return isUpdate;
	}

	public void setUpdate(boolean isUpdate) {
		this.isUpdate = isUpdate;
	}
}
