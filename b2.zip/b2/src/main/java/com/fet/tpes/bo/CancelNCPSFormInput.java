package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class CancelNCPSFormInput extends BaseInputBo {

	private String acceptNum;
	private String fmbhNo;
	private String srTp;
	private String cancelCode;
	private String deptNo;
	private String userScNo;
	private String userDeptNo;
	private String userId;
	private String recordKind;
	private String dcisFg;

	@Override
	public boolean isValid() {
		boolean isPass = true;
		
		if(StringUtil.isEmptyOrNull(this.acceptNum)) {
			isPass = false;
		}
		else if(StringUtil.isEmptyOrNull(this.getRegion())) {
			isPass = false;
		}
		
		return isPass;
	}

	public String getAcceptNum() {
		return acceptNum;
	}

	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}

	public String getFmbhNo() {
		return fmbhNo;
	}

	public void setFmbhNo(String fmbhNo) {
		this.fmbhNo = fmbhNo;
	}

	public String getSrTp() {
		return srTp;
	}

	public void setSrTp(String srTp) {
		this.srTp = srTp;
	}

	public String getCancelCode() {
		return cancelCode;
	}

	public void setCancelCode(String cancelCode) {
		this.cancelCode = cancelCode;
	}

	public String getDeptNo() {
		return deptNo;
	}

	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}

	public String getUserScNo() {
		return userScNo;
	}

	public void setUserScNo(String userScNo) {
		this.userScNo = userScNo;
	}

	public String getUserDeptNo() {
		return userDeptNo;
	}

	public void setUserDeptNo(String userDeptNo) {
		this.userDeptNo = userDeptNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRecordKind() {
		return recordKind;
	}

	public void setRecordKind(String recordKind) {
		this.recordKind = recordKind;
	}

	public String getDcisFg() {
		return dcisFg;
	}

	public void setDcisFg(String dcisFg) {
		this.dcisFg = dcisFg;
	}
}
