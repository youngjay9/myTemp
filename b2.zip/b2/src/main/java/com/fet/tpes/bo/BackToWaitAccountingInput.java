package com.fet.tpes.bo;

import org.apache.commons.lang3.StringUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;


public class BackToWaitAccountingInput extends BaseInputBo{
	private Integer seq;
	private String accounting;
	private Integer formSeq;
	private String businessRegion;
	private String acceptNum;
	
	
	
	public Integer getFormSeq() {
		return formSeq;
	}


	public void setFormSeq(Integer formSeq) {
		this.formSeq = formSeq;
	}


	public Integer getSeq() {
		return seq;
	}


	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	

	public String getAccounting() {
		return accounting;
	}


	public void setAccounting(String accounting) {
		this.accounting = accounting;
	}


	public String getBusinessRegion() {
		return businessRegion;
	}


	public void setBusinessRegion(String businessRegion) {
		this.businessRegion = businessRegion;
	}


	public String getAcceptNum() {
		return acceptNum;
	}


	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(this.seq == null) {
			result = false;
			LogUtil.error(this.getClass(), "BackToWaitAccountingInput input 缺少 seq");
		}
		if(StringUtils.isEmpty(this.accounting)) {
			result = false;
			LogUtil.error(this.getClass(), "BackToWaitAccountingInput input 缺少 accounting");
		}
		if(StringUtils.isEmpty(this.acceptNum)) {
			result = false;
			LogUtil.error(this.getClass(), "BackToWaitAccountingInput input 缺少 acceptNum");
		}
		return result;
	}
}
