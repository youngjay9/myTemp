package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AuthRoleBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryAuthRoleByEmpNoOutput extends BaseOutputBo{
	
	private List<AuthRoleBean> authRoleBeanList;

	public List<AuthRoleBean> getAuthRoleBeanList() {
		return authRoleBeanList;
	}

	public void setAuthRoleBeanList(List<AuthRoleBean> authRoleBeanList) {
		this.authRoleBeanList = authRoleBeanList;
	}

}
