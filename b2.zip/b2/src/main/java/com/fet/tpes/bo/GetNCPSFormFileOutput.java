package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.NcpsFormFileBean;
import com.fet.tpes.bo.base.BaseOutputBo;


public class GetNCPSFormFileOutput extends BaseOutputBo {
	private List<NcpsFormFileBean> ncpsFormFileList;

	public List<NcpsFormFileBean> getNcpsFormFileList() {
		return ncpsFormFileList;
	}

	public void setNcpsFormFileList(List<NcpsFormFileBean> ncpsFormFileList) {
		this.ncpsFormFileList = ncpsFormFileList;
	}
}
