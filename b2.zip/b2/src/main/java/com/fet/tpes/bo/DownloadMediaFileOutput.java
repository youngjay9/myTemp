package com.fet.tpes.bo;

import com.fet.tpes.bean.material.MediaFileBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class DownloadMediaFileOutput extends BaseOutputBo {
	private MediaFileBean mediaFile;

	public MediaFileBean getMediaFile() {
		return mediaFile;
	}

	public void setMediaFile(MediaFileBean mediaFile) {
		this.mediaFile = mediaFile;
	}
}
