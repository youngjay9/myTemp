package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class RemoveFileInput extends BaseInputBo {

	// 檔案流水號
	private Integer fileNo;
	// 檔案實體路徑
	private String path;

	@Override
	public boolean isValid() {
		return true;
	}
	
	public Integer getFileNo() {
		return fileNo;
	}
	public void setFileNo(Integer fileNo) {
		this.fileNo = fileNo;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
}
