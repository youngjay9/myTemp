package com.fet.tpes.bo;

import com.fet.tpes.bean.LogViewFormBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class CreateViewFormLogInput extends BaseInputBo{
	private LogViewFormBean logViewFormBean;
	
	
	public LogViewFormBean getLogViewFormBean() {
		return logViewFormBean;
	}


	public void setLogViewFormBean(LogViewFormBean logViewFormBean) {
		this.logViewFormBean = logViewFormBean;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(logViewFormBean == null) {
			result = false;
			LogUtil.error(this.getClass(), "CreateViewFormLogInput input缺少參數logViewFormBean");
		}
		return result;
	}
}
