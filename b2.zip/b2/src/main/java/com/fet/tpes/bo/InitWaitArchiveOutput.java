package com.fet.tpes.bo;

import java.util.List;
import java.util.Map;

import com.fet.tpes.bean.AccountingBean;
import com.fet.tpes.bean.TpesFormBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class InitWaitArchiveOutput extends BaseOutputBo{
	private List<AccountingBean> ownAccountingBean;
	private List<AccountingBean> agentAccountingBean;
	private List<TpesFormBean> ownFormBean;
	private List<TpesFormBean> agentFormBean;
	private Map<String, String> acceptItemMap;
	
	public List<AccountingBean> getOwnAccountingBean() {
		return ownAccountingBean;
	}
	public void setOwnAccountingBean(List<AccountingBean> ownAccountingBean) {
		this.ownAccountingBean = ownAccountingBean;
	}
	public List<AccountingBean> getAgentAccountingBean() {
		return agentAccountingBean;
	}
	public void setAgentAccountingBean(List<AccountingBean> agentAccountingBean) {
		this.agentAccountingBean = agentAccountingBean;
	}
	public Map<String, String> getAcceptItemMap() {
		return acceptItemMap;
	}
	public void setAcceptItemMap(Map<String, String> acceptItemMap) {
		this.acceptItemMap = acceptItemMap;
	}
	public List<TpesFormBean> getOwnFormBean() {
		return ownFormBean;
	}
	public void setOwnFormBean(List<TpesFormBean> ownFormBean) {
		this.ownFormBean = ownFormBean;
	}
	public List<TpesFormBean> getAgentFormBean() {
		return agentFormBean;
	}
	public void setAgentFormBean(List<TpesFormBean> agentFormBean) {
		this.agentFormBean = agentFormBean;
	}
	
	
}
