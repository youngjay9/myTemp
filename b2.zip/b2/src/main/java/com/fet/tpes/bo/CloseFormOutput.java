package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class CloseFormOutput extends BaseOutputBo {

	private String status;

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
