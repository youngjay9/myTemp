package com.fet.tpes.bo.base;

import java.util.List;

import com.fet.tpes.bean.AgentApplicationBean;

public abstract class BaseInputBo {
	
	// 使用者員工姓名代號
	private String empNo;
	// 使用者姓名
	private String empName;
	// 使用者所屬區處
	private String region;
	// 使用者目前代理中的人
	private List<AgentApplicationBean> agentList;
	
	public abstract boolean isValid();
	
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public List<AgentApplicationBean> getAgentList() {
		return agentList;
	}
	public void setAgentList(List<AgentApplicationBean> agentList) {
		this.agentList = agentList;
	}
}
