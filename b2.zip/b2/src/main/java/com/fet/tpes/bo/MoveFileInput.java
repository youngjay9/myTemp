package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class MoveFileInput extends BaseInputBo {

	private String sourcePath;
	private String targetPath;
	
	@Override
	public boolean isValid() {
		return true;
	}
	
	public String getSourcePath() {
		return sourcePath;
	}
	public void setSourcePath(String sourcePath) {
		this.sourcePath = sourcePath;
	}
	public String getTargetPath() {
		return targetPath;
	}
	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}
}
