package com.fet.tpes.bo;

import com.fet.tpes.bean.satisfaction.SatisfactionReportBean;
import com.fet.tpes.bo.base.BaseOutputBo;

import java.util.List;

public class QuerySatisfactionReportOutput extends BaseOutputBo {

	private List<SatisfactionReportBean> fileList;

	public List<SatisfactionReportBean> getFileList() {
		return fileList;
	}

	public void setFileList(List<SatisfactionReportBean> fileList) {
		this.fileList = fileList;
	}
}
