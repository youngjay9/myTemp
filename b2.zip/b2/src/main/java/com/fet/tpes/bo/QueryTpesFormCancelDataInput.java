package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryTpesFormCancelDataInput extends BaseInputBo{
	private String acceptNum;
	
	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmptyOrNull(acceptNum)) {
			result = false;
			LogUtil.error(this.getClass(), "QueryTpesFormCancelDataInput input 缺少 acceptNum");
		}
		return result;
	}

	public String getAcceptNum() {
		return acceptNum;
	}

	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}
}
