package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

import java.util.List;
import java.util.Map;

public class QuerySatisfactionSurveyDataOutput extends BaseOutputBo{
	private List<Map<String,Object>> reportDataList;

	public List<Map<String, Object>> getReportDataList() {
		return reportDataList;
	}

	public void setReportDataList(List<Map<String, Object>> reportDataList) {
		this.reportDataList = reportDataList;
	}
}
