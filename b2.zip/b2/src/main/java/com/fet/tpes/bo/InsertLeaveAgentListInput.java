package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.entity.AgentApplication;
import com.fet.tpes.util.LogUtil;

public class InsertLeaveAgentListInput extends BaseInputBo{
	private List<AgentApplication> agentApplicationList;
	
	
	public List<AgentApplication> getAgentApplicationList() {
		return agentApplicationList;
	}


	public void setAgentApplicationList(List<AgentApplication> agentApplicationList) {
		this.agentApplicationList = agentApplicationList;
	}


	@Override
	public boolean isValid() {
		boolean result = true;
		if(CollectionUtils.isEmpty(this.agentApplicationList)){
			result = false;
			LogUtil.error(this.getClass(), "InsertLeaveAgentListInput input缺少參數agentApplicationList");
		}
		return result;
	}
}
