package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class QueryReadNumInput extends BaseInputBo {

	@Override
	public boolean isValid() {
		return StringUtil.isNotEmpty(getRegion());
	}

}
