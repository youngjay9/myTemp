package com.fet.tpes.bo.base;

public class BaseOutputBo {
	private boolean isSuccess;
	private String returnMessage;
	private String returnCode;

	
	public BaseOutputBo() {
		
	}
	public BaseOutputBo(boolean isSuccess, String returnMessage, String returnCode) {
		this.isSuccess = isSuccess;
		this.returnMessage = returnMessage;
		this.returnCode = returnCode;
	}

	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
}
