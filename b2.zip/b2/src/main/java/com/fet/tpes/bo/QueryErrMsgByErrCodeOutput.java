package com.fet.tpes.bo;

import com.fet.tpes.bean.CfgErrCodeBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryErrMsgByErrCodeOutput extends BaseOutputBo{
	
	private CfgErrCodeBean cfgErrCodeBean;

	public CfgErrCodeBean getCfgErrCodeBean() {
		return cfgErrCodeBean;
	}

	public void setCfgErrCodeBean(CfgErrCodeBean cfgErrCodeBean) {
		this.cfgErrCodeBean = cfgErrCodeBean;
	}
}
