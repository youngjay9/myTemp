package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bean.AuthEmpRoleMapBean;
import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class DeleteAutoSetRoleByEmpNoInput extends BaseInputBo {
	List<String> empNoList;
	
	private List<AuthEmpRoleMapBean> authEmpRoleMapBeanList;
	private String settingStyle;
	private String recordType;
	
	
	

	public String getSettingStyle() {
		return settingStyle;
	}

	public void setSettingStyle(String settingStyle) {
		this.settingStyle = settingStyle;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public List<AuthEmpRoleMapBean> getAuthEmpRoleMapBeanList() {
		return authEmpRoleMapBeanList;
	}

	public void setAuthEmpRoleMapBeanList(List<AuthEmpRoleMapBean> authEmpRoleMapBeanList) {
		this.authEmpRoleMapBeanList = authEmpRoleMapBeanList;
	}

	public List<String> getEmpNoList() {
		return empNoList;
	}

	public void setEmpNoList(List<String> empNoList) {
		this.empNoList = empNoList;
	}

	@Override
	public boolean isValid() {
		boolean result = true;
		if (CollectionUtils.isEmpty(this.empNoList)) {
			result = false;
			LogUtil.error(this.getClass(), "DeleteAutoSetRoleByEmpNoInput input缺少參數empNoList");
		}
		return result;
	}
}
