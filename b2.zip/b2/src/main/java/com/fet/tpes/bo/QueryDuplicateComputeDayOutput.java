package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryDuplicateComputeDayOutput extends BaseOutputBo{
	private boolean isDuplicate;

	public boolean getIsDuplicate() {
		return isDuplicate;
	}

	public void setIsDuplicate(boolean isDuplicate) {
		this.isDuplicate = isDuplicate;
	}
}
