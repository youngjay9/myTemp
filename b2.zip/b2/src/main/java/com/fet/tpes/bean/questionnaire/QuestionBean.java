package com.fet.tpes.bean.questionnaire;


import java.util.List;

/**
 * @author JohnZeng
 * @version 1.0
 * @create 2021/10/26 下午 05:01
 * @Copyright Copyright (c) 2020-2021
 * @Company FET
 */
public class QuestionBean {

    private Long questionId;
    private String title;
    private String type;
    private boolean isRequired;
    private List<AnswerBean> answers;

    public Long getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Long questionId) {
        this.questionId = questionId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isRequired() {
        return isRequired;
    }

    public void setRequired(boolean required) {
        isRequired = required;
    }

    public List<AnswerBean> getAnswers() {
        return answers;
    }

    public void setAnswers(List<AnswerBean> answers) {
        this.answers = answers;
    }
}
