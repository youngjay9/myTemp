package com.fet.tpes.bo;

import java.util.List;
import java.util.Map;

import com.fet.tpes.bean.DepartmentBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryDeptInfoByConditionsOutput extends BaseOutputBo{
	private List<DepartmentBean> deptBeanList;
	private Map<String,String> deptBeanMap;

	public List<DepartmentBean> getDeptBeanList() {
		return deptBeanList;
	}

	public void setDeptBeanList(List<DepartmentBean> deptBeanList) {
		this.deptBeanList = deptBeanList;
	}

	public Map<String,String> getDeptBeanMap() {
		return deptBeanMap;
	}

	public void setDeptBeanMap(Map<String,String> deptBeanMap) {
		this.deptBeanMap = deptBeanMap;
	}
}
