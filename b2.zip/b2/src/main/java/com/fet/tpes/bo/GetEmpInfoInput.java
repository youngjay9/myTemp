package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class GetEmpInfoInput extends BaseInputBo{
	private String division;
	private String department;
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.division)) {
			result = false;
			LogUtil.error(this.getClass(), "GetEmpInfoInput input缺少參數division");
		}
		if(StringUtil.isEmpty(this.department)) {
			result = false;
			LogUtil.error(this.getClass(), "GetEmpInfoInput input缺少參數department");
		}
		return result;
	}
}
