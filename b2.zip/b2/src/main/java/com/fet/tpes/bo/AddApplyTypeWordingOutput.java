package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;

public class AddApplyTypeWordingOutput extends BaseOutputBo {

	private String file;

	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
}
