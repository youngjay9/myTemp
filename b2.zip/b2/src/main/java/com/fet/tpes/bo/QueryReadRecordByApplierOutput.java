package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.ReadApplyBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryReadRecordByApplierOutput extends BaseOutputBo{
	private List<ReadApplyBean> readApplyBeanList;

	public List<ReadApplyBean> getReadApplyBeanList() {
		return readApplyBeanList;
	}

	public void setReadApplyBeanList(List<ReadApplyBean> readApplyBeanList) {
		this.readApplyBeanList = readApplyBeanList;
	}
}
