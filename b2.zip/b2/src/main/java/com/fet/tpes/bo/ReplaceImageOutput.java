package com.fet.tpes.bo;

import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import com.fet.tpes.bo.base.BaseOutputBo;

public class ReplaceImageOutput extends BaseOutputBo {
	private XWPFDocument doc;
	private List<XWPFParagraph> paragraphs;
	private int index;
	public XWPFDocument getDoc() {
		return doc;
	}
	public void setDoc(XWPFDocument doc) {
		this.doc = doc;
	}
	public List<XWPFParagraph> getParagraphs() {
		return paragraphs;
	}
	public void setParagraphs(List<XWPFParagraph> paragraphs) {
		this.paragraphs = paragraphs;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
}
