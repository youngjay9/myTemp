package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AuthEmpRoleMapBean;
import com.fet.tpes.bo.base.BaseInputBo;

public class DeleteEmpRoleByEmpNoInput extends BaseInputBo{
	List<String> deleteEmpNoList;
	
	private List<AuthEmpRoleMapBean> authEmpRoleMapBeanList;
	private String settingStyle;
	private String recordType;
	
	
	
	public String getSettingStyle() {
		return settingStyle;
	}



	public void setSettingStyle(String settingStyle) {
		this.settingStyle = settingStyle;
	}



	public String getRecordType() {
		return recordType;
	}



	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}



	public List<AuthEmpRoleMapBean> getAuthEmpRoleMapBeanList() {
		return authEmpRoleMapBeanList;
	}



	public void setAuthEmpRoleMapBeanList(List<AuthEmpRoleMapBean> authEmpRoleMapBeanList) {
		this.authEmpRoleMapBeanList = authEmpRoleMapBeanList;
	}



	public List<String> getDeleteEmpNoList() {
		return deleteEmpNoList;
	}



	public void setDeleteEmpNoList(List<String> deleteEmpNoList) {
		this.deleteEmpNoList = deleteEmpNoList;
	}



	@Override
	public boolean isValid() {
		return true;
	}
}
