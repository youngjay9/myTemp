package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class GetEmpInfoByEmpNoInput extends BaseInputBo {
	
	private String user;
	private String pwwd; // 密碼 (for codeScan)
	
	// 參數檢查失敗時告至訊息用
	String errorMsg;
	
	@Override
	public boolean isValid() {
		boolean pass = true;
		
		if(StringUtil.isEmpty(user)) {
			pass = false;
			errorMsg = "input 參數缺少 user";
		}
		else if (StringUtil.isEmpty(pwwd)) {
			pass = false;
			errorMsg = "input 參數缺少 password";
		}
		else if (StringUtil.isEmpty(getEmpNo())) {
			pass = false;
			errorMsg = "input 參數缺少 empNo";
		}
		
		return pass;
	}

	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPwwd() {
		return pwwd;
	}
	public void setPwwd(String pwwd) {
		this.pwwd = pwwd;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}
