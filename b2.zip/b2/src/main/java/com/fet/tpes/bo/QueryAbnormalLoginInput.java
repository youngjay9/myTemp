package com.fet.tpes.bo;

import java.util.Date;

public class QueryAbnormalLoginInput {

	private String abnormalHourStart;
	private String abnormalHourEnd;
	private Date startDate;
	private Date endDate;
	public String getAbnormalHourStart() {
		return abnormalHourStart;
	}
	public void setAbnormalHourStart(String abnormalHourStart) {
		this.abnormalHourStart = abnormalHourStart;
	}
	public String getAbnormalHourEnd() {
		return abnormalHourEnd;
	}
	public void setAbnormalHourEnd(String abnormalHourEnd) {
		this.abnormalHourEnd = abnormalHourEnd;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
}
