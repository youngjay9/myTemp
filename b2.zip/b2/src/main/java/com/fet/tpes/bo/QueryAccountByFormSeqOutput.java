package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.Accounting;

public class QueryAccountByFormSeqOutput extends BaseOutputBo{
	private Accounting accounting;

	public Accounting getAccounting() {
		return accounting;
	}
	public void setAccounting(Accounting accounting) {
		this.accounting = accounting;
	}
}
