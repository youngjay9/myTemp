package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.StringUtil;

public class SaveArchiveNumInput extends BaseInputBo {

	private Integer formSeq;
	private String archiveNum;
	
	@Override
	public boolean isValid() {
		return formSeq != null && StringUtil.isNotEmpty(archiveNum);
	}

	public Integer getFormSeq() {
		return formSeq;
	}
	public void setFormSeq(Integer formSeq) {
		this.formSeq = formSeq;
	}
	public String getArchiveNum() {
		return archiveNum;
	}
	public void setArchiveNum(String archiveNum) {
		this.archiveNum = archiveNum;
	}
}
