package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryUnassignedListInput extends BaseInputBo{
	private String acceptItem;
	
	
	
	public String getAcceptItem() {
		return acceptItem;
	}



	public void setAcceptItem(String acceptItem) {
		this.acceptItem = acceptItem;
	}



	@Override
	public boolean isValid() {
		boolean result = true;
		return result;
	}
}
