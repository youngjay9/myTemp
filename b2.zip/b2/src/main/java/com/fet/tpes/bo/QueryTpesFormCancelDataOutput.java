package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.TpesFormCancelData;

public class QueryTpesFormCancelDataOutput extends BaseOutputBo{
	private TpesFormCancelData tpesFormCancelData;

	public TpesFormCancelData getTpesFormCancelData() {
		return tpesFormCancelData;
	}

	public void setTpesFormCancelData(TpesFormCancelData tpesFormCancelData) {
		this.tpesFormCancelData = tpesFormCancelData;
	}
}
