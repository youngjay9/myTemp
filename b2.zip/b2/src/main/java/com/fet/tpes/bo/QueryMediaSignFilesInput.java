package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryMediaSignFilesInput extends BaseInputBo {

	private Long relatedSeq;
	private String category;

	@Override
	public boolean isValid() {
		boolean isPass = true;

		return isPass;
	}

	public Long getRelatedSeq() {
		return relatedSeq;
	}

	public void setRelatedSeq(Long relatedSeq) {
		this.relatedSeq = relatedSeq;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
}
