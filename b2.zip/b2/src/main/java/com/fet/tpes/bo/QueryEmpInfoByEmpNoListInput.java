package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;

public class QueryEmpInfoByEmpNoListInput extends BaseInputBo {

	private List<String> empNoList;

	public List<String> getEmpNoList() {
		return empNoList;
	}

	public void setEmpNoList(List<String> empNoList) {
		this.empNoList = empNoList;
	}

	@Override
	public boolean isValid() {
		boolean result = true;

		if (CollectionUtils.isEmpty(empNoList)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數empNoList為空值");
		}

		return result;
	}

}
