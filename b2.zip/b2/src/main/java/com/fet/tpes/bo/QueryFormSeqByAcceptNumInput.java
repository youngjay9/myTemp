package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryFormSeqByAcceptNumInput extends BaseInputBo{
	private String acceptnum;

	public String getAcceptnum() {
		return acceptnum;
	}

	public void setAcceptnum(String acceptnum) {
		this.acceptnum = acceptnum;
	}

	@Override
	public boolean isValid() {
		
		boolean result = true;
		if(StringUtil.isEmpty(acceptnum)) {
			result = false;
			LogUtil.error(this.getClass(), "受理編號為空值");
		}
		return result;
	}
	
}
