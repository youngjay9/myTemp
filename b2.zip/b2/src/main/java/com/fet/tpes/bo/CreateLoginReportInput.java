package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.LogLoginBean;
import com.fet.tpes.bo.base.BaseInputBo;

public class CreateLoginReportInput extends BaseInputBo{
	private List<LogLoginBean> logLoginBeanList;
	private List<LogLoginBean> loginFailBeanList;
	
	
	
	public List<LogLoginBean> getLogLoginBeanList() {
		return logLoginBeanList;
	}



	public void setLogLoginBeanList(List<LogLoginBean> logLoginBeanList) {
		this.logLoginBeanList = logLoginBeanList;
	}

	

	public List<LogLoginBean> getLoginFailBeanList() {
		return loginFailBeanList;
	}



	public void setLoginFailBeanList(List<LogLoginBean> loginFailBeanList) {
		this.loginFailBeanList = loginFailBeanList;
	}



	@Override
	public boolean isValid() {
		return true;
	}
}
