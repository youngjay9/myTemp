package com.fet.tpes.bo;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fet.tpes.bo.base.BaseInputBo;
import com.fet.tpes.util.LogUtil;
import com.fet.tpes.util.StringUtil;

public class QueryAccountingInfoByCalculateInput extends BaseInputBo{
	
	private List<String> calculateList;
	public List<String> getCalculateList() {
		return calculateList;
	}
	
	
	public void setCalculateList(List<String> calculateList) {
		this.calculateList = calculateList;
	}	

	@Override
	public boolean isValid() {
		boolean result = true;
		if(StringUtil.isEmpty(this.getRegion())) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數region為空值");
		} else if (CollectionUtils.isEmpty(calculateList)) {
			result = false;
			LogUtil.error(this.getClass(), "傳入參數calculateList為空值");
		}
		
		return result;
	}



}
