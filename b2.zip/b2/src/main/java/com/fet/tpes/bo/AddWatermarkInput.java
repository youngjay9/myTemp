package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class AddWatermarkInput extends BaseInputBo {

	private String file;
	private String watermark;
	private String fileExt;
	
	@Override
	public boolean isValid() {
		return true;
	}

	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getWatermark() {
		return watermark;
	}
	public void setWatermark(String watermark) {
		this.watermark = watermark;
	}
	public String getFileExt() {
		return fileExt;
	}
	public void setFileExt(String fileExt) {
		this.fileExt = fileExt;
	}
}
