package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class QueryAcceptItemListInput extends BaseInputBo{

	@Override
	public boolean isValid() {
		return true;
	}
}
