package com.fet.tpes.bo;

import com.fet.tpes.bo.base.BaseInputBo;

public class CreateAuthPrivilegeChangeLogInput extends BaseInputBo{

	@Override
	public boolean isValid() {
		boolean result = true;
		
		return result;
	}

}
