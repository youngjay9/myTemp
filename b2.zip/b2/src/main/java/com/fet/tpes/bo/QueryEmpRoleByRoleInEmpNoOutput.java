package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AuthEmpRoleMapBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryEmpRoleByRoleInEmpNoOutput extends BaseOutputBo{

	private List<AuthEmpRoleMapBean> authEmpRoleMapBeanList;

	public List<AuthEmpRoleMapBean> getAuthEmpRoleMapBeanList() {
		return authEmpRoleMapBeanList;
	}

	public void setAuthEmpRoleMapBeanList(List<AuthEmpRoleMapBean> authEmpRoleMapBeanList) {
		this.authEmpRoleMapBeanList = authEmpRoleMapBeanList;
	}
	
}
