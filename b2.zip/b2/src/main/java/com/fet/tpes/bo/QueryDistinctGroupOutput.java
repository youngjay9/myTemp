package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryDistinctGroupOutput extends BaseOutputBo{
	private List<String> distinctDivGroup;

	public List<String> getDistinctDivGroup() {
		return distinctDivGroup;
	}

	public void setDistinctDivGroup(List<String> distinctDivGroup) {
		this.distinctDivGroup = distinctDivGroup;
	}
	
	
}
