package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.NcpsFormFileBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class GetFormFileOutput extends BaseOutputBo {
	private List<NcpsFormFileBean> ncpsFormFileList;
	private String resultString;

	public List<NcpsFormFileBean> getNcpsFormFileList() {
		return ncpsFormFileList;
	}

	public void setNcpsFormFileList(List<NcpsFormFileBean> ncpsFormFileList) {
		this.ncpsFormFileList = ncpsFormFileList;
	}

	public String getResultString() {
		return resultString;
	}

	public void setResultString(String resultString) {
		this.resultString = resultString;
	}
}
