package com.fet.tpes.bo;

import java.util.List;

import com.fet.tpes.bean.AccountingBean;
import com.fet.tpes.bo.base.BaseOutputBo;

public class QueryAllWaitAccntingOutput extends BaseOutputBo{
	private List<AccountingBean> accntingBeanList;

	public List<AccountingBean> getAccntingBeanList() {
		return accntingBeanList;
	}

	public void setAccntingBeanList(List<AccountingBean> accntingBeanList) {
		this.accntingBeanList = accntingBeanList;
	}
	
	
}
