package com.fet.tpes.bo.pmc;

public class UpdatePmcComputerInput {
	
	private String hostName;
	private String pmcType;
	private String versionMd5;
	
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getPmcType() {
		return pmcType;
	}
	public void setPmcType(String pmcType) {
		this.pmcType = pmcType;
	}
	public String getVersionMd5() {
		return versionMd5;
	}
	public void setVersionMd5(String versionMd5) {
		this.versionMd5 = versionMd5;
	}
}
