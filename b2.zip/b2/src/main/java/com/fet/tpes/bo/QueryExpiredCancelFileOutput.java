package com.fet.tpes.bo;

import java.util.List;
import java.util.Map;

import com.fet.tpes.bo.base.BaseOutputBo;
import com.fet.tpes.entity.TpesFile;

public class QueryExpiredCancelFileOutput extends BaseOutputBo {

	private Map<Integer, List<TpesFile>> fileMap;

	public Map<Integer, List<TpesFile>> getFileMap() {
		return fileMap;
	}
	public void setFileMap(Map<Integer, List<TpesFile>> fileMap) {
		this.fileMap = fileMap;
	}
}
