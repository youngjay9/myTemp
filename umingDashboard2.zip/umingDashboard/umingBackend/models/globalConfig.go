package models

import (
	"github.com/jinzhu/gorm"
)

// GlobalSettingType ,
var GlobalSettingType = "GlobalSetting"

// GlobalConfig data model
type GlobalConfig struct {
	gorm.Model
	Type                      string `json:"type" gorm:"NOT NULL;default:''"`
	TokenExpiredDuration      int64  `json:"tokenExpiredDuration" gorm:"NOT NULL;default:86400"`
	HelpPageDescriptionRed    string `json:"helpPageDescriptionRed" gorm:"size:5000;NOT NULL;default:''"`
	HelpPageDescriptionGreen  string `json:"helpPageDescriptionGreen" gorm:"size:5000;NOT NULL;default:''"`
	HelpPageDescriptionYellow string `json:"helpPageDescriptionYellow" gorm:"size:5000;NOT NULL;default:''"`
	ShipPosition              string `json:"shipPosition" gorm:"type:text;size:30000;NOT NULL;"`
}
