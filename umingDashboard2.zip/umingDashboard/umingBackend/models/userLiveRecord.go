package models

import (
	"github.com/jinzhu/gorm"
)

// UserLiveRecord data model, Role = ["Admin" | "Normal" ]
type UserLiveRecord struct {
	gorm.Model
	Account          string `json:"account" gorm:"NOT NULL"`
	Name             string `json:"name" gorm:"NOT NULL;default:''"`
	Role             string `json:"role" gorm:"NOT NULL;default:'Normal'"`
	LoginTime        int64  `json:"loginTime" gorm:"NOT NULL;default:0"`
	LogoutTime       int64  `json:"logoutTime" gorm:"NOT NULL;default:0"`
	StayTime         int64  `json:"stayTime" gorm:"NOT NULL;default:0"`
	LoginTimeString  string `json:"loginTimeString" gorm:"NOT NULL;default:''"`
	LogoutTimeString string `json:"logoutTimeString" gorm:"NOT NULL;default:''"`
	StayTimeString   string `json:"stayTimeString" gorm:"NOT NULL;default:''"`
	LoginIP          string `json:"loginIp" gorm:"NOT NULL;default:''"`
	LoginSuccess     int    `json:"loginSuccess" gorm:"NOT NULL;default:0"`
	LoginFail        int    `json:"loginFail" gorm:"NOT NULL;default:0"`
	Error            string `json:"error" gorm:"size:5000;NOT NULL;default:''"`
	LiveDuration     int64  `json:"liveDuration" gorm:"default:NULL"`
}

// // Serialize serializes user data
// func (u *UserLiveRecord) Serialize() map[string]interface{} {
// 	return map[string]interface{}{
// 		"id":                     u.ID,
// 		"account":                u.Account,
// 		"name":                   u.Name,
// 		"role":                   u.Role,
// 		"loginTime":              u.LoginTime,
// 		"logoutTime":             u.LogoutTime,
// 		"loginExpiredTime":       u.LoginExpiredTime,
// 		"loginTimeString":        u.LoginTimeString,
// 		"logoutTimeString":       u.LogoutTimeString,
// 		"loginExpiredTimeString": u.LoginExpiredTimeString,
// 		"loginIp":                u.LoginIP,
// 	}
// }
