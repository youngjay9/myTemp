package models

import (
	"fmt"

	"github.com/jinzhu/gorm"
)

// Migrate automigrates models using ORM
func Migrate(db *gorm.DB) {
	db.AutoMigrate(&User{}, &UserLiveRecord{}, &UserActivityRecord{}, &GlobalConfig{})
	// set up foreign keys

	globalConfig := GlobalConfig{
		Type:                      GlobalSettingType,
		TokenExpiredDuration:      86400,
		HelpPageDescriptionRed:    "",
		HelpPageDescriptionGreen:  "",
		HelpPageDescriptionYellow: "",
	}
	if err := db.Where("type = ?", GlobalSettingType).First(&globalConfig).Error; err != nil {
		//create one if it does not exist in DB
		db.NewRecord(globalConfig)
		db.Create(&globalConfig)
	}

	fmt.Println("Auto Migration has beed processed")
}
