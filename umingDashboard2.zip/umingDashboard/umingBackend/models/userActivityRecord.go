package models

import (
	"github.com/jinzhu/gorm"
)

// UserActivityRecord data model, Role = ["Admin" | "Normal" ]
type UserActivityRecord struct {
	gorm.Model
	Account         string `json:"account" gorm:"NOT NULL"`
	Name            string `json:"name" gorm:"NOT NULL;default:''"`
	Role            string `json:"role" gorm:"NOT NULL;default:'Normal'"`
	ClickTime       int64  `json:"clickTime" gorm:"NOT NULL;default:0"`
	StayTime        int64  `json:"stayTime" gorm:"NOT NULL;default:0"`
	ClickTimeString string `json:"clickTimeString" gorm:"NOT NULL;default:''"`
	StayTimeString  string `json:"stayTimeString" gorm:"NOT NULL;default:''"`
	LoginIP         string `json:"loginIp" gorm:"NOT NULL;default:''"`
	LiveDuration    int64  `json:"liveDuration" gorm:"NOT NULL;default:0"`
	Category        string `json:"category" gorm:"NOT NULL;default:''"`
	Action          string `json:"action" gorm:"NOT NULL;default:''"`
	Label           string `json:"label" gorm:"NOT NULL;default:''"`
	Value           string `json:"value" gorm:"NOT NULL;default:''"`
	IsClose         bool   `json:"isClose" gorm:"NOT NULL;default:false"`
}
