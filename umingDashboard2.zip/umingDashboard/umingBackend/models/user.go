package models

import (
	"github.com/jinzhu/gorm"
)

// User data model, Role = ["Admin" | "Normal" ]
type User struct {
	gorm.Model
	Account                string `json:"account" gorm:"NOT NULL"`
	Token                  string `json:"token" gorm:"size:5000;NOT NULL;default:''"`
	Name                   string `json:"name" gorm:"NOT NULL;default:''"`
	Role                   string `json:"role" gorm:"NOT NULL;default:'Normal'"`
	TokenExpiredDuration   int64  `json:"tokenExpiredDuration" gorm:"NOT NULL;default:0"`
	ShipPosition           string `json:"shipPosition" gorm:"type:text;size:30000;NOT NULL;"`
	LoginTime              int64  `json:"loginTime" gorm:"NOT NULL;default:0"`
	LogoutTime             int64  `json:"logoutTime" gorm:"NOT NULL;default:0"`
	LoginExpiredTime       int64  `json:"loginExpiredTime" gorm:"NOT NULL;default:0"`
	LoginTimeString        string `json:"loginTimeString" gorm:"NOT NULL;default:''"`
	LogoutTimeString       string `json:"logoutTimeString" gorm:"NOT NULL;default:''"`
	LoginExpiredTimeString string `json:"loginExpiredTimeString" gorm:"NOT NULL;default:''"`
	LoginIP                string `json:"loginIp" gorm:"NOT NULL;default:''"`
}

// Serialize serializes user data
func (u *User) Serialize() map[string]interface{} {
	return map[string]interface{}{
		"id":                     u.ID,
		"account":                u.Account,
		"token":                  u.Token,
		"name":                   u.Name,
		"role":                   u.Role,
		"tokenExpiredDuration":   u.TokenExpiredDuration,
		"shipPosition":           u.ShipPosition,
		"loginTime":              u.LoginTime,
		"logoutTime":             u.LogoutTime,
		"loginExpiredTime":       u.LoginExpiredTime,
		"loginTimeString":        u.LoginTimeString,
		"logoutTimeString":       u.LogoutTimeString,
		"loginExpiredTimeString": u.LoginExpiredTimeString,
		"loginIp":                u.LoginIP,
	}
}

// SerializeHideToken serializes user data
func (u *User) SerializeHideToken() map[string]interface{} {
	return map[string]interface{}{
		"id":                     u.ID,
		"account":                u.Account,
		"name":                   u.Name,
		"role":                   u.Role,
		"tokenExpiredDuration":   u.TokenExpiredDuration,
		"loginTime":              u.LoginTime,
		"logoutTime":             u.LogoutTime,
		"loginExpiredTime":       u.LoginExpiredTime,
		"loginTimeString":        u.LoginTimeString,
		"logoutTimeString":       u.LogoutTimeString,
		"loginExpiredTimeString": u.LoginExpiredTimeString,
		"loginIp":                u.LoginIP,
	}
}

// InitValue user data
func (u *User) InitValue(m map[string]interface{}) {
	if m["account"] != nil {
		u.Account = m["account"].(string)
	}

	if m["token"] != nil {
		u.Token = m["token"].(string)
	}

	if m["name"] != nil {
		u.Name = m["name"].(string)
	}

	if m["role"] != nil {
		u.Role = m["role"].(string)
	} else {
		u.Role = "Normal"
	}

	if m["loginIp"] != nil {
		u.LoginIP = m["loginIp"].(string)
	}

	if m["tokenExpiredDuration"] != nil {
		u.TokenExpiredDuration = m["tokenExpiredDuration"].(int64)
	}

	u.ShipPosition = ""

}
