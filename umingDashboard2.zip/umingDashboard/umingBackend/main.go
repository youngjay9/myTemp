package main

import (
	"goGinBassinet/startup"
	"os"

	"github.com/gin-gonic/gin"
)

func main() {

	app := initEveryThing()

	port := os.Getenv("PORT")

	app.Run(":" + port) // listen to given port
}

func initEveryThing() *gin.Engine {
	startup.SetUpEnvironmen()
	app := startup.SetupRouter()
	return app
}
