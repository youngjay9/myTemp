package startup

import (
	"goGinBassinet/api"
	"goGinBassinet/database"
	"goGinBassinet/logger"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
)

// SetUpEnvironmen ,
func SetUpEnvironmen() {
	// init log
	logger.InitLogger()

	// load .env environment variables
	err := godotenv.Load()
	if err != nil {
		panic(err)
	}
}

// SetupRouter ,
func SetupRouter() *gin.Engine {

	app := gin.Default() // create gin app

	app.Use(cors.New(cors.Config{
		AllowOrigins: []string{"*"},
		AllowMethods: []string{"PUT", "PATCH", "POST", "GET", "OPTIONS", "DELETE"},
		AllowHeaders: []string{"*"},

		AllowCredentials: true,

		MaxAge: 12 * time.Hour,
	}))

	// initializes database
	database.InitDB()
	api.ApplyRoutes(app) // apply api router

	return app
}
