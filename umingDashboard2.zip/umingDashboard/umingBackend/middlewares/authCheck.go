package middlewares

import "github.com/gin-gonic/gin"

// AuthCheck blocks unauthorized requestrs
func AuthCheck() gin.HandlerFunc {
	return func(c *gin.Context) {
		_, exists := c.Get("user")
		if !exists {
			c.AbortWithStatus(401)
			return
		}
	}
}
