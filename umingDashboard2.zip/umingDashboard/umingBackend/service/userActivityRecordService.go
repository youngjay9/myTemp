package service

import (
	"goGinBassinet/database"
	"goGinBassinet/logger"
	"goGinBassinet/models"
	"time"

	"github.com/brianvoe/gofakeit/v5"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

const (
	actionClick = "Click"
	actionLive  = "Live"
)

const (
	categoryTop    = "Top_View"
	categoryLevel2 = "IDC_View_Detail"
	categoryLevel3 = "Boat_View_Detail"
)

// HandleTrackEvent , goroutine
func HandleTrackEvent(ch chan string, c *gin.Context, category string, action string, label string, value string) string {
	if action == actionClick {
		ret := clickEvent(c, category, action, label, value)
		ch <- ret
		return ret
	} else if action == actionLive {
		ret := liveEvent(c, category, action, label, value)
		ch <- ret
		return ret
	} else {
		ch <- "Unknow Event Type"
		return "Unknow Event Type"
	}
}

func clickEvent(c *gin.Context, category string, action string, label string, value string) string {
	userAccount := c.GetString("user_account")
	if userAccount == "" {
		logger.Log.Info("action: " + action + ", no user account found")
		return ""
	}

	dateNow := time.Now()

	CloseAllUncloseEvent(userAccount)

	activityRecord := models.UserActivityRecord{
		Account:         c.GetString("user_account"),
		Name:            c.GetString("user_name"),
		Role:            c.GetString("user_role"),
		ClickTime:       dateNow.Unix(),
		StayTime:        0,
		ClickTimeString: dateNow.Format(time.RFC3339),
		StayTimeString:  "",
		LoginIP:         c.GetString("login_ip"),
		LiveDuration:    int64(gofakeit.Number(1, 10)),
		Category:        category,
		Action:          action,
		Label:           label,
		Value:           value,
		IsClose:         false,
	}
	db := database.DB
	db.Create(&activityRecord)
	return ""
}

// CloseAllUncloseEvent ,
func CloseAllUncloseEvent(userAccount string) string {
	var activityRecords []models.UserActivityRecord
	db := database.DB
	err := db.Set("gorm:auto_preload", true).Where("account = ? AND is_close = false", userAccount).Find(&activityRecords).Error

	if gorm.IsRecordNotFoundError(err) {
		return ""
	} else if err != nil {
		logger.Log.Error(err)
		return ""
	}

	for _, record := range activityRecords {
		record.IsClose = true
		db.Save(record)
	}

	return ""
}

func liveEvent(c *gin.Context, category string, action string, label string, value string) string {
	userAccount := c.GetString("user_account")
	if userAccount == "" {
		logger.Log.Info("action: " + action + ", no user account found")
		return ""
	}
	var activityRecord models.UserActivityRecord
	db := database.DB
	err := db.Set("gorm:auto_preload", true).Where("account = ? AND category = ? AND is_close = false", userAccount, category).Last(&activityRecord).Error

	if gorm.IsRecordNotFoundError(err) {
		logger.Log.Error("User activity record not found in DB")
		return "User activity record not found in DB. Does client call trackEvent before user click any page?"
	} else if err != nil {
		logger.Log.Error(err)
		return "db error when query track log record"
	}

	dateNow := time.Now()

	activityRecord.StayTime = dateNow.Unix()
	activityRecord.StayTimeString = dateNow.Format(time.RFC3339)
	activityRecord.LiveDuration = activityRecord.StayTime - activityRecord.ClickTime
	db.Save(&activityRecord)
	return ""
}
