package service

import (
	"goGinBassinet/database"
	"goGinBassinet/logger"
	"goGinBassinet/models"
	"time"

	"github.com/jinzhu/gorm"
)

// HandleUserLiveRecordLogin ,
func HandleUserLiveRecordLogin(user *models.User, isLogin bool, err string) {
	CloseAllUncloseEvent(user.Account)

	liveRecord := models.UserLiveRecord{
		Account:          user.Account,
		Name:             user.Name,
		Role:             user.Role,
		LoginTime:        user.LoginTime,
		LogoutTime:       user.LogoutTime,
		LoginTimeString:  user.LoginTimeString,
		LogoutTimeString: user.LogoutTimeString,
		LoginIP:          user.LoginIP,
		Error:            err,
	}
	if isLogin == true {
		liveRecord.LoginSuccess = 1
		liveRecord.LiveDuration = 0
	} else {
		liveRecord.LoginFail = 1
	}
	db := database.DB
	db.Create(&liveRecord)
}

// HandleUserLiveRecordLogout ,
func HandleUserLiveRecordLogout(user *models.User) {
	if user.LoginTime == 0 {
		logger.Log.Warning("user : " + user.Account + " , err : logout but login time = 0")
		return
	}

	var liveRecord models.UserLiveRecord
	db := database.DB
	dbErr := db.Set("gorm:auto_preload", true).Where("account = ? AND login_time = ?", user.Account, user.LoginTime).Last(&liveRecord).Error

	if gorm.IsRecordNotFoundError(dbErr) {
		logger.Log.Warning("user : " + user.Account + " , err : logout but db not found live record")
		return
	} else if dbErr != nil {
		logger.Log.Info(dbErr)
		return
	}

	liveRecord.LogoutTime = user.LogoutTime
	liveRecord.LogoutTimeString = user.LogoutTimeString
	liveRecord.LiveDuration = user.LogoutTime - user.LoginTime

	db.Save(&liveRecord)
}

// HandleUserLiveRecordEvent , goroutine
func HandleUserLiveRecordEvent(ch chan string, userAccount string, action string) string {
	if actionLive != action {
		ch <- ""
		return ""
	}

	var liveRecord models.UserLiveRecord
	db := database.DB
	err := db.Set("gorm:auto_preload", true).Where("account = ?", userAccount).Last(&liveRecord).Error

	if gorm.IsRecordNotFoundError(err) {
		logger.Log.Error("User live record not found in DB")
		ch <- "User live record not found in DB. Does client call trackEvent after user logout?"
		return "User live record not found in DB. Does client call trackEvent after user logout?"
	} else if err != nil {
		logger.Log.Error(err)
		ch <- "db error when query track log record"
		return "db error when query track log record"
	}

	if liveRecord.LogoutTime != 0 {
		logger.Log.Error("User live record not found in DB")
		ch <- "User live record not found in DB. Does client call trackEvent after user logout?"
		return "User live record not found in DB. Does client call trackEvent after user logout?"
	}

	dateNow := time.Now()

	liveRecord.StayTime = dateNow.Unix()
	liveRecord.StayTimeString = dateNow.Format(time.RFC3339)
	liveRecord.LiveDuration = liveRecord.StayTime - liveRecord.LoginTime
	db.Save(&liveRecord)
	ch <- ""
	return ""
}
