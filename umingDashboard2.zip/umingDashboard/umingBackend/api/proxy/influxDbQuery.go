package proxy

import (
	b64 "encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"

	"github.com/gin-gonic/gin"
)

func influxDbQueryByPostRequest(c *gin.Context) {

	ipAddr := c.ClientIP()
	fmt.Println(ipAddr)

	fmt.Println(c.PostForm("q"))
	fmt.Println(c.PostForm("db"))
	fmt.Println(c.PostForm("u"))
	fmt.Println(c.PostForm("p"))

	qDec, _ := b64.StdEncoding.DecodeString(c.PostForm("q"))
	fmt.Println(string(qDec))

	params := make(url.Values)
	params.Set("db", c.PostForm("db"))
	params.Set("u", c.PostForm("u"))
	params.Set("p", c.PostForm("p"))
	params.Set("q", string(qDec))

	resp, err := http.PostForm("http://10.1.50.58:8086/query", params)
	if err != nil {
		c.JSON(400, gin.H{
			"err": err,
		})
		return
	}

	defer resp.Body.Close()

	var result map[string]interface{}
	err2 := json.NewDecoder(resp.Body).Decode(&result)
	if err2 != nil {
		c.JSON(400, gin.H{
			"error": err2,
		})
		return
	}

	c.JSON(200, result)
}
