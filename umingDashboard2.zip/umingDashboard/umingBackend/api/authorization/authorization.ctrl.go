package authorization

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"time"

	"goGinBassinet/authv3"
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"goGinBassinet/models"
	"goGinBassinet/service"
	"goGinBassinet/utility"

	jwt "github.com/dgrijalva/jwt-go"
	"github.com/gin-gonic/gin"
	"github.com/go-ldap/ldap/v3"
	"github.com/jinzhu/gorm"
)

//LoginInfo ,  unexport
type LoginInfo struct {
	Account  string `form:"account" json:"account" binding:"required"`
	Password string `form:"password" json:"password" binding:"required"`
}

// StructToMap ,  helper function to struct -> map[string]interface
func StructToMap(obj interface{}) map[string]interface{} {
	var data = make(map[string]interface{})
	dataByte, _ := json.Marshal(obj)
	json.Unmarshal(dataByte, &data)
	return data
}

func loginAd(c *gin.Context) {

	var params LoginInfo
	if err := c.ShouldBindJSON(&params); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	dateNow := time.Now()

	var user models.User = models.User{
		Account:         params.Account,
		LoginTime:       dateNow.Unix(),
		LoginTimeString: dateNow.Format(time.RFC3339),
		LoginIP:         c.ClientIP(),
	}

	configServer1 := &authv3.Config{
		Server: "tpmtdc1.hqfeg.com",
		Port:   389,
		BaseDN: "OU=UMING裕民航運,OU=Headquarter,DC=HQFEG,DC=COM",
	}

	configServer2 := &authv3.Config{
		Server: "tpmtdc2.hqfeg.com",
		Port:   389,
		BaseDN: "OU=UMING裕民航運,OU=Headquarter,DC=HQFEG,DC=COM",
	}

	username := params.Account
	password := params.Password

	var group []string
	attributes := []string{"displayName"}

	var status bool = false
	var entry (*ldap.Entry)
	var err error

	status, entry, _, err = authv3.AuthenticateExtended2(configServer1, username, password, attributes, group)
	if status == false {
		fmt.Println("login first AD server fail")
		if err != nil {
			fmt.Println(err)
		}

		status, entry, _, err = authv3.AuthenticateExtended2(configServer2, username, password, attributes, group)
		if status == false {
			fmt.Println("login second AD server fail")
			if err != nil {
				fmt.Println(err)
				c.Error(err)
			}
			c.JSON(httperror.ErrorMessage(httperror.ErrAccountPassworFail))
			return
		}
	}

	if err != nil {
		fmt.Println(err)
	}

	userDisplayName := ""
	if entry != nil {
		userDisplayName = entry.GetAttributeValue("displayName")
	} else {
		fmt.Println(username)
		fmt.Println("this account ahs no entry (attributes)")
	}

	db := database.DB
	dbErr := db.Set("gorm:auto_preload", true).Where("account = ?", params.Account).First(&user).Error

	if gorm.IsRecordNotFoundError(dbErr) {
		logger.Log.Info("No Access right to this web")
		service.HandleUserLiveRecordLogin(&user, false, "No Access right to this web")
		c.JSON(httperror.ErrorMessage(httperror.ErrNoSystemAccessRight))
		return
	} else if dbErr != nil {
		logger.Log.Info(dbErr)
		service.HandleUserLiveRecordLogin(&user, false, dbErr.Error())
		c.Error(dbErr)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	if user.Role == "" {
		user.Role = "Normal"
	}

	user.Name = userDisplayName

	var tokenExpiredDuration int64 = user.TokenExpiredDuration
	if tokenExpiredDuration == 0 {
		tokenExpiredDuration = utility.GetDefaultTokenExpiredDuration()
	}

	tokenTmp, _ := generateToken(map[string]interface{}{
		"account": user.Account,
		"name":    user.Name,
		"role":    user.Role,
		"loginIp": user.LoginIP,
	}, tokenExpiredDuration)

	user.LoginTime = dateNow.Unix()
	user.LoginTimeString = dateNow.Format(time.RFC3339)
	dateExpired := dateNow.Add(time.Duration(tokenExpiredDuration) * time.Second)
	user.LoginExpiredTime = dateExpired.Unix()
	user.LoginExpiredTimeString = dateExpired.Format(time.RFC3339)
	user.LogoutTime = 0
	user.LogoutTimeString = ""
	user.LoginIP = c.ClientIP()

	user.Token = tokenTmp

	if true == db.NewRecord(user) {
		db.Create(&user)
	} else {
		db.Save(&user)
	}

	service.CloseAllUncloseEvent(user.Account)
	service.HandleUserLiveRecordLogin(&user, true, "")

	c.JSON(200, gin.H{
		"data": user.Serialize(),
	})
}

func logout(c *gin.Context) {
	userAccount := c.GetString("user_account")

	logger.Log.Info("user : " + userAccount)

	var user models.User
	db := database.DB
	err := db.Set("gorm:auto_preload", true).Where("account = ?", userAccount).First(&user).Error

	if gorm.IsRecordNotFoundError(err) {
		logger.Log.Error("User Not Found")
		c.JSON(httperror.ErrorMessage(httperror.ErrUserNotFound))
		return
	} else if err != nil {
		logger.Log.Error(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	dateNow := time.Now()
	user.LogoutTime = dateNow.Unix()
	user.LogoutTimeString = dateNow.Format(time.RFC3339)
	user.Token = ""

	db.Save(&user)

	service.HandleUserLiveRecordLogout(&user)
	service.CloseAllUncloseEvent(userAccount)

	c.JSON(200, gin.H{
		"data": user.Serialize(),
	})
}

func generateToken(data map[string]interface{}, tokenExpiredDuration int64) (string, error) {

	date := time.Now().Add(time.Duration(tokenExpiredDuration) * time.Second)

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"user": data,
		"exp":  date.Unix(),
	})

	pwd, _ := os.Getwd()
	keyPath := pwd + "/jwtsecret.key"
	key, readErr := ioutil.ReadFile(keyPath)
	if readErr != nil {
		return "", readErr
	}
	tokenString, err := token.SignedString(key)
	return tokenString, err
}
