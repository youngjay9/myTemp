package authorization

import (
	"github.com/gin-gonic/gin"
)

// ApplyPublicRoutes applies router to the gin Engine
func ApplyPublicRoutes(r *gin.RouterGroup) {
	r.POST("/loginAd", loginAd)
}

// ApplyPrivateRoutes applies router to the gin Engine
func ApplyPrivateRoutes(r *gin.RouterGroup) {
	r.POST("/logout", logout)
}
