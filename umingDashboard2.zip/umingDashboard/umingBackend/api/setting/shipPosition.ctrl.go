package setting

import (
	"encoding/json"
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"goGinBassinet/models"
	"io/ioutil"

	"github.com/gin-gonic/gin"
)

// postGlobalShipPosition , save global ship position
func postGlobalShipPosition(c *gin.Context) {
	userAccount := c.GetString("user_account")
	logger.Log.Info("user: " + userAccount)

	userRole := c.GetString("user_role")
	if userRole != "Admin" {
		c.JSON(httperror.ErrorMessage(httperror.ErrForbidden))
		return
	}

	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	body, _ := ioutil.ReadAll(c.Request.Body)
	bodyStr := string(body)
	logger.Log.Info(bodyStr)

	var globalConfig models.GlobalConfig
	db := database.DB
	if err := db.Where("type = ?", models.GlobalSettingType).First(&globalConfig).Error; err == nil {
		globalConfig.ShipPosition = bodyStr
		db.Save(&globalConfig)
		c.JSON(200, gin.H{})

	} else {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDataNotFound))
	}
}

// getGlobalShiptPosition , load global ship position
func getGlobalShipPosition(c *gin.Context) {
	userAccount := c.GetString("user_account")

	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	logger.Log.Info("user : " + userAccount)

	var globalConfig models.GlobalConfig
	db := database.DB
	if err := db.Where("type = ?", models.GlobalSettingType).First(&globalConfig).Error; err == nil {

		if globalConfig.ShipPosition == "" {
			c.JSON(200, gin.H{})
			return
		} else {
			var bytePosition []byte = []byte(globalConfig.ShipPosition)
			var mapPosition interface{}
			json.Unmarshal(bytePosition, &mapPosition)
			c.JSON(200, mapPosition)
			return
		}
	} else {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDataNotFound))
	}
}
