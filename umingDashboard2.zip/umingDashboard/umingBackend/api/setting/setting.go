package setting

import (
	"github.com/gin-gonic/gin"
)

// ApplyPublicRoutes applies router to the gin Engine
func ApplyPublicRoutes(r *gin.RouterGroup) {

}

// ApplyPrivateRoutes applies router to the gin Engine
func ApplyPrivateRoutes(r *gin.RouterGroup) {
	r.PUT("/setting/globalConfig", putGlobalConfig)
	r.GET("/setting/globalConfig", getGlobalConfig)
	r.PUT("/setting/globalShipPosition", postGlobalShipPosition)
	r.GET("/setting/globalShipPosition", getGlobalShipPosition)
}
