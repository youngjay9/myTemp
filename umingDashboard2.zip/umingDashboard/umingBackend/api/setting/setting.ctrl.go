package setting

import (
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"goGinBassinet/models"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

func putGlobalConfig(c *gin.Context) {

	type sParamsConfig struct {
		TokenExpiredDuration      int64  `json:"tokenExpiredDuration"`
		HelpPageDescriptionRed    string `json:"helpPageDescriptionRed"`
		HelpPageDescriptionGreen  string `json:"helpPageDescriptionGreen"`
		HelpPageDescriptionYellow string `json:"helpPageDescriptionYellow"`
	}

	var params sParamsConfig
	if err := c.ShouldBindJSON(&params); err != nil {
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrWrongParameter))
		return
	}

	userAccount := c.GetString("user_account")
	logger.Log.Info("user: " + userAccount)
	logger.Log.Info(params)

	db := database.DB
	var globalConfig models.GlobalConfig
	if err := db.Where("type = ?", models.GlobalSettingType).First(&globalConfig).Error; err != nil {
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDataNotFound))
		return
	}

	if params.HelpPageDescriptionGreen != "" {
		globalConfig.HelpPageDescriptionGreen = params.HelpPageDescriptionGreen
	}
	if params.HelpPageDescriptionRed != "" {
		globalConfig.HelpPageDescriptionRed = params.HelpPageDescriptionRed
	}
	if params.HelpPageDescriptionYellow != "" {
		globalConfig.HelpPageDescriptionYellow = params.HelpPageDescriptionYellow
	}
	if params.TokenExpiredDuration > 0 {
		globalConfig.TokenExpiredDuration = params.TokenExpiredDuration
	}

	db.Save(&globalConfig)

	c.JSON(200, gin.H{
		"data": globalConfig,
	})
}

func getGlobalConfig(c *gin.Context) {

	var globalConfig models.GlobalConfig
	db := database.DB

	var err error = nil
	err = db.Where("type = ?", models.GlobalSettingType).First(&globalConfig).Error

	if gorm.IsRecordNotFoundError(err) {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDataNotFound))
		return
	} else if err != nil {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	c.JSON(200, gin.H{
		"data": globalConfig,
	})
}
