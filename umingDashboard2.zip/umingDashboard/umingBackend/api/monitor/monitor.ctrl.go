package monitor

import (
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"goGinBassinet/models"
	"goGinBassinet/service"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

func getLiveUserList(c *gin.Context) {
	userAccount := c.GetString("user_account")
	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}
	logger.Log.Info("user : " + userAccount)

	dateNow := time.Now()
	tsNow := dateNow.Unix()

	var users []models.User
	db := database.DB

	var err error = nil
	err = db.Set("gorm:auto_preload", true).Where("logout_time = 0 AND login_expired_time>= ?", tsNow).Find(&users).Error

	if gorm.IsRecordNotFoundError(err) {
		// not found
	} else if err != nil {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	length := len(users)
	serialized := make([]map[string]interface{}, length, length)

	for i := 0; i < length; i++ {
		serialized[i] = users[i].SerializeHideToken()
	}

	//we can direct use users if you want output all data,
	c.JSON(200, gin.H{
		"data": users,
	})

}

func postTrackEvent(c *gin.Context) {
	type TrackEvent struct {
		Category string `json:"category" binding:"required,oneof=Top_View IDC_View_Detail Boat_View_Detail"`
		Action   string `json:"action" binding:"required,oneof=Click Live"`
		Label    string `json:"label"`
		Value    string `json:"value"`
	}

	var event TrackEvent
	if err := c.ShouldBindJSON(&event); err != nil {
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrWrongParameter))
		return
	}

	userAccount := c.GetString("user_account")
	logger.Log.Info("user: " + userAccount)
	logger.Log.Info(event)

	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrUserNotFound))
		return
	}

	ch := make(chan string)

	go service.HandleUserLiveRecordEvent(ch, userAccount, event.Action)
	go service.HandleTrackEvent(ch, c, event.Category, event.Action, event.Label, event.Value)
	err, err2 := <-ch, <-ch

	if err != "" {
		c.JSON(httperror.ErrorMessage(httperror.NewCustomAPIError(err)))
		return
	}
	if err2 != "" {
		c.JSON(httperror.ErrorMessage(httperror.NewCustomAPIError(err2)))
		return
	}

	c.JSON(200, gin.H{})
}
