package monitor

import (
	"github.com/gin-gonic/gin"
)

// ApplyPublicRoutes applies router to the gin Engine
func ApplyPublicRoutes(r *gin.RouterGroup) {

}

// ApplyPrivateRoutes applies router to the gin Engine
func ApplyPrivateRoutes(r *gin.RouterGroup) {
	r.GET("/monitor/liveUser", getLiveUserList)
	r.POST("/monitor/trackEvent", postTrackEvent)
}
