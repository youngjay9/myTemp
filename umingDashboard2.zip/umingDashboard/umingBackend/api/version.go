package api

import "github.com/gin-gonic/gin"

// version,
func version(c *gin.Context) {
	c.JSON(200, gin.H{
		"version": "1.0.14",
	})
}
