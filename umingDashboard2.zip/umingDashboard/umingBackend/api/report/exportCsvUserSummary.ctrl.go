package report

import (
	"bytes"
	"encoding/csv"
	"fmt"
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"strconv"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

func getUserSummaryCsv(c *gin.Context) {
	type QueryParams struct {
		LastDays int    `form:"lastDays"`
		FromTS   int64  `form:"fromTs"`
		ToTS     int64  `form:"toTs"`
		UserName string `form:"userName"`
		UserID   string `form:"userId"`
	}

	userAccount := c.GetString("user_account")
	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	var params QueryParams
	if err := c.ShouldBindQuery(&params); err != nil {
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrWrongParameter))
		return
	}

	logger.Log.Info("user: " + userAccount)
	logger.Log.Info(params)

	db := database.DB
	var tx *gorm.DB = db.Table("user_live_records").
		Select("account, SUM(live_duration) as live_sum, AVG(live_duration) as live_avg, SUM(login_success) as login_success_count, SUM(login_fail) as login_fail_count")

	// handle account condition
	if params.UserID != "" {
		tx = tx.Where("account LIKE ?", "%"+params.UserID+"%")
	}

	// handle name condition
	if params.UserName != "" {
		tx = tx.Where("name LIKE ?", "%"+params.UserName+"%")
	}

	// handle time period condition, LastDays take precedence over FromTS and ToTS
	var beforeDaysTs int64 = 0
	if params.LastDays > 0 {
		beforeDays := time.Now().Add(time.Hour * 24 * time.Duration(params.LastDays) * -1)
		beforeDaysTs = beforeDays.Unix()
		tx = tx.Where("login_time >= ?", beforeDaysTs)

	} else if params.FromTS > 0 && params.ToTS > 0 {
		tx = tx.Where("login_time >= ?", params.FromTS).Where("login_time <= ?", params.ToTS)
	}

	var recordResults []RecordResult
	dbErr := tx.
		Group("account").
		Order("account ASC").
		Scan(&recordResults).Error

	if gorm.IsRecordNotFoundError(dbErr) {

	} else if dbErr != nil {
		logger.Log.Info(dbErr)
		c.Error(dbErr)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	var wg sync.WaitGroup
	for i := 0; i < len(recordResults); i++ {
		wg.Add(1)
		go workerFillLastRecord(&recordResults[i], beforeDaysTs, params.FromTS, params.ToTS, &wg)
	}
	wg.Wait()

	var (
		dataBytes = new(bytes.Buffer)
	)

	headList := []string{"UserID", "User Name", "Last Login Time", "Last Logout Time", "Last Login IP", "Login Success", "Login Failure", "Total Session Length", "Average Session Length"}
	dataBytes.WriteString("\xEF\xBB\xBF") // UTF-8 BOM
	wr := csv.NewWriter(dataBytes)
	wr.Write(headList)
	loc := time.FixedZone("UTC-8", 8*60*60)
	for _, record := range recordResults {
		loginTimeStr := ""
		if record.LoginTime > 0 {
			loginTimeStr = time.Unix(record.LoginTime, 0).In(loc).Format("2006-1-2 15:4:5")
		}
		logoutTimeStr := ""
		if record.LogoutTime > 0 {
			logoutTimeStr = time.Unix(record.LogoutTime, 0).In(loc).Format("2006-1-2 15:4:5")
		}
		durationTimeStr := ""
		if record.LiveSum > 0 {
			var hour int64 = record.LiveSum / 3600
			var minute int64 = ((record.LiveSum % 3600) / 60)
			var second int64 = ((record.LiveSum % 3600) % 60)
			if hour > 0 {
				durationTimeStr = fmt.Sprintf("%dh ", hour)
			}
			if minute > 0 {
				durationTimeStr = fmt.Sprintf("%s%dm ", durationTimeStr, minute)
			}
			if second > 0 {
				durationTimeStr = fmt.Sprintf("%s%ds ", durationTimeStr, second)
			}
		}
		AvgTimeStr := ""
		if record.LiveAvg > 0 {
			livAvgInt := int64(record.LiveAvg)
			var hour int64 = livAvgInt / 3600
			var minute int64 = ((livAvgInt % 3600) / 60)
			var second int64 = ((livAvgInt % 3600) % 60)
			if hour > 0 {
				AvgTimeStr = fmt.Sprintf("%dh ", hour)
			}
			if minute > 0 {
				AvgTimeStr = fmt.Sprintf("%s%dm ", AvgTimeStr, minute)
			}
			if second > 0 {
				AvgTimeStr = fmt.Sprintf("%s%ds ", AvgTimeStr, second)
			}
		}

		bodyList := []string{
			record.Account,
			record.Name,
			loginTimeStr,
			logoutTimeStr,
			record.LoginIP,
			strconv.FormatInt(int64(record.LoginSuccessCount), 10),
			strconv.FormatInt(int64(record.LoginFailCount), 10),
			durationTimeStr,
			AvgTimeStr,
		}
		wr.Write(bodyList)
	}
	wr.Flush()
	c.Writer.Header().Set("Content-type", "application/octet-stream")
	c.Writer.Header().Set("Content-Disposition", fmt.Sprintf("attachment;filename=%s", "user_summary_report.csv"))
	c.String(200, dataBytes.String())
}
