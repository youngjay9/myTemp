package report

import (
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

func getUserActivityReport(c *gin.Context) {
	// ActivityResult ,
	type ActivityResult struct {
		Account         string `json:"account"`
		Name            string `json:"name"`
		Role            string `json:"role"`
		Category        string `json:"category"`
		Action          string `json:"action"`
		LoginIP         string `json:"loginIp"`
		ClickTime       int64  `json:"clickTime"`
		StayTime        int64  `json:"stayTime"`
		ClickTimeString string `json:"clickTimeString"`
		StayTimeString  string `json:"stayTimeString"`
		LiveDuration    int64  `json:"liveDuration"`
	}

	type QueryParams struct {
		LastDays int    `form:"lastDays"`
		FromTS   int64  `form:"fromTs"`
		ToTS     int64  `form:"toTs"`
		UserName string `form:"userName"`
		UserID   string `form:"userId"`
		Category string `form:"category"`
		SortBy   string `form:"sortBy"`
		OrderBy  string `form:"orderBy"`
		Limit    int64  `form:"limit"`
		Offset   int64  `form:"offset"`
	}

	userAccount := c.GetString("user_account")
	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	var params QueryParams
	if err := c.ShouldBindQuery(&params); err != nil {
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrWrongParameter))
		return
	}

	logger.Log.Info("user: " + userAccount)
	logger.Log.Info(params)

	fromDate := time.Now()
	toDate := time.Now()

	if params.LastDays > 0 {
		nowDate := time.Now()
		toDate = nowDate
		fromDate = nowDate.Add(time.Duration(params.LastDays) * 24 * time.Hour * -1)
	} else if params.FromTS > 0 && params.ToTS > 0 {
		fromDate = time.Unix(params.FromTS, 0)
		toDate = time.Unix(params.ToTS, 0)
	}

	logger.Log.Info("Date From : ", fromDate)
	logger.Log.Info("Date To : ", toDate)

	db := database.DB
	var tx *gorm.DB = db.Table("user_activity_records")

	// handle account condition
	if params.UserID != "" {
		tx = tx.Where("account LIKE ?", "%"+params.UserID+"%")
	}

	// handle name condition
	if params.UserName != "" {
		tx = tx.Where("name LIKE ?", "%"+params.UserName+"%")
	}

	// handle category condition
	if params.Category != "" {
		tx = tx.Where("category = ?", params.Category)
	}

	tx = tx.Where("click_time >= ?", fromDate.Unix()).Where("click_time < ?", toDate.Unix())

	if params.OrderBy != "" && params.SortBy != "" {
		orderByStr := params.SortBy + " " + params.OrderBy + ", click_time DESC"
		tx = tx.Order(orderByStr)
	} else {
		tx = tx.Order("click_time DESC")
	}

	var count int = 0
	tx.Count(&count)

	if params.Offset > 0 {
		tx = tx.Offset(params.Offset)
	}

	if params.Limit > 0 {
		tx = tx.Limit(params.Limit)
	} else {
		params.Limit = 1000
		tx = tx.Limit(params.Limit)
	}

	var activityResults []ActivityResult
	dbErr := tx.Find(&activityResults).Error

	if gorm.IsRecordNotFoundError(dbErr) {

	} else if dbErr != nil {
		logger.Log.Info(dbErr)
		c.Error(dbErr)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	c.JSON(200, gin.H{
		"data":   activityResults,
		"total":  count,
		"offset": params.Offset,
		"limit":  params.Limit,
	})

}
