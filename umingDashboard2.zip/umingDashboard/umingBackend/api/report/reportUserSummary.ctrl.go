package report

import (
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"goGinBassinet/models"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

// RecordResult ,
type RecordResult struct {
	Account           string  `json:"account"`
	Name              string  `json:"name"`
	LiveSum           int64   `json:"liveSum"`
	LiveAvg           float64 `json:"liveAvg"`
	LoginFailCount    int     `json:"loginFailCount"`
	LoginSuccessCount int     `json:"loginSuccessCount"`
	LoginTime         int64   `json:"loginTime"`
	LogoutTime        int64   `json:"logoutTime"`
	StayTime          int64   `json:"stayTime"`
	LoginTimeString   string  `json:"loginTimeString"`
	LogoutTimeString  string  `json:"logoutTimeString"`
	StayTimeString    string  `json:"stayTimeString"`
	LoginIP           string  `json:"loginIp"`
}

func getUserSummaryReport(c *gin.Context) {
	type QueryParams struct {
		LastDays int    `form:"lastDays"`
		FromTS   int64  `form:"fromTs"`
		ToTS     int64  `form:"toTs"`
		UserName string `form:"userName"`
		UserID   string `form:"userId"`
	}

	userAccount := c.GetString("user_account")
	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	var params QueryParams
	if err := c.ShouldBindQuery(&params); err != nil {
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrWrongParameter))
		return
	}

	logger.Log.Info("user: " + userAccount)
	logger.Log.Info(params)

	db := database.DB
	var tx *gorm.DB = db.Table("user_live_records").
		Select("account, SUM(live_duration) as live_sum, AVG(live_duration) as live_avg, SUM(login_success) as login_success_count, SUM(login_fail) as login_fail_count")

	// handle account condition
	if params.UserID != "" {
		tx = tx.Where("account LIKE ?", "%"+params.UserID+"%")
	}

	// handle name condition
	if params.UserName != "" {
		tx = tx.Where("name LIKE ?", "%"+params.UserName+"%")
	}

	// handle time period condition, LastDays take precedence over FromTS and ToTS
	var beforeDaysTs int64 = 0
	if params.LastDays > 0 {
		beforeDays := time.Now().Add(time.Hour * 24 * time.Duration(params.LastDays) * -1)
		beforeDaysTs = beforeDays.Unix()
		tx = tx.Where("login_time >= ?", beforeDaysTs)

	} else if params.FromTS > 0 && params.ToTS > 0 {
		tx = tx.Where("login_time >= ?", params.FromTS).Where("login_time <= ?", params.ToTS)
	}

	var recordResults []RecordResult
	dbErr := tx.
		Group("account").
		Order("account ASC").
		Scan(&recordResults).Error

	if gorm.IsRecordNotFoundError(dbErr) {

	} else if dbErr != nil {
		logger.Log.Info(dbErr)
		c.Error(dbErr)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	var wg sync.WaitGroup
	for i := 0; i < len(recordResults); i++ {
		wg.Add(1)
		go workerFillLastRecord(&recordResults[i], beforeDaysTs, params.FromTS, params.ToTS, &wg)
	}
	wg.Wait()

	c.JSON(200, gin.H{
		"total": len(recordResults),
		"data":  recordResults,
	})
}

// workerFillLastRecord , goroutine
func workerFillLastRecord(recordResult *RecordResult, beforeDaysTs int64, fromTs int64, toTs int64, wg *sync.WaitGroup) {
	defer wg.Done()
	fillLastRecord(recordResult, beforeDaysTs, fromTs, toTs)
}

func fillLastRecord(recordResult *RecordResult, beforeDaysTs int64, fromTs int64, toTs int64) {
	var liveRecord models.UserLiveRecord
	db := database.DB

	var tx *gorm.DB
	if recordResult.LoginSuccessCount == 0 {
		tx = db.Where("account = ?", recordResult.Account)
	} else {
		tx = db.Where("account = ? AND login_success = 1", recordResult.Account)
	}

	if beforeDaysTs > 0 {
		tx = tx.Where("login_time >= ?", beforeDaysTs)
	} else if fromTs > 0 && toTs > 0 {
		tx = tx.Where("login_time >= ?", fromTs).Where("login_time <= ?", toTs)
	}

	dbErr := tx.Last(&liveRecord).Error

	if gorm.IsRecordNotFoundError(dbErr) {

	} else if dbErr != nil {
		logger.Log.Info(dbErr)
		return
	}

	recordResult.Name = liveRecord.Name
	recordResult.LoginIP = liveRecord.LoginIP
	recordResult.LoginTime = liveRecord.LoginTime
	recordResult.LoginTimeString = liveRecord.LoginTimeString
	recordResult.LogoutTime = liveRecord.LogoutTime
	recordResult.LogoutTimeString = liveRecord.LogoutTimeString
	recordResult.StayTime = liveRecord.StayTime
	recordResult.StayTimeString = liveRecord.StayTimeString
}
