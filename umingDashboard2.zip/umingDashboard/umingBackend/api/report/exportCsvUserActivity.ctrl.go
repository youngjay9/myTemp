package report

import (
	"bytes"
	"encoding/csv"
	"fmt"
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

func getUserActivityCsv(c *gin.Context) {
	// ActivityResult ,
	type ActivityResult struct {
		Account         string `json:"account"`
		Name            string `json:"name"`
		Category        string `json:"category"`
		LoginIP         string `json:"loginIp"`
		ClickTime       int64  `json:"clickTime"`
		StayTime        int64  `json:"stayTime"`
		ClickTimeString string `json:"clickTimeString"`
		StayTimeString  string `json:"stayTimeString"`
		LiveDuration    int64  `json:"liveDuration"`
	}

	type QueryParams struct {
		LastDays int    `form:"lastDays"`
		FromTS   int64  `form:"fromTs"`
		ToTS     int64  `form:"toTs"`
		UserName string `form:"userName"`
		UserID   string `form:"userId"`
		Category string `form:"category"`
		SortBy   string `form:"sortBy"`
		OrderBy  string `form:"orderBy"`
		Limit    int64  `form:"limit"`
		Offset   int64  `form:"offset"`
	}

	userAccount := c.GetString("user_account")
	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	var params QueryParams
	if err := c.ShouldBindQuery(&params); err != nil {
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrWrongParameter))
		return
	}

	logger.Log.Info("user: " + userAccount)
	logger.Log.Info(params)

	fromDate := time.Now()
	toDate := time.Now()

	if params.LastDays > 0 {
		nowDate := time.Now()
		toDate = nowDate
		fromDate = nowDate.Add(time.Duration(params.LastDays) * 24 * time.Hour * -1)
	} else if params.FromTS > 0 && params.ToTS > 0 {
		fromDate = time.Unix(params.FromTS, 0)
		toDate = time.Unix(params.ToTS, 0)
	}

	logger.Log.Info("Date From : ", fromDate)
	logger.Log.Info("Date To : ", toDate)

	db := database.DB
	var tx *gorm.DB = db.Table("user_activity_records")

	// handle account condition
	if params.UserID != "" {
		tx = tx.Where("account LIKE ?", "%"+params.UserID+"%")
	}

	// handle name condition
	if params.UserName != "" {
		tx = tx.Where("name LIKE ?", "%"+params.UserName+"%")
	}

	// handle category condition
	if params.Category != "" {
		tx = tx.Where("category = ?", params.Category)
	}

	tx = tx.Where("click_time >= ?", fromDate.Unix()).Where("click_time < ?", toDate.Unix())

	if params.OrderBy != "" && params.SortBy != "" {
		orderByStr := params.SortBy + " " + params.OrderBy + ", click_time DESC"
		tx = tx.Order(orderByStr)
	} else {
		tx = tx.Order("click_time DESC")
	}

	if params.Offset > 0 {
		tx = tx.Offset(params.Offset)
	}

	if params.Limit > 0 {
		tx = tx.Limit(params.Limit)
	} else {
		params.Limit = 1000
		tx = tx.Limit(params.Limit)
	}

	var activityResults []ActivityResult
	dbErr := tx.Find(&activityResults).Error

	if gorm.IsRecordNotFoundError(dbErr) {

	} else if dbErr != nil {
		logger.Log.Info(dbErr)
		c.Error(dbErr)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	var (
		dataBytes = new(bytes.Buffer)
	)

	headList := []string{"UserID", "User Name", "Last Click Time", "Last Stay Time", "Last Login IP", "Total Sesstion Length", "Function"}
	dataBytes.WriteString("\xEF\xBB\xBF") // UTF-8 BOM
	wr := csv.NewWriter(dataBytes)
	wr.Write(headList)
	loc := time.FixedZone("UTC-8", 8*60*60)
	for _, activity := range activityResults {
		clickTimeStr := ""
		if activity.ClickTime > 0 {
			clickTimeStr = time.Unix(activity.ClickTime, 0).In(loc).Format("2006-1-2 15:4:5")
		}
		stayTimeStr := ""
		if activity.StayTime > 0 {
			stayTimeStr = time.Unix(activity.StayTime, 0).In(loc).Format("2006-1-2 15:4:5")
		}
		durationTimeStr := ""
		if activity.LiveDuration > 0 {
			var hour int64 = activity.LiveDuration / 3600
			var minute int64 = ((activity.LiveDuration % 3600) / 60)
			var second int64 = ((activity.LiveDuration % 3600) % 60)
			if hour > 0 {
				durationTimeStr = fmt.Sprintf("%dh ", hour)
			}
			if minute > 0 {
				durationTimeStr = fmt.Sprintf("%s%dm ", durationTimeStr, minute)
			}
			if second > 0 {
				durationTimeStr = fmt.Sprintf("%s%ds ", durationTimeStr, second)
			}
		}

		bodyList := []string{
			activity.Account,
			activity.Name,
			clickTimeStr,
			stayTimeStr,
			activity.LoginIP,
			durationTimeStr,
			activity.Category,
		}
		wr.Write(bodyList)
	}
	wr.Flush()
	c.Writer.Header().Set("Content-type", "application/octet-stream")
	c.Writer.Header().Set("Content-Disposition", fmt.Sprintf("attachment;filename=%s", "user_activity_report.csv"))
	c.String(200, dataBytes.String())
}
