package api

import (
	"goGinBassinet/api/authorization"
	"goGinBassinet/api/chart"
	"goGinBassinet/api/monitor"
	"goGinBassinet/api/proxy"
	"goGinBassinet/api/report"
	"goGinBassinet/api/setting"
	"goGinBassinet/api/user"
	"goGinBassinet/middlewares"

	"github.com/gin-gonic/gin"
)

func ping(c *gin.Context) {
	c.JSON(200, gin.H{
		"message": "pong",
	})
}

// ApplyRoutes applies router to the gin Engine
func ApplyRoutes(r *gin.Engine) {

	/* ---------------------------  Load HTML template  --------------------------- */
	r.LoadHTMLFiles("./public/swagger.tmpl")

	/* ---------------------------  Public routes  --------------------------- */
	apiRoutePublic := r.Group("/api")
	{
		apiRoutePublic.GET("/ping", ping)
		apiRoutePublic.GET("/version", version)
		authorization.ApplyPublicRoutes(apiRoutePublic)
		proxy.ApplyRoutes(apiRoutePublic)
		user.ApplyPublicRoutes(apiRoutePublic)
		//swagger.ApplyPublicRoutes(apiRoutePublic)
		monitor.ApplyPublicRoutes(apiRoutePublic)
		report.ApplyPublicRoutes(apiRoutePublic)
		chart.ApplyPublicRoutes(apiRoutePublic)
		setting.ApplyPublicRoutes(apiRoutePublic)
	}

	/* ---------------------------  Private routes  --------------------------- */
	apiRoutePrivate := r.Group("/api")
	{
		apiRoutePrivate.Use(middlewares.JWTMiddleware())
		apiRoutePrivate.Use(middlewares.AuthCheck())
		authorization.ApplyPrivateRoutes(apiRoutePrivate)
		user.ApplyPrivateRoutes(apiRoutePrivate)
		//swagger.ApplyPrivateRoutes(apiRoutePrivate)
		monitor.ApplyPrivateRoutes(apiRoutePrivate)
		report.ApplyPrivateRoutes(apiRoutePrivate)
		chart.ApplyPrivateRoutes(apiRoutePrivate)
		setting.ApplyPrivateRoutes(apiRoutePrivate)
	}
}
