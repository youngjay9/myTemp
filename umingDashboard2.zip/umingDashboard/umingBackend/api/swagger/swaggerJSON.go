package swagger

func getSwaggerJSONString() string {

	swaggerJSON := `{
		"openapi": "3.0.0",
		"info": {
			"title": "裕民 dashboard backend API",
			"version": "1.0",
			"description": "Version : 1.0.14"
		},
		"servers": [
			{
				"url": "http://127.0.0.1:3000/api/"
			}
		],
		"paths": {
			"/login": {
				"post": {
					"summary": "登入 (測試用)",
					"operationId": "post-login",
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"success": {
											"value": {
												"data": {
													"account": "gogogo",
													"id": 1,
													"loginExpiredTime": 1597287074,
													"loginExpiredTimeString": "2020-08-13T10:51:14+08:00",
													"loginTime": 1597286774,
													"loginTimeString": "2020-08-13T10:46:14+08:00",
													"logoutTime": 0,
													"logoutTimeString": "",
													"name": "David",
													"role": "Normal",
													"shipPosition": "[\r\n  {\r\n    \"host_display_name\": \"HONOR_192.168.1.2\",\r\n    \"coordinate\": {\r\n      \"x\": -7,\r\n      \"y\": 7,\r\n      \"z\": 0\r\n    }\r\n  }\r\n]",
													"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1OTcyODcwNzQsInVzZXIiOnsiYWNjb3VudCI6ImdvZ29nbyIsIm5hbWUiOiJEYXZpZCIsInJvbGUiOiJOb3JtYWwifX0.JOSseCklMKcywZDEGO3w9VlURCUKB5n-PWA0C7uoIVk",
													"tokenExpiredTime": 0
												}
											}
										}
									}
								}
							}
						}
					},
					"requestBody": {
						"content": {
							"application/json": {
								"schema": {
									"type": "object",
									"properties": {}
								},
								"examples": {
									"Post Body": {
										"value": {
											"account": "gogogo",
											"password": "54321"
										}
									}
								}
							}
						},
						"description": ""
					},
					"description": "login,   for debug use if loginAD not work",
					"tags": [
						"Auth"
					]
				}
			},
			"/loginAd": {
				"post": {
					"summary": "登入",
					"operationId": "post-loginAd",
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": {
													"account": "fe1",
													"boatPosition": "",
													"id": 2,
													"name": "遠傳",
													"role": "Normal",
													"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1OTc2NTIzMDcsInVzZXIiOnsiYWNjb3VudCI6ImZlMSIsIm5hbWUiOiLpgaDlgrMiLCJyb2xlIjoiTm9ybWFsIn19.WbmcVx7eqC7efFcobtM1nbx6RENfWGM2hPASMYjP3ZE",
													"tokenExpiredTime": 1000
												}
											}
										}
									}
								}
							}
						}
					},
					"description": "login useing 裕民 AD account",
					"requestBody": {
						"content": {
							"application/json": {
								"schema": {
									"type": "object",
									"properties": {}
								},
								"examples": {
									"Post Body": {
										"value": {
											"account": "fe1",
											"password": "AAAAA"
										}
									}
								}
							}
						}
					},
					"tags": [
						"Auth"
					]
				}
			},
			"/user/me/shipPosition": {
				"get": {
					"summary": "取得主頁船的位置",
					"tags": [
						"User"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": [
													{
														"coordinate": {
															"x": -7,
															"y": 7,
															"z": 0
														},
														"host_display_name": "HONOR_192.168.1.2"
													}
												]
											}
										}
									}
								}
							}
						},
						"400": {
							"description": "Bad Request",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"E0009": {
											"value": {
												"status": 400,
												"errCode": "E0009",
												"errMsg": "User not found"
											}
										},
										"E0005": {
											"value": {
												"status": 400,
												"errCode": "E0005",
												"errMsg": "Database error"
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-user-me-boatPosition",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "header",
							"name": "Authorization",
							"description": "Bearer ${TOKEN}"
						}
					],
					"security": []
				},
				"post": {
					"summary": "儲存主頁船的位置",
					"operationId": "post-user-me-boatPosition",
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {}
										}
									}
								}
							}
						},
						"400": {
							"description": "Bad Request",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"E0009": {
											"value": {
												"status": 400,
												"errCode": "E0009",
												"errMsg": "User not found"
											}
										},
										"E0005": {
											"value": {
												"status": 400,
												"errCode": "E0005",
												"errMsg": "Database error"
											}
										}
									}
								}
							}
						}
					},
					"tags": [
						"User"
					],
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "header",
							"name": "Authorization",
							"description": "Bearer ${TOKEN}"
						}
					],
					"requestBody": {
						"content": {
							"application/json": {
								"schema": {
									"type": "object",
									"properties": {}
								},
								"examples": {
									"Post Body": {
										"value": {
											"data": [
												{
													"coordinate": {
														"x": -7,
														"y": 7,
														"z": 0
													},
													"host_display_name": "HONOR_192.168.1.2"
												}
											]
										}
									}
								}
							}
						}
					}
				},
				"parameters": []
			},
			"/logout": {
				"post": {
					"summary": "登出",
					"operationId": "post-logout",
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": {
													"account": "gogogo",
													"id": 1,
													"loginExpiredTime": 1597287074,
													"loginExpiredTimeString": "2020-08-13T10:51:14+08:00",
													"loginTime": 1597286774,
													"loginTimeString": "2020-08-13T10:46:14+08:00",
													"logoutTime": 1597286928,
													"logoutTimeString": "2020-08-13T10:48:48+08:00",
													"name": "David",
													"role": "Normal",
													"shipPosition": "[\r\n  {\r\n    \"host_display_name\": \"HONOR_192.168.1.2\",\r\n    \"coordinate\": {\r\n      \"x\": -7,\r\n      \"y\": 7,\r\n      \"z\": 0\r\n    }\r\n  }\r\n]",
													"token": "",
													"tokenExpiredTime": 0
												}
											}
										}
									}
								}
							}
						}
					},
					"tags": [
						"Auth"
					],
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "header",
							"name": "Authorization",
							"description": "Bearer ${TOKEN}"
						}
					]
				}
			},
			"/user/config": {
				"post": {
					"summary": "設定使用者 腳色 以及 token 時效",
					"operationId": "post-user-config",
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": {
													"account": "gogoro2",
													"id": 2,
													"loginExpiredTime": 0,
													"loginExpiredTimeString": "",
													"loginTime": 0,
													"loginTimeString": "",
													"logoutTime": 0,
													"logoutTimeString": "",
													"name": "",
													"role": "Admin",
													"tokenExpiredDuration": 3600
												}
											}
										}
									}
								}
							}
						},
						"400": {
							"description": "Bad Request",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"E0004": {
											"value": {
												"status": 400,
												"errCode": "E0004",
												"errMsg": "Wrong parameter"
											}
										}
									}
								}
							}
						}
					},
					"tags": [
						"User"
					],
					"requestBody": {
						"content": {
							"application/json": {
								"schema": {
									"type": "object",
									"properties": {}
								},
								"examples": {
									"全參數": {
										"value": {
											"account": "gogoro2",
											"role": "Admin",
											"tokenExpiredDuration": 3600
										}
									},
									"只修改 role": {
										"value": {
											"account": "gogoro2",
											"role": "Admin"
										}
									},
									"只修改 token  期效": {
										"value": {
											"account": "gogoro2",
											"tokenExpiredDuration": 3600
										}
									}
								}
							}
						}
					},
					"description": "### 1.不檢查帳號是否存在於 AD ，如果資料庫內無此帳號，會新增，如果有，會修改其設定\n\n### 2.參數定義如下\n\n- account (Must): AD 帳號\n- role (Optional) : 允許值為 \"Admin\" 或 \"Normal\"\n- tokenExpiredDuration (Optional) : Unit time format， 單位秒數，如果設為 0 時，此帳號的 token 有效期會使用 global default\n"
				}
			},
			"/version": {
				"get": {
					"summary": "取得 API 版本",
					"tags": [
						"Version"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"version": "1.0.1"
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-veersion"
				},
				"parameters": []
			},
			"/user": {
				"get": {
					"summary": "取得使用者資料清單",
					"tags": [
						"User"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": [
													{
														"account": "gogogo",
														"id": 1,
														"loginExpiredTime": 1597820157,
														"loginExpiredTimeString": "2020-08-19T14:55:57+08:00",
														"loginTime": 1597733757,
														"loginTimeString": "2020-08-18T14:55:57+08:00",
														"logoutTime": 0,
														"logoutTimeString": "",
														"name": "David",
														"role": "Normal",
														"tokenExpiredDuration": 0
													},
													{
														"account": "gogoro2",
														"id": 2,
														"loginExpiredTime": 0,
														"loginExpiredTimeString": "",
														"loginTime": 0,
														"loginTimeString": "",
														"logoutTime": 0,
														"logoutTimeString": "",
														"name": "",
														"role": "Admin",
														"tokenExpiredDuration": 3600
													}
												]
											}
										}
									}
								}
							}
						},
						"400": {
							"description": "Bad Request",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"E0005": {
											"value": {
												"status": 400,
												"errCode": "E0005",
												"errMsg": "Database error"
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-user",
					"description": "query parames 可以指定 role 來過濾不想要的，例如 ?role=Admin，若不設定 role ，預設撈取所有使用者",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "role",
							"description": "[\"Admin\" | \"Normal\"]"
						}
					]
				}
			},
			"/monitor/liveUser": {
				"get": {
					"summary": "取得目前已登入的使用者資料清單",
					"tags": [
						"Monitor"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": [
													{
														"account": "gogogo",
														"id": 1,
														"loginExpiredTime": 1597890770,
														"loginExpiredTimeString": "2020-08-20T10:32:50+08:00",
														"loginTime": 1597804370,
														"loginTimeString": "2020-08-19T10:32:50+08:00",
														"logoutTime": 0,
														"logoutTimeString": "",
														"name": "David",
														"role": "Normal",
														"tokenExpiredDuration": 0
													}
												]
											}
										}
									}
								}
							}
						},
						"400": {
							"description": "Bad Request",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"E00005": {
											"value": {
												"status": 400,
												"errCode": "E0005",
												"errMsg": "Database error"
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-monitor-liveUser"
				}
			},
			"/monitor/trackEvent": {
				"post": {
					"summary": "記錄使用者點擊頁面與存活事件",
					"operationId": "post-monitor-trackEvent",
					"responses": {
						"200": {
							"description": "OK"
						},
						"400": {
							"description": "Bad Request",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Wrong Parameter": {
											"value": {
												"status": 400,
												"errCode": "E0004",
												"errMsg": "Wrong parameter"
											}
										},
										"event logic conflict": {
											"value": {
												"status": 400,
												"errCode": "E0000",
												"errMsg": "User activity record not found in DB. Does client call trackEvent befor user click any page?"
											}
										}
									}
								}
							}
						}
					},
					"tags": [
						"Monitor"
					],
					"description": "## (1) 用法\n- 每次進頁面上傳點擊事件 (Top_View, Click)\n- 每 5 分鐘上傳存活事件，例如 (IDC_Vew_Detail, Live)\n\n## (2) 錯誤\n- 除了權限檢查失敗外，因為在事件上傳時就會做初步統計，事件邏輯錯誤也會回報，例如 Live event 比 Click event 更早出現，此種錯誤不影響統計，旨在協助 debug ，\n\n## (3) category 以下三種\n- Top_View\n- IDC_View_Detail \n- Boat_View_Detail\n\n## (4) action 以下兩種\n- Click\n- Live ",
					"requestBody": {
						"content": {
							"application/json": {
								"schema": {
									"type": "object",
									"properties": {}
								},
								"examples": {
									"click event": {
										"value": {
											"category": "Top_View",
											"action": "Click"
										}
									},
									"Live Event": {
										"value": {
											"category": "Top_View",
											"action": "Live"
										}
									}
								}
							}
						}
					}
				}
			},
			"/report/userSummary": {
				"get": {
					"summary": "取得使用者統計資料",
					"tags": [
						"Report"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": [
													{
														"account": "gogogo1",
														"name": "",
														"liveSum": 0,
														"liveAvg": 0,
														"loginFailCount": 1,
														"loginSuccessCount": 0,
														"loginTime": 1598866055,
														"logoutTime": 0,
														"stayTime": 0,
														"loginTimeString": "2020-08-31T17:27:35+08:00",
														"logoutTimeString": "",
														"stayTimeString": "",
														"loginIp": "::1"
													},
													{
														"account": "gogogo",
														"name": "Adrian Connelly",
														"liveSum": 354,
														"liveAvg": 118,
														"loginFailCount": 1,
														"loginSuccessCount": 6,
														"loginTime": 1598931578,
														"logoutTime": 0,
														"stayTime": 0,
														"loginTimeString": "2020-09-01T11:39:38+08:00",
														"logoutTimeString": "",
														"stayTimeString": "",
														"loginIp": "::1"
													},
													{
														"account": "gogogo3",
														"name": "David",
														"liveSum": 44,
														"liveAvg": 44,
														"loginFailCount": 0,
														"loginSuccessCount": 1,
														"loginTime": 1598866430,
														"logoutTime": 1598866474,
														"stayTime": 0,
														"loginTimeString": "2020-08-31T17:33:50+08:00",
														"logoutTimeString": "2020-08-31T17:34:34+08:00",
														"stayTimeString": "",
														"loginIp": "::1"
													},
													{
														"account": "gogogo2",
														"name": "David",
														"liveSum": 55,
														"liveAvg": 55,
														"loginFailCount": 0,
														"loginSuccessCount": 1,
														"loginTime": 1598866508,
														"logoutTime": 0,
														"stayTime": 1598866563,
														"loginTimeString": "2020-08-31T17:35:08+08:00",
														"logoutTimeString": "",
														"stayTimeString": "2020-08-31T17:36:03+08:00",
														"loginIp": "::1"
													}
												],
												"total": 4
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-report-userSummary",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userId",
							"description": "使用者帳號"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userName",
							"description": "使用者名稱"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "lastDays",
							"description": "最近幾天內的資料(單位:天)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "fromTs",
							"description": "起始時間 Unix Time(單位:秒)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "toTs",
							"description": "結束時間Unix Time(單位: 秒)"
						}
					],
					"description": "# (1) 所有參數皆為 Optional ，時間參數若沒有基本會查無資料\n\n- userId, userName 會用模糊比對 (LIKE)\n- lastDays 指過去幾天，24 hours 就給 1\n- lastDays 和 (fromTs, toTs) 都代表時間區間，若都有值，優先採用 lastDays\n- fromTs, toTs，格式為 Unix Time，單位:秒，例如 1598866054 "
				}
			},
			"/chart/userCountEachHoursOrDays": {
				"get": {
					"summary": "圖表: 每小時或每日的系統使用人數",
					"tags": [
						"Chart"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": [
													{
														"count": 0,
														"fromTime": 1598716800,
														"toTime": 1598803200,
														"fromTimeString": "2020-08-30 00:00:00 +0800 CST",
														"toTimeString": "2020-08-31 00:00:00 +0800 CST"
													},
													{
														"count": 4,
														"fromTime": 1598803200,
														"toTime": 1598889600,
														"fromTimeString": "2020-08-31 00:00:00 +0800 CST",
														"toTimeString": "2020-09-01 00:00:00 +0800 CST"
													},
													{
														"count": 1,
														"fromTime": 1598889600,
														"toTime": 1598976000,
														"fromTimeString": "2020-09-01 00:00:00 +0800 CST",
														"toTimeString": "2020-09-02 00:00:00 +0800 CST"
													},
													{
														"count": 1,
														"fromTime": 1598976000,
														"toTime": 1599062400,
														"fromTimeString": "2020-09-02 00:00:00 +0800 CST",
														"toTimeString": "2020-09-03 00:00:00 +0800 CST"
													}
												],
												"total": 4
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-chart-userCountEachHoursOrDays",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userId",
							"description": "使用者帳號"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userName",
							"description": "使用者名稱"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "lastDays",
							"description": "最近幾天內的資料(單位:天)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "fromTs",
							"description": "起始時間 Unix Time(單位:秒)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "toTs",
							"description": "結束時間Unix Time(單位: 秒)"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "unit",
							"description": "時間區間單位，允許值為 Hour, Day",
							"required": true
						}
					],
					"description": "- userId, userName 會用模糊比對 (LIKE)\n- lastDays 指過去幾天，24 hours 就給 1\n- lastDays 和 (fromTs, toTs) 都代表時間區間，若都有值，優先採用 lastDays\n- fromTs, toTs，格式為 Unix Time，單位:秒，例如 1598866054 \n- Unit (Must): 單位，允許值為 Hour, Day"
				}
			},
			"/chart/usageCountEachAccount": {
				"get": {
					"summary": "圖表: 每個帳號總使用次數",
					"tags": [
						"Chart"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": [
													{
														"account": "gogogo",
														"count": 7
													},
													{
														"account": "gogogo3",
														"count": 1
													},
													{
														"account": "gogogo2",
														"count": 1
													}
												],
												"total": 3
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-chart-usage",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userId",
							"description": "使用者帳號"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userName",
							"description": "使用者名稱"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "lastDays",
							"description": "最近幾天內的資料(單位:天)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "fromTs",
							"description": "起始時間 Unix Time(單位:秒)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "toTs",
							"description": "結束時間Unix Time(單位: 秒)"
						}
					],
					"description": "- userId, userName 會用模糊比對 (LIKE)\n- lastDays 指過去幾天，24 hours 就給 1\n- lastDays 和 (fromTs, toTs) 都代表時間區間，若都有值，優先採用 lastDays\n- fromTs, toTs，格式為 Unix Time，單位:秒，例如 1598866054 "
				},
				"parameters": []
			},
			"/chart/liveAverageEachAccount": {
				"get": {
					"summary": "圖表: 每個帳號平均使用時間(秒數)",
					"tags": [
						"Chart"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": [
													{
														"account": "gogogo",
														"average": 2750.75
													},
													{
														"account": "gogogo3",
														"average": 44
													},
													{
														"account": "gogogo2",
														"average": 75645
													}
												],
												"total": 3
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-chart-liveAverageEachAccount",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userId",
							"description": "使用者帳號"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userName",
							"description": "使用者名稱"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "lastDays",
							"description": "最近幾天內的資料(單位:天)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "fromTs",
							"description": "起始時間 Unix Time(單位:秒)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "toTs",
							"description": "結束時間Unix Time(單位: 秒)"
						}
					],
					"description": "- userId, userName 會用模糊比對 (LIKE)\n- lastDays 指過去幾天，24 hours 就給 1\n- lastDays 和 (fromTs, toTs) 都代表時間區間，若都有值，優先採用 lastDays\n- fromTs, toTs，格式為 Unix Time，單位:秒，例如 1598866054 "
				}
			},
			"/report/userActivity": {
				"get": {
					"summary": "取得使用者活動紀錄(三個功能)",
					"tags": [
						"Report"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": [
													{
														"account": "gogogo2",
														"name": "Tessie Hirthe",
														"role": "Normal",
														"category": "IDC_View_Detail",
														"action": "Click",
														"loginIp": "::1",
														"clickTime": 1599633968,
														"stayTime": 0,
														"clickTimeString": "2020-09-09T14:46:08+08:00",
														"stayTimeString": "",
														"liveDuration": 2
													},
													{
														"account": "gogogo2",
														"name": "Tessie Hirthe",
														"role": "Normal",
														"category": "IDC_View_Detail",
														"action": "Click",
														"loginIp": "::1",
														"clickTime": 1599633750,
														"stayTime": 0,
														"clickTimeString": "2020-09-09T14:42:30+08:00",
														"stayTimeString": "",
														"liveDuration": 40
													},
													{
														"account": "gogogo2",
														"name": "Tessie Hirthe",
														"role": "Normal",
														"category": "Top_View",
														"action": "Click",
														"loginIp": "::1",
														"clickTime": 1599633735,
														"stayTime": 0,
														"clickTimeString": "2020-09-09T14:42:15+08:00",
														"stayTimeString": "",
														"liveDuration": 45
													}
												],
												"limit": 3,
												"offset": 0,
												"total": 6
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-report-userActivity",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userId",
							"description": "使用者帳號"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userName",
							"description": "使用者名稱"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "lastDays",
							"description": "最近幾天內的資料(單位:天)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "fromTs",
							"description": "起始時間 Unix Time(單位:秒)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "toTs",
							"description": "結束時間Unix Time(單位: 秒)"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "category",
							"description": "function的分類，允許值為 Top_View, IDC_View_Detail, Boat_View_Detail"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "limit",
							"description": "最多撈取幾筆"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "offset",
							"description": "從第幾筆開始撈取"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "sortBy",
							"description": "用哪個欄位排序，[ account | name | click_time | live_duration | category]"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "orderBy",
							"description": "降冪或升冪排序，[ asc | desc ]"
						}
					],
					"description": "# (1) 所有參數皆為 Optional ，時間參數若沒有基本會查無資料\n\n- userId, userName 會用模糊比對 (LIKE)\n- lastDays 指過去幾天，24 hours 就給 1\n- lastDays 和 (fromTs, toTs) 都代表時間區間，若都有值，優先採用 lastDays\n- fromTs, toTs，格式為 Unix Time，單位:秒，例如 1598866054 \n- category, 允許值為 Top_View, IDC_View_Detail, Boat_View_Detail\n- limit, 最多撈幾筆，預設 1000\n- offset, 從哪個位置開始撈取\n- sortBy, 依據哪個欄位做排序，需與 orderBy ，可使用的值為 [ account | name | click_time | live_duration | category]，搭配，預設是 click_time desc\n- orderBy, 可使用的值為 [ asc | desc ]"
				}
			},
			"/chart/timeCategoryEachAccount": {
				"get": {
					"summary": "圖表: 每個帳號使用那些功能與多少時間(秒數)",
					"tags": [
						"Chart"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": [
													{
														"account": "gogogo",
														"categories": [
															{
																"category": "Boat_View_Detail",
																"total": 27,
																"average": 27
															},
															{
																"category": "IDC_View_Detail",
																"total": 12,
																"average": 12
															}
														]
													},
													{
														"account": "gogogo2",
														"categories": [
															{
																"category": "Boat_View_Detail",
																"total": 22,
																"average": 11
															},
															{
																"category": "IDC_View_Detail",
																"total": 37,
																"average": 37
															},
															{
																"category": "Top_View",
																"total": 75609,
																"average": 37804.5
															}
														]
													},
													{
														"account": "gogogo3",
														"categories": [
															{
																"category": "Top_View",
																"total": 14,
																"average": 14
															}
														]
													}
												],
												"total": 3
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-chart-timeCategoryEachAccount",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userId",
							"description": "使用者帳號"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userName",
							"description": "使用者名稱"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "lastDays",
							"description": "最近幾天內的資料(單位:天)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "fromTs",
							"description": "起始時間 Unix Time(單位:秒)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "toTs",
							"description": "結束時間Unix Time(單位: 秒)"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "category",
							"description": "function的分類，允許值為 Top_View, IDC_View_Detail, Boat_View_Detail"
						}
					],
					"description": "- userId, userName 會用模糊比對 (LIKE)\n- lastDays 指過去幾天，24 hours 就給 1\n- lastDays 和 (fromTs, toTs) 都代表時間區間，若都有值，優先採用 lastDays\n- fromTs, toTs，格式為 Unix Time，單位:秒，例如 1598866054 \n- category, 允許值為 Top_View, IDC_View_Detail, Boat_View_Detail"
				}
			},
			"/chart/usageEachCategory": {
				"get": {
					"summary": "圖表: 每個功能被使用的總次數與總時間(秒數)",
					"tags": [
						"Chart"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": [
													{
														"category": "Boat_View_Detail",
														"total": 49,
														"count": 3
													},
													{
														"category": "IDC_View_Detail",
														"total": 49,
														"count": 2
													},
													{
														"category": "Top_View",
														"total": 75623,
														"count": 8
													}
												],
												"total": 3
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-chart-usageEachCategory",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userId",
							"description": "使用者帳號"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userName",
							"description": "使用者名稱"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "lastDays",
							"description": "最近幾天內的資料(單位:天)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "fromTs",
							"description": "起始時間 Unix Time(單位:秒)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "toTs",
							"description": "結束時間Unix Time(單位: 秒)"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "category",
							"description": "function的分類，允許值為 Top_View, IDC_View_Detail, Boat_View_Detail"
						}
					],
					"description": "- userId, userName 會用模糊比對 (LIKE)\n- lastDays 指過去幾天，24 hours 就給 1\n- lastDays 和 (fromTs, toTs) 都代表時間區間，若都有值，優先採用 lastDays\n- fromTs, toTs，格式為 Unix Time，單位:秒，例如 1598866054 \n- category, 允許值為 Top_View, IDC_View_Detail, Boat_View_Detail"
				}
			},
			"/report/exportCsvUserSummary": {
				"get": {
					"summary": "匯出(CSV)使用者統計資料",
					"tags": [
						"Report"
					],
					"responses": {
						"200": {
							"description": "OK",
							"headers": {
								"Content-Type": {
									"schema": {
										"type": "string"
									},
									"description": "application/octet-stream"
								},
								"Content-Disposition": {
									"schema": {
										"type": "string"
									},
									"description": "attachment;filename=user_summary_report.csv"
								}
							},
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"CSV file": {}
									}
								}
							}
						}
					},
					"operationId": "get-report-exportCsvUserSummary",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userId",
							"description": "使用者帳號"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userName",
							"description": "使用者名稱"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "lastDays",
							"description": "最近幾天內的資料(單位:天)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "fromTs",
							"description": "起始時間 Unix Time(單位:秒)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "toTs",
							"description": "結束時間Unix Time(單位: 秒)"
						}
					],
					"description": "# (1) 所有參數皆為 Optional ，時間參數若沒有基本會查無資料\n\n- userId, userName 會用模糊比對 (LIKE)\n- lastDays 指過去幾天，24 hours 就給 1\n- lastDays 和 (fromTs, toTs) 都代表時間區間，若都有值，優先採用 lastDays\n- fromTs, toTs，格式為 Unix Time，單位:秒，例如 1598866054 \n\n# (2) 回傳 csv format file binary"
				}
			},
			"/report/exportCsvUserActivity": {
				"get": {
					"summary": "Your GET endpoint",
					"tags": [],
					"responses": {
						"200": {
							"description": "OK",
							"headers": {
								"Content-Type": {
									"schema": {
										"type": "string"
									},
									"description": "application/octet-stream"
								},
								"Content-Disposition": {
									"schema": {
										"type": "string"
									},
									"description": "attachment;filename=user_activity_report.csv"
								}
							},
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"CSV file": {}
									}
								}
							}
						}
					},
					"operationId": "get-report-exportCsvUserActivity",
					"parameters": [
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userId",
							"description": "使用者帳號"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "userName",
							"description": "使用者名稱"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "lastDays",
							"description": "最近幾天內的資料(單位:天)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "fromTs",
							"description": "起始時間 Unix Time(單位:秒)"
						},
						{
							"schema": {
								"type": "number"
							},
							"in": "query",
							"name": "toTs",
							"description": "結束時間Unix Time(單位: 秒)"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "category",
							"description": "function的分類，允許值為 Top_View, IDC_View_Detail, Boat_View_Detail"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "limit",
							"description": "最多撈取幾筆"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "offset",
							"description": "從第幾筆開始撈取"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "sortBy",
							"description": "用哪個欄位排序，[ account | name | click_time | live_duration | category]"
						},
						{
							"schema": {
								"type": "string"
							},
							"in": "query",
							"name": "orderBy",
							"description": "降冪或升冪排序，[ asc | desc ]"
						}
					],
					"description": "# (1) 所有參數皆為 Optional ，時間參數若沒有基本會查無資料\n\n- userId, userName 會用模糊比對 (LIKE)\n- lastDays 指過去幾天，24 hours 就給 1\n- lastDays 和 (fromTs, toTs) 都代表時間區間，若都有值，優先採用 lastDays\n- fromTs, toTs，格式為 Unix Time，單位:秒，例如 1598866054 \n- category, 允許值為 Top_View, IDC_View_Detail, Boat_View_Detail\n- limit, 最多撈幾筆，預設 1000\n- offset, 從哪個位置開始撈取\n- sortBy, 依據哪個欄位做排序，需與 orderBy ，可使用的值為 [ account | name | click_time | live_duration | category]，搭配，預設是 click_time desc\n- orderBy, 可使用的值為 [ asc | desc ]\n\n# (2) 回傳 csv format file binary"
				}
			},
			"/setting/globalConfig": {
				"get": {
					"summary": "取得 global config (ex, help page content)",
					"tags": [
						"Setting"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": {
													"ID": 1,
													"CreatedAt": "2020-09-11T11:27:16+08:00",
													"UpdatedAt": "2020-09-11T11:27:28+08:00",
													"DeletedAt": null,
													"type": "GlobalSetting",
													"tokenExpiredDuration": 86400,
													"helpPageDescriptionRed": "ip <br> ip2",
													"helpPageDescriptionGreen": "ip3 <br> ip4",
													"helpPageDescriptionYellow": "ip5 <br> ip6"
												}
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-setting-globalConfig",
					"description": ""
				},
				"put": {
					"summary": "修改 global config (ex, help page content)",
					"operationId": "put-setting-globalConfig",
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {
												"data": {
													"ID": 1,
													"CreatedAt": "2020-09-11T11:27:16+08:00",
													"UpdatedAt": "2020-09-11T11:27:28.0242899+08:00",
													"DeletedAt": null,
													"type": "GlobalSetting",
													"tokenExpiredDuration": 86400,
													"helpPageDescriptionRed": "ip <br> ip2",
													"helpPageDescriptionGreen": "ip3 <br> ip4",
													"helpPageDescriptionYellow": "ip5 <br> ip6"
												}
											}
										}
									}
								}
							}
						}
					},
					"requestBody": {
						"content": {
							"application/json": {
								"schema": {
									"type": "object",
									"properties": {}
								},
								"examples": {
									"Put Body": {
										"value": {
											"helpPageDescriptionRed": "ip <br> ip2",
											"helpPageDescriptionGreen": "ip3 <br> ip4",
											"helpPageDescriptionYellow": "ip5 <br> ip6"
										}
									}
								}
							}
						}
					},
					"tags": [
						"Setting"
					]
				}
			},
			"/setting/globalShipPosition": {
				"get": {
					"summary": "取得主頁船的位置 (global setting)",
					"tags": [
						"Setting"
					],
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"success": {
											"value": {
												"data": [
													{
														"coordinate": {
															"x": -7,
															"y": 7,
															"z": 0
														},
														"host_display_name": "HONOR_192.168.1.2"
													}
												]
											}
										}
									}
								}
							}
						}
					},
					"operationId": "get-setting-globalShipPosition"
				},
				"put": {
					"summary": "儲存主頁船的位置 (global setting)",
					"operationId": "put-setting-globalShipPosition",
					"responses": {
						"200": {
							"description": "OK"
						}
					},
					"tags": [
						"Setting"
					],
					"requestBody": {
						"content": {
							"application/json": {
								"schema": {
									"type": "object",
									"properties": {}
								},
								"examples": {
									"put body": {
										"value": {
											"data": [
												{
													"coordinate": {
														"x": -7,
														"y": 7,
														"z": 0
													},
													"host_display_name": "HONOR_192.168.1.2"
												}
											]
										}
									}
								}
							}
						}
					}
				}
			},
			"/user/{userId}": {
				"parameters": [
					{
						"schema": {
							"type": "string"
						},
						"name": "userId",
						"in": "path",
						"required": true
					}
				],
				"delete": {
					"summary": "刪除使用者",
					"operationId": "delete-user-userId",
					"responses": {
						"200": {
							"description": "OK",
							"content": {
								"application/json": {
									"schema": {
										"type": "object",
										"properties": {}
									},
									"examples": {
										"Success": {
											"value": {}
										}
									}
								}
							}
						}
					},
					"tags": [
						"User"
					]
				}
			}
		},
		"components": {
			"schemas": {},
			"securitySchemes": {}
		}
	}`

	return swaggerJSON

}
