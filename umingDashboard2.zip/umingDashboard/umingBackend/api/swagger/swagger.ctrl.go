package swagger

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// getSwaggerHTML , get swagger html
func getSwaggerHTML(c *gin.Context) {

	jsonStr := getSwaggerJSONString()

	c.HTML(http.StatusOK, "swagger.tmpl", gin.H{
		"specJson": jsonStr,
	})
}
