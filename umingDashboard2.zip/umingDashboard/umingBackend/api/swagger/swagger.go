package swagger

import (
	"os"

	"github.com/gin-gonic/gin"
)

// ApplyPublicRoutes applies router to the gin Engine
func ApplyPublicRoutes(r *gin.RouterGroup) {
	if os.Getenv("SWAGGER_DOC") == "YES" {
		//r.GET("/swagger", getSwaggerHTML)
	}
}

// ApplyPrivateRoutes applies router to the gin Engine
func ApplyPrivateRoutes(r *gin.RouterGroup) {

}
