package chart

import (
	"github.com/gin-gonic/gin"
)

// ApplyPublicRoutes applies router to the gin Engine
func ApplyPublicRoutes(r *gin.RouterGroup) {

}

// ApplyPrivateRoutes applies router to the gin Engine
func ApplyPrivateRoutes(r *gin.RouterGroup) {
	r.GET("/chart/userCountEachHoursOrDays", getUserCountEachHoursOrDays)
	r.GET("/chart/usageCountEachAccount", getUsageCountEachAccount)
	r.GET("/chart/liveAverageEachAccount", getLiveAverageEachAccount)
	r.GET("/chart/timeCategoryEachAccount", getTimeCategoryEachAccount)
	r.GET("/chart/usageEachCategory", getUsageEachCategory)
}
