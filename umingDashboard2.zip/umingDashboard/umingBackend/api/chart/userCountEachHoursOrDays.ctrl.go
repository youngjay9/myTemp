package chart

import (
	"fmt"
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"sort"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

// CountResult ,
type CountResult struct {
	Count          int64  `json:"count"`
	FromTime       int64  `json:"fromTime"`
	ToTime         int64  `json:"toTime"`
	FromTimeString string `json:"fromTimeString"`
	ToTimeString   string `json:"toTimeString"`
}

// CountResults ,
type CountResults []CountResult

//Len()
func (s CountResults) Len() int {
	return len(s)
}

//Less(): 時間
func (s CountResults) Less(i, j int) bool {
	return s[i].FromTime < s[j].FromTime
}

//Swap()
func (s CountResults) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}

func getUserCountEachHoursOrDays(c *gin.Context) {
	type QueryParams struct {
		LastDays int    `form:"lastDays"`
		FromTS   int64  `form:"fromTs"`
		ToTS     int64  `form:"toTs"`
		UserName string `form:"userName"`
		UserID   string `form:"userId"`
		Unit     string `form:"unit" binding:"required,oneof=Hour Day"`
	}

	userAccount := c.GetString("user_account")
	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	var params QueryParams
	if err := c.ShouldBindQuery(&params); err != nil {
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrWrongParameter))
		return
	}

	logger.Log.Info("user: " + userAccount)
	logger.Log.Info(params)

	fromDate := time.Now()
	toDate := time.Now()

	if params.LastDays > 0 {
		nowDate := time.Now()
		toDate = nowDate
		fromDate = nowDate.Add(time.Duration(params.LastDays) * 24 * time.Hour * -1)
	} else if params.FromTS > 0 && params.ToTS > 0 {
		fromDate = time.Unix(params.FromTS, 0)
		toDate = time.Unix(params.ToTS, 0)
	}

	logger.Log.Info("Date From : ", fromDate)
	logger.Log.Info("Date To : ", toDate)

	var countResults CountResults

	if params.Unit == "Hour" {
		currentHour := toDate.Round(time.Hour)

		logger.Log.Info("current hour : ", currentHour)

		currentHourTs := currentHour.Unix()
		index := 1

		for currentHour.Unix() > fromDate.Unix() {
			previousHour := currentHour.Add(time.Hour * -1)
			previousHourTs := previousHour.Unix()
			fmt.Printf("--- %d ----\n", index)
			fmt.Printf("%s  ===>  %s  ||  %d  ===>  %d\n", previousHour, currentHour, previousHourTs, currentHourTs)
			countResults = append(countResults, CountResult{
				Count:          0,
				FromTime:       previousHourTs,
				ToTime:         currentHourTs,
				FromTimeString: previousHour.String(),
				ToTimeString:   currentHour.String(),
			})
			currentHour = previousHour
			currentHourTs = previousHourTs
			index++
		}
	} else if params.Unit == "Day" {
		currentDay := getBeginOfDay(toDate).Add(time.Hour * 24)
		logger.Log.Info("current day : ", currentDay)

		currentDayTs := currentDay.Unix()
		index := 1
		for currentDay.Unix() > fromDate.Unix() {
			previousDay := currentDay.Add(time.Hour * 24 * -1)
			previousDayTs := previousDay.Unix()
			fmt.Printf("--- %d ----\n", index)
			fmt.Printf("%s  ===>  %s  ||  %d  ===>  %d\n", previousDay, currentDay, previousDayTs, currentDayTs)
			countResults = append(countResults, CountResult{
				Count:          0,
				FromTime:       previousDayTs,
				ToTime:         currentDayTs,
				FromTimeString: previousDay.String(),
				ToTimeString:   currentDay.String(),
			})
			currentDay = previousDay
			currentDayTs = previousDayTs
			index++
		}

	}

	sort.Sort(countResults)

	var wg sync.WaitGroup
	for i := 0; i < len(countResults); i++ {
		wg.Add(1)
		go workerFillCountResult(&countResults[i], params.UserID, params.UserName, &wg)
	}
	wg.Wait()

	c.JSON(200, gin.H{
		"data":  countResults,
		"total": len(countResults),
	})

}

func getBeginOfDay(t time.Time) time.Time {
	loc := time.FixedZone("CST", 8*60*60)
	year, month, day := t.Date()
	return time.Date(year, month, day, 0, 0, 0, 0, loc)
}

// workerFillLastRecord , go
func workerFillCountResult(result *CountResult, account string, name string, wg *sync.WaitGroup) {
	defer wg.Done()
	fillCountResult(result, account, name)
}

func fillCountResult(result *CountResult, account string, name string) {
	db := database.DB
	var tx *gorm.DB = db.Table("user_live_records").
		Select("COUNT(distinct(account))")

	if account != "" {
		tx = tx.Where("account LIKE ?", "%"+account+"%")
	}

	if name != "" {
		tx = tx.Where("name LIKE ?", "%"+name+"%")
	}

	tx = tx.Where("login_time >= ?", result.FromTime).Where("login_time < ?", result.ToTime)

	var count int64
	dbErr := tx.Count(&count).Error

	if gorm.IsRecordNotFoundError(dbErr) {

	} else if dbErr != nil {
		logger.Log.Info(dbErr)
		return
	}

	result.Count = count
}
