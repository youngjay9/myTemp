package chart

import (
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

func getTimeCategoryEachAccount(c *gin.Context) {
	type QueryParams struct {
		LastDays int    `form:"lastDays"`
		FromTS   int64  `form:"fromTs"`
		ToTS     int64  `form:"toTs"`
		UserName string `form:"userName"`
		UserID   string `form:"userId"`
		Category string `form:"category"`
	}

	userAccount := c.GetString("user_account")
	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	var params QueryParams
	if err := c.ShouldBindQuery(&params); err != nil {
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrWrongParameter))
		return
	}

	logger.Log.Info("user: " + userAccount)
	logger.Log.Info(params)

	fromDate := time.Now()
	toDate := time.Now()

	if params.LastDays > 0 {
		nowDate := time.Now()
		toDate = nowDate
		fromDate = nowDate.Add(time.Duration(params.LastDays) * 24 * time.Hour * -1)
	} else if params.FromTS > 0 && params.ToTS > 0 {
		fromDate = time.Unix(params.FromTS, 0)
		toDate = time.Unix(params.ToTS, 0)
	}

	logger.Log.Info("Date From : ", fromDate)
	logger.Log.Info("Date To : ", toDate)

	db := database.DB
	var tx *gorm.DB = db.Table("user_activity_records").
		Select("account, category, SUM(live_duration) as total, AVG(live_duration) as average")

	tx = tx.Where("live_duration > 0")

	if params.UserID != "" {
		tx = tx.Where("account LIKE ?", "%"+params.UserID+"%")
	}

	if params.UserName != "" {
		tx = tx.Where("name LIKE ?", "%"+params.UserName+"%")
	}

	if params.Category != "" {
		tx = tx.Where("category = ?", params.Category)
	}

	tx = tx.Where("click_time >= ?", fromDate.Unix()).Where("click_time < ?", toDate.Unix())

	type DbActivityResult struct {
		Account  string  `json:"account"`
		Category string  `json:"category"`
		Total    int64   `json:"total"`
		Average  float64 `json:"average"`
	}

	var activityResults []DbActivityResult
	dbErr := tx.
		Group("account, category").
		Order("account, category ASC").
		Scan(&activityResults).Error

	if gorm.IsRecordNotFoundError(dbErr) {

	} else if dbErr != nil {
		logger.Log.Info(dbErr)
		c.Error(dbErr)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	type TimeCategory struct {
		Category string  `json:"category"`
		Total    int64   `json:"total"`
		Average  float64 `json:"average"`
	}

	type TimeCategoryResult struct {
		Account    string         `json:"account"`
		Categories []TimeCategory `json:"categories"`
	}

	var results []TimeCategoryResult
	recordAccount := ""
	for _, record := range activityResults {
		if recordAccount != record.Account {
			results = append(results, TimeCategoryResult{
				Account: record.Account,
			})
			recordAccount = record.Account
		}

		results[len(results)-1].Categories = append(results[len(results)-1].Categories, TimeCategory{
			Category: record.Category,
			Total:    record.Total,
			Average:  record.Average,
		})
	}

	c.JSON(200, gin.H{
		"data":  results,
		"total": len(results),
	})

}
