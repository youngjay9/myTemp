package user

import (
	"encoding/json"
	"goGinBassinet/database"
	"goGinBassinet/httperror"
	"goGinBassinet/logger"
	"goGinBassinet/models"
	"io/ioutil"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

// postShipPosition , save user's ship position
func postMeShipPosition(c *gin.Context) {
	userAccount := c.GetString("user_account")

	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	logger.Log.Info("user : " + userAccount)
	body, _ := ioutil.ReadAll(c.Request.Body)
	bodyStr := string(body)
	logger.Log.Info(bodyStr)

	var user models.User
	db := database.DB
	err := db.Set("gorm:auto_preload", true).Where("account = ?", userAccount).First(&user).Error

	if gorm.IsRecordNotFoundError(err) {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrUserNotFound))
		return
	} else if err != nil {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	user.ShipPosition = bodyStr

	db.Save(&user)

	c.JSON(200, gin.H{})
}

// getShiptPosition , load
func getMeShipPosition(c *gin.Context) {
	userAccount := c.GetString("user_account")

	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	logger.Log.Info("user : " + userAccount)

	var user models.User
	db := database.DB
	err := db.Set("gorm:auto_preload", true).Where("account = ?", userAccount).First(&user).Error

	if gorm.IsRecordNotFoundError(err) {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrUserNotFound))
		return
	} else if err != nil {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	shipPosition := user.ShipPosition
	if shipPosition == "" {
		var globalConfig models.GlobalConfig
		if err := db.Where("type = ?", models.GlobalSettingType).First(&globalConfig).Error; err == nil {

			if globalConfig.ShipPosition == "" {
				c.JSON(200, gin.H{})
				return
			} else {
				shipPosition = globalConfig.ShipPosition
			}
		} else {
			logger.Log.Info(err)
			c.Error(err)
			c.JSON(httperror.ErrorMessage(httperror.ErrDataNotFound))
		}
	}

	// var bytePosition []byte = []byte(user.ShipPosition)
	// mapPosition := make([]interface{}, len(user.ShipPosition))
	// json.Unmarshal(bytePosition, &mapPosition)

	var bytePosition []byte = []byte(shipPosition)
	//var mapPosition map[string]interface{}
	var mapPosition interface{}
	json.Unmarshal(bytePosition, &mapPosition)

	c.JSON(200, mapPosition)

	// c.JSON(200, gin.H{
	// 	"data": mapPosition,
	// })
}

// postUserConfig , config
func postUserConfig(c *gin.Context) {
	userAccount := c.GetString("user_account")
	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	type UserConfig struct {
		Account              string `json:"account" binding:"required"`
		Role                 string `json:"role"`
		TokenExpiredDuration int64  `json:"tokenExpiredDuration" default:"-1"`
	}

	var userConfig UserConfig
	if err := c.ShouldBindJSON(&userConfig); err != nil {
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrWrongParameter))
		return
	}

	logger.Log.Info("user : " + userAccount)
	logger.Log.Info(userConfig)

	// Role must be Admin or Normal
	if userConfig.Role != "" && !(userConfig.Role == "Admin" || userConfig.Role == "Normal") {
		c.JSON(httperror.ErrorMessage(httperror.ErrWrongParameter))
		return
	}

	var user models.User
	db := database.DB
	err := db.Set("gorm:auto_preload", true).Where("account = ?", userConfig.Account).First(&user).Error

	if gorm.IsRecordNotFoundError(err) {
		user.InitValue(map[string]interface{}{
			"account":              userConfig.Account,
			"token":                "",
			"name":                 "",
			"role":                 "Normal",
			"tokenExpiredDuration": int64(0),
		})
	} else if err != nil {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	if userConfig.Role != "" {
		user.Role = userConfig.Role
	}
	if userConfig.TokenExpiredDuration != -1 {
		user.TokenExpiredDuration = userConfig.TokenExpiredDuration
	}

	db.Save(&user)

	c.JSON(200, gin.H{
		"data": user.SerializeHideToken(),
	})
}

// getUserInfoList
func getUserInfoList(c *gin.Context) {
	userAccount := c.GetString("user_account")
	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	role := c.Query("role")

	var users []models.User
	db := database.DB

	var err error = nil

	if role == "" {
		err = db.Set("gorm:auto_preload", true).Find(&users).Error
	} else {
		err = db.Set("gorm:auto_preload", true).Where("role = ?", role).Find(&users).Error
	}

	if gorm.IsRecordNotFoundError(err) {
		// not found
	} else if err != nil {
		logger.Log.Info(err)
		c.Error(err)
		c.JSON(httperror.ErrorMessage(httperror.ErrDatabase))
		return
	}

	length := len(users)
	serialized := make([]map[string]interface{}, length, length)

	for i := 0; i < length; i++ {
		serialized[i] = users[i].SerializeHideToken()
	}

	c.JSON(200, gin.H{
		"data": serialized,
	})

}

// deleteUser
func deleteUser(c *gin.Context) {
	userAccount := c.GetString("user_account")
	if userAccount == "" {
		c.JSON(httperror.ErrorMessage(httperror.ErrToken))
		return
	}

	userRole := c.GetString("user_role")
	if userRole != "Admin" {
		c.JSON(httperror.ErrorMessage(httperror.ErrForbidden))
		return
	}

	userID := c.Param("userId")

	var user models.User
	db := database.DB
	db.Unscoped().Delete(&user, userID)

	c.JSON(200, gin.H{})
}
