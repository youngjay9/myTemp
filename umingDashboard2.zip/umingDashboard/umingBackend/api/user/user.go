package user

import (
	"github.com/gin-gonic/gin"
)

// ApplyPublicRoutes applies router to the gin Engine
func ApplyPublicRoutes(r *gin.RouterGroup) {

}

// ApplyPrivateRoutes applies router to the gin Engine
func ApplyPrivateRoutes(r *gin.RouterGroup) {
	r.POST("/user/me/shipPosition", postMeShipPosition)
	r.GET("/user/me/shipPosition", getMeShipPosition)
	r.POST("/user/config", postUserConfig)
	r.GET("/user", getUserInfoList)
	r.DELETE("/user/:userId", deleteUser)
}
