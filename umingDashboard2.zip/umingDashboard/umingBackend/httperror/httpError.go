package httperror

// APIErrors for
type APIErrors struct {
	Errors []*APIError `json:"errors"`
}

// Status , get error status code
func (errors *APIErrors) Status() int {
	return errors.Errors[0].Status
}

// APIError for
type APIError struct {
	Status  int    `json:"status" example:"400"`
	Code    string `json:"errCode" example:"E0004"`
	Message string `json:"errMsg" example:"Wrong parameter"`
}

// NewCustomAPIError ,
func NewCustomAPIError(msg string) *APIError {
	return &APIError{
		Status:  400,
		Code:    "E0000",
		Message: msg,
	}
}

func newAPIError(status int, code string, msg string) *APIError {
	return &APIError{
		Status:  status,
		Code:    code,
		Message: msg,
	}
}

var (
	ErrUnknown             = newAPIError(400, "E0000", "Unknown error")
	ErrCommon              = newAPIError(400, "E0001", "Common error")
	ErrUnauthorized        = newAPIError(401, "E0002", "Unauthorized")
	ErrForbidden           = newAPIError(403, "E0003", "Forbidden")
	ErrWrongParameter      = newAPIError(400, "E0004", "Wrong parameter")
	ErrDatabase            = newAPIError(400, "E0005", "Database error")
	ErrDataNotFound        = newAPIError(400, "E0006", "Data not found")
	ErrAccountPassworFail  = newAPIError(400, "E0007", "Account/ password fail")
	ErrToken               = newAPIError(400, "E0008", "Wrong token data")
	ErrUserNotFound        = newAPIError(400, "E0009", "User not found")
	ErrNoSystemAccessRight = newAPIError(400, "E0010", "No Access right to this web")
)

// ErrorMessage (),error helper function
func ErrorMessage(error interface{}) (int, *APIError) {
	var apiError *APIError

	switch error.(type) {
	case *APIError:
		apiError = error.(*APIError)

	default:
		apiError = ErrUnknown
	}
	return apiError.Status, apiError
}

// ErrorMessages (),error helper function
func ErrorMessages(error interface{}) (int, *APIErrors) {
	var apiErrors *APIErrors

	switch error.(type) {
	case *APIError:
		apiError := error.(*APIError)
		apiErrors = &APIErrors{
			Errors: []*APIError{apiError},
		}
	case *APIErrors:
		apiErrors = error.(*APIErrors)
	default:
		apiErrors = &APIErrors{
			Errors: []*APIError{ErrUnknown},
		}
	}
	return apiErrors.Status(), apiErrors
}
