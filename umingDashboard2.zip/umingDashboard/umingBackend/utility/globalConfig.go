package utility

import (
	"goGinBassinet/database"
	"goGinBassinet/models"
)

// GetDefaultTokenExpiredDuration , jj
func GetDefaultTokenExpiredDuration() int64 {
	var defaultExpiredDuration int64 = 86400
	var globalConfig models.GlobalConfig
	db := database.DB
	if err := db.Where("type = ?", models.GlobalSettingType).First(&globalConfig).Error; err == nil {
		//Found
		defaultExpiredDuration = int64(globalConfig.TokenExpiredDuration)
	}
	return defaultExpiredDuration
}
