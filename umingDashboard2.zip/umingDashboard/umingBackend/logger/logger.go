package logger

import (
	"os"

	"github.com/op/go-logging"
)

//Log , export log
var Log = logging.MustGetLogger("uming-logger")

var loggerFormat = logging.MustStringFormatter(
	`%{color}%{time:2006-01-02T15:04:05.999Z-07:00} %{shortfunc} ▶ %{level:.4s} %{color:reset} %{message}`,
)

// InitLogger ,
func InitLogger() {
	backend1 := logging.NewLogBackend(os.Stdout, "", 0)
	backend1Formatter := logging.NewBackendFormatter(backend1, loggerFormat)
	logging.SetBackend(backend1Formatter)
}
