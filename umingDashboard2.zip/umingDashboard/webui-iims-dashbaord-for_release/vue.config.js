const defaultSettings = require('./src/settings.js')
const publicPath = defaultSettings.publicPath || '/' // publicPath
const name = defaultSettings.title || 'to-vs-front-end-template' // page title
const path = require('path')
function resolve(dir) {
  return path.join(__dirname, dir)
}
module.exports = {
  productionSourceMap: false,
  lintOnSave: false,
  runtimeCompiler: true,
  publicPath,
  assetsDir: 'static',
  configureWebpack: {
    // provide the app's title in webpack's name field, so that
    // it can be accessed in index.html to inject the correct title.
    name: name,
    resolve: {
      alias: {
        '@': resolve('src')
      }
    }
  },

  devServer: {
    disableHostCheck: true,
    proxy: {
      '/iimsApi': {
        target: defaultSettings.api.iims,
        ws: true,
        changeOrigin: true,
        pathRewrite: {
          '^/iimsApi': '/'
        }
      },
      '/thrukApi': {
        target: defaultSettings.api.thruk,
        ws: true,
        changeOrigin: true,
        pathRewrite: {
          '^/thrukApi': '/'
        }
      }
    }
  },

  pluginOptions: {
    quasar: {
      importStrategy: 'kebab',
      rtlSupport: false
    }
  },

  transpileDependencies: [
    'quasar',
    'vue-echarts',
    'resize-detector'
  ]
}
