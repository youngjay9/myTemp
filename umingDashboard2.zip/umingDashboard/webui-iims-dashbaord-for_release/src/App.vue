<template>
  <router-view></router-view>
</template>

<script>
export default {
  name: 'App',
  mounted() {
    this.$q.dark.set(true)
    const lang = JSON.parse(localStorage.getItem('lang')) || 'zh-TW'
    this.$i18n.locale = lang
    localStorage.setItem('lang', JSON.stringify(lang))
  }
}
</script>

<style lang="sass">
  // Import Main styles for this application
  // @import 'assets/scss/style';
  @import '@/styles/style'
</style>
