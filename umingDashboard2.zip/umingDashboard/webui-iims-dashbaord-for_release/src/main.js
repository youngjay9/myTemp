import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// css
import cssVars from 'css-vars-ponyfill'
cssVars({
  onlyLegacy: true,
  watch: true
  // onComplete(cssText, styleNode, cssVariables) {
  // console.log(cssText)
  // }
})

import './quasar'
// 其他套件
import './vendor'
// CSS
import 'animate.css'
// i18n
import i18n from '@/vendor/vue-i18n'
// https://ithelp.ithome.com.tw/articles/10209584

// 權限
import './permission' // permission control
import permission from '@/directives/permission' // 權限判斷
Vue.use(permission)

Vue.config.productionTip = false

new Vue({
  router,
  store,
  i18n,
  render: h => h(App)
}).$mount('#app')
