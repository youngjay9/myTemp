<template>
  <v-chart :autoresize="true" theme="dark-iims" :options="chart"/>
</template>
<script>
// import { colors } from 'quasar'
// const { changeAlpha } = colors
import theme from '@/vendor/EchartTheme-dark.json'
import ChartSetting from '@/shared/chartOptions.js'
import 'echarts/lib/chart/line'
import 'echarts/lib/chart/bar'
import 'echarts/lib/chart/candlestick'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/tooltip'
import 'echarts/lib/component/dataZoom'
import 'echarts/lib/component/polar'

export default {
  name: 'Chart',
  props: {
    darkmode: {
      type: Boolean,
      default: true
    },
    data: {
      type: Object,
      default: () => null
    },
    theme: {
      type: Object,
      default: () => theme
    }
  },
  computed: {
    chart() {
      return {
        grid: {
          top: 40,
          bottom: 60,
          left: 20,
          right: 20,
          containLabel: true
        },
        tooltip: {
          trigger: 'item',
          // trigger: 'axis',
          // formatter: '{b} : {c}'
          axisPointer: {
            animation: false,
            type: 'cross'
          }
        },
        legend: {
          itemWidth: 14,
          itemHeight: 14,
          inactiveColor: '#333',
          textStyle: {
            color: '#fff'
          },
          left: 100,
          padding: [5, 80]
          // data: lengend
        },
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        },
        xAxis: {
          type: 'category',
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          // axisLine: {
          //   // show: false,
          //   lineStyle: {
          //     color: '#fff'
          //   }
          // },
          splitLine: {
            show: false,
            lineStyle: {
              color: '#333'
            }
          },
          axisLabel: {
            textStyle: {
              color: '#ccc'
            }
          }
        },
        yAxis: {
          type: 'value',
          axisLine: {
            show: false,
            lineStyle: {
              color: '#fff'
            }
          },
          axisLabel: {
            textStyle: {
              color: '#fff'
            }
          },
          splitLine: {
            show: false,
            lineStyle: {
              color: '#333'
            }
          }
        },
        dataZoom: ChartSetting.dataZoom(94, 100),
        series: [{
          type: 'line',
          name: 'A',
          areaStyle: {
            normal: {
              // 漸層色
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: 'rgba(245,91,91,0.2)'
              },
              {
                offset: 1,
                color: 'rgba(245,91,91,0)'
              }
              ], false)
            }
          },
          data: [820, 932, 901, 934, 1290, 1330, 1320]
        },
        {
          type: 'line',
          name: 'B',
          areaStyle: {
            normal: {
              // 漸層色
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: 'rgba(243,221,65,0.2)'
              },
              {
                offset: 1,
                color: 'rgba(243,221,65,0)'
              }
              ], false)
            }
          },
          data: [20, 32, 91, 34, 1290, 30, 10]
        }],
        ...this.data
      }
    }
  },
  created() {
    // console.log(this.theme.theme.color)
  }
}
</script>
<style lang="sass" scoped>
/**
 * The default size is 600px×400px, for responsive charts
 * you may need to set percentage values as follows (also
 * don't forget to provide a size for the container).
 */
.echarts
  width: 100%
  height: 100%
  // min-height: 320px
</style>
