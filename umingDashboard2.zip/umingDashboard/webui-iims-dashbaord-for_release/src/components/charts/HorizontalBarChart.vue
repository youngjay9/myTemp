<template>
  <v-chart :resizable="true" theme="dark-iims" :options="chart"/>
</template>
<script>
// import { colors } from 'quasar'
// const { changeAlpha } = colors
import theme from '@/vendor/EchartTheme-dark.json'
import 'echarts/lib/chart/bar'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/tooltip'

export default {
  name: 'BarChart',
  props: {
    darkmode: {
      type: Boolean,
      default: true
    },
    data: {
      type: Object,
      default: () => null
    },
    options: {
      type: Object,
      default: () => {}
    },
    theme: {
      type: Object,
      default: () => theme
    }
  },
  data() {
    // const opt = {
    //   ...this.options
    // }
    const data = [
      { value: 33, name: 'usage' }
      // { value: 3, name: 'Fail' }
    ]
    // const color = this.theme.theme.color
    const lengend = data.map(d => d.name)
    return {
      chart: {
        tooltip: {
          trigger: 'item',
          formatter: '{b} : {c}'
        },
        // legend: {
        //   itemWidth: 14,
        //   itemHeight: 14,
        //   bottom: 10,
        //   inactiveColor: '#333',
        //   textStyle: {
        //     color: '#eee'
        //   },
        //   data: lengend
        // },
        grid: {
          left: 50
        },
        xAxis: {
          type: 'value',
          show: false
        },
        yAxis: {
          type: 'category',
          axisTick: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: '#eee'
            }
          },
          axisLine: {
            show: false
          },
          data: lengend
        },
        series: [{
          type: 'bar',
          label: {
            show: true,
            position: 'right'
          },
          itemStyle: {
            emphasis: {
              // barBorderRadius: [50, 50]
            },
            normal: {
              barBorderRadius: [2, 2, 0, 0],
              color: function(params) {
                return theme.theme.color[params.dataIndex]
              }
            }
          },
          barWidth: 20,
          data: data
        }]
      }
    }
  },
  created() {
    // console.log(this.theme.theme.color)
  }
}
</script>
<style lang="sass" scoped>
/**
 * The default size is 600px×400px, for responsive charts
 * you may need to set percentage values as follows (also
 * don't forget to provide a size for the container).
 */
.echarts
  width: 100%
  height: 100%
  // min-height: 100px
</style>
