<template>
  <v-chart :resizable="true" :chartId="chartId" theme="dark-iims" :options="chart" @click="handleClick"/>
</template>
<script>
// import { colors } from 'quasar'
// const { changeAlpha } = colors
import theme from '@/vendor/EchartTheme-dark.json'
import 'echarts/lib/chart/bar'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/tooltip'
import 'echarts/lib/component/polar'

export default {
  name: 'BarChart',
  props: {
    chartId: {
      type: String,
      required: true
    },
    darkmode: {
      type: Boolean,
      default: true
    },
    data: {
      type: Object,
      default: () => {
        return {
          groupName: '',
          centerText: '70%',
          title: '',
          options: null,
          labels: ['Normal', 'Fail'],
          data: [
            { value: 33, name: 'Normal' },
            { value: 3, name: 'Fail' }
          ]
        }
      }
    },
    theme: {
      type: Object,
      default: () => theme
    }
  },
  computed: {
    chart() {
      // if (!this.data.data) return this.data.options
      const lengend = this.data.labels || ['Normal', 'Fail']
      return {
        tooltip: {
          trigger: 'item',
          formatter: '{b} : {c}'
        },
        legend: {
          itemWidth: 14,
          itemHeight: 14,
          bottom: 10,
          inactiveColor: '#333',
          textStyle: {
            color: '#eee'
          },
          data: lengend
        },
        xAxis: {
          triggerEvent: true,
          type: 'category',
          data: lengend,
          axisTick: {
            show: false
          },
          axisLabel: {
            interval: 0,
            textStyle: {
              color: '#eee'
            }
          },
          axisLine: {
            show: false
          }
        },
        yAxis: {
          type: 'value',
          show: false,
          axisLine: {
          },
          axisLabel: {
            show: false
          }
        },
        series: [{
          type: 'bar',
          label: {
            show: true,
            position: 'top',
            color: '#fff'
          },
          showBackground: true,
          backgroundStyle: {
            color: 'rgba(38, 50, 56, 0.8)'
          },
          itemStyle: {
            emphasis: {
            // barBorderRadius: [50, 50]
            },
            normal: {
              barBorderRadius: [2, 2, 0, 0]
            // color: function(params) {
            //   return theme.theme.color[params.dataIndex]
            // }
            }
          },
          barWidth: 40,
          data: this.data.data
        }],
        ...this.data.options
      }
    }
  },
  data() {
    return {}
  },
  methods: {
    mouseover(e) {
      console.log(e)
      // if (e.data && e.data.dataUrl) {
      //   window.open(e.data.dataUrl, '_blank')
      // }
    },
    handleClick(e) {
      if (e.data && e.data.dataUrl) {
        window.open(e.data.dataUrl, '_blank')
      }
      if (e.targetType === 'axisLabel') {
        const item = this.data.data.find(d => d.name === e.value)
        if (item && item.dataUrl) {
          window.open(item.dataUrl, '_blank')
        }
      }
    }
  },
  created() {
    // console.log(this.theme.theme.color)
  }
}
</script>
<style lang="sass" scoped>
/**
 * The default size is 600px×400px, for responsive charts
 * you may need to set percentage values as follows (also
 * don't forget to provide a size for the container).
 */
.echarts
  width: 100%
  height: 100%
  // min-height: 220px
</style>
