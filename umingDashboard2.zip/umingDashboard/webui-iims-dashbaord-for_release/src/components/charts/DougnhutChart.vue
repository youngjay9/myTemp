<template>
  <v-chart :resizable="true" :chartId="chartId" theme="dark-iims" :options="chart" @legendselectchanged="legendselectchanged" @click="handleClick"/>
</template>
<script>
// import { colors } from 'quasar'
// const { changeAlpha } = colors
import theme from '@/vendor/EchartTheme-dark.json'
import 'echarts/lib/chart/pie'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/tooltip'

export default {
  name: 'DoughnutChart',
  props: {
    chartId: {
      type: String,
      required: true
    },
    darkmode: {
      type: Boolean,
      default: true
    },
    data: {
      type: Object,
      default: () => {
        return {
          groupName: '',
          centerText: '70%',
          options: null,
          data: [
            { value: 33, name: 'Normal' },
            { value: 3, name: 'Fail' }
          ]
        }
      }
    },
    theme: {
      type: Object,
      default: () => theme
    }
    // width: {
    //   type: String,
    //   default: '100%'
    // },
    // height: {
    //   type: String,
    //   default: '100%'
    // }
  },
  watch: {
  },
  computed: {
    chart() {
      return {
        animation: this.animation,
        title: [{
          text: this.data.centerText || '',
          subtext: '',
          top: '38%',
          left: 'center',
          textStyle: {
            color: '#fff'
          }
        }],
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
          // selectedMode: false,
          // orient: 'vertical',
          itemWidth: 14,
          itemHeight: 14,
          // x: 'right', // 'center' | 'left' | {number},
          // y: 'top', // 'center' | 'bottom' | {number}
          bottom: -5,
          inactiveColor: '#888',
          textStyle: {
            color: '#eee'
          }
          // data: lengend
        },
        series: [
          {
            name: this.data.groupName,
            type: 'pie',
            // radius: ['55%', '75%'],
            radius: ['55%', '70%'],
            center: ['50%', '40%'],
            label: {
              show: false,
              position: 'center'
            },
            labelLine: {
              show: false
            },
            data: this.data.data
          }
        ],
        ...this.data.options
      }
    }
    // size() {
    //   return {
    //     width: this.width,
    //     height: this.height
    //   }
    // }
  },
  data() {
    return {
      // chart
      animation: true
    }
  },
  methods: {
    async legendselectchanged(e) {
      this.animation = false
      if (this.data.data) {
        const item = this.data.data.find(({ name })=> name === e.name)
        if (item && item.dataUrl) {
          window.open(item.dataUrl, '_blank')
        }
      }
      // await this.$nextTick()
      this.animation = true
    },
    handleClick(e) {
      if (e.data && e.data.dataUrl) {
        window.open(e.data.dataUrl, '_blank')
      }
      if (e.targetType === 'axisLabel') {
        const item = this.data.data.find(d => d.name === e.value)
        if (item && item.dataUrl) {
          window.open(item.dataUrl, '_blank')
        }
      }
    }
  },
  created() {
  }
}
</script>
<style lang="sass" scoped>
/**
 * The default size is 600px×400px, for responsive charts
 * you may need to set percentage values as follows (also
 * don't forget to provide a size for the container).
 */
.echarts
  width: 100%
  height: 100%
</style>
