<template>
  <v-chart :resizable="true" theme="dark-iims" :options="chart"/>
</template>
<script>
// import { colors } from 'quasar'
// const { changeAlpha } = colors
import theme from '@/vendor/EchartTheme-dark.json'
import 'echarts/lib/chart/gauge'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/tooltip'

export default {
  name: 'GaugeChart',
  props: {
    darkmode: {
      type: Boolean,
      default: true
    },
    data: {
      type: Object,
      default: () => {
        return {
          seriesName: 'chart',
          data: [{ value: 10, name: 'cpu' }],
          colorSet: [
            [0.5, '#01FF00'],
            [0.9, '#FFF002'],
            [1, '#FF0007']],
          options: {}
        }
      }
    },
    theme: {
      type: Object,
      default: () => theme
    }
    // width: {
    //   type: String,
    //   default: '100%'
    // },
    // height: {
    //   type: String,
    //   default: '190px'
    // }
  },
  computed: {
    chart() {
      const dataArr = this.data.data
      const colorSet = this.data.colorSet
      return {
        // radius: '95%',
        // splitNumber: 20,
        // startAngle: 225,
        // endAngle: -45,
        min: 0,
        max: 100,
        tooltip: {
          show: true
        },
        series: [
          {
            name: 'inner pie',
            type: 'pie',
            center: ['50%', '45%'],
            tooltip: {
              show: true,
              trigger: 'item',
              formatter: function(params) {
                return `${dataArr[0].name} <br/> Usage: ${dataArr[0].value}%`
              }
            },
            startAngle: '-90',
            endAngle: '90',
            hoverAnimation: false,
            legendHoverLink: false,
            radius: '35%',
            z: 0,
            labelLine: {
              'normal': {
                'show': false
              }
            },
            // detail: { formatter: '{value}%' },
            data: [
              {
                value: 0
              },
              {
                value: 100,
                itemStyle: {
                  normal: {
                    color: 'rgba(38, 50, 56, 0.8)'
                  },
                  emphasis: {
                    color: 'rgba(38, 50, 56, 0.8)'
                  }
                }
              }
            ]
          },
          {
            type: 'gauge',
            name: 'outer',
            radius: '85%',
            startAngle: '225',
            endAngle: '-45',
            splitNumber: '120',
            center: ['50%', '42.5%'],
            pointer: {
              show: false
            },
            tooltip: {
              show: false
            },
            detail: {
              show: false
            },
            data: [{ value: 1 }],
            title: {
              show: true,
              offsetCenter: [0, 30]
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: [
                  [1, '#ddd']
                  // [1, 'rgba(38, 50, 56, 1)']
                ],
                width: 1,
                opacity: 0.2
              }
            },
            axisTick: {
              show: false
            },
            splitLine: {
              show: true,
              length: 20,
              lineStyle: {
                color: '#051932',
                width: 0,
                type: 'solid'
              }
            },
            axisLabel: {
              show: false
            }
          },
          {
            type: 'gauge',
            radius: '76%',
            startAngle: '225',
            endAngle: '-45',
            center: ['50%', '42.5%'],
            pointer: {
              show: true
            },
            tooltip: {
              show: false
            },
            detail: {
              show: true,
              formatter: (value) => {
                return [`{seriesName|${this.data.seriesName || ''}}`, `{value|${value} %}`].join('\n')
              },
              rich: {
                seriesName: {
                  // color: '#fefefe',
                  fontSize: 15,
                  fontWeight: 'bold',
                  padding: [-15, 0, 0, 0]
                },
                value: {
                  fontSize: 14,
                  lineHeight: 12,
                  color: '#fefefe',
                  padding: [-55, 0, 0, 0]
                }
              }
            },
            data: dataArr,
            title: {
              show: false
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: colorSet,
                width: 10,
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                opacity: 1
              }
            },
            axisTick: {
              show: false
            },
            splitLine: {
              show: false,
              length: 25,
              lineStyle: {
                color: '#00377a',
                width: 2,
                type: 'solid'
              }
            },
            axisLabel: {
              show: false
            },
            animationDuration: 4000
          },
          {
            type: 'gauge',
            center: ['50%', '42.5%'],
            radius: '73%',
            splitNumber: 10,
            min: 0,
            max: 100,
            startAngle: 225,
            endAngle: -45,
            axisLine: {
              show: false,
              lineStyle: {
                width: 1,
                color: [
                  [1, 'rgba(255, 255, 255, .7)']
                ]
              }
            },
            axisTick: {
              splitNumber: 2,
              length: 6
            },
            splitLine: {
              show: true,
              length: 8,
              lineStyle: {
                width: 1
              }
            },
            // 分隔线样式
            axisLabel: {
              show: false,
              distance: 5,
              textStyle: {
                color: '#fff',
                fontSize: '12',
                fontWeight: 'bold'
              }
            },
            detail: {
              show: 0
            }
          }
          // {
          //   name: 'CPU',
          //   type: 'gauge',
          //   axisLine: {
          //     show: true,
          //     lineStyle: {
          //       'color': [
          //         [
          //           0.5,
          //           '#01FF00'
          //         ],
          //         [
          //           0.9,
          //           '#FFF002'
          //         ],
          //         [
          //           1,
          //           '#FF0007'
          //         ]
          //       ],
          //       width: 8
          //     }
          //   },
          //   detail: { formatter: '{value}%' },
          //   data: this.data.data
          // }
        ]
        // ...this.data.options
      }
    }
  },
  created() {
    // console.log(this.theme.theme.color)
  }
}
</script>
<style lang="sass" scoped>
/**
 * The default size is 600px×400px, for responsive charts
 * you may need to set percentage values as follows (also
 * don't forget to provide a size for the container).
 */
.echarts
  width: 100%
  height: 100%
  // min-height: 190px
</style>
