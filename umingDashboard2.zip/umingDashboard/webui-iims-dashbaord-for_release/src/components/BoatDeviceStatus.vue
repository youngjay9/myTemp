<template>
  <div class="HorizontalStatus column">
    <template v-if="data.total > 0">
      <div class="StatusList" >
        <div class="label label-success">
           <svg width="100%" height="100%" viewBox="0 0 178 70" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 0H138L178 35L138 70H0L40 35L0 0Z" fill="#C4C4C4"/>
            <text x="65" y="54" font-size="40" fill="#000"> {{data.ok}} </text>
          </svg>
        </div>
        <div class="bar">
          <div class="bar-success" :style="{ width: `${ data.ok/ data.total * 100 }%` }"></div>
        </div>
      </div>
      <!-- <div class="StatusList">
        <div class="label label-warning">
           <svg width="100%" height="100%" viewBox="0 0 178 70" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 0H138L178 35L138 70H0L40 35L0 0Z" fill="#C4C4C4"/>
            <text x="65" y="54" font-size="40" fill="#fff"> {{data.warning}} </text>
          </svg>
        </div>
        <div class="bar">
          <div class="bar-warning" :style="{ width: `${ data.warning/ data.total * 100 }%` }"></div>
        </div>
      </div> -->
      <div class="StatusList">
        <div class="label label-fail">
          <svg width="100%" height="100%" viewBox="0 0 178 70" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 0H138L178 35L138 70H0L40 35L0 0Z" fill="#C4C4C4"/>
            <text x="65" y="54" font-size="40" fill="#000"> {{data.critical}} </text>
          </svg>
        </div>
        <div class="bar">
          <div class="bar-fail" :style="{ width: `${ data.critical/ data.total * 100 }%` }"></div>
        </div>
      </div>
    </template>
    <div class="StatusTotal q-mt-sm">
      Total: <b>{{data.total}}</b>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BoatDeviceStatus',
  props: {
    data: {
      type: Object,
      default: () => {
        return {
          total: 33,
          ok: 28,
          warning: 3,
          critical: 2
        }
      }
    }
  },
  data() {
    return {
      // statusdata: {}
    }
  },
  mounted() {
  }
}
</script>

<style lang="sass" scoped>
@import '@/styles/quasar.variables.sass'
.HorizontalStatus
  font-size: 0.85rem
  width: 100%
  height: 100%
  .StatusTotal
    width: 100%
    letter-spacing: 1px
    font-size: 1rem
  .StatusList
    width: 100%
    height: 36px
    // min-height: 24px
    // max-height: 50px
    padding: 4px 0
    display: flex
    // grid-template-columns: minmax(50px, 20%) 1fr
    .label
      width: 30%
      min-width: 55px
      position: relative
      // clip-path: polygon(75% 0%, 100% 50%, 75% 100%, 0% 100%, 25% 50%, 0% 0%)
      text-align: center
      display: flex
      align-items: center
      justify-content: center
      &-success
        // background: var(--q-color-positive)
        path
          fill: var(--q-color-positive)
      &-warning
        // background: var(--q-color-warning)
        path
          fill: var(--q-color-warning)
      &-fail
        // background: var(--q-color-negative)
        path
          fill: var(--q-color-negative)
    .bar
      width: 100%
      margin-left: .5rem
      border-radius: 0px 3px 3px 0px
      background: rgba(38, 50, 56, 0.8)
      &-success
        height: 100%
        background: var(--q-color-positive)
        border-radius: 0px 3px 3px 0px
        // background: linear-gradient(90deg,darken($positive, 20) 0%, var(--q-color-positive) 100%)
        // box-shadow: 0px 0px 10px darken($positive, 20)
      &-warning
        background: var(--q-color-warning)
        border-radius: 0px 3px 3px 0px
        height: 100%
        // background: linear-gradient(90deg,darken($warning, 20) 0%, var(--q-color-warning) 100%)
        // box-shadow: 0px 0px 10px darken($warning, 20)
      &-fail
        background: var(--q-color-negative)
        border-radius: 0px 3px 3px 0px
        height: 100%
        // background: linear-gradient(90deg,darken($negative, 20) 0%, var(--q-color-negative) 100%)
        // box-shadow: 0px 0px 10px darken($negative, 20)
</style>
