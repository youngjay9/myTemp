<template>
  <div>
    HelloWorld {{msg}}
  </div>
</template>

<style>
</style>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: {
      type: String
    }
  }
}
</script>
