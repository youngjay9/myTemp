<template>
  <div class="sla-status">
    <div class="row flex-center">
      <div class="col-6 flex q-gutter-xs q-pa-xs flex-center sla-upload" v-if="data.upload">
        <div class="text-right full-width q-px-xs">
          <b>{{capitalize($t('sla.upload'))}}</b>
        </div>
       <div
        class="full-width item"
        v-ripple="{ color: color[index] }"
        v-for="(item, index) in upload"
        @click="showDetail(data.upload[item])"
        :key="item">
          <!-- <div class="label no-wrap"> {{Math.max(data.upload[item].length, 0)}} / {{data.total}} </div>
          <div
            class="barSlot text-right q-px-sm"
            :style="getColor(item, 'upload', index)">
            <span class="bar-item-name">{{item}}</span>
          </div>
         </div> -->
          <div
            class="barSlot q-px-sm full-width "
            :style="getColor(item, 'upload', index)" >
            <span class="label no-wrap">
              {{Math.max(data.upload[item].length, 0)}} / {{data.total}}
            </span>
            <span class="bar-item-name">{{item}}</span>
          </div>
          </div>
      </div>
      <div class="col-6 flex q-gutter-xs q-pa-xs flex-center sla-download"  v-if="data.download">
        <div class="text-left full-width q-px-xs">
          <b>{{capitalize($t('sla.download'))}}</b>
        </div>
        <div
          class="full-width item"
          v-ripple="{ color: color[index] }"
          v-for="(item, index) in download"
          @click="showDetail(data.download[item])"
          :key="item">
            <div
              class="barSlot q-px-sm full-width "
              :style="getColor(item, 'download', index)" >
              <span class="bar-item-name">{{item}}</span>
              <span class="label no-wrap">
                {{Math.max(data.download[item].length, 0)}} / {{data.total}}
              </span>
            </div>
          </div>
      </div>
    </div>
    <q-dialog v-model="showingDetail">
      <q-card style="width: 780px; max-width: 80vw;" v-if="detail">
        <q-card-section class="row items-center q-pb-none">
          <b class="q-mr-md text-h6 text-primary text-weight-bold"> {{$t(`topView.Satellite`)}}</b>
          <q-space />
          <q-btn icon="close" flat round dense v-close-popup />
        </q-card-section>
        <q-card-section v-if="detail.length === 0" class="q-pa-sm" style="height: 40vh; width: 100%;">
           <div class="q-px-md">{{$t('vesselView.noData')}}</div>
        </q-card-section>
        <q-scroll-area v-else style="height: 80vh; width: 100%;" class="q-pa-sm">
          <q-card-section>
            <div class="q-mt-sm">
              <div v-for="item in detail" :key="item.vesselCode" class="q-pb-md">
                <q-btn
                  :href="getXILink(item)"
                  flat
                  padding="xs sm"
                  align="left"
                  type="a"
                  target="_blank"
                  class="full-width text-primary">{{item.boat_display_name}}</q-btn>
                <div class="q-px-md">
                  <b>{{capitalize($t('sla.upload'))}}：</b>
                  {{item.boatSla.bpsout_display}}
                </div>
                <div class="q-px-md">
                  <b>{{capitalize($t('sla.download'))}}：</b>
                  {{item.boatSla.bpsin_display}}
                </div>
              </div>
            </div>
          </q-card-section>
        </q-scroll-area>
      </q-card>
    </q-dialog>
  </div>
</template>

<script>
import { format } from 'quasar'
import { mapGetters } from 'vuex'
const { capitalize } = format

export default {
  name: 'SlaStatus',
  props: {
    data: {
      type: Object,
      default: () => {
        return {
          download: null,
          upload: null,
          total: 0
        }
      }
    }
  },
  data() {
    return {
      color: [
        // 'rgba(0, 212, 153, 0.5)',
        // 'rgba(75, 192, 192, 0.5)',
        // 'rgba(242, 192, 55, 0.5)',
        // 'rgba(255, 92, 80, 0.5)'
        'rgba(75, 192, 192, 0.5)',
        'rgba(75, 192, 192, 0.5)',
        'rgba(75, 192, 192, 0.5)',
        'rgba(75, 192, 192, 0.5)'
      ],
      upload: ['256K+', '128K~256K', '1K~128K', 'Disconnect'],
      download: ['1M+', '512K~1M', '1K~512K', 'Disconnect'],
      showingDetail: false,
      detail: null
      // color,
      // color: [colors.getBrand('positive'),
      //   colors.getBrand('info'),
      //   colors.getBrand('warning'),
      //   colors.getBrand('negative')]
    }
  },
  computed: {
    ...mapGetters({
      nagiosxiUrl: 'user/nagiosxiLink'
    })
  },
  methods: {
    getColor(item, key, index) {
      // const browser = this.$checkBrowser()
      const startColor = this.color[index]
      const count = item
      const keyData = this.data[key][count] || []
      const start = Math.max(keyData.length, 0) / this.data.total * 100
      const end = Math.max(keyData.length, 0) / this.data.total * 100
      // const startColor = 'rgba(36, 46, 53, 1)'
      return key === 'download'
        ? {
          'background-image': `linear-gradient(to left,
          ${startColor} 0%,
          ${this.color[index]} ${start}%,
          rgba(0,0,0,0) ${end}%)`
        }
        : {
          'background-image': `linear-gradient(to right,
          ${startColor} 0%,
          ${this.color[index]} ${start}%,
          rgba(0,0,0,0) ${end}%)`
        }
    },
    getXILink(item) {
      return item.boatSla.state === 2
        ? `${this.nagiosxiUrl}%26show%3Dservices%26servicegroup%3DSatellite%26search%3D${item.name}`
        : `${this.nagiosxiUrl}host%3D${item.name}_192.168.1.1%26search%3DWAN1`
    },
    capitalize(str) {
      return capitalize(str)
    },
    showDetail(item) {
      this.showingDetail = true
      this.detail = item
    }
  }
}
</script>

<style lang="sass" scoped>
  .sla-status
    width: 100%
  .label
    // width: 25%
  .item
    width: 100%
    display: flex
    background: rgba(38, 50, 56, 0.8)
    padding: .25rem
    position: relative
    min-height: 28px
    justify-content: space-between
    border-radius: 5px
    cursor: pointer
    transition: .2s
    &:hover
      background: rgba(46, 60, 67, 0.8)
  .barSlot
    width: 100%
    position: relative
    display: flex
    justify-content: space-between
    border-radius: 5px
    .bar-item-name
      font-weight: 500
  .sla-upload
    .item
      flex-direction: row
      .bar
        right: 0
  .sla-download
    .item
      flex-direction: row-reverse
</style>
