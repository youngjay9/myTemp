<template>
  <div :class="['hex-info-box', dark, lang, hexGridSize]"  ref="hexGrid">
     <!-- 星空背景，css 不在此 component，寫在 style.css 中 -->
    <div class="stars-wrapper">
      <div class="layer" data-depth="0.00"></div>
      <div class="stars-cluster stars-cluster-1 layer" data-depth="0.30">
        <div class="star star-1"></div>
        <div class="star star-2"></div>
        <div class="star star-3"></div>
        <div class="star star-4"></div>
        <div class="star star-5"></div>
        <div class="star star-6"></div>
        <div class="star star-7"></div>
        <div class="star star-8"></div>
        <div class="star star-9"></div>
        <div class="star star-10"></div>
        <div class="star star-11"></div>
        <div class="star star-12"></div>
        <div class="star star-13"></div>
        <div class="star star-14"></div>
        <div class="star star-15"></div>
        <div class="star star-16"></div>
        <div class="star star-17"></div>
        <div class="star star-18"></div>
        <div class="star star-19"></div>
        <div class="star star-20"></div>
        <div class="star star-21"></div>
        <div class="star star-22"></div>
        <div class="star star-23"></div>
        <div class="star star-24"></div>
        <div class="star star-25"></div>
        <div class="star star-26"></div>
        <div class="star star-27"></div>
        <div class="star star-28"></div>
        <div class="star star-29"></div>
        <div class="star star-30"></div>
        <div class="star star-31"></div>
        <div class="star star-32"></div>
        <div class="star star-33"></div>
        <div class="star star-34"></div>
        <div class="star star-35"></div>
        <div class="star star-36"></div>
        <div class="star star-37"></div>
        <div class="star star-38"></div>
        <div class="star star-39"></div>
        <div class="star star-40"></div>
        <!-- ↓↓↓ 十字星芒 ↓↓↓ -->
        <div class="star-2 star-41-cross">
            <img src="@/assets/image/cross-star.png" alt="star-cross">
        </div>
        <div class="star-2 star-42-cross">
            <img src="@/assets/image/cross-star.png" alt="star-cross">
        </div>
        <div class="star-2 star-43-cross">
            <img src="@/assets/image/cross-star.png" alt="star-cross">
        </div>
        <div class="star-2 star-44-cross">
            <img src="@/assets/image/cross-star.png" alt="star-cross">
        </div>
        <div class="star-2 star-45-cross">
            <img src="@/assets/image/cross-star.png" alt="star-cross">
        </div>
        <!-- ↑↑↑ 十字星芒 ↑↑↑ -->
      </div>
      <div class="stars-cluster stars-cluster-2 layer" data-depth="0.50">
        <div class="star star-1"></div>
        <div class="star star-2"></div>
        <div class="star star-3"></div>
        <div class="star star-4"></div>
        <div class="star star-5"></div>
        <div class="star star-6"></div>
        <div class="star star-7"></div>
        <div class="star star-8"></div>
        <div class="star star-9"></div>
        <div class="star star-10"></div>
        <div class="star star-11"></div>
        <div class="star star-12"></div>
        <div class="star star-13"></div>
        <div class="star star-14"></div>
        <div class="star star-15"></div>
        <div class="star star-16"></div>
        <div class="star star-17"></div>
        <div class="star star-18"></div>
        <div class="star star-19"></div>
        <div class="star star-20"></div>
        <div class="star star-21"></div>
        <div class="star star-22"></div>
        <div class="star star-23"></div>
        <div class="star star-24"></div>
        <div class="star star-25"></div>
        <div class="star star-26"></div>
        <div class="star star-27"></div>
        <div class="star star-28"></div>
        <div class="star star-29"></div>
        <div class="star star-30"></div>
        <div class="star star-31"></div>
        <div class="star star-32"></div>
        <div class="star star-33"></div>
        <div class="star star-34"></div>
        <div class="star star-35"></div>
        <div class="star star-36"></div>
        <div class="star star-37"></div>
        <div class="star star-38"></div>
        <div class="star star-39"></div>
        <div class="star star-40"></div>
      </div>
      <div class="stars-cluster stars-cluster-3 layer" data-depth="0.90">
        <div class="star star-1"></div>
        <div class="star star-2"></div>
        <div class="star star-3"></div>
        <div class="star star-4"></div>
        <div class="star star-5"></div>
        <div class="star star-6"></div>
        <div class="star star-7"></div>
        <div class="star star-8"></div>
        <div class="star star-9"></div>
        <div class="star star-10"></div>
        <div class="star star-11"></div>
        <div class="star star-12"></div>
        <div class="star star-13"></div>
        <div class="star star-14"></div>
        <div class="star star-15"></div>
      </div>
    </div>
    <draggable
      class="hex-grid__list"
      :draggable="draggable"
      group="hex"
      :style="hexSize"
      :list="hexList"
      :move="handleMove"
      @end="handleDragEnd">
      <!-- @change="log" -->
      <div
        :class="['hex-grid__item', {'hex-grid__draggable': !item.frozen },  {'hex-grid--empty': !item.data }]"
        v-for="(item, index) in hexList"
        :style="[hexItem, getPosition('hex', item.hex)]"
        :key="index"
       >
        <div
          :class="[
            'hex-grid__content',
            {'clickable': item.data && !permission },
            {'grabale': item.data && permission },
            {'empty': !item.data },
            {'up':  item.data &&  parseInt(item.data.boatSla.state, 10) === 0},
            {'warning': item.data && parseInt(item.data.boatSla.state, 10) === 1},
            {'danger': item.data &&  parseInt(item.data.boatSla.state, 10) >= 2},
          ]"
          >
          <svg
            @click="clickfn(item)"
            class="hexSvg"
            viewBox="0 0 100 88"
            fill="none"
            xmlns="http://www.w3.org/2000/svg">
            <path d="M100 44L75 87.3013L25 87.3013L-2.18557e-06 44L25 0.698727L75 0.698729L100 44Z" />
            <template  v-if="item.data">
              <text x="18" y="35" font-size="14" fill="#000"> ⮝ {{item.data.boatSla.bpsout_display}} </text>
              <text x="18" y="50" font-size="14" fill="#000"> ⮟ {{item.data.boatSla.bpsin_display}} </text>
              <text x="49" y="66" text-anchor="middle" font-size="14" fill="#000"> {{item.data.boat_display_name}} </text>
            </template>
          </svg>
        </div>
      </div>
      <div class="overlay-container" slot="footer" role="group" :style="getPosition('logo')">
        <div class="logo-wrap" draggable="false" >
          <!-- <img src="@/assets/image/UM-logo-z.png" alt="UM Logo"> -->
          <div class="globe" :style="logoWrapScale">
            <div class="globe__sphere"></div>
            <div class="globe__outer_shadow"></div>
            <div class="globe__worldmap">
              <div class="globe__worldmap__back"></div>
              <div class="globe__worldmap__front"></div>
            </div>
            <div class="globe__inner_shadow"></div>
            <div class="logo-container">
              <img src="@/assets/image/UM-logo.png" alt="UM Logo">
            </div>
          </div>
        </div>
      </div>
    </draggable>
    <q-dialog v-model="loading" seamless>
      <q-card style="min-width: 250px">
        <q-card-section class="text-center">
          <div class="q-mb-sm">
            {{$t('HexInfo.loading')}}
          </div>
          <q-linear-progress indeterminate />
        </q-card-section>
      </q-card>
    </q-dialog>
  </div>
</template>

<script>
import draggable from 'vuedraggable'
// https://www.redblobgames.com/grids/hexagons/
export default {
  components: {
    draggable
  },
  props: {
    darkMode: {
      type: Boolean,
      default: false
    },
    size: {
      type: Object,
      default: () => ({
        width: 0,
        heigth: 0
      })
    },
    data: {
      type: Array,
      default: () => []
    },
    columns: {
      type: Number,
      default: 15
    },
    rows: {
      type: Number,
      default: 7
    },
    storePosition: {
      type: Function
    },
    logoRadius: {
      type: Number,
      default: 3
    },
    permission: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      hexList: [],
      frozenList: new Set(),
      futureIndex: 0,
      movingIndex: 0,
      delay: true,
      hexSize: {
        width: 0,
        height: 0
      }
    }
  },
  watch: {
    data() {
      this.delay = true
      this.initLayout()
    }
  },
  computed: {
    lang() {
      return `hex-${JSON.parse(localStorage.getItem('lang')) || 'zh-TW'}`
    },
    dark() {
      return this.darkMode
        ? 'hex-dark'
        : ''
    },
    loading() {
      return !this.delay && this.data.length === 0
    },
    hexGridSize() {
      // if (!this.$refs.hexGrid) return ''
      // const w = this.$refs.hexGrid.clientWidth
      const w = parseInt(this.hexSize.width, 10)
      if (w > 2560) return 'hex-info-box-4k'
      if (w > 1400) return 'hex-info-box-2k'
      if (w > 1199) return 'hex-info-box-lg'
      if (w > 800) return 'hex-info-box-md'
      if (w > 500) return 'hex-info-box-xs'
      return 'hex-info-box-xs'
    },
    logoWrapScale() {
      // console.log(this.getPosition('logo'))
      const w = parseFloat((this.getPosition('logo').width || 0), 10)
      // let Item = 250
      // console.log(w)
      // if (w <= 250) Item = 250
      // if (w > 250) Item = w * 0.75
      const Item = w * 0.75
      return {
        '-ms-transform-origin': 'center center',
        'transform-origin': 'center center',
        '-ms-transform': `scale(${Item / 250})`,
        'transform': `scale(${Item / 250})`
      }
    },
    draggable() {
      return this.permission ? '.hex-grid__draggable' : ''
    },
    hexItem() {
      // grid-template-columns: repeat(var(--amount), 1fr 2fr) 1fr;
      // hex w = 2 * r (等差級數， 2r + (col -1)*(2r - 0.5r))
      // hex h = Math.sqrt(3) * r 根號3
      const w = parseInt(this.hexSize.width, 10)
      //  0.75 * size * (this.columns - 1) = w 全寬
      const itemW = 1.5 * (this.columns - 1) + 2
      const size = w / itemW
      return {
        'width': `${size * 2}px`,
        'height': `${size * Math.sqrt(3)}px`
      }
    }
  },
  methods: {
    initLayout() {
      setTimeout(() => {
        this.delay = false
      }, 1000)
      this.hexList = []
      console.log('init')
      // make hex grid layout
      const columns = this.columns // should be odd number
      const rows = this.rows // should be odd number
      const maxWidthCount = Math.floor(columns / 2)
      const maxRowCount = Math.floor(rows / 2)
      const cubeDistance = (a, b) => (Math.abs(a.x - b.x) + Math.abs(a.y - b.y) + Math.abs(a.z - b.z)) / 2
      let count = 0
      // has coordinate
      // no coordinate
      for (let i = 0; i < rows; i++) {
        for (let j = 0; j < columns; j++) {
          const hex = {
            col: j - maxWidthCount,
            row: i - maxRowCount
          }
          const coordinate = {
            x: hex.col,
            z: hex.row - (hex.col + (hex.col & 1)) / 2,
            y: (-1 * hex.col) - (hex.row - (hex.col + (hex.col & 1)) / 2)
          }
          const distance = 3// scss span
          const center = { x: 0, y: 0, z: 0 }
          if (cubeDistance(coordinate, center) < distance) {
            this.frozenList.add(count)
          }
          // col & row => x, y, z coordinate
          const data = this.data.find(d => d.coordinate && d.coordinate.x === coordinate.x && d.coordinate.y === coordinate.y && d.coordinate.z === coordinate.z)
          this.hexList.push({
            ...coordinate,
            hex: {
              x: j,
              y: i
            },
            data,
            frozen: cubeDistance(coordinate, center) < distance
          })
          count += 1 // index
        }
      }
      this.data.forEach((obj, index) => {
        if (!obj.coordinate) {
          const slot = this.hexList.findIndex(d => !d.frozen && !d.data)
          this.hexList[slot].data = obj
        }
      })
    },
    add() {
      // this.hexList.push({ name: 'Juan' })
    },
    replace() {
      // this.hexList = [{ name: 'Edgard' }]
    },
    clone(el) {
      return {
        name: el.name + ' cloned'
      }
    },
    log(evt) {
      console.log(evt)
    },
    handleDragEnd() {
      this.futureItem = this.hexList[this.futureIndex]
      this.movingItem = this.hexList[this.movingIndex]
      const _items = Object.assign([], this.hexList)
      if (!this.frozenList.has(this.futureIndex) && this.movingItem.data) {
        // coordinate fixed
        _items[this.futureIndex] = {
          ... _items[this.futureIndex],
          data: this.movingItem.data
        }
        _items[this.movingIndex] = {
          ... _items[this.movingIndex],
          data: this.futureItem.data
        }
        // store new _items' position
        // this.storePosition(this.movingItem)
        // this.storePosition(this.futureItem)
        // console.log('ori:', this.movingItem)
        // console.log('movingTo:', this.futureItem)
        // store positions
        this.hexList = _items
        this.storePosition(this.hexList)
      }
    },
    handleMove(e) {
      const { index, futureIndex } = e.draggedContext
      this.movingIndex = index
      this.futureIndex = futureIndex
      return false // disable sort
    },
    clickfn(e) {
      if (this.permission) return
      if (!e.data) return
      if (e.data.clickfn) {
        e.data.clickfn()
      }
      if (e.data.url) {
        this.$router.push(e.data.url)
      }
    },
    getPosition(type, ItemIndex) {
      // w = 2 * size
      // h = sqrt(3) * size. The sqrt(3) comes from sin(60°).
      const size = parseFloat(this.hexItem.width) / 2 // hex r
      const itemW = size * 2
      const itemH = size * Math.sqrt(3)
      const XPos = (itemW, x, Xoffset) => 0.75 * itemW * x + Xoffset
      const YPos = (itemH, y, Yoffset) => itemH * y + Yoffset
      const Xoffset = 0
      const Yoffset = (x, itemH) => x % 2 !== 0 ? (itemH * 0.5) : 0 // 上下錯落
      if (type === 'logo') {
        const radius = this.logoRadius
        const startX = Math.floor((this.columns - radius) / 2) - 0.75
        const startY = Math.floor((this.rows - radius) / 2) - 1
        const blockWSpan = (0.75 + radius) * itemW
        const blockHSpan = (1 + (radius - 1) * 2) * itemH
        return {
          left: `${XPos(itemW, startX, Xoffset)}px`,
          top: `${YPos(itemH, startY, Yoffset(startX, itemH))}px`,
          width: `${blockWSpan}px`,
          height: `${blockHSpan}px`
        }
      }
      const { x, y } = ItemIndex
      return {
        left: `${XPos(itemW, x, Xoffset)}px`,
        top: `${YPos(itemH, y, Yoffset(x, itemH))}px`
      }
    }
  },
  created() {
    this.hexList = []
  },
  async mounted() {
    const width = `${this.$refs.hexGrid.clientWidth - 16}px`
    const height = `${this.$refs.hexGrid.clientHeight - 16}px`
    this.hexSize = { width, height }
    // console.log(this.hexSize)
    await this.$nextTick()
    this.initLayout()
  }
}
</script>
<style lang="scss" scoped>
// Rwd
.hex-info-box-4k {
  .overlay-container {
    -ms-transform: translate(-12px, -12px);
    transform: translate(-12px, -12px);
  }
  .hex-grid__list {
    font-size: calc(24px + 0.75vmin);
    line-height: 1;
    .hex-grid__item {
      padding: 8px;
    }
  }
  .hex-grid__item .hex-grid__detail {
    padding: 26px calc(17.5% + 4px);
  }
}
.hex-info-box-2k {
  .overlay-container {
    -ms-transform: translate(-12px, -12px);
    transform: translate(-12px, -12px);
  }
  .hex-grid__list {
    font-size: 24px;
    line-height: 1;
    .hex-grid__item {
      padding: 8px;
    }
  }
  .hex-grid__item .hex-grid__detail {
    padding: 18px calc(17.5% + 0px);
  }
}
.hex-info-box-lg {
  .overlay-container {
    -ms-transform: translate(-2px, -2px);
    transform: translate(-2px, -2px);
  }
  .hex-grid__list {
    font-size: 12px;
    line-height: 1;
  }
  .hex-grid__item .hex-grid__detail {
    padding: 5px 17.5%;
    b {
      -ms-transform: scale(0.9);
      transform: scale(0.9);
    }
  }
}
.hex-info-box-md {
  .overlay-container {
    -ms-transform: translate(-2px, -2px);
    transform: translate(-2px, -2px);
  }
  .hex-grid__list {
    font-size: 7pt;
    line-height: 1;
    .hex-grid__item {
      padding: 2px;
    }
  }
  .hex-grid__item .hex-grid__detail {
    padding: 3px 0px;
    -ms-transform: scale(0.99);
    transform: scale(0.99);
    b {
      -ms-transform: scale(0.83);
      transform: scale(0.83);
    }
  }
}
.hex-info-box-sm {
  .overlay-container {
    transform: translate(-2px, -2px);
  }
  .hex-grid__list {
    font-size: 12px;
    line-height: 0.9;
    .hex-grid__item {
      padding: 1px;
    }
  }
  .hex-grid__item .hex-grid__detail {
    // padding: 2px calc(17.5% + 1px);
    padding: 2px 0px;
    -ms-transform: translate(-3px, -3px) scale(0.6);
    transform: translate(-3px, -3px) scale(0.6);
    b {
      -ms-transform: scale(0.9);
      transform: scale(0.9);
    }
  }
}
.hex-info-box-xs {
  .overlay-container {
    -ms-transform: translate(0px, 0px);
    transform: translate(0px, 0px);
    margin: auto;
  }
  .hex-grid__list {
    // font-size: 6pt;
    line-height: 0.9;
    .hex-grid__item {
      padding: 1px;
    }
  }
  .hex-grid__item .hex-grid__detail {
    padding: 0px 0px;
    -ms-transform: translate(0px, 0px) scale(0.45);
    transform: translate(0px, 0px) scale(0.45);
    b {
      -ms-transform: scale(0.65);
      transform: scale(0.65);
    }
  }
}
.hex-zh-TW {
  &.hex-info-box-lg {
    .hex-grid__item .hex-grid__detail {
      font-size: 14px;
      b {
        -ms-transform: scale(1);
        transform: scale(1);
      }
    }
  }
  &.hex-info-box-md {
    .hex-grid__item .hex-grid__detail {
      font-size: 12px;
      padding: 3px 0px;
      -ms-transform: scale(0.975);
      transform: scale(0.975);
      b {
        -ms-transform: scale(1.1);
        transform: scale(1.1);
      }
    }
  }
  &.hex-info-box-sm {
    .hex-grid__item .hex-grid__detail {
      font-size: 12px;
      // -ms-transform: translate(0px, 0px) scale(0.5);
      // transform: translate(0px, 0px) scale(0.5);
      b {
        -ms-transform: scale(1);
        transform: scale(1);
      }
    }
  }
  &.hex-info-box-xs {
    .hex-grid__item .hex-grid__detail {
      font-size: 12px;
      -ms-transform: translate(0px, 0px) scale(0.65);
      transform: translate(0px, 0px) scale(0.65);
      b {
        -ms-transform: scale(1);
        transform: scale(1);
      }
    }
  }
}
.hex-info-box {
  position: relative;
  width: 100%;
  height: 100%;
  margin: 0 auto;
  overflow: hidden;
  --bg-color: #178;
  --hex-color: #42545d;
  --hex-mask: rgba(255, 255, 255, 0.8);
  --text-color: #111;
  --danger: #FF0007;
  --warning: #FFF002;
  &.hex-dark {
    // $bg-color: #178;
    --bg-color: rgba(0, 0, 0, 0);
    --hex-color: #42545d;
    --hex-mask: rgba(92, 113, 124, 0.5);//rgba(255, 255, 255, 0.8);
    --text-color: #fff;
    // --emptyHex: rgba(0, 0, 0, 0.05);
    --emptyHex: rgba(35, 38, 47, 0);
  }
}
.overlay-container {
  user-select: none;
  display: flex;
  align-items: center;
  justify-items: center;
  position: absolute;
  // top: 0;
  // bottom: 0;
  // left: 0;
  // right: 0;
  // margin: auto;
  padding: 1rem;
  z-index: 1;
  // 對應 hex grid padding
  transform: translate(-0.15rem, -0.15rem);
}
.logo-wrap {
  width: 100%;
  height: 100%;
  opacity: 1;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  .logo-container {
    width: 65%;
    max-width: 300px;
    // margin: auto;
    z-index: 99;
    img {
      width: 100%;
    }
  }
  // img {
  //   width: 100%;
  // }
  // &:after {
  //   content: '';
  //   display: block;
  //   padding-bottom: 100%;
  // }
}
// 六角蜂格 Group 容器
.hex-grid__list {
  position: relative;
  width: 100%;
  height: 100%;
  .hex-grid__item {
    position: absolute;
    padding: .15rem;
    .hex-grid__content{
      overflow: hidden;
      height: 100%;
      width: 100%;
      svg {
        width: 100%;
        height: 100%;
        &.hexSvg {
          path {
            stroke: #42545d;
            stroke-width: 2px;
            stroke-linejoin: round;
            fill: #4F636C;
          }
        }
      }
      &.clickable {
        cursor: pointer;
      }
      &.grabale {
        // cursor: pointer;
        cursor: grab;
      }
      &.up {
        .hexSvg {
          path {
            stroke:#01FF00;
            stroke-width: 2px;
            stroke-linejoin: round;
            fill: rgba(#01FF00, 1);
          }
        }
      }
      &.danger {
        .hexSvg {
          path {
            stroke:#FF0007;
            stroke-width: 2px;
            stroke-linejoin: round;
            fill: rgba(#FF0007, 1);
          }
        }
      }
      &.warning {
        .hexSvg {
          path {
            stroke: #FFF002;
            stroke-width: 2px;
            stroke-linejoin: round;
            fill: rgba(#FFF002, 1);

          }
        }
      }
      &.empty {
        .hexSvg {
          path {
            stroke: rgba(0, 0, 0, 0);
            stroke-width: 2px;
            stroke-linejoin: round;
            fill: rgba(0, 0, 0, 0);
          }
        }
      }
    }
    // draggable
    &.hex-grid__draggable {
      z-index: 3;
      &:not(.hex-grid--empty) {
        // cursor: grab;
        z-index: 3;
        &:hover {
          transform: scale(1.05);
          transition: .2s;
          z-index: 4;
        }
      }
    }
    .hex-grid__detail {
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    &.loading {
      overflow: hidden;
    }
  }
  .clickable {
    cursor: pointer;
  }
}

</style>
