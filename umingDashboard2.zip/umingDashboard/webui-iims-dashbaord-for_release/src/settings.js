module.exports = {
  title: 'U-MING IT Monitoring System',
  publicPath: process.env.VUE_APP_PUBLICPATH || '/',
  version: require('../package.json').version,
  api: {
    iims: process.env.VUE_APP_API_URL,
    nagiosxi: process.env.VUE_APP_NAGIOSXI_API_URL,
    thruk: process.env.VUE_APP_THRUK_API_URL
  },
  config: {
    nagiosxiLink: process.env.VUE_APP_NAGIOSXILINK,
    thrukKey: process.env.VUE_APP_THRUKKEY
  }
}
