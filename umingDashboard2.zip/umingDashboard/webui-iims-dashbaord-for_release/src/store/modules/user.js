import router from '@/router'
import IIMS from '@/api/iims'
import roleType from '@/store/static/roleType.json'
import axios from '@/vendor/axios'
import settings from '@/settings.js'

const state = {
  token: null,
  authority: null,
  name: null,
  isExpired: false,
  thrukKey: settings.config.thrukKey,
  nagiosxiLink: settings.config.nagiosxiLink
}
const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_AUTHORITY: (state, authority) => {
    state.authority = authority
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_EXPIRED: (state, status) => {
    state.isExpired = status
  }
}

const actions = {
  // user login
  async login({ commit, dispatch }, userInfo) {
    const { account, password } = userInfo
    // console.log(account + ' ' + password)
    return new Promise((resolve, reject) => {
      IIMS.loginAd({
        account: account,
        password: password
      })
        .then(function(response) {
          if (!response.data) {
            reject(response.data)
          }
          const userData = {
            ...response.data.data,
            authority: roleType[response.data.data.role]
          }
          // login
          sessionStorage.setItem('user', JSON.stringify(userData))
          dispatch('storeUserData', userData)
          resolve(userData)
          if (userData.tokenExpiredDuration > 0) {
            setTimeout(() => {
              console.log('Token is expired')
              dispatch('logout')
              dispatch('storeUserData', null)
              sessionStorage.clear()
              router.push('/pages/login').catch(() => { })
            }, userData.tokenExpiredDuration * 1000)
          }
        })
        .catch(function(error) {
          console.error(error)
          reject(error)
        })
    })
  },
  // user logout
  async logout({ commit }) {
    // console.log(sessionStorage.getItem('user'))
    return new Promise((resolve, reject) => {
      IIMS.logout()
        .then(function(response) {
          resolve(response)
        })
        .catch(function(error) {
          console.error(error)
          reject(error)
        })
    })
  },
  storeUserData({ commit }, userData) {
    // userData
    // console.log('storeUserData', userData)
    if (userData && JSON.stringify(userData) !== '{}') {
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + userData.token
      commit('SET_TOKEN', userData.token)
      commit('SET_AUTHORITY', userData.authority)
      commit('SET_NAME', userData.name)
    } else {
      axios.defaults.headers.common['Authorization'] = ''
      commit('SET_TOKEN', null)
      commit('SET_AUTHORITY', null)
      commit('SET_NAME', null)
    }
  },
  async trackEvent({ commit }, data) {
    console.log(
      `%c${data.category} || ${data.action} || ${new Date()}`,
      'color:#1188c0; background: #f6f8fa; padding: 5px;'
    )
    try {
      await IIMS.trackEvent(data)
    } catch (error) {
      console.error(error)
      // if (error.response.status === 400) {
      //   await IIMS.trackEvent({
      //     ...data,
      //     action: 'Click'
      //   })
      // }
    }
  }
}
const getters = {
  user: state => {
    return {
      name: state.name,
      authority: state.authority,
      token: state.token
    }
  },
  thrukKey: state => state.thrukKey,
  nagiosxiLink: state => state.nagiosxiLink,
  isExpired: state => state.isExpired
}

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters
}
