// Nagiosxi Controller
import Nagiosxi from '@/api/nagiosxi'
const getReadableFileSizeString = (fileSizeInBytes) => {
  let i = -1
  const byteUnits = [' kbps', ' Mbps', ' Gbps', ' Tbps', 'Pbps', 'Ebps', 'Zbps', 'Ybps']
  do {
    fileSizeInBytes = fileSizeInBytes / 1024
    i++
  } while (fileSizeInBytes > 1024)

  return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i]
}
const state = {
  hosts: null, // all hosts
  allBoats: [], // _@@@
  boatsWan1: [],
  Satellite: [],
  contacts: null, // all contacts
  hostGroups: null, // 所有 hostgroups,
  boats: null, // statelite hexgrid
  boatsList: null,
  timer: false,
  vesselPosition: null,
  getBoatFlag: false
}

const mutations = {
  SET_TIMER: (state, data) => {
    state.timer = data
  },
  SET_HOSTS: (state, data) => {
    state.hosts = data
  },
  SET_ALL_BOATS: (state, data) => {
    state.allBoats = data
  },
  SET_BOATS_WAN1: (state, data) => {
    state.boatsWan1 = data
  },
  SET_BOATS_SATELLITE: (state, data) => {
    state.Satellite = data
  },
  SET_HOSTDISPLAYNAME: (state, data) => {
    state.hostDisplaynames = data
  },
  SET_HOSTGROUPS: (state, data) => {
    state.hostGroups = data
  },
  SET_BOATS: (state, data) => {
    state.boats = data.sort((a, b) => {
      return a.name.toLowerCase().localeCompare(b.name.toLowerCase())
    })
  },
  SET_BOATSLIST: (state, data) => {
    state.boatsList = data
  },
  SET_VESSELPOSITION: (state, data) => {
    state.vesselPosition = data
  },
  SET_BOATFLAG: (state, status) => {
    state.getBoatFlag = status
  }
}

const actions = {
  timer({ commit, dispatch, state }) {
    setTimeout(() => {
      console.log(
        `%cTimer ${state.timer} || Vessel data || ${new Date()}`,
        'color:#11ccc0; background: #f6f8fa; padding: 5px;'
      )
      if (state.timer === true && state.boats) {
        dispatch('getBoats')
      }
      dispatch('timer')
    }, 120000)
  },
  setTimer({ commit }, boolean) {
    commit('SET_TIMER', boolean)
  },
  async getAllBoats({ commit }) {
    try {
      const response = await Nagiosxi.thruk(`/hostgroups?notes[regex]=@@@`)
      commit('SET_ALL_BOATS', response.data)
    } catch (err) {
      console.log(err)
    }
  },
  async getBoatWAN1Data({ commit }) {
    try {
      const response = await Nagiosxi.thruk(`/services?description=If WAN1&columns=contact_groups,host_groups,host_name,host_display_name,perf_data,state`)
      commit('SET_BOATS_WAN1', response.data)
    } catch (err) {
      console.log(err)
    }
  },
  async getBoatSatelliteData({ commit }) {
    try {
      const response = await Nagiosxi.thruk(`/services?groups[regex]=Satellite&columns=state,last_check,last_time_ok,host_name,display_name,host_display_name,host_alias,display_name,description`)
      // &columns=state,host_name
      commit('SET_BOATS_SATELLITE', response.data)
    } catch (err) {
      console.log(err)
    }
  },
  async getBoats({ state, commit, dispatch }) {
    const lang = JSON.parse(localStorage.getItem('lang')) || 'zh-TW'
    if (state.getBoatFlag) return
    try {
      // SET_BOATFLAG
      commit('SET_BOATFLAG', true)
      // get all boats
      if (state.allBoats.length === 0) await dispatch('getAllBoats')
      // 名稱
      // TODO: .1.1 是主機 _Status 的 members 裡會沒有 .1.1
      // 船隻狀態 & 連線速度
      if (state.boatsWan1.length === 0) await dispatch('getBoatWAN1Data')
      const boatWAN1Data = state.boatsWan1
      // services keyWords
      const boatKeywords = boatWAN1Data.map(d => d.host_name.split('_')[0] || '').join('_Status|')
      // const vesselHostKeywords = boatWAN1Data.map(d => d.host_display_name).join('|')
      // get all services
      // host_display_name[regex]=${vesselHostKeywords}&
      // const vesselHost = await Nagiosxi.thruk(`/services?host_display_name[regex]=${vesselHostKeywords}_Status&columns=description,display_name,groups,host_address,host_alias,host_display_name,host_groups,host_name,host_perf_data,host_state,perf_data,state`)
      const boatData = await Nagiosxi.thruk(`/services?host_groups[regex]=${boatKeywords}_Status&columns=description,display_name,groups,host_address,host_alias,host_display_name,host_groups,host_name,host_perf_data,host_state,perf_data,state,notes`)
      // const Satellite = await Nagiosxi.thruk(`/services?groups[regex]=Satellite`)
      await dispatch('getBoatSatelliteData')
      const Satellite = state.Satellite
      // mapping all boat datas
      const boats = state.allBoats
        .filter(d => !d.name.match('_Status'))
        .map(d => {
          const eName = d.notes.split('_')[0] || 'boat'
          const cName = d.notes.split('_')[1] || '船名'
          const vesselCode = d.notes.split('_')[2] || ''
          const boatHost = boatWAN1Data.find(boat => boat['host_groups'].indexOf(d.name) > -1) || {}
          const Satellite_stats = (Satellite || []).find(({ host_name }) => host_name.indexOf(d.name) > -1)
          const boatSla = {
            state: 0,
            bpsin: 0,
            bpsin_display: '--',
            bpsout: 0,
            bpsout_display: '--'
          }
          if (Satellite_stats && Satellite_stats.state === 0 && boatHost.perf_data) {
            boatHost.perf_data.split(' ')
              .reduce((map, val) => {
                const key = val.split('=')[0]
                map[key] = val.split('=')[1].split(';')
                if (val.split('=')[0] === 'bpsin' || val.split('=')[0] === 'bpsout') {
                  const value = parseFloat(val.split('=')[1].split(';')[0], 10)
                  map[key + '_display'] = getReadableFileSizeString(value) || '--'
                }
                return map
              }, boatSla)
          }
          const membersData = boatData.data
            .filter(boat => boat.groups.indexOf(d.name) > -1 && boat.display_name === 'Uptime')
          boatSla.state = Satellite_stats.state > 0
            ? 2
            : Math.max(...membersData.map(d => d.state)) !== 0
              ? 1
              : 0
          // state
          return {
            ...d,
            boatSla,
            boat_display_name: lang === 'zh-TW'
              ? `${cName}`
              : `${eName}`,
            url: `/vessel/${eName}/all`,
            vesselCode,
            name: eName
            // membersData
          }
        })
      commit('SET_BOATS', boats)
      // dispatch('timer')
    } catch (err) {
      console.log(err)
    } finally {
      commit('SET_BOATFLAG', false)
    }
  }
}
const getters = {
  hosts: state => state.hosts,
  services: state => state.services,
  contacts: state => state.contacts,
  hostGroups: state => state.hostGroups,
  boats: state => state.boats,
  boatsList: state => state.boats,
  Satellite: state => state.Satellite,
  SlaStatus: (state, getters) => {
    // const download = ['1M+', '512K~1M', '1K~512K', '0']
    // const upload = ['256K+', '128K~256K', '1K~128K', '0']
    const download = {
      '1M+': [],
      '512K~1M': [],
      '1K~512K': [],
      'Disconnect': []
    }
    const upload = {
      '256K+': [],
      '128K~256K': [],
      '1K~128K': [],
      'Disconnect': []
    }
    if (!getters.boats) return null
    getters.boats.forEach(d => {
      const bpsin = d.boatSla.bpsin[0] || 0
      const bpsout = d.boatSla.bpsout[0] || 0
      if (bpsin === 0) download['Disconnect'].push(d)
      if (bpsout === 0) upload['Disconnect'].push(d)
      if (bpsin > 0 && bpsin < 524288) download['1K~512K'].push(d)
      if (bpsout > 0 && bpsout < 131072) upload['1K~128K'].push(d)
      if (bpsin >= 524288 && bpsin < 1048576) download['512K~1M'].push(d)
      if (bpsout >= 131072 && bpsout < 262144) upload['128K~256K'].push(d)
      if (bpsin >= 1048576) download['1M+'].push(d)
      if (bpsout >= 262144) upload['256K+'].push(d)
    })
    return {
      total: state.boats.length || 0,
      download,
      upload
      //  download.reduce((map, val) => { map[val] = (map[val] || 0) + 1; return map }, {}),
      // upload.reduce((map, val) => { map[val] = (map[val] || 0) + 1; return map }, {})
    }
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters
}
