// import { hashPassword } from '@/shared/hash'
// import router from '@/router'
import IIMS from '@/api/iims'
// import axios from '@/vendor/axios'

const state = {
  positions: []
}

const mutations = {
  SET_POSITION: (state, positions) => {
    state.positions = positions
  }
}

const actions = {
  // user login
  async getGlobalShipPosition({ commit }, data) {
    try {
      const { data } = await IIMS.getGlobalShipPosition()
      commit('SET_POSITION', data?.data || [])
    } catch (error) {
      console.error(error)
    }
  },
  async getPosition({ commit }, data) {
    try {
      const { data } = await IIMS.getShipPosition()
      commit('SET_POSITION', data?.data || [])
    } catch (error) {
      console.error(error)
    }
  },
  async setPosition({ commit }, positions) {
    commit('SET_POSITION', positions)
  },
  async storePosition({ commit, dispatch }, data) {
    const vessel = data
      .filter(({ data }) => data)
      .map(d => {
        return {
          coordinate: {
            x: d.x,
            y: d.y,
            z: d.z
          },
          host_display_name: d.data.vesselCode
        }
      })
    try {
      await IIMS.storeShipPosition({
        data: vessel
      })
      dispatch('setPosition', vessel)
      dispatch('getPosition')
    } catch (error) {
      console.log(error)
    }
  }
}
const getters = {
  positions: state => state.positions
}

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters
}
