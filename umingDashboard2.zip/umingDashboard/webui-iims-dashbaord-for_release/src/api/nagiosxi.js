import settings from '@/settings'
import store from '@/store'

// nagiosxi Data
// r/services : 全部 service 狀態資料
// r/contacts : 全部 contacts
// r/hostgroups : 全部 hostgroups 與其中的 host 清單
// r/hosts/<name>/services : 指定 host 與全部 service 狀態資料
// r/hostgroups/<name>/stats : 指定 hostgroups 與其中 host 數量與狀態統計
// r/ 全部可用的 API url 與說明
class Nagiosxi {
  static get baseUrl() {
    // vue proxy
    // return settings.api.iims
    return process.env.NODE_ENV === 'development'
      ? '/thrukApi'
      : settings.api.thruk
  }
  static get apikey() {
    // vue proxy
    return store.getters['user/thrukKey']
  }
  static api(queryString) {
    return axios.get(`${this.baseUrl}/nagiosxi/api/v1/objects/${queryString}?apikey=ruvUA5XGOlk9CmfLFdTYLecNsGL7ClAjS5tJarFePfHHFVoA9huaP0dBGYHujdQs&pretty=1`)
  }
  static thruk(queryString) {
    return axios.get(`${this.baseUrl}/thruk/r${queryString}`,
      {
        headers:
          { 'X-Thruk-Auth-Key': this.apikey }
      })
  }
  // 全部 host 狀態資料
  // static getHosts(queryString) {
  //   return axios.get(`${this.baseUrl}/thruk/r/hosts${queryString ? '?' + queryString : ''}`,
  //     { headers:
  //       { 'X-Thruk-Auth-Key': this.apikey }
  //     })
  // }
  // static getHost(name) {
  //   return axios.get(`${this.baseUrl}/thruk/r/host/${name}`,
  //     {
  //       headers:
  //         { 'X-Thruk-Auth-Key': this.apikey }
  //     })
  // }
  // static getHostService(name) {
  //   return axios.get(`${this.baseUrl}/thruk/r/host/${name}/service`,
  //     {
  //       headers:
  //         { 'X-Thruk-Auth-Key': this.apikey }
  //     })
  // }
  // 全部 service 狀態資料
  // static getServices(queryString) {
  //   return axios.get(`${this.baseUrl}/thruk/r/services${queryString ? '?' + queryString : ''}`,
  //     {
  //       headers:
  //         { 'X-Thruk-Auth-Key': this.apikey }
  //     })
  // }

  // 全部 service 狀態資料
  // static getContacts(queryString) {
  //   return axios.get(`${this.baseUrl}/thruk/r/contacts${queryString ? '?' + queryString : ''}`,
  //     {
  //       headers:
  //         { 'X-Thruk-Auth-Key': this.apikey }
  //     })
  // }

  // 全部 hostgroups 與其中的 host 清單
  // static getHostgroups(queryString) {
  //   return axios.get(`${this.baseUrl}/thruk/r/hostgroups${queryString ? '?' + queryString : ''}`,
  //     {
  //       headers:
  //         { 'X-Thruk-Auth-Key': this.apikey }
  //     })
  // }
  // static getHostgroup(queryString) {
  //   return axios.get(`${this.baseUrl}/thruk/r/hostgroup/${queryString ? '?' + queryString : ''}`,
  //     {
  //       headers:
  //         { 'X-Thruk-Auth-Key': this.apikey }
  //     })
  // }
  // static getHostgroupStats(groupName) {
  //   return axios.get(`${this.baseUrl}/thruk/r/hostgroup/${groupName}/stats`,
  //     {
  //       headers:
  //         { 'X-Thruk-Auth-Key': this.apikey }
  //     })
  // }
  // static getServicegroup(groupName) {
  //   return axios.get(`/thrukApi/thruk/r/servicegroups/${groupName}/stats`,
  //     {
  //       headers:
  //         { 'X-Thruk-Auth-Key': this.apikey }
  //     })
  // }
}

export default Nagiosxi

