import settings from '@/settings'
import Qs from 'qs'

class IIMS {
  static get baseUrl() {
    // vue proxy
    // return settings.api.iims
    return process.env.NODE_ENV === 'development'
      ? '/iimsApi'
      : settings.api.iims
  }
  static login(data) {
    return axios.post(`${this.baseUrl}/login`, data)
  }
  static loginAd(data) {
    return axios.post(`${this.baseUrl}/loginAd`, data)
  }
  static logout() {
    return axios.post(`${this.baseUrl}/logout`)
  }

  static getUsers(queryString) {
    return axios.get(`${this.baseUrl}/user${queryString || ''}`)
  }

  static deleteUser(userId) {
    return axios.delete(`${this.baseUrl}/user/${userId}`)
  }

  static getShipPosition() {
    return axios.get(`${this.baseUrl}/user/me/shipPosition`)
  }

  static storeShipPosition(data) {
    return axios.post(`${this.baseUrl}/user/me/shipPosition`, data)
  }

  static Userconfig(data) {
    return axios.post(`${this.baseUrl}/user/config`, data)
  }

  static influxDb(string) {
    return axios.post(`${this.baseUrl}/influxDb/query`,
      Qs.stringify({
        db: 'collection',
        u: 'collectread',
        p: 'collectread',
        q: btoa(unescape(encodeURIComponent(string))) // BASE 64 encode Query String
      }),
      {
        headers: { 'content-type': 'application/x-www-form-urlencoded' }
      }
    )
  }

  // Monitor --------------------------
  static getLiveUser() {
    return axios.get(`${this.baseUrl}/monitor/liveUser`)
  }

  // trackEvent --------------------------
  static trackEvent(data) {
    return axios.post(`${this.baseUrl}/monitor/trackEvent`, data)
  }

  // Report --------------------------
  static userSummary(params) {
    const query = Qs.stringify(params)
    return axios.get(`${this.baseUrl}/report/userSummary?${query}`)
  }
  static userActivity(params) {
    const query = Qs.stringify(params)
    return axios.get(`${this.baseUrl}/report/userActivity?${query}`)
  }
  // Report download
  static exportCsvUserSummary(params) {
    const query = Qs.stringify(params)
    return axios.get(`${this.baseUrl}/report/exportCsvUserSummary?${query}`, {
      responseType: 'blob' // arraybuffer
    })
  }
  static exportCsvUserActivity(params) {
    const query = Qs.stringify(params)
    return axios.get(`${this.baseUrl}/report/exportCsvUserActivity?${query}`, {
      responseType: 'blob' // arraybuffer
    })
  }

  // Chart --------------------------
  // 圖表: 每小時或每日的系統使用人數
  static userCountEachHoursOrDays(params) {
    const query = Qs.stringify(params)
    return axios.get(`${this.baseUrl}/chart/userCountEachHoursOrDays?${query}`)
  }
  // 圖表: 每個帳號總使用次數
  static usageCountEachAccount(params) {
    const query = Qs.stringify(params)
    return axios.get(`${this.baseUrl}/chart/usageCountEachAccount?${query}`)
  }
  // 圖表: 每個帳號平均使用時間(秒數)
  static liveAverageEachAccount(params) {
    const query = Qs.stringify(params)
    return axios.get(`${this.baseUrl}/chart/liveAverageEachAccount?${query}`)
  }
  // 圖表: 每個帳號使用那些功能與多少時間(秒數)
  static timeCategoryEachAccount(params) {
    const query = Qs.stringify(params)
    return axios.get(`${this.baseUrl}/chart/timeCategoryEachAccount?${query}`)
  }
  // 圖表:每個功能被使用的總次數與總時間(秒數)
  static usageEachCategory(params) {
    const query = Qs.stringify(params)
    return axios.get(`${this.baseUrl}/chart/usageEachCategory?${query}`)
  }

  // Setting --------------------------
  // help page
  static getGlobalconfig() {
    return axios.get(`${this.baseUrl}/setting/globalConfig`)
  }
  static putGlobalconfig(data) {
    return axios.put(`${this.baseUrl}/setting/globalConfig`, data)
  }
  // /setting/globalShipPosition
  static getGlobalShipPosition() {
    return axios.get(`${this.baseUrl}/setting/globalShipPosition`)
  }
  static storeGlobalShipPosition(data) {
    return axios.put(`${this.baseUrl}/setting/globalShipPosition`, data)
  }
}
export default IIMS

