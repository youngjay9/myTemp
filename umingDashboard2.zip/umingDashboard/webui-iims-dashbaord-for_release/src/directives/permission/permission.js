import store from '@/store'
export default {
  inserted(el, binding) {
    const { value } = binding
    if (value && value instanceof Array && value.length > 0) {
      const permissionRoles = value
      const user = store.getters.user
      const hasPermission = permissionRoles.includes(user.authority)
      if (!hasPermission) {
        el.parentNode && el.parentNode.removeChild(el)
      }
    } else {
      throw new Error(`need roles! Like v-permission="[1,2]"`)
    }
  }
}
