import router from './router'
import store from './store'

router.beforeEach(async(to, from, next) => {
  // 重新取得登入資訊
  // await store.dispatch('user/getInfo')
  const user = store.getters['user/user']
    ? store.getters['user/user'].authority
      ? store.getters['user/user']
      : JSON.parse(sessionStorage.getItem('user') || '{}')
    : JSON.parse(sessionStorage.getItem('user') || '{}')
  if (!store.getters['user/user'].token) {
    await store.dispatch('user/storeUserData', JSON.parse(sessionStorage.getItem('user') || '{}'))
  }
  // 已登入
  if (to.path === '/pages/login' && user && user.authority) {
    next({ path: '/' })
    return
  }
  const role = Object.values(to.meta.role || {})
  if (Object.keys(role).length === 0) {
    // 不須權限
    next()
    return
  }
  const chkPermission = (authority) => role.indexOf(authority) > -1
  const hasPermission = chkPermission(user.authority)
  if (!hasPermission) {
    // 無權限
    console.log('no Permission')
    sessionStorage.clear()
    next({ path: '/pages/login' })
    return
  }
  try {
    const login = from.name === 'Login'
    // all boats name
    // if (login || !store.getters['nagiosxi/boatsList']) {
    //   await store.dispatch('nagiosxi/getBoats')
    // }
    if (login || !store.getters['nagiosxi/boatsList']) {
      store.dispatch('nagiosxi/getBoats')
      store.dispatch('nagiosxi/timer')
    }
  } catch (error) {
    console.error(error)
    sessionStorage.clear()
    next({ path: '/pages/login' })
    throw error
  }

  next() // 有權限
  return
})
