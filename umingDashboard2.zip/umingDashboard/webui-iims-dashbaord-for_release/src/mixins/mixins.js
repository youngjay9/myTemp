import { date } from 'quasar'
export default {
  methods: {
    getDateDiff(timeString) {
      const days = 0
      let timeLeft = days * 24 * 60 * 60 * 1000
      // if (date.getDateDiff(timeString * 1000, timeLeft, 'hours') > 24) {
      //   days = date.getDateDiff(timeString * 1000, timeLeft, 'days')
      //   timeLeft = timeLeft + (days * 24 * 60 * 60 * 1000)
      // }
      const hours = date.getDateDiff(timeString * 1000, timeLeft, 'hours')
      timeLeft = timeLeft + (hours * 60 * 60 * 1000)
      const mins = date.getDateDiff(timeString * 1000, timeLeft, 'minutes')
      timeLeft = timeLeft + (mins * 60 * 1000)
      const secs = date.getDateDiff(timeString * 1000, timeLeft, 'seconds')
      return `
    ${days
    ? days === 1
      ? days + 'day'
      : days + 'days'
    : ''}
    ${hours ? hours === 1
    ? hours + 'hr'
    : hours + 'hrs'
    : ''}
    ${mins ? mins === 1
    ? mins + 'min'
    : mins + 'mins'
    : ''}
    ${secs ? secs === 1
    ? secs + 'sec'
    : secs + 'secs'
    : ''}`
      // return timeString + '秒'
    },
    // download
    downloadCSV(data, fileName) {
      if (!data) return
      const csvFileName = `${fileName}.csv`
      if (window.navigator.msSaveBlob) {
        // Internet Explorer
        window.navigator.msSaveBlob(new Blob([data]), csvFileName)
      } else if (window.webkitURL != null) {
        // Google Chrome and Mozilla Firefox
        const url = window.URL.createObjectURL(data)
        var a = document.createElement('a')
        a.href = url
        a.style.display = 'none'
        a.download = csvFileName
        a.click()
      } else if (navigator.appName === 'Microsoft Internet Explorer') {
        // Internet Explorer 8 and 9
        var oWin = window.open()
        oWin.document.write('sep=,\r\n' + data)
        oWin.document.close()
        oWin.document.execCommand('SaveAs', true, csvFileName)
        oWin.close()
      } else {
        // Everything Else
        window.open(data)
      }
    }
  }
}
