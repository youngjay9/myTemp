<template>
<q-page class="flex flex-center bg-blue-grey-10 login-bg">
  <div class="flex flex-center login-container">
    <div class="logo-container-login">
      <img class="logo-img" src="@/assets/image/UM-logo.png" alt="UM Logo">
    </div>
    <div class="login-title">
      U-MING IT Monitoring System
    </div>
    <div class="login">
      <div class="q-pa-md" style="width: 380px;">
        <q-form
          @submit="onSubmit"
          class="q-pa-md column q-gutter-md login-box">
          <q-input
            trim
            v-model="loginForm.account"
            :label="$t('form.username')"
            lazy-rules
            :rules="[ val => val && val.length > 0 || $t('validation.empty')]"
          />
          <q-input
            trim
            type="password"
            v-model="loginForm.password"
            :label="$t('form.password')"
            lazy-rules
            :rules="[ val => val && val.length > 0 || $t('validation.empty')]"
          />
          <div class="text-centet bg-negative q-pa-md rounded-borders" v-if="response.show">
          {{response.msg}}
          </div>
          <div class=" text-center">
            <q-btn
              :loading="isPending"
              :disable="isPending"
              no-caps
              type="submit"
              color="primary"
              class="full-width"
              size="md">
              {{ $t('form.login') }}
            </q-btn>
          </div>
          <div class="text-center lang-switch">
            <q-btn-toggle
              name="lang"
              v-model="lang"
              @input="changeLang"
              flat
              no-caps
              dense
              toggle-color="primary"
              spread
              :options="[
                {label: '中文', value: 'zh-TW'},
                {label: 'English', value: 'en-US'}
              ]"
            />
          </div>
        </q-form>
      </div>
    </div>
  </div>
</q-page>
</template>

<script>
import { mapActions } from 'vuex'

export default {
  name: 'Login',
  data() {
    return {
      loginForm: {
        account: '',
        password: ''
        // account: 'fe1',
        // password: 'Init1234'
      },
      response: {
        show: false,
        msg: ''
      },
      lang: 'zh-TW',
      error: null,
      isPending: false,
      siteVerify: true
    }
  },
  watch: {
    'loginForm.account'() {
      this.response.show = false
    },
    'loginForm.password'() {
      this.response.show = false
    }
  },
  methods: {
    ...mapActions({
      login: 'user/login',
      setPosition: 'vessel/setPosition',
      setTimer: 'nagiosxi/setTimer'
    }),
    changeLang() {
      this.$i18n.locale = this.lang
      localStorage.setItem('lang', JSON.stringify(this.lang))
    },
    async onSubmit() {
      this.isPending = true
      try {
        const res = await this.login(this.loginForm)
        if (res) {
          this.$router.push('/overall')
          this.setTimer(true)
          // if (res.shipPosition) {
          //   this.setPosition(JSON.parse(res.shipPosition)?.data)
          // }
          this.changeLang()
        } else {
          this.response.show = true
          this.response.msg = 'login error'
        }
      } catch (error) {
        this.isPending = false
        console.error(error)
        this.response.show = true
        this.response.msg = error.response?.data?.errMsg || 'login error'
      }
    }
  },
  async mounted() {
    this.setTimer(false)
    sessionStorage.clear()
    this.$q.dark.set(true)
    this.lang = JSON.parse(localStorage.getItem('lang')) || 'zh-TW'
    this.$i18n.locale = this.lang
  }
}
</script>
<style lang="scss" scoped>
// fix for IE
.loginPage {
  height: 600px;
}
</style>
