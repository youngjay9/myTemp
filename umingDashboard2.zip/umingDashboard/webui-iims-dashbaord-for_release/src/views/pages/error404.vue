<template>
<q-page class="flex flex-center">
  <!-- <div class="container"> -->
    <div class="items-center">
      <h1 class="q-ma-none">404</h1>
      <h4 class="q-mt-xs q-mb-sm">Oops! You're lost.</h4>
      <p class="text-muted">The page you are looking for was not found.</p>
    </div>
  <!-- </div> -->
</q-page>
</template>

<script>
export default {
  name: 'Page404'
}
</script>
