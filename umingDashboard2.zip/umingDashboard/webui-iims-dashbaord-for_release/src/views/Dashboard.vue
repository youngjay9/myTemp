<template>
 <q-page class="Dashboard full-height">
    <div class="row">
      <div class="left-col items-stretch">
        <div class="column full-height q-col-gutter-xs">
          <div class="col-3" v-for="item in hostGroupsData" :key="item.name">
            <q-card class="my-card full-height">
              <transition-group
                appear
                enter-active-class="animate__animated animate__fadeIn"
                leave-active-class="animate__animated animate__fadeOut">
                <q-card-section  class="q-pa-xs" :key="'title-' + item.name">
                  <q-btn v-if="!item.url"  align="left" class="text-weight-bold full-width" dense flat color="primary" :label="$t(`topView.${item.name}`)" @click="showSummary = true"/>
                  <q-btn v-else  align="left" class="text-weight-bold full-width" dense flat color="primary" :label="$t(`topView.${item.name}`)" :to="item.url"/>
                </q-card-section>
                <q-card-section class="q-pa-none chart" v-if="item.data" :key="'chart-' + item.name" style="'min-height': 255px">
                  <template v-if="item.chartType === 'DougnhutChart'">
                    <DougnhutChart :chartId="'cht-' + item.name" :data="DoughnutData(item.data)" style="height: 195px"/>
                  </template>
                  <template v-if="item.chartType === 'BarChart'">
                    <BarChart :chartId="'cht-' + item.name" :data="BarData(item.data)"/>
                  </template>
                </q-card-section>
                <div v-else :key="'loading-' + item.name">
                  <q-linear-progress dark query class="q-mt-sm" />
              </div>
              </transition-group>
            </q-card>
          </div>
        </div>
      </div>
      <div class="center-col items-strech">
        <div class="column full-height q-col-gutter-xs">
          <div class="col" ref="overall">
            <q-card class="my-card full-height">
              <q-card-section
                class="bg-blue-grey-10 hexgridContainer q-pa-sm"
                :style="hexSize"
                >
                <transition
                  appear
                  enter-active-class="animate__animated animate__fadeIn"
                  leave-active-class="animate__animated animate__fadeOut">
                  <HexGrid
                    v-if="hexSize"
                    :darkMode="$q.dark.isActive"
                    :storePosition="storePosition"
                    :permission="permission"
                    :size="hexSize"
                    :data="hexdata"/>
                </transition>
              </q-card-section>
              <q-card-section class="text-right q-ma-none q-pa-xs no-wrap cursor-pointer">
                <q-icon name="info" size="sm"  @click="helpInfo = true"/>
              </q-card-section>
              <q-card-section class="row flex flex-center no-wrap" v-if="SlaStatusData">
                <SlaStatus class="col-10" :data="SlaStatusData"/>
              </q-card-section>
            </q-card>
          </div>
        </div>
      </div>
      <div class="right-col items-strech">
        <div class="column full-height q-col-gutter-xs">
          <div class="">
            <q-select
              filled
              use-input
              fill-input
              hide-selected
              dense
              options-dense
              hide-dropdown-icon
              v-model="searchText"
              input-debounce="0"
              :auto-close="false"
              :options="filterOptions"
              @filter="filterFn">
              <template v-slot:prepend>
                <q-icon name="search" />
              </template>
              <template v-slot:selected>
                  {{ searchText.name }} （{{ searchText.alias.split('_')[1] }} {{ searchText.vesselCode}}）
              </template>
                <template v-slot:option="scope">
              <q-item
                v-bind="scope.itemProps"
                v-on="scope.itemEvents"
              >
              <q-item-section>
                <!-- <q-item-label v-html="scope.opt.label" /> -->
                <q-item-label caption>
                  {{ scope.opt.name }} （{{ scope.opt.alias.split('_')[1] }} {{ scope.opt.vesselCode}}）
                </q-item-label>
              </q-item-section>
              </q-item>
            </template>
            </q-select>
          </div>
          <div
            :class="{col: item.name !== 'boat_web_status'}"
            v-for="item in serviceGroupsData"
            :key="item.name">
            <q-card class="my-card full-height item-stretch">
              <transition-group
                appear
                enter-active-class="animate__animated animate__fadeIn"
                leave-active-class="animate__animated animate__fadeOut">
                <q-card-section class="q-pa-none q-pa-xs q-mb-sm  row" :key="'title-' + item.name">
                  <q-btn
                    class="text-weight-bold q-pa-none full-width"
                    align="left"
                    dense
                    flat
                    no-caps
                    color="primary"
                    type="a"
                    block
                    target="_blank"
                    :href="`${nagiosxiUrl}${item.url}`" >
                      {{item.label ? item.label : $t(`topView.${item.name}`)}}
                  </q-btn>
                </q-card-section>
                <q-card-section class="q-pa-none q-px-sm q-pb-sm row sgStatus-block" v-if="item.data" :key="'chart-' + item.name">
                  <div class="row full-width"  v-if="item.name === 'boat_web_status'">
                    <h4 class="col text-center q-ma-none font-weight-bold">{{item.data.total > 0 ? Math.round(item.data.ok / item.data.total * 10000) / 100 : 0}} %</h4>
                    <div class="col-grow">
                      <!--  v-if="item.data.ok" -->
                      <div class="row text-positive justify-end">
                        <span class="block bg-positive"></span>
                        <span style="min-width: 40px">{{item.data.ok}}</span>
                      </div>
                      <div class="row text-negative justify-end">
                        <span class="block bg-negative "></span>
                        <span style="min-width: 40px">{{item.data.critical}}</span>
                      </div>
                    </div>
                  </div>
                  <template v-else>
                    <BoatDeviceStatus :data="item.data"/>
                  </template>
                </q-card-section>
                <div v-else :key="'loading-' + item.name">
                  <q-linear-progress dark query class="q-mt-sm" />
                </div>
              </transition-group>
            </q-card>
          </div>
        </div>
      </div>
    </div>
    <q-dialog v-model="helpInfo">
      <q-card style="width: 780px; max-width: 80vw;">
        <q-card-section class="row items-center q-pb-none">
          <b class="q-mr-md"> {{$t('HexInfo.title')}} </b>
          <q-space />
          <q-btn icon="close" flat round dense v-close-popup />
        </q-card-section>
        <q-card-section>
          <div id="help">
            <div class="row full-width" v-if="helpContent">
              <div class="col-4">
                <div style="background: #FF0007" class="text-dark text-center q-mx-xs q-pa-xs">{{$t('Info.red')}}</div>
                <div class="text-center q-mx-xs q-pa-xs" v-html="helpContent.helpPageDescriptionRed">
                  Network disconnection Internet Speed = 0
                </div>
              </div>
              <div class="col-4">
                <div style="background: #FFF002" class="text-dark text-center q-mx-xs q-pa-xs">{{$t('Info.yellow')}}</div>
                <div class="text-center q-mx-xs q-pa-xs" v-html="helpContent.helpPageDescriptionYellow">
                  <p> The Statellite network is connected, but any of the following hosts are disconnected </p>
                  <p>192.168.1.58</p>
                  <p>192.168.1.59</p>
                  <p>192.168.1.60</p>
                  <p>192.168.1.61</p>
                  <p>192.168.1.62</p>
                  <p>192.168.1.69</p>
                  <p>192.168.1.70</p>
                  <p>192.168.1.83</p>
                  <p>192.168.1.84</p>
                  <p>192.168.1.206</p>
                  <p> Vessel_Website disconnection
                    <a class="text-primary" href="http://192.168.1.68:8080/OBA" id="">http://192.168.1.68:8080/OBA</a>
                  </p>
                </div>
              </div>
              <div class="col-4">
                <div style="background: #01FF00" class="text-dark text-center q-mx-xs q-pa-xs">{{$t('Info.green')}}</div>
                <div class="text-center q-mx-xs q-pa-xs" v-html="helpContent.helpPageDescriptionGreen">
                  Non-red and yellow lights are green lights.
                </div>
              </div>
            </div>
            <div class="text-center" v-else>
              <q-circular-progress
                indeterminate
                size="45px"
                class="q-ma-md"/>
            </div>
        </div>
        </q-card-section>
      </q-card>
    </q-dialog>
    <q-dialog v-model="showSummary">
      <q-card style="width: 780px; max-width: 80vw;" v-if="summaryStatus">
        <q-card-section class="row items-center q-pb-none">
          <b class="q-mr-md text-h6 text-primary text-weight-bold"> {{$t('topView.summary')}} </b>
          <q-space />
          <q-btn icon="close" flat round dense v-close-popup />
        </q-card-section>
        <q-scroll-area style="height: 80vh; width: 100%;" class="q-pa-sm">
          <q-card-section horizontal>
            <q-card-section class="col">
              <div class="text-h6 text-primary"> {{$t(`topView.service_Critical`)}}</div>
              <div class="q-mt-sm">
                <div v-for="(item, index) in summaryStatus.down" :key="index + '-' + item.display_name + '-' + item.host_address + '-' + item.host_state" class="q-pb-md">
                   <q-btn
                    :href="`${nagiosxiUrl}host%3D${item.host_alias}`"
                    flat
                    padding="xs sm"
                    align="left"
                    type="a"
                    target="_blank"
                    class="full-width text-primary">{{item.host_alias}}</q-btn>
                  <div class="q-px-sm">{{item.display_name}}</div>
                  <div class="q-px-sm text-negative">{{item.plugin_output}}</div>
                </div>
              </div>
            </q-card-section>
            <q-card-section class="col">
              <div class="text-h6 text-primary"> {{$t(`topView.service_Warning`)}}</div>
              <div class="q-mt-sm">
                <div v-for="(item, index) in summaryStatus.warning" :key="index + '-' + item.display_name + '-' + item.host_address + '-' + item.host_state" class="q-pb-md">
                  <q-btn
                    :href="`${nagiosxiUrl}host%3D${item.host_alias}`"
                    flat
                    padding="xs sm"
                    align="left"
                    type="a"
                    target="_blank"
                    class="full-width text-primary">{{item.host_alias}}</q-btn>
                  <div class="q-px-sm">{{item.display_name}}</div>
                  <div class="q-px-sm text-warning">{{item.plugin_output}}</div>
                </div>
              </div>
            </q-card-section>
          </q-card-section>
        </q-scroll-area>
      </q-card>
    </q-dialog>
  <!-- </div> -->
 </q-page>
</template>

<script>
import { colors, dom } from 'quasar'
import { mapActions, mapGetters } from 'vuex'
import IIMS from '@/api/iims'
import Nagiosxi from '@/api/nagiosxi'
import HexGrid from '@/components/HexGrid'
import DougnhutChart from '@/components/charts/DougnhutChart'
import BarChart from '@/components/charts/BarChart'
import BoatDeviceStatus from '@/components/BoatDeviceStatus'
import SlaStatus from '@/components/SlaStatus'
import hostGroup from '@/store/static/hostGroup.json'
import serviceGroup from '@/store/static/serviceGroup.json'
const { width } = dom

export default {
  name: 'Dashboard',
  components: {
    HexGrid,
    BarChart,
    DougnhutChart,
    BoatDeviceStatus,
    SlaStatus
  },
  data() {
    return {
      keepTimer: null,
      helpInfo: false,
      helpContent: null,
      searchText: null,
      filterOptions: [],
      hostGroupsData: hostGroup,
      serviceGroupsData: serviceGroup,
      summaryData: null,
      showSummary: false,
      hexSize: null
    }
  },
  watch: {
    summaryData() {
      this.hostGroupsData = this.hostGroupsData
        .map((d, index) => {
          if (d.name === 'summary') {
            return {
              ...d,
              data: {
                groupName: d.name,
                ...this.summaryData
              }
            }
          }
          return {
            ...d
          }
        })
    },
    // url
    searchText() {
      if (this.searchText) {
        this.$router.push(this.searchText.url).catch(() => { })
      }
    }
  },
  computed: {
    ...mapGetters({
      user: 'user/user',
      boats: 'nagiosxi/boats',
      boatsList: 'nagiosxi/boatsList',
      SlaStatusData: 'nagiosxi/SlaStatus',
      positions: 'vessel/positions',
      nagiosxiUrl: 'user/nagiosxiLink'
    }),
    permission() {
      return false
      // if (this.user.authority > 8) return true
      // else return false
    },
    hexdata() {
      if (!this.positions || !this.boats) return []
      return this.boats
        .map(d => {
          const obj = this.positions
            ? this.positions.find(({ host_display_name }) => host_display_name === d.vesselCode) || null
            : null
          return {
            ...d,
            coordinate: obj ? (obj.coordinate || null) : null
          }
        })
    },
    summaryStatus() {
      if (!this.summaryData) return null
      return {
        warning: this.summaryData.data.filter(({ state }) => parseInt(state, 10) === 1),
        down: this.summaryData.data.filter(({ state }) => parseInt(state, 10) === 2)
      }
    }
  },
  methods: {
    ...mapActions({
      trackEvent: 'user/trackEvent',
      getGlobalShipPosition: 'vessel/getGlobalShipPosition',
      getPosition: 'vessel/getPosition',
      storePosition: 'vessel/storePosition',
      setTimer: 'nagiosxi/setTimer'
    }),
    filterFn(val, update) {
      update(() => {
        if (val.length <= 0) {
          this.filterOptions = (this.boatsList || [])
        } else {
          const needle = val.toLowerCase()
          this.filterOptions = (this.boatsList || [])
            .filter(
              v => v.alias.toLowerCase().indexOf(needle) > -1
            )
        }
      })
    },
    getSummary(host) {
      const summaryData = host || []
      const data = {
        groupName: 'summary',
        data: summaryData,
        dataUrl: {
          up: `${this.nagiosxiUrl}%26show%3Dservices%26hoststatustypes%3D0%26servicestatustypes%3D2`,
          warning: `${this.nagiosxiUrl}%26show%3Dservices%26hoststatustypes%3D0%26servicestatustypes%3D4`,
          down: `${this.nagiosxiUrl}%26show%3Dservices%26hoststatustypes%3D0%26servicestatustypes%3D16`
        },
        total: summaryData.length,
        up: summaryData.filter(({ state }) => parseInt(state, 10) === 0).length,
        warning: summaryData.filter(({ state }) => parseInt(state, 10) === 1).length,
        down: summaryData.filter(({ state }) => parseInt(state, 10) === 2).length
      }
      this.summaryData = data
    },
    async getHostGroupsData() {
      const hostLists = this.hostGroupsData
      const hostGroups = await Promise.all(
        Array.from(
          hostLists, x => Nagiosxi.thruk(x.fetch)
        )
      )
      this.hostGroupsData = hostLists.map((d, index) => {
        if (d.name === 'summary') {
          this.getSummary(hostGroups[index].data)
          return {
            ...d
          }
        }
        return {
          ...d,
          data: {
            groupName: d.name,
            dataUrl: {
              up: `${this.nagiosxiUrl}${d.dataUrl.up}`,
              down: `${this.nagiosxiUrl}${d.dataUrl.down}`
            },
            ...hostGroups[index].data
          }
        }
      })
    },
    async getServiceGStats() {
      const SGLists = this.serviceGroupsData
      const SGroups = await Promise.all(
        Array.from(
          SGLists, x => Nagiosxi.thruk(`/services?groups[regex]=${x.name}&columns=state,host_alias,host_state`)
          // SGLists, x => Nagiosxi.thruk(`/servicegroups/${x.name}`)
          // SGLists, x => Nagiosxi.thruk(`/servicegroups/${x.name}/stats`)
        )
      )
      // ?columns=ok,warning,critical,total
      // console.log(SGroups)
      this.serviceGroupsData = SGLists.map((d, index) => {
        const data = SGroups[index].data.reduce((map, val) => {
          // console.log(val)
          if (!map[val.host_alias]) map[val.host_alias] = {}
          map[val.host_alias] = val
          return map
        }, {})
        const status = {
          // ok,warning,critical,total
          ok: Object.values(data).filter(({ host_state }) => host_state === 0).length,
          // warning: Object.values(data).filter(({ host_state }) => host_state === 1).length,
          critical: Object.values(data).filter(({ host_state }) => host_state > 0).length,
          total: Object.keys(data).length
        }
        return {
          ...d,
          data: {
            groupName: d.name,
            ...status
            // ...SGroups[index].data
          }
        }
      })
    },
    DoughnutData(data) {
      const isIE = this.$checkBrowser().indexOf('Internet Explorer') >= 0
      const chartData = [
        { value: data.down,
          name: this.$t(`topView.host_down`),
          dataUrl: data.dataUrl ? data.dataUrl.down : '',
          itemStyle: {
            normal: {
              color: isIE ? '#FF0007' : colors.getBrand('negative')
            }
          }
        },
        { value: data.warning,
          name: this.$t(`topView.warning`),
          dataUrl: data.dataUrl ? data.dataUrl.warning : '',
          itemStyle: {
            normal: {
              color: isIE ? '#FFF002' : colors.getBrand('warning')
            }
          }
        },
        { value: data.up,
          name: this.$t(`topView.host_up`),
          dataUrl: data.dataUrl ? data.dataUrl.up : '',
          itemStyle: {
            normal: {
              color: isIE ? '#01FF00' : colors.getBrand('positive')
            }
          }
        }
      ].filter(({ value }) => value !== undefined)
      return {
        groupName: this.$t(`topView.${data.groupName}`),
        centerText: `${Math.round(data.up / data.total * 100)}%`,
        data: chartData
      }
    },
    BarData(data) {
      const isService = !!data.warning
      const isIE = this.$checkBrowser().indexOf('Internet Explorer') >= 0
      const chartData = [
        { value: data.critical ?? data.down,
          name: isService ? this.$t(`topView.service_Critical`) : this.$t(`topView.host_down`),
          dataUrl: data.dataUrl ? data.dataUrl.down : '',
          itemStyle: {
            normal: {
              color: isIE ? '#FF0007' : colors.getBrand('negative')
            }
          }
        },
        { value: data.warning,
          name: isService ? this.$t(`topView.service_Warning`) : this.$t(`topView.warning`),
          dataUrl: data.dataUrl ? data.dataUrl.warning : '',
          itemStyle: {
            normal: {
              color: isIE ? '#FFF002' : colors.getBrand('warning')
            }
          }
        },
        { value: data.ok ?? data.up,
          name: isService ? this.$t(`topView.service_Ok`) : this.$t(`topView.host_up`),
          dataUrl: data.dataUrl ? data.dataUrl.up : '',
          itemStyle: {
            normal: {
              color: isIE ? '#01FF00' : colors.getBrand('positive')
            }
          }
        }
      ].filter(({ value }) => value !== undefined)
      return {
        labels: chartData.map(d => d.name),
        data: chartData
      }
    },
    sized() {
      const w = width(this.$refs.overall)
      const asRatio = 0.5625
      this.hexSize = {
        // width: `${w}px`,
        width: '100%',
        height: `${w * asRatio}px`
      }
    }
  },
  async created() {
    // if (this.permission) {
    //   await this.getPosition()
    // } else {
    // }
    await this.getGlobalShipPosition()
    await this.getServiceGStats()
    await this.getHostGroupsData()
    try {
      const { data: {
        data: {
          helpPageDescriptionRed,
          helpPageDescriptionYellow,
          helpPageDescriptionGreen
        }
      }} = await IIMS.getGlobalconfig()
      this.helpContent = {
        helpPageDescriptionRed,
        helpPageDescriptionYellow,
        helpPageDescriptionGreen
      }
    } catch (error) {
      console.log(error)
      this.helpContent = null
    }
  },
  async mounted() {
    this.trackEvent({
      category: 'Top_View',
      action: 'Click'
    })
    this.setTimer(true)
    this.sized()
    this.keepTimer = setInterval(() => {
      console.log('dashboard timer')
      this.getHostGroupsData()
      this.getServiceGStats()
      this.trackEvent({
        category: 'Top_View',
        action: 'Live'
      })
    }, 300000)
    window.addEventListener('resize', this.sized)
  },
  beforeDestroy() {
    console.log('beforeDestroy dashboard timer')
    clearInterval(this.keepTimer)
    window.removeEventListener('resize', this.sized)
    this.setTimer(false)
  }
}
</script>
<style lang="sass">
  .Dashboard
    padding: .75rem
    box-sizing: border-box
    .my-card
      height: 100%
      min-height: 100px
    .left-col
      width: 20%
      .chart
        height: 205px
      .my-card
        min-height: 250px
    .center-col
      width: calc( 60% - 1rem )
      margin: 0 .5rem
    .right-col
      width: 20%
      .sgStatus-block
        height: calc(100% - 32px)
      .block
        position: relative
        width: 16px
        height: 16px
        margin: 4px
        border-radius: 2px / 2px
</style>
