<template>
  <q-page v-if="waitForboatFetch === 0">
    <q-linear-progress indeterminate />
  </q-page>
  <q-page class="row" padding v-else>
    <div class="col-xs-12 col-sm-12 col-md-3">
      <div class="q-pa-md q-gutter-sm">
        <q-select
          v-model="boat"
          :options="boatsOpt"
          borderless
          emit-value
          map-options
          caption
          class="q-mb-sm">
          <template v-slot:selected caption>
            <h5 class="text-weight-bold q-ma-none">{{boat.label}}</h5>
          </template>
        </q-select>
        <q-select
          v-model="device"
          use-input
          hide-selected
          fill-input
          hide-dropdown-icon
          options-dense
          input-debounce="0"
          :label="$t('vesselView.Device')"
          :auto-close="false"
          :options="filterOptions"
          :option-label="opt => Object(opt) === opt && 'label' in opt ?  opt.label.toUpperCase() : '--'"
          @filter="filterFn"
        >
          <template v-slot:prepend>
            <q-icon name="search" />
          </template>
          <template v-slot:option="scope">
            <q-item v-bind="scope.itemProps" v-on="scope.itemEvents">
              <q-item-section caption>
                <q-item-label
                  :class="['light', {'light--negative': scope.opt.data && scope.opt.data.state > 1},
                  {'light--warning': scope.opt.data && scope.opt.data.state === 1},
                  {'light--positive': scope.opt.data && scope.opt.data.state === 0}]"
                >{{ scope.opt.label.toUpperCase() }}</q-item-label>
              </q-item-section>
            </q-item>
          </template>
        </q-select>
         <!-- {{boatSatellite}} -->
        <div v-if="boatSatellite">
          <q-btn
            target="_blank"
            push
            type="a"
            no-caps
            block
            flat
            class="full-width"
            align="left"
            dense
            :href="`${nagiosxiUrl}host%3D${boatSatellite.host_alias}`"
            :color="parseInt(boatSatellite.state, 10) === 0 ? 'positive' : 'negative'"
            >
            {{$t('vesselView.Satellite.state')}}: {{boatSatellite.state === 0 ? SatelliteState[0] : SatelliteState[1]}}
            <!-- <span class="q-px-xs" v-if="boatSatellite.state !== 0">{{ getDateDiff(( boatSatellite.last_check - boatSatellite.last_time_ok))}} </span> -->
          </q-btn>
          <div class="q-px-xs">
            {{$t('vesselView.Satellite.last_check')}} : {{formatDate(boatSatellite.last_check * 1000, 'YYYY/MM/DD HH:mm:ss')}}
          </div>
          <div class="q-px-xs" v-if="boatSatellite.state !== 0">
             {{$t('vesselView.Satellite.last_time_ok')}} : {{formatDate(boatSatellite.last_time_ok * 1000, 'YYYY/MM/DD HH:mm:ss')}}
          </div>
          <div class="q-px-xs">
            {{boatSatellite.plugin_output}}
          </div>
        </div>
        <div>
          <q-btn
            v-if="device && device.data"
            target="_blank"
            push
            type="a"
            no-caps
            block
            flat
            class="full-width"
            align="left"
            dense
            :href="`${nagiosxiUrl}host%3D${device.data.host_alias}`">
              {{device.data ? device.data.host_alias : ''}}
          </q-btn>
        </div>
      </div>
    </div>
    <div
      ref="vesselBoard"
      :class="['col-xs-12 col-sm-12 col-md-9 right-block container', { 'right-block-all': cardsStatus === 'block'|| cardsStatus === 'blockLine' }]">
      <div
        v-if="cardsStatus !== 'line'"
        :class="['row card-grid q-col-gutter-sm', {'card-grid-md': $q.screen.lt.md && !$q.screen.lt.sm}, {'card-grid-sm': $q.screen.lt.sm}]">
        <div :class="[{ 'col-md-6 col-sm-6 col-xs-12': cardsStatus === 'block' || cardsStatus === 'blockLine' }, { 'col-md-3 col-sm-6 col-xs-12': cardsStatus === 'default' }]">
          <q-card class="my-card">
            <q-card-section class="q-pa-sm" v-if="cardsStatus !== 'block' && cardsStatus !== 'blockLine'  && showStatus.indexOf('Uptime') > -1" >
              <q-btn
                target="_blank"
                push
                type="a"
                no-caps
                flat
                align="left"
                dense
                class="text-weight-bold full-width"
                :href="`${nagiosxiUrl}%26host%3D${queryString}`">
                  {{$t('vesselView.Host')}}
              </q-btn>
            </q-card-section>
            <q-card-section class="q-pa-sm" v-else><b class="text-primary">{{$t('vesselView.Host')}}</b></q-card-section>
            <q-linear-progress v-if="loading" indeterminate />
            <q-card-section class="q-pa-sm" v-if="showStatus.indexOf('Uptime') > -1 && Uptime">
              <div class="row">
                <div :class="['col-12', {'col-md-6 col-sm-12': (cardsStatus ==='block' || cardsStatus === 'blockLine') && Uptime.critical.length > 0}]">
                  <DougnhutChart
                    class="flex flex-center"
                    chartId="cht-host"
                    :style="{ 'height': `${chartHeight}px` }"
                    :data="DoughnutData(Uptime.chart)"/>
                  <div class="q-pa-xs" v-if="Uptime.chart">
                    <h6 class="text-center q-ma-none">
                      <span
                        :class="{'text-negative': (Uptime.critical.length || 0) >= 1}">
                        {{Uptime.critical.length}}
                      </span>
                      / {{Uptime.total}}
                    </h6>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12" :style="{ 'min-height': `${scrollArea}px` }"  v-if="Uptime.critical.length > 0 && (cardsStatus ==='block' || cardsStatus === 'blockLine')">
                  <q-scroll-area class="rounded-borders q-px-md full-height">
                    <q-btn
                      v-for="(item, index) in Uptime.critical"
                      :key="item.host_alias"
                      :href="`${nagiosxiUrl}host%3D${item.host_alias}`"
                      target="_blank"
                      push
                      type="a"
                      no-caps
                      block
                      flat
                      class="full-width"
                    >
                      <div class="nagiosxi-link q-my-xs">
                        <div>
                          {{index + 1}}/
                          <b class="text-negative">{{item.host_address}}</b>
                        </div>
                        <div class="text-negative">time out</div>
                      </div>
                    </q-btn>
                  </q-scroll-area>
                </div>
              </div>
            </q-card-section>
            <q-card-section class="row q-pa-sm" v-else-if="!loading">
              <div
                class="col-12 text-center"
                :style="{ height: blockHeight + 'px' }">{{$t('vesselView.noData')}}</div>
            </q-card-section>
          </q-card>
        </div>
        <div :class="[{ 'col-md-6 col-sm-6 col-xs-12': cardsStatus === 'block' || cardsStatus === 'blockLine' }, { 'col-md-3 col-sm-6 col-xs-12': cardsStatus === 'default' }]">
          <q-card class="my-card">
            <q-card-section class="flex justify-between q-pa-sm" v-if="cardsStatus !== 'block' && cardsStatus !== 'blockLine' && showStatus.indexOf('Cpu Usage') > -1">
              <q-btn
                target="_blank"
                push
                type="a"
                no-caps
                flat
                align="left"
                dense
                class="text-weight-bold full-width"
                :href="`${nagiosxiUrl}%26host%3D${queryString}`">
                  CPU
              </q-btn>
            </q-card-section>
            <q-card-section class="q-pa-sm" v-else> <b class="text-primary">CPU</b> </q-card-section>
            <q-linear-progress v-if="loading" indeterminate />
            <q-card-section class="q-pa-sm" v-if="showStatus.indexOf('Cpu Usage') > -1 && CpuData" >
              <div class="row">
                <!--  :style="{ height: blockHeight + 'px' }" -->
                <div :class="['col-12',{'col-md-6 col-sm-12': (cardsStatus ==='block' || cardsStatus === 'blockLine') && CpuData.critical.length > 0}]">
                  <!-- data.warning / data.total / 100 -->
                  <GaugeChart
                    class="flex flex-center"
                    :style="{ 'height': `${chartHeight}px` }"
                    :data="GaugeChartData(CpuData.reduce)"
                    chartId="cht-cpu" />
                  <div class="q-pa-xs">
                    <h6 class="text-center q-ma-none">
                      <span
                        :class="{'text-negative': (CpuData.critical.length || 0) >= 1}"
                      >{{CpuData.critical.length}}</span>
                      / {{CpuData.total}}
                      <q-tooltip anchor="top middle" self="bottom middle" :offset="[10, 10]">Warning: SLA > {{Math.round(CpuData.reduce.warning / CpuData.reduce.total) }} %</q-tooltip>
                    </h6>
                  </div>
                </div>
                <!-- {{CpuData.critical}} -->
                <div class="col-md-6 col-sm-12" :style="{ 'min-height': `${scrollArea}px` }" v-if="CpuData.critical.length > 0 && (cardsStatus ==='block' || cardsStatus === 'blockLine')">
                  <q-scroll-area class="rounded-borders q-px-md full-height">
                    <q-btn
                      v-for="(item, index) in CpuData.critical"
                      :key="item.host_alias"
                      :href="`${nagiosxiUrl}host%3D${item.host_alias}`"
                      target="_blank"
                      push
                      type="a"
                      no-caps
                      block
                      flat
                      class="full-width"
                    >
                      <div class="nagiosxi-link q-my-xs">
                        <div>
                          {{index + 1}}/
                          <b class="text-negative">{{item.host_address}}</b>
                        </div>
                        <div class="text-negative">Warning</div>
                      </div>
                    </q-btn>
                  </q-scroll-area>
                </div>
              </div>
            </q-card-section>
            <q-card-section class="row q-pa-sm" v-else-if="!loading">
              <div class="col-12 text-center" :style="{ height: blockHeight + 'px' }" >{{$t('vesselView.noData')}}</div>
            </q-card-section>
          </q-card>
        </div>
        <div :class="[{ 'col-md-6 col-sm-6 col-xs-12': cardsStatus === 'block' || cardsStatus === 'blockLine'}, { 'col-md-3 col-sm-6 col-xs-12': cardsStatus === 'default' }]">
          <q-card class="my-card">
            <q-card-section class="q-pa-sm" v-if="cardsStatus !== 'block' && cardsStatus !== 'blockLine' && showStatus.indexOf('Mem Usage') > -1">
              <q-btn
                target="_blank"
                push
                type="a"
                no-caps
                flat
                align="left"
                dense
                class="text-weight-bold full-width"
                :href="`${nagiosxiUrl}%26host%3D${queryString}`">
                  Memory Usage
              </q-btn>
            </q-card-section>
            <q-card-section class="q-pa-sm" v-else> <b class="text-primary">Memory Usage</b> </q-card-section>
            <q-linear-progress v-if="loading" indeterminate />
            <q-card-section class="q-pa-sm" v-if="showStatus.indexOf('Mem Usage') > -1 && MemData">
              <div class="row">
                <div :class="['col-12', {'col-md-6 col-sm-12': MemData.critical.length > 0 && (cardsStatus ==='block' || cardsStatus === 'blockLine')}]">
                  <DougnhutChart
                    v-if="cardsStatus ==='block' || cardsStatus === 'blockLine'"
                    class="flex flex-center"
                    :style="{ 'height': `${chartHeight}px` }"
                    :data="DoughnutData(MemData.chart)"
                    chartId="cht-mem"/>
                  <BarChart
                    v-else
                    class="flex flex-center"
                    :style="{ 'height': `${chartHeight}px` }"
                    :data="barChartwithPolar(MemData.chart)"
                    chartId="cht-mem-bar"/>
                  <div class="q-pa-xs" v-if="MemData.chart">
                    <h6 class="text-center q-ma-none" v-if="cardsStatus ==='block' || cardsStatus === 'blockLine'">
                      <span :class="{'text-negative': (MemData.chart.down || 0 )>= 1}">
                        {{MemData.chart.down || 0}}
                      </span> / {{ MemData.chart.total }}
                    </h6>
                    <h6 class="text-center q-ma-none" v-if="cardsStatus ==='default'">
                      <span :class="{'text-negative': (MemData.chart.used || 0) >= 1}" >
                        {{MemData.chart.used || 0}}
                      </span> / {{ MemData.chart.total }}
                    </h6>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12" :style="{ 'min-height': `${scrollArea}px` }" v-if="MemData.critical.length > 0 && (cardsStatus ==='block' || cardsStatus === 'blockLine')">
                  <q-scroll-area class="rounded-borders q-px-md full-height">
                    <q-btn
                      v-for="(item, index) in MemData.critical"
                      :key="item.host_alias"
                      :href="`${nagiosxiUrl}host%3D${item.host_alias}`"
                      target="_blank"
                      push
                      type="a"
                      no-caps
                      block
                      flat
                      class="full-width">
                      <div class="nagiosxi-link q-my-xs">
                        <!-- show mem partition ? there is no partition -->
                        <div>
                          {{index + 1}}/
                          <b class="text-negative">{{item.host_address}}</b>
                        </div>
                        <div class="text-negative">{{item.perf_data.Physical_Memory_Utilisation[0]}}</div>
                      </div>
                    </q-btn>
                  </q-scroll-area>
                </div>
              </div>
            </q-card-section>
            <q-card-section class="row q-pa-sm" v-else-if="!loading">
              <div class="col-12 text-center" :style="{ height: blockHeight + 'px' }" >{{$t('vesselView.noData')}}</div>
            </q-card-section>
          </q-card>
        </div>
        <div :class="[{ 'col-md-6 col-sm-6 col-xs-12': cardsStatus === 'block' || cardsStatus === 'blockLine'}, { 'col-md-3 col-sm-6 col-xs-12': cardsStatus === 'default' }]">
          <q-card class="my-card">
            <q-card-section class="q-pa-sm" v-if="(cardsStatus !== 'block' && cardsStatus !== 'blockLine') && showStatus.indexOf('Disk Usage') > -1">
              <q-btn
                target="_blank"
                push
                type="a"
                no-caps
                flat
                align="left"
                dense
                class="text-weight-bold full-width"
                :href="`${nagiosxiUrl}%26host%3D${queryString}`">
                  Disk Usage
              </q-btn>
            </q-card-section>
            <q-card-section class="q-pa-sm" v-else> <b class="text-primary">Disk Usage</b> </q-card-section>
            <q-linear-progress v-if="loading" indeterminate />
            <q-card-section class=" q-pa-sm" v-if="showStatus.indexOf('Disk Usage') > -1 && DiskData">
              <div class="row">
                <div :class="['col-12', {'col-md-6 col-sm-12': DiskData.critical.length > 0 && (cardsStatus ==='block' || cardsStatus === 'blockLine')}]">
                  <DougnhutChart
                    v-if="cardsStatus ==='block' || cardsStatus === 'blockLine'"
                    chartId="cht-disk"
                    class="flex flex-center"
                    :style="{ 'height': `${chartHeight}px` }"
                    :data="DoughnutData(DiskData.chart)"
                  />
                  <BarChart
                    v-else
                    class="flex flex-center"
                    chartId="cht-disk-bar"
                    :style="{ 'height': `${chartHeight }px` }"
                    :data="barChartwithPolar(DiskData.chart)" />
                  <div class="q-pa-xs" v-if="DiskData.chart">
                    <h6
                      class="text-center q-ma-none cursor-pointer"
                      @click="showPartitions = true"
                      v-if="cardsStatus ==='default' && DiskData.chart.perf_data"
                    >
                      <span
                        :class="{'text-negative': (DiskData.chart.perf_data.partitionWarning || 0 )>= 1}"
                      >{{DiskData.chart.perf_data.partitionWarning}}</span>
                      / {{Object.keys(DiskData.chart.perf_data['Used Space']).length || 0}}
                    </h6>
                    <h6 class="text-center q-ma-none" v-if="cardsStatus ==='block' || cardsStatus === 'blockLine'">
                      <span
                        :class="{'text-negative': (DiskData.chart.down || 0 )>= 1}"
                      >{{DiskData.chart.down || 0}}</span>
                      / {{DiskData.chart.total }}
                    </h6>
                    <h6 class="text-center q-ma-none" v-if="cardsStatus ==='default'">
                      <span
                        :class="{'text-negative': (DiskData.chart.used || 0 )>= 1}"
                      >{{DiskData.chart.used || 0}}</span>
                      / {{DiskData.chart.total }}
                    </h6>
                  </div>
                </div>
                <!-- {{DiskData}} -->
                <div class="col-md-6 col-sm-12" :style="{ 'min-height': `${scrollArea}px` }"  v-if="DiskData.critical.length > 0 && (cardsStatus ==='block' || cardsStatus === 'blockLine')">
                  <q-scroll-area class="rounded-borders q-px-md full-height">
                    <q-btn
                      v-for="(item, index) in DiskData.critical"
                      :key="item.host_alias"
                      :href="`${nagiosxiUrl}host%3D${item.host_alias}`"
                      target="_blank"
                      push
                      type="a"
                      no-caps
                      block
                      flat
                      class="full-width"
                    >
                      <div class="nagiosxi-link q-my-xs">
                        <div>
                          {{index + 1}}/
                          <b class="text-negative">{{item.host_address}}</b>
                        </div>
                        <span
                          class="text-negative"
                          v-if="item.perf_data['/ Percent']"
                        >{{item.perf_data['/ Percent'][0]}}</span>
                        <span
                          class="text-negative"
                          v-else
                          :title="JSON.stringify(item.perf_data)"
                        >Warning</span>
                      </div>
                    </q-btn>
                  </q-scroll-area>
                <!-- show partition ? -->
                </div>
              </div>
            </q-card-section>
            <q-card-section class="row q-pa-sm" v-else-if="!loading">
              <div
                class="col-12 column no-wrap text-center"
                :style="{ height: blockHeight + 'px' }"
              >{{$t('vesselView.noData')}}</div>
            </q-card-section>
          </q-card>
        </div>
      </div>
      <div :class="['row',  {'q-mt-md': cardsStatus !== 'line'}]" v-if="cardsStatus !== 'block'" >
        <div class="col-xs-12 col-sm-12 col-md-12">
          <q-card>
            <q-card-section class="row q-col-gutter-sm q-pb-none q-mb-sm">
              <div class="col-xs-12 col-sm-12 col-md-12 flex items-baseline q-gutter-sm">
                <q-select
                  dense
                  filled
                  v-model="chartTimeType"
                  :options="TimeOptions"
                  style="min-width: 160px;"
                  class="col-auto"
                />
                <q-select
                  dense
                  filled
                  v-model="chartDevice"
                  :options="deviceOpts"
                  style="min-width: 160px;"
                  class="col-auto"
                />
                <q-select
                  dense
                  filled
                  v-model="diskPartition"
                  :options="diskOpt"
                  style="min-width: 160px;"
                  class="col-auto"
                  v-if="diskOpt.length > 0 && chartDevice && chartDevice.label === 'Disk'"
                />
              </div>
            </q-card-section>
            <q-linear-progress indeterminate v-if="loadingInflux"/>
            <q-card-section class="q-pt-lg" v-if="LineChartData">
              <LineChart chartId="item.id" :data="LineChartData" :style="[{'height': cardsStatus !== 'line' ? '420px' : '70vh'}]" />
            </q-card-section>
            <q-card-section class="q-pa-md text-center" v-else>{{$t('vesselView.noData')}}</q-card-section>
          </q-card>
        </div>
      </div>
    </div>
    <q-dialog v-model="showPartitions">
      <q-card v-if="DiskData && DiskData.chart">
        <q-card-section>
          <div class="text-h6">Disk Partition Warning</div>
        </q-card-section>
        <q-card-section class="q-pa-md partitions-output">{{DiskData.chart.plugin_output ? DiskData.chart.plugin_output : 'No Warning'}}</q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="OK" color="primary" v-close-popup />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import { colors, format, date } from 'quasar'
import Nagiosxi from '../api/nagiosxi'
import IIMS from '@/api/iims'
import DougnhutChart from '@/components/charts/DougnhutChart'
import LineChart from '@/components/charts/LineChart'
import GaugeChart from '@/components/charts/GaugeChart'
import BarChart from '@/components/charts/BarChart'
import mixins from '@/mixins/mixins'

const { humanStorageSize } = format
const getReadableFileSizeString = (fileSizeInBytes) => {
  let i = -1
  const byteUnits = [' kbps', ' Mbps', ' Gbps', ' Tbps', 'Pbps', 'Ebps', 'Zbps', 'Ybps']
  do {
    fileSizeInBytes = fileSizeInBytes / 1024
    i++
  } while (fileSizeInBytes > 1024)
  return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i]
}

export default {
  name: 'VesselDetail',
  mixins: [mixins],
  components: {
    DougnhutChart,
    LineChart,
    GaugeChart,
    BarChart
  },
  props: {
    id: {
      // boat
      type: String
    },
    type: {
      // host
      type: String
    }
  },
  data() {
    return {
      keepTimer: null,
      blockHeight: 200,
      scrollArea: 60,
      boat: '',
      membersOptiondata: [],
      searchText: '',
      device: null,
      SatelliteState: [this.$t('topView.host_up'), this.$t('topView.host_down')],
      filterOptions: [],
      chartTimeType: null,
      chartDevice: null,
      dashBoardData: null,
      LineChartData: null,
      diskPartition: null,
      diskOpt: [],
      showPartitions: false,
      inFluxTimer: null,
      waitForboatFetch: 0,
      loading: false,
      loadingInflux: false
    }
  },
  watch: {
    boatsList() {
      if (this.boatsList && this.waitForboatFetch !== 1) {
        this.waitForboatFetch = 1 // finally got boats
        this.Init()
      }
    },
    boat(oldvalue, newValue) {
      // query
      console.log('watch boat')
      if (!this.boat) return
      if (this.boat.name !== this.id) {
        this.device = this.membersOpts[0]
      }
      const type = this.device ? this.device.label : this.type
      this.$router.push(`/vessel/${this.boat.name}/${type}`).catch(() => {})
      this.chartTimeType = this.TimeOptions[0]
    },
    device() {
      if (!this.boat || !this.device) return
      if (this.type === 'all') {
        this.chartTimeType = this.TimeOptions[0]
      }
      this.$router
        .push(`/vessel/${this.boat.name}/${this.device.label}`)
        .catch(() => {})
    },
    deviceOpts() {
      this.chartDevice = this.deviceOpts[0]
    },
    async DiskData() {
      this.diskOpt = (this.DiskData?.chart?.perf_data?.regexKey || [])
    },
    diskOpt() {
      if (this.diskOpt.length > 0) {
        this.diskPartition = this.diskOpt[0]
      }
    },
    async queryString() {
      await this.getMembers(this.boat.name)
    },
    fluxDB(newVal, oldVal) {
      const same = JSON.stringify(newVal) === JSON.stringify(oldVal)
      if (this.fluxDB && this.fluxDB.length > 0 && !same) {
        clearInterval(this.inFluxTimer)
        this.getInfluxDb()
        if (this.chartTimeType.id === 'realtime') {
          console.log('realtime get InfluxDb')
          this.inFluxTimer = setInterval(() => {
            this.getInfluxDb()
          }, 300000)
        }
      }
    }
  },
  computed: {
    ...mapGetters({
      boats: 'nagiosxi/boats',
      boatsList: 'nagiosxi/boatsList',
      Satellite: 'nagiosxi/Satellite',
      nagiosxiUrl: 'user/nagiosxiLink'
    }),
    queryString() {
      return `${this.id}_${this.type}`
    },
    chartHeight() {
      if (this.cardsStatus === 'default') {
        return this.blockHeight - 32
      }
      // block
      return this.blockHeight
    },
    cardsStatus() {
      // return 'default'
      const showStatus =
        this.showStatus.indexOf('Uptime') > -1 ||
        this.showStatus.indexOf('Cpu Usage') > -1 ||
        this.showStatus.indexOf('Disk Usage') > -1 ||
        this.showStatus.indexOf('Mem Usage') > -1
      // block, line, default
      if (this.type === 'all' && this.boat.type === 'boat') {
        return 'blockLine'
      }
      if (this.type === 'all') {
        return 'block'
      }
      if (this.type === '192.168.1.68' || !showStatus) {
        return 'line'
      }
      return showStatus ? 'default' : 'line'
    },
    fluxDB() {
      if (
        !this.chartDevice ||
        !this.chartTimeType) return []
      // chart type
      const selectLine = `SELECT mean("value") FROM "metrics" WHERE`
      // 開(open) 收(close) 最低(lowest) 最高(highest)
      const selectCandlestick = `SELECT first("value"),last("value"),min("value"),max("value"),mean("value") FROM "metrics" WHERE`
      // service
      let service = this.chartDevice.value
      // time
      const time = `and time >= ${this.chartTimeType.value}`
      // Satellite
      if (this.type === 'all') {
        if (this.chartDevice.id === 'Satellite') {
          const host_alias = this.boatSatellite.host_alias
          const realtime = this.chartTimeType.id === 'realtime' ? 'now() - 48h GROUP BY time(1m)' : this.chartTimeType.value
          return [
            {
              name: this.chartDevice.label,
              type: 'line',
              query: `${selectLine} ("host"= '${host_alias}' AND ${service}) and time >=${realtime}`
            }
          ]
        }
      }
      if (
        !this.device ||
        !this.device.data) return []
      if (this.chartTimeType.id === 'realtime') {
        // 只有折線圖
        if (this.chartDevice.value.indexOf('If WAN1') > 0) {
          // 上下載速度
          // const host_alias = this.boatSatellite.host_alias
          return [
            // {
            //   name: this.$t('vesselView.Alive'),
            //   type: 'line',
            //   query: `${selectLine} ("host"= '${host_alias}' AND "service" = 'Satellite Status') ${time}`
            // },
            {
              name: `${this.$t('vesselView.Bandwidth')} - ${this.$t(
                'vesselView.upload'
              )}`,
              type: 'line',
              query: `${selectLine} ("host"= '${this.device.data.host_alias}' AND ${this.chartDevice.value} AND "performanceLabel" = 'bpsout') ${time}`
            },
            {
              name: `${this.$t('vesselView.Bandwidth')} - ${this.$t(
                'vesselView.download'
              )}`,
              type: 'line',
              query: `${selectLine} ("host"= '${this.device.data.host_alias}' AND ${this.chartDevice.value} AND "performanceLabel" = 'bpsin') ${time}`
            }
          ]
        }
        // CPU  MEM 連線 / RTA Disk: 船端 & 岸端
        if (this.chartDevice.label === 'Disk') {
          // const diskPartition = atob(this.diskPartition.value || '')
          const diskPartition = this.diskPartition
          service = `"service" = 'Disk Usage' AND "performanceLabel" = '${diskPartition}'`
          return [
            {
              name: 'Average',
              type: 'line',
              query: `${selectLine} ("host"= '${this.device.data.host_alias}' AND "service" = 'Disk Usage') ${time}`
            },
            {
              name: `${diskPartition}`,
              type: 'line',
              query: `${selectLine} ("host"= '${this.device.data.host_alias}' AND ${service}) ${time}`
            }
          ]
        }
        return [
          {
            name: this.chartDevice.label,
            type: 'line',
            query: `${selectLine} ("host"= '${this.device.data.host_alias}' AND ${service}) ${time}`
          }
        ]
      } else {
        // 日周月
        // Disk: 船端 & 岸端
        if (this.chartDevice.label === 'Disk') {
          // const diskPartition = atob(this.diskPartition.value || '')
          const diskPartition = this.diskPartition
          const service = `"service" = 'Disk Usage' AND "performanceLabel" = '${diskPartition}'`
          return [
            {
              name: `${diskPartition}`,
              type: 'candlestick',
              query: `${selectCandlestick} ("host"= '${this.device.data.host_alias}' AND ${service}) ${time}`
            },
            {
              name: `Average`,
              type: 'line',
              query: `${selectLine} ("host"= '${this.device.data.host_alias}' AND ${service}) ${time}`
            }
          ]
        }
        return [
          {
            name: this.chartDevice.label,
            type: 'candlestick',
            query: `${selectCandlestick} ("host"= '${this.device.data.host_alias}' AND ${service}) ${time}`
          },
          {
            name: `Average`,
            type: 'line',
            query: `${selectLine} ("host"= '${this.device.data.host_alias}' AND ${service}) ${time}`
          }
        ]
      }
    },
    boatsOpt() {
      const lang = JSON.parse(localStorage.getItem('lang')) || 'zh-TW'
      const arr = [
        {
          label: this.$t('vesselView.boatsOpt.TPE'),
          type: 'IDC',
          name: 'TPE',
          group: 'host_tpe'
        },
        {
          label: this.$t('vesselView.boatsOpt.IDC'),
          type: 'IDC',
          name: 'IDC',
          group: 'host_idc'
        }
      ]
      const boatsList = (this.boatsList || []).map((d) => {
        const label =
          lang === 'zh-TW'
            ? d.notes.split('_')[1] || ''
            : d.notes.split('_')[0] || ''
        return {
          type: 'boat',
          name: d.name,
          label,
          notes: d.notes,
          alias: d.alias,
          data: d,
          group: d.name
        }
      })
      return [...arr, ...boatsList]
    },
    membersOpts() {
      if (this.membersOptiondata.length === 0) {
        return [
          {
            label: 'all',
            data: null
          }
        ]
      }
      const data = this.membersOptiondata.reduce((map, d) => {
        if (!map[d.host_address]) {
          map[d.host_address] = {
            state: 0,
            host_alias: '',
            description: [],
            detail: []
          }
        }
        if (d.description === 'Uptime') {
          map[d.host_address].state = map[d.host_address].state + d.state
        }
        map[d.host_address].host_alias = d.host_alias
        map[d.host_address].description.push(d.description)
        map[d.host_address].detail.push(d)
        return map
      }, {})
      return [
        {
          label: 'all',
          data: null
        },
        ...Object.entries(data).map((d) => ({ label: d[0], data: d[1] }))
      ]
    },
    filterMemberOptions() {
      if (this.searchText === '') {
        return this.membersOpts
      } else {
        const needle = this.searchText.toLowerCase()
        return this.membersOpts.filter((v) => v.label.toLowerCase().indexOf(needle) > -1)
      }
    },
    TimeOptions() {
      return [
        {
          label: this.$t('idcView.chart.realtime'),
          value: 'now() - 72h GROUP BY time(5m)',
          id: 'realtime'
        },
        {
          label: this.$t('idcView.chart.day'),
          value: 'now() - 30d GROUP BY time(1d)',
          id: 'day',
          disable: this.type === 'all'
        },
        {
          label: this.$t('idcView.chart.week'),
          value: 'now() - 180d GROUP BY time(7d,-4d)',
          id: 'week',
          disable: this.type === 'all'
        },
        {
          label: this.$t('idcView.chart.month'),
          value: 'now() - 360d GROUP BY time(30d)',
          id: 'month',
          disable: this.type === 'all'
        }
      ]
    },
    deviceOpts() {
      if (!this.boat || !this.type || !this.chartTimeType) return []
      let options = []
      // 衛星
      if (this.type === 'all' && this.boat.type === 'boat') {
        return [
          {
            id: 'Satellite',
            label: this.$t('vesselView.Alive'),
            value: `"service" = 'Satellite Status'` // 網速 上傳 + 下載 line chart
          }
        ]
      }
      // 全部 船隊 .1.1
      if (this.type === '192.168.1.1') {
        const WAN1 =
          this.chartTimeType.id === 'realtime'
            ? [
              {
                id: 'Bandwidth',
                label: this.$t('vesselView.Bandwidth'),
                value: `"service" = 'If WAN1'` // 網速 上傳 + 下載 line chart
              }
            ]
            : [
              {
                id: 'bpsout',
                label: `${this.$t('vesselView.Bandwidth')} - ${this.$t(
                  'vesselView.upload'
                )}`,
                value: `"service" = 'If WAN1' AND "performanceLabel" = 'bpsout'` // 網速 上傳 k-line
              },
              {
                id: 'bpsin',
                label: `${this.$t('vesselView.Bandwidth')} - ${this.$t(
                  'vesselView.download'
                )}`,
                value: `"service" = 'If WAN1' AND "performanceLabel" = 'bpsin'` // 網速 上傳 k-line
              }
            ]
        return [
          ...WAN1,
          {
            id: 'RTA',
            label: this.$t('vesselView.RTA'),
            value: `"service"= 'hostcheck'  AND "performanceLabel" = 'rta'` // 連線
          }
        ]
      }
      // 船端網址 TODO: IDC的船端網址是哪一個??
      // cardsStatus
      if (this.cardsStatus === 'line') {
        return [{
          id: 'RTA',
          label: this.$t('vesselView.RTA'),
          value: `"service"= 'hostcheck'  AND "performanceLabel" = 'rta'` // 連線
        }]
      }
      if (this.type === '192.168.1.68') {
        return [
          {
            id: 'RTA',
            label: this.$t('vesselView.RTA'),
            value: `"service"= 'hostcheck' AND "performanceLabel" = 'rta'` // 連線
          }
        ]
      }
      options = [
        {
          id: 'CPU',
          label: 'CPU',
          value: `"service" = 'Cpu Usage' AND "performanceLabel" = 'Avg_CPU_Utilisation'`,
          serviceName: 'Cpu Usage'
        },
        {
          id: 'Memory',
          label: 'Memory',
          value: `"service" = 'Mem Usage'`,
          serviceName: 'Mem Usage'
        },
        {
          id: 'Disk',
          label: 'Disk',
          value: `"service" = 'Disk Usage'`,
          serviceName: 'Disk Usage'
        },
        {
          id: 'RTA',
          label: this.$t('vesselView.RTA'),
          value: `"service"= 'hostcheck'  AND "performanceLabel" = 'rta'` // 連線
        }
      ]
      return options
    },
    showStatus() {
      if (!this.device) return []
      if (this.device.label === 'all') {
        return ['Cpu Usage', 'Disk Usage', 'Mem Usage', 'Uptime']
      }
      return this.device.data ? this.device.data.description : []
    },
    boatSatellite() {
      if (!this.boat) return null
      return this.Satellite.find(({ host_name }) => host_name.indexOf(this.boat.name) >= 0) || null
    },
    Uptime() {
      if (!this.dashBoardData || !this.dashBoardData['Uptime']) return null
      const hostData = this.dashBoardData['Uptime'] || []
      const critical = hostData.filter((d) => d.state > 0)
      return {
        total: (hostData || []).length,
        data: hostData,
        critical,
        chart: {
          groupName: 'Host',
          down: critical.length,
          up: (hostData || []).length - critical.length,
          total: (hostData || []).length
        }
      }
    },
    CpuData() {
      if (!this.dashBoardData || !this.dashBoardData['Cpu Usage']) return null
      const CpuData = this.dashBoardData['Cpu Usage'] || []
      const critical = CpuData.filter((d) => d.state > 0)
      return {
        total: (CpuData || []).length,
        data: CpuData,
        critical,
        reduce: CpuData.reduce(
          (map, data, index) => {
            const value = data.perf_data
              ? parseFloat(data.perf_data.split('=')[1].split(';')[0], 10) || 0
              : 0
            const warning = data.perf_data
              ? parseFloat(data.perf_data.split('=')[1].split(';')[1], 10) || 0
              : 75
            const critical = data.perf_data
              ? parseFloat(data.perf_data.split('=')[1].split(';')[2], 10) || 0
              : 85
            return {
              groupName: 'CPU',
              avg: map.avg + value,
              warning: map.warning + warning,
              critical: map.critical + critical,
              total: index + 1
            }
          },
          {
            groupName: '',
            avg: 0,
            warning: 0,
            critical: 0,
            total: 0
          }
        )
      }
    },
    MemData() {
      if (!this.dashBoardData || !this.dashBoardData['Mem Usage']) return null
      const MemData = this.dashBoardData['Mem Usage'] || []
      const Pattern = /[a-zA-Z]+/g
      const perfData = (str) =>
        str.split(' ').reduce((map, val) => {
          if (val) {
            const key = (val.split('=')[0].match(Pattern) || []).join('_')
            if (key === 'Physical_Memory_Utilisation') {
              map[key] = val.split('=')[1].split(';')
            } else if (key === 'Physical_Memory_Used') {
              map[key] = val.split('=')[1]
              map['Physical_Memory_Used_display'] = humanStorageSize(
                parseInt(val.split('=')[1].split(';'), 10)
              )
            } else {
              map[key] = val.split('=')[1]
            }
          } else {
            map['Physical_Memory_Utilisation'] = ['Error']
          }
          return map
        }, {})
      const critical = MemData.filter((d) => d.state > 0).map((d) => {
        return {
          ...d,
          perf_data: perfData(d.perf_data),
          plugin_output: d.plugin_output
        }
      })
      let chart = {
        groupName: 'Memory Usage',
        down: critical.length,
        up: (MemData || []).length - critical.length,
        total: (MemData || []).length
      }
      if (MemData.length === 1 && MemData[0].perf_data) {
        const perf_data = perfData(MemData[0].perf_data)
        let total = 100
        if (
          MemData[0].plugin_output &&
          MemData[0].plugin_output.indexOf('Total:') > 0
        ) {
          total =
            parseFloat(
              MemData[0].plugin_output.match(/Total: (.*) - Used:/)[1]
            ) || 100
          // console.log(MemData[0].plugin_output.split('Total: '))
        }
        chart = {
          groupName: 'Memory Usage',
          plugin_output: MemData[0].plugin_output,
          usage: parseInt(perf_data.Physical_Memory_Utilisation[0], 10) || 0,
          used: perf_data.Physical_Memory_Used_display || '',
          title: perf_data.Physical_Memory_Utilisation[0] || '',
          total: total + 'GB',
          state: MemData[0].state !== 0,
          perf_data
        }
      }
      return {
        total: (MemData || []).length,
        data: MemData,
        critical,
        chart
      }
    },
    DiskData() {
      if (!this.dashBoardData || !this.dashBoardData['Disk Usage']) return null
      const Pattern1 = /"/g
      const Pattern2 = / '/g
      // const Pattern3 = /'[^'"]*'(?=(?:[^"]*"[^"]*")*[^"]*$)/g
      const DiskData = this.dashBoardData['Disk Usage'] || []
      const perfData = (str) => {
        const arr = str.replace(Pattern1, '').replace(Pattern2, `#'`).split('#')
        if (str) {
          const obj = arr.reduce(
            (map, key, index) => {
              if (key) {
                let regexKey = key.split('=')[0]
                // .replace(`/\\\'/g`, '')
                // const regexKey = key.split('=')[0].replace(`/'+/g`, '')
                // const regexKey = key.split('=')[0].replaceAll(`'`, '')
                const regexValue = key.split('=')[1].split(';')
                if (regexKey.charAt(0) === '\'') regexKey = regexKey.substring(1)
                if (regexKey.charAt(regexKey.length - 1) === '\'') regexKey = regexKey.slice(0, -1)
                // console.log(str)
                // console.log(key)
                // console.log(regexKey)
                if (!map['regexKey']) map['regexKey'] = []
                map['regexKey'].push(regexKey)
                if (key.indexOf('Percent') >= 0) {
                  if (!map['Percent']) map['Percent'] = {}
                  map['Percent'][regexKey.replace(' Percent', '')] = regexValue
                }
                if (key.indexOf('Percent') < 0) {
                  if (!map['Used Space']) map['Used Space'] = {}
                  map['Used Space'][regexKey] = regexValue
                  if (parseInt(regexValue[0], 10) >= parseInt(regexValue[1], 10)) {
                    map.partitionWarning++
                  }
                  map.critical = map.critical + parseInt(regexValue[1], 10) || 0
                  map.warning = map.warning + parseInt(regexValue[2], 10) || 0
                  map.total = map.total + parseInt(regexValue[4], 10) || 0
                }
              }
              return map
            },
            {
              partitionWarning: 0,
              critical: 0,
              warning: 0,
              total: 0
            }
          )
          return obj
        } else {
          return {
            '/ Percent': ['--']
          }
        }
      }
      const critical = DiskData.filter((d) => d.state > 0).map((d) => {
        return {
          ...d,
          perf_data: {
            // ...perfData(d.perf_data),
            ...perfData(JSON.stringify(d.perf_data)),
            data: d.perf_data
          }
        }
      })
      let chart = {
        groupName: 'Disk Usage',
        down: critical.length,
        up: (DiskData || []).length - critical.length,
        total: (DiskData || []).length
      }
      if (DiskData.length === 1 && DiskData[0].perf_data) {
        const perf_data = perfData(JSON.stringify(DiskData[0].perf_data))
        // const perf_data = perfData(DiskData[0].perf_data)
        let used = 0
        let total = 100
        if (perf_data['Used Space']) {
          total = Object.values(perf_data['Used Space']).reduce((map, val) => {
            return map + parseInt(val[val.length - 1] || 0, 10)
          }, 0)
          used = Object.values(perf_data['Used Space']).reduce((map, val) => {
            return map + parseInt(val[0] || 0, 10)
          }, 0)
        }
        chart = {
          groupName: 'Disk Usage',
          plugin_output: DiskData[0].plugin_output,
          usage: ((used / total) * 100).toFixed(2).replace(/\.00$/, '') + '%',
          // usage: parseInt(perf_data.Physical_Memory_Utilisation[0], 10) || 0,
          used: used + 'GB',
          title: ((used / total) * 100).toFixed(2).replace(/\.00$/, '') + '%',
          total: total + 'GB',
          state: DiskData[0].state !== 0,
          perf_data,
          perf_data_str: DiskData[0].perf_data
          // partitionWarning: DiskData[0]
        }
        // console.log('perf_data', perf_data)
        // console.log('chart', chart)
      }
      return {
        total: (DiskData || []).length,
        data: DiskData,
        critical,
        chart
      }
    }
  },
  methods: {
    ...mapActions({
      trackEvent: 'user/trackEvent',
      setTimer: 'nagiosxi/setTimer'
    }),
    Init() {
      this.boat = this.boatsOpt.find((d) => d.name === this.id) || null
      this.getMembers(this.boat.name)
      this.chartTimeType = this.TimeOptions[0]
    },
    formatDate(timeStamp, format) {
      return date.formatDate(
        timeStamp,
        format
      )
    },
    filterFn(val, update) {
      update(() => {
        if (val === '') {
          this.filterOptions = this.membersOpts
        } else {
          const needle = val.toLowerCase()
          this.filterOptions = this.membersOpts.filter(
            (v) => v.label.toLowerCase().indexOf(needle) > -1
          )
        }
      })
    },
    async getMembers(keyWord) {
      // this.membersOptiondata = []
      this.loading = true
      this.dashBoardData = null
      const str = this.boat.type === 'IDC'
        ? `/services?host_groups[regex]=${keyWord}_Status&columns=description,display_name,groups,host_address,host_alias,host_display_name,host_groups,host_name,host_perf_data,state,perf_data,state,plugin_output`
        : `/services?groups[regex]=${keyWord}&columns=description,display_name,groups,host_address,host_alias,host_display_name,host_groups,host_name,host_perf_data,state,perf_data,state,plugin_output`
      try {
        const res = await Nagiosxi.thruk(str)
        this.membersOptiondata = [...res.data] || []
      } catch (error) {
        console.error(error)
        this.loading = false
      }
      if (!this.type) {
        this.device = this.membersOpts[0]
      } else {
        this.device =
          this.membersOpts.find((d) => d.label === this.type) ||
          this.membersOpts[0]
      }
      const hostName = this.boat.type === 'IDC' ? this.type : this.queryString
      this.dashBoardData = this.membersOptiondata
        .filter((d) => {
          return this.type === 'all'
            ? d // .groups.indexOf(this.boat.group) > -1
            : d.host_name === hostName
        })
        .reduce((map, val) => {
          if (!map[val['description']]) map[val['description']] = []
          map[val['description']] = [...map[val['description']], val]
          return map
        }, {})
      this.loading = false
    },
    async getServicesDetail(host, description) {
      try {
        // services/<host>/<service>
        const { data } = await Nagiosxi.thruk(`/services/${host}/${description}`)
        return data
      } catch (error) {
        console.error(error)
        return null
      }
    },
    barChartwithPolar(data) {
      if (!data) return null
      let tooltip = '' // threshold
      if (data.perf_data && data.perf_data.total) {
        const critical = (
          (data.perf_data.critical / data.perf_data.total) *
          100
        ).toFixed(0)
        const warning = (
          (data.perf_data.warning / data.perf_data.total) *
          100
        ).toFixed(0)
        //  margin-top: 0.5rem; padding-top:
        tooltip = `<div class="q-mt-sm q-pt-xs" style="border-top: 1px solid #efefef;"> critical: ${critical}% <br/> warning: ${warning}% </div>`
      }
      //  const labels = ['up', 'down']
      const color = data.state
        ? (colors.getBrand('negative') || '#FF0007')
        : (colors.getBrand('positive') || '#01FF00')
      return {
        groupName: data.groupName,
        labels: ['usage'],
        options: {
          title: [
            {
              text: data.title,
              top: '35%',
              left: 'center',
              textStyle: {
                color: '#fff'
              }
            },
            {
              text: data.groupName,
              bottom: '5',
              left: 'center',
              textStyle: {
                fontSize: '12',
                color: '#fff'
              }
            }
          ],
          polar: {
            radius: ['55%', '70%'],
            center: ['50%', '40%']
          },
          tooltip: {
            trigger: 'item',
            // formatter: '{b} : {c}GB'
            formatter: `{b}: {c}GB<br /> total: ${data.total} <br/> ${tooltip}`
          },
          xAxis: {
            show: false
          },
          yAxis: {
            show: false
          },
          angleAxis: {
            max: parseFloat(data.total, 10),
            show: false
          },
          radiusAxis: {
            type: 'category',
            show: true
          },
          series: [
            {
              type: 'bar',
              barWidth: 100,
              showBackground: true,
              backgroundStyle: {
                color: 'rgba(66, 66, 66, .5)'
              },
              coordinateSystem: 'polar',
              data: [
                {
                  value: parseFloat(data.used, 10),
                  name: 'usage',
                  itemStyle: {
                    normal: {
                      borderWidth: 2,
                      color: color
                    }
                  }
                }
              ]
            }
          ]
        }
      }
    },
    DoughnutData(data) {
      if (!data) return null
      const labels = [this.$t('topView.host_up'), this.$t('topView.host_down')]
      return {
        groupName: data.groupName,
        options: {
          title: {
            text: `${Math.round((data.up / data.total) * 100)}%`,
            top: '35%',
            left: 'center',
            textStyle: {
              color: '#fff'
            }
          },
          legend: {
            bottom: 2
          }
        },
        data: [
          {
            value: data.up,
            name: labels[0],
            itemStyle: {
              normal: {
                color: (colors.getBrand('positive') || '#01FF00')
              }
            }
          },
          {
            value: data.down,
            name: labels[1],
            itemStyle: {
              normal: {
                color: (colors.getBrand('negative') || '#FF0007')
              }
            }
          }
        ]
      }
    },
    GaugeChartData(data) {
      if (!data) return {}
      return {
        colorSet: [
          [data.warning / data.total / 100, (colors.getBrand('positive') || '#01FF00')],
          [data.critical / data.total / 100, (colors.getBrand('warning') || '#FFF002')],
          [1, (colors.getBrand('negative') || '#FF0007')]
        ],
        seriesName: 'CPU',
        data: [
          {
            value: parseFloat(data.avg / data.total).toFixed(2).replace(/\.00$/, ''),
            name: `${data.groupName}`
          }
        ]
      }
    },
    async getInfluxDb() {
      this.loadingInflux = true
      let results = null
      this.LineChartData = null
      try {
        const res = await Promise.all(
          Array.from(this.fluxDB, async(x) => ({
            name: x.name,
            type: x.type,
            data: await IIMS.influxDb(x.query)
          }))
        )
        results = res.map((d) => ({ ...d, data: d.data.data.results }))
      } catch (error) {
        console.error(error)
      }
      if (!results) {
        this.LineChartData = null
        this.loadingInflux = false
        return
      }
      // const dates = results
      const series = results.map((d) => {
        if (d.type === 'line') {
          return {
            type: d.type,
            cursor: 'default',
            areaStyle: {
              color: {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                  offset: 0, color: '#365470' // 0%
                }, {
                  offset: 1, color: '#242933 ' // 100%
                }],
                global: false
              }
            },
            name: d.name,
            showSymbol: false,
            data: d.data
              ? d.data[0].series
                ? d.data[0].series[0].values
                : []
              : []
          }
        }
        return {
          type: d.type,
          cursor: 'default',
          name: d.name,
          data: d.data
            ? d.data[0].series
              ? d.data[0].series[0].values
              : []
            : [],
          itemStyle: {
            color: '#FD1050',
            color0: '#0CF49B',
            borderColor: '#FD1050',
            borderColor0: '#0CF49B'
          }
        }
      })
      let formatter = null
      let YAxisFormat = null
      if (this.chartDevice) {
        if (this.chartDevice.id === 'Bandwidth' || this.chartDevice.id === 'bpsout' || this.chartDevice.id === 'bpsin') {
          YAxisFormat = (value) => getReadableFileSizeString(value)
        }
        if (this.chartDevice.id === 'CPU') {
          YAxisFormat = '{value}%'
        }
        if (this.chartDevice.id === 'Memory') {
          YAxisFormat = (value) => humanStorageSize(value)
        }
        if (this.chartDevice.id === 'Disk') {
          YAxisFormat = '{value}GB'
        }
        if (this.chartDevice.id === 'RTA' || this.chartDevice.id === 'Satellite') {
          YAxisFormat = '{value}s'
        }
        this.chartTimeType.id === 'realtime'
          ? formatter = (params) => {
            return params.map(item => {
              let formatValue = item.value[1]
              if (this.chartDevice.id === 'Bandwidth') {
                formatValue = !isNaN(item.value[1]) ? getReadableFileSizeString(item.value[1] || 0) : '--'
              }
              if (this.chartDevice.id === 'CPU') {
                formatValue = !isNaN(item.value[1]) ? item.value[1] + '%' : '--'
              }
              if (this.chartDevice.id === 'Memory') {
                formatValue = !isNaN(item.value[1]) ? humanStorageSize(item.value[1] || 0) : '--'
              }
              if (this.chartDevice.id === 'Disk') {
                formatValue = !isNaN(item.value[1]) ? item.value[1] + 'GB' : '--'
              }
              if (this.chartDevice.id === 'RTA' || this.chartDevice.id === 'Satellite') {
                formatValue = item.value[1] !== null ? item.value[1] + 's' : item.value[1]
              }
              return `<div>${item.axisValueLabel} <br/>
                ${item.marker} ${item.seriesName}: ${formatValue}</div>`
            }).join('')
          }
          : formatter = (params) => {
            return params.map(item => {
              const marker = `<span style="display:inline-block;margin-right:5px;border-radius:5px;width:5px;height:5px;background-color:${item.color};"></span>`
              const dimensionNames = item.dimensionNames
                .map((dim, index) => {
                  let formatValue = item.value[index]
                  if (this.chartDevice.id === 'bpsout' || this.chartDevice.id === 'bpsin') {
                    formatValue = !isNaN(formatValue) ? getReadableFileSizeString(formatValue || 0) : '--'
                  }
                  if (this.chartDevice.id === 'CPU') {
                    formatValue = !isNaN(formatValue) ? formatValue + '%' : '--'
                  }
                  if (this.chartDevice.id === 'Memory') {
                    formatValue = !isNaN(formatValue) ? humanStorageSize(formatValue || 0) : '--'
                  }
                  if (this.chartDevice.id === 'Disk') {
                    formatValue = !isNaN(formatValue) ? formatValue + 'GB' : '--'
                  }
                  if (this.chartDevice.id === 'RTA') {
                    formatValue = !isNaN(formatValue) ? formatValue + 'ms' : '--'
                  }
                  if (dim === 'base' || dim === 'value' || dim === 'x') return ''
                  if (dim === 'y') return `${formatValue}`
                  else return `<div> ${marker} ${dim}: ${formatValue} </div>`
                })
                .filter(d => d)
              if (item.componentSubType === 'line') {
                return `<div>
                  ${marker} ${item.seriesName}: ${dimensionNames.join('')}</div>`
              }
              return `<div>${item.axisValueLabel} <br/>
                  ${item.marker} ${item.seriesName}: ${dimensionNames.join('')}</div>`
            }).join('')
          }
      }
      const tooltip = {
        trigger: 'axis',
        formatter,
        axisPointer: {
          animation: false,
          type: 'cross'
        }
      }
      this.LineChartData = {
        tooltip,
        yAxis: {
          type: 'value',
          axisLabel: {
            formatter: YAxisFormat,
            textStyle: {
              color: '#fff'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: '#333'
            }
          }
        },
        xAxis: {
          type: 'time',
          splitLine: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: '#ccc'
            }
          }
        },
        series
      }
      this.loadingInflux = false
    }
  },
  mounted() {
    this.setTimer(true)
    this.trackEvent({
      category: 'Boat_View_Detail',
      action: 'Click'
    })
    if (this.boatsList) {
      this.waitForboatFetch = 1 // has boats
      this.Init()
    }
    this.keepTimer = setInterval(async() => {
      this.trackEvent({
        category: 'Boat_View_Detail',
        action: 'Live'
      })
    }, 300000)
  },
  beforeDestroy() {
    clearInterval(this.keepTimer)
    clearInterval(this.inFluxTimer)
    console.log('beforeDestroy vessesl timer')
    this.setTimer(false)
  }
}
</script>
<style lang="sass" scoped>
  .right-block
    // display: flex
    // grid-template-columns: 1fr
    // grid-template-rows: minmax(1fr, 320px)
    // grid-gap: 0.5rem
    // > div
    //   width: 100%
    //   height: 100%
    //   min-height: 320px
  .card-grid
    .my-card
      min-height: 310px
      // padding: .5rem
      // display: flex
      // width: 50%
      // display: grid
      // grid-template-columns: repeat(4, 1fr)
      // grid-template-rows: 1fr
      // grid-gap: 0.5rem
      // width: 100%
      &.card-grid-md
        // grid-template-columns: repeat(2, 1fr)
        // grid-template-rows: repeat(2, 320px)
        // repeat(2, 1fr)
      &.card-grid-sm
        // grid-template-columns: 1fr
        // grid-template-rows: repeat(4, minmax(1fr, 320px))
    &.right-block-all
      .my-card
        // min-height: 50%
      .card-grid
        // grid-template-columns: repeat(2, 1fr)
        // grid-template-rows: repeat(2, auto)
  .light
    position: relative
    padding-left: 16px
    text-transform: capitalize
    &:before
      content: ''
      width: 10px
      height: 10px
      left: 0
      top: 6px
      position: absolute
      background: transparent
      border-radius: 50%
    &.light--positive
      &:before
        background: #01FF00
        background: var(--q-color-positive)
    &.light--negative
      &:before
        background: #FF0007
        background: var(--q-color-negative)
    &.light--warning
      &:before
        background: #FFF002
        background: var(--q-color-warning)
.partitions-output
  letter-spacing: 1px
</style>
