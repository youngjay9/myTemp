<template>
<q-page class="q-pa-md">
  <div class="">
    <div class="row q-pa-sm">
      <div class="q-pa-sm col-xs-12 col-sm-6 col-md-4">
        <q-input dense filled v-model="dateRange" :label="$t('form.dateRange')">
          <!-- mask="date" :rules="['date']" -->
          <template v-slot:append>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy ref="qDateProxyEnd" transition-show="scale" transition-hide="scale">
                <q-date
                  :options="dateOptions"
                  v-model="date"
                  range/>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>
      <div class="q-pa-sm col-xs-12 col-sm-3 col-md-4">
        <q-input dense filled v-model="query.userName" debounce="500" :label="$t('report.UserName')" @change="fetchData" />
      </div>
      <div class="q-pa-sm col-xs-12 col-sm-3 col-md-4">
        <q-input dense filled v-model="query.userId" debounce="500" :label="$t('report.UserID')" @change="fetchData"/>
      </div>
    </div>
    <div class="col q-pa-md flex justify-end">
      <q-btn
        outline
        rounded
        align="around"
        color="primary"
        :label="$t('report.downloadReport')"
        icon="get_app"
        @click="download"/>
    </div>
    <div class="col q-pa-md">
      <q-table
        :grid="$q.screen.lt.sm"
        :title="$t('menu.summary')"
        row-key="index"
        :data="tableData"
        :columns="columns"
        :loading="loading"
        color="primary"
        :rows-per-page-label="$t('report.rowPage')"
        :pagination="{
          sortBy: 'loginTimeString',
          descending: true,
        }"
      />
    </div>
    <div class="row">
      <div class="col q-pa-md">
        <template v-if="userCount">
            <!-- 依所選條件，顯示每小時或每日的系統使用人數 -->
          <h6 class="q-ma-none"> {{userCount.title}} </h6>
          <LineChart chartId="userCount" style="height: 450px" :data="lineChart(userCount)"/>
        </template>
      </div>
    </div>
    <div class="row">
      <div class="col q-pa-md" >
        <template v-if="usageCount">
          <!-- 顯示每個帳號的總使用次數 (取Login Success 欄位值) -->
          <h6 class="q-ma-none"> {{usageCount.title}} </h6>
          <LineChart chartId="usageCount" style="height: 450px" :data="barChart(usageCount)"/>
        </template>
      </div>
    </div>
    <div class="row">
      <div class="col q-pa-md">
        <template v-if="liveAverage">
          <!-- 顯示每個帳號的Average Session Length -->
          <h6 class="q-ma-none"> {{liveAverage.title}} </h6>
          <LineChart chartId="liveAverage" style="height: 450px" :data="barChart(liveAverage)"/>
        </template>
      </div>
    </div>
  </div>
</q-page>
</template>

<script>
import { date } from 'quasar'
import IIMS from '@/api/iims'
import LineChart from '@/components/charts/LineChart'
import mixins from '@/mixins/mixins'
import ChartSetting from '@/shared/chartOptions'
// import { mapActions } from 'vuex'

export default {
  name: 'ReportSummary',
  mixins: [mixins],
  components: {
    LineChart
  },
  props: {
    type: {
      type: String
    }
  },
  data() {
    const endDate = date.formatDate(new Date(), 'YYYY/MM/DD')
    const startDate = date.formatDate(date.subtractFromDate(endDate, { days: 30 }), 'YYYY/MM/DD')
    return {
      query: {
        userId: '',
        userName: '',
        fromTs: 0,
        toTs: 0
      },
      date: {
        from: startDate,
        to: endDate
      },
      loading: false,
      columns: [
        {
          label: '#',
          align: 'left',
          field: 'index'
        },
        { name: 'UserID', align: 'left', label: this.$t('report.UserID'), field: 'account', sortable: true },
        {
          name: 'name',
          align: 'left',
          label: this.$t('report.UserName'),
          field: 'name',
          sortable: true
        },
        { name: 'loginTimeString',
          align: 'left',
          label: this.$t('report.loginTimeString'),
          field: row => date.formatDate(row.loginTimeString, 'YYYY-MM-DD HH:mm:ss'),
          sortable: true
        },
        { name: 'logoutTimeString',
          align: 'left',
          label: this.$t('report.logoutTimeString'),
          field: row => date.formatDate(row.logoutTimeString, 'YYYY-MM-DD HH:mm:ss'),
          sortable: true
        },
        { name: 'loginIp',
          label: this.$t('report.loginIp'),
          field: 'loginIp'
        },
        { name: 'loginSuccessCount',
          label: this.$t('report.loginSuccessCount'),
          field: 'loginSuccessCount',
          sortable: true
        },
        { name: 'loginFailCount',
          label: this.$t('report.loginFailCount'),
          field: 'loginFailCount',
          sortable: true
        },
        { name: 'liveSum',
          label: this.$t('report.clickTime'),
          field: row => this.getDateDiff(row.liveSum),
          sortable: true
        },
        { name: 'liveAvg',
          label: this.$t('report.liveAvg'),
          field: row => this.getDateDiff(row.liveAvg),
          sortable: true
        }
      ],
      data: [],
      userCount: null,
      usageCount: null,
      liveAverage: null
    }
  },
  watch: {
    date() {
      if (this.date && this.date.from && this.date.to) {
        this.$refs.qDateProxyEnd.hide()
        this.query.fromTs = parseInt(date.formatDate(`${this.date.from} 00:00:00`, 'X'), 10)
        this.query.toTs = parseInt(date.formatDate(`${this.date.to} 23:59:59`, 'X'), 10)
        this.fetchData()
      }
    }
  },
  computed: {
    dateRange: {
      get: function() {
        if (!this.date) return ''
        this.fetchData()
        return `${this.date.from} - ${this.date.to}`
      },
      set: function() {
        return ''
      }
    },
    tableData() {
      return this.data
        .slice()
        .sort((a, b) => b.loginTime - a.loginTime)
        .map((d, index) => ({
          index: index + 1,
          // key: `${d.account}-${index}`,
          ...d
        }))
    }
  },
  methods: {
    dateOptions(d) {
      return d <= date.formatDate(new Date(), 'YYYY/MM/DD')
    },
    async fetchData() {
      if (!this.query.fromTs || !this.query.toTs) return
      this.loading = true
      this.data = []
      try {
        const { data: {
          data
        }} = await IIMS.userSummary(this.query)
        data && (this.data = data)
        this.userCountEachHoursOrDays(this.query)
        this.usageCountEachAccount(this.query)
        this.liveAverageEachAccount(this.query)
      } catch (error) {
        console.error(error)
      } finally {
        this.loading = false
      }
    },
    async download() {
      try {
        const { data } = await IIMS.exportCsvUserSummary(this.query)
        data && this.downloadCSV(data, `UserSummary_${this.dateRange}`)
      } catch (error) {
        console.error(error)
      }
    },
    async userCountEachHoursOrDays(query) {
      let unit = 'Hour'
      let formatDate = 'YYYY/MM/DD HH:mm'
      // over 1 week
      if (this.query.toTs - this.query.fromTs > 24 * 60 * 60 * 5) {
        unit = 'Day'
        formatDate = 'YYYY/MM/DD'
      }
      this.userCount = null
      try {
        const { data } = await IIMS.userCountEachHoursOrDays({
          ...query,
          unit
        })
        this.userCount = {
          title: this.$t('report.Usage'),
          ...data,
          data: data.data.map(d => ({ name: d.fromTime * 1000,
            value: [date.formatDate(d.fromTime * 1000, formatDate), d.count]
          })),
          // tooltipFormatter: '{a} <br> {c0}'
          tooltipFormatter: (list) => {
            const data = list[0]
            return `<div style="padding: 2px;"><span>${data.axisValueLabel}</span></div>
              <div style="padding: 2px;"><b style="color: ${data.color}">${this.$t('report.Usage')}:</b> <span>${data.value}</span></div>`
          }
        }
      } catch (error) {
        console.error(error)
      }
    },
    async usageCountEachAccount(query) {
      this.usageCount = null
      try {
        const { data } = await IIMS.usageCountEachAccount(query)
        data && (this.usageCount = {
          title: this.$t('report.Usage_counts'),
          ...data,
          data: data.data.map(d => ({
            name: d.account,
            value: d.count
          })),
          tooltipFormatter: (list) => {
            const data = list[0]
            return `<div style="padding: 2px;"><b style="color: ${data.color}">${this.$t('report.UserID')}:</b> <span>${data.name}</span></div>
              <div style="padding: 2px;"><b style="color: ${data.color}">${this.$t('report.Counts')}:</b> <span>${data.value}</span></div>`
          }
        })
      } catch (error) {
        console.error(error)
      }
    },
    async liveAverageEachAccount(query) {
      this.liveAverage = null
      try {
        const { data } = await IIMS.liveAverageEachAccount(query)
        data && (this.liveAverage = {
          title: this.$t('report.liveAvg'),
          ...data,
          data: data.data.map(d => ({
            name: d.account,
            value: d.average
          })),
          tooltipFormatter: (list) => {
            const data = list[0]
            return `<div style="padding: 2px;"><b style="color: ${data.color}">${this.$t('report.UserID')}:</b> <span>${data.name}</span></div>
              <div style="padding: 2px;"><b style="color: ${data.color}">${this.$t('report.Average')}:</b> <span>${this.getDateDiff(data.value)}</span></div>`
          }
        })
      } catch (error) {
        console.error(error)
      }
    },
    barChart(data) {
      return {
        grid: {
          left: '15',
          right: '15',
          bottom: '55',
          top: '55',
          containLabel: true
        },
        legend: {
          top: '15',
          left: '20'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
            label: {
              backgroundColor: '#6a7985'
            }
          },
          formatter: data.tooltipFormatter
        },
        xAxis: {
          type: 'category',
          axisLine: {
            show: true,
            lineStyle: {
              color: '#ddd'
            }
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: '#ccc'
            }
          },
          data: data.data.map(d => d.name)
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            textStyle: {
              color: '#fff'
            }
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#ddd'
            }
          },
          splitLine: {
            show: false,
            lineStyle: {
              color: '#333'
            }
          }
        },
        dataZoom: ChartSetting.dataZoom(),
        series: [{
          name: data.title,
          type: 'bar',
          barMaxWidth: 40,
          cursor: 'default',
          data: data.data.map(d => d.value),
          // showBackground: true,
          // backgroundStyle: {
          //   color: 'rgba(220, 220, 220, 0.1)'
          // },
          itemStyle: {
            normal: {
              color: '#01FF00'
              //  colors.getBrand('positive')
            }
          }
        }
        ]
      }
    },
    lineChart(data) {
      return {
        grid: {
          left: '15',
          right: '15',
          bottom: '55',
          top: '55',
          containLabel: true
        },
        dataZoom: ChartSetting.dataZoom(),
        xAxis: {
          type: 'time',
          axisLine: {
            show: true,
            lineStyle: {
              color: '#ddd'
            }
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: '#ccc'
            }
          }
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            textStyle: {
              color: '#fff'
            }
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#ddd'
            }
          },
          splitLine: {
            show: false,
            lineStyle: {
              color: '#333'
            }
          }
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'line'
          },
          formatter: data.tooltipFormatter
        },
        series: [{
          type: 'line',
          name: this.$t('report.Usage'),
          showSymbol: false,
          cursor: 'default',
          data: data.data
        }]
      }
    }
  },
  mounted() {
    this.query.fromTs = parseInt(date.formatDate(`${this.date.from} 00:00:00`, 'X'), 10)
    this.query.toTs = parseInt(date.formatDate(`${this.date.to} 23:59:59`, 'X'), 10)
  }
}
</script>
