<template>
  <q-page class="q-pa-md">
    <div class="">
      <div class="col q-pa-md flex justify-between">
        </div>
        <div class="col q-pa-md">
          <q-table
            :title="$t('menu.online')"
            :grid="$q.screen.lt.sm"
            :data="dataTable"
            :columns="columns"
            row-key="key"
            :rows-per-page-label="$t('report.rowPage')"
            :pagination="pagination">
          </q-table>
        </div>
    </div>
  </q-page>
</template>

<script>
import { date } from 'quasar'
import IIMS from '@/api/iims'

export default {
  name: 'Report',
  props: {
    type: {
      type: String
    }
  },
  data() {
    const endDate = date.formatDate(new Date(), 'YYYY/MM/DD')
    const startDate = date.formatDate(date.subtractFromDate(endDate, {
      days: 7
    }), 'YYYY/MM/DD')
    return {
      keepTimer: null,
      date: {
        startDate,
        endDate
      },
      userName: '',
      fnc: '',
      fnOptions: ['Top', 'L1', 'L2', 'L3'],
      show: 'table',
      pagination: {
        sortBy: 'loginTimeString',
        descending: true,
        page: 1,
        rowsPerPage: 15
      },
      columns: [{
        name: 'rowIndex',
        label: '#',
        field: 'rowIndex',
        align: 'left'
      },
      {
        name: 'key',
        label: this.$t('report.UserID'),
        required: true,
        align: 'left',
        field: 'account',
        // field: row => row.name,
        // format: val => `${val}`,
        sortable: true
      },
      {
        name: 'account',
        label: this.$t('report.UserName'),
        align: 'left',
        field: 'name',
        sortable: true
      },
      {
        name: 'loginTimeString',
        label: this.$t('report.loginTimeString'),
        format: val => `${date.formatDate(val, 'YYYY/MM/DD HH:mm:ss') || ''}`,
        field: 'loginTimeString',
        sortable: true
      },
      {
        name: 'loginIp',
        label: this.$t('report.loginIp'),
        field: 'loginIp',
        sortable: true
      }
      ],
      data: []
    }
  },
  computed: {
    dataTable() {
      return this.data.slice()
        .sort((a, b) => b.loginTime - a.loginTime)
        .map((d, i) => ({
          rowIndex: i + 1,
          key: `${i}-${d.account}`,
          ...d
        }))
    }
  },
  methods: {
    endDateOptionsFn(date) {
      return date >= this.date.startDate
    },
    async getLiveUser() {
      try {
        const res = await IIMS.getLiveUser()
        this.data = res.data.data
      } catch (error) {
        console.error(error)
      }
    }
  },
  created() {
    this.getLiveUser()
  },
  async mounted() {
    // this.keepTimer = setInterval(async() => {
    //   await this.getLiveUser()
    // }, 500000)
  },
  beforeDestroy() {
    // clearInterval(this.keepTimer)
    // console.log('beforeDestroy LiveUser timer')
  }
}
</script>
