<template>
<q-page class="q-pa-md">
  <div class="">
    <div class="row q-pa-sm">
      <div class="q-pa-sm col-xs-12 col-sm-3 col-md-3">
        <q-input dense filled v-model="dateRange" :label="$t('form.dateRange')">
          <!-- mask="date" :rules="['date']" -->
          <template v-slot:append>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy ref="qDateProxyEnd" transition-show="scale" transition-hide="scale">
                <q-date
                  :options="dateOptions"
                  v-model="date"
                  range />
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>
      <div class="q-pa-sm col-xs-12 col-sm-3 col-md-3">
        <q-select emit-value map-options dense filled v-model="query.category" :options="categorys" :label="$t('report.function')" @input="onRequest"/>
      </div>
      <div class="q-pa-sm col-xs-12 col-sm-3 col-md-3">
        <q-input dense filled v-model="query.userName" debounce="500" :label="$t('report.UserName')" @input="onRequest" />
      </div>
      <div class="q-pa-sm col-xs-12 col-sm-3 col-md-3">
        <q-input dense filled v-model="query.userId" debounce="500" :label="$t('report.UserID')" @input="onRequest"/>
      </div>
    </div>
    <div class="col q-pa-md flex justify-end">
      <q-btn
        outline
        rounded
        align="around"
        color="primary"
        :label="$t('report.downloadReport')"
        icon="get_app"
        @click="download"/>
    </div>
    <div class="col q-pa-md">
      <q-table
        :grid="$q.screen.lt.sm"
        :title="$t('menu.activity')"
        :data="tableData"
        :columns="columns"
        row-key="key"
        :loading="loading"
        color="primary"
        :pagination.sync="pagination"
        :rows-per-page-label="$t('report.rowPage')"
        @request="onRequest">
      </q-table>
    </div>
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 q-pa-md">
        <!-- 每個帳號在這段時間使用哪些Function及多少時間 -->
        <template v-if="accountCount">
          <h6 class="q-ma-none"> {{accountCount.title}} </h6>
          <LineChart chartId="accountCount" style="height: 450px" :data="barChart(accountCount)"/>
        </template>
      </div>
      <div class="col-xs-12 col-sm-12 col-md-12 q-pa-md">
        <!-- 依所選條件，顯示每個Function被使用的總次數及總時間 -->
        <template  v-if="categoryCount">
          <h6 class="q-ma-none"> {{categoryCount.title}} </h6>
          <LineChart chartId="categoryCount" style="height: 450px" :data="barLineChart(categoryCount)"/>
        </template>
      </div>
    </div>
  </div>
</q-page>
</template>

<script>
import { colors, date } from 'quasar'
import IIMS from '@/api/iims'
import LineChart from '@/components/charts/LineChart'
import mixins from '@/mixins/mixins'
import ChartSetting from '@/shared/chartOptions'

export default {
  name: 'ReportActive',
  mixins: [mixins],
  components: {
    LineChart
  },
  props: {
    type: {
      type: String
    }
  },
  data() {
    const endDate = date.formatDate(new Date(), 'YYYY/MM/DD')
    const startDate = date.formatDate(date.subtractFromDate(endDate, { days: 7 }), 'YYYY/MM/DD')
    return {
      query: {
        userId: '',
        userName: '',
        category: '',
        fromTs: 0,
        toTs: 0
      },
      pagination: {
        sortBy: 'click_time',
        descending: true,
        page: 1,
        rowsPerPage: 7,
        rowsNumber: 100
      },
      date: {
        from: startDate,
        to: endDate
      },
      loading: false,
      categorys: [
        {
          label: 'All',
          value: ''
        },
        {
          label: 'Top View',
          value: 'Top_View'
        },
        {
          label: 'LEVEL 2 IDC View Detail',
          value: 'IDC_View_Detail'
        },
        {
          label: 'LEVEL 3  Boat View Detail',
          value: 'Boat_View_Detail'
        }
      ],
      show: 'table',
      columns: [
        {
          label: '#',
          align: 'left',
          field: 'index'
        },
        {
          name: 'account',
          label: this.$t('report.UserID'),
          required: true,
          align: 'left',
          field: 'account',
          sortable: true
        },
        {
          name: 'name',
          align: 'left',
          label: this.$t('report.UserName'),
          field: 'name',
          sortable: true
        },
        {
          name: 'click_time',
          label: this.$t('report.click_time'),
          align: 'left',
          field: row => date.formatDate(row.clickTimeString, 'YYYY-MM-DD HH:mm:ss'),
          sortable: true
        },
        {
          name: 'live_duration',
          label: this.$t('report.live_duration'),
          align: 'left',
          field: row => date.formatDate(row.stayTimeString, 'YYYY-MM-DD HH:mm:ss')
        },
        {
          name: 'loginIp',
          label: this.$t('report.loginIp'),
          field: 'loginIp'
        },
        {
          name: 'clickTime',
          label: this.$t('report.clickTime'),
          field: row => this.getDateDiff(row.liveDuration)
        },
        {
          name: 'category',
          label: this.$t('report.function'),
          field: 'category',
          sortable: true
        }
      ],
      data: [],
      accountCount: null,
      categoryCount: null
    }
  },
  watch: {
    date() {
      if (this.date && this.date.from && this.date.to) {
        this.$refs.qDateProxyEnd.hide()
        //  0 點0 分0 秒 ，後面應該是23點59分59
        this.query.fromTs = parseInt(date.formatDate(`${this.date.from} 00:00:00`, 'X'), 10)
        this.query.toTs = parseInt(date.formatDate(`${this.date.to} 23:59:59`, 'X'), 10)
        this.pagination.page = 1
        this.onRequest({ pagination: this.pagination })
      }
    }
  },
  computed: {
    dateRange: {
      get: function() {
        if (!this.date) return ''
        return `${this.date.from} - ${this.date.to}`
      },
      set: function() {
        return
      }
    },
    tableData() {
      const page = (this.pagination.page - 1) * this.pagination.rowsPerPage
      return this.data
        .map((d, index) => ({
          index: index + 1 + page,
          key: `${d.account}-${index}`,
          ...d
        }))
    }
  },
  methods: {
    dateOptions(d) {
      return d <= date.formatDate(new Date(), 'YYYY/MM/DD')
    },
    onRequest(props) {
      const { page, rowsPerPage, sortBy, descending } = props.pagination ? props.pagination : this.pagination
      const query = {
        limit: rowsPerPage,
        offset: page - 1,
        sortBy,
        orderBy: descending ? 'desc' : 'asc'
      }
      this.pagination = {
        ...this.pagination,
        ...props.pagination
      }
      this.fetchData(query)
    },
    async fetchData(pagination) {
      if (!this.query.fromTs || !this.query.toTs) return
      this.loading = true
      // this.data = []
      this.accountCount = null
      this.categoryCount = null
      try {
        const { data } = await IIMS.userActivity({
          ...this.query,
          ...pagination
        })
        if (data.total >= 0) {
          this.data = data.data
          this.pagination.rowsNumber = data.total
          this.timeCategoryEachAccount(this.query)
          this.usageEachCategory(this.query)
        }
      } catch (error) {
        console.error(error)
      } finally {
        this.loading = false
      }
    },
    async timeCategoryEachAccount(query) {
      this.accountCount = null
      try {
        const { data } = await IIMS.timeCategoryEachAccount(query)
        if (data.total <= 0) return
        const funcCategorys = this.categorys.map(d => d.value).filter(d => d)
        const series = funcCategorys.map(cat => {
          const d = data.data.map(d => {
            const item = d.categories.find(item => item.category === cat) || null
            return {
              value: item ? item.total : '',
              item
            }
          })
          return {
            name: cat,
            type: 'bar',
            data: d,
            cursor: 'default',
            barMaxWidth: 40,
            barMinHeight: 20
          }
        })
        this.accountCount = {
          title: this.$t('report.Each_Account_on_Category'),
          ...data,
          series,
          tooltipFormatter: (list) => {
            const listData = list.map(item => {
              const blockStyle = `<div style="display: inline-block; border-radius: 50%; width: 12px; height: 12px; background: ${item.color}"></div>`
              if (!item.data.item) {
                return `
                  <div style="padding: 2px;">
                    <div>${item.axisValue}</div>
                    <div style="padding-bottom: 2px;">
                      ${blockStyle}
                      <div style="display: inline-block; padding-right: 15px;"><b>${item.seriesName}</b></div>
                    </div>
                    <div style="color: #eee">
                      ${this.$t('vesselView.noData')}
                    </div>
                  </div>`
              }
              return `
              <div style="padding: 2px;">
                <div style="padding-bottom: 2px;">
                  ${blockStyle} <div style="display: inline-block;"><b>${item.seriesName}</b></div>
                </div>
                <div> <b style="color: #bbb;">${this.$t('report.Total')}:</b> <span>${this.getDateDiff(item.data.item.total)}</span> </div>
                <div> <b style="color: #bbb;">${this.$t('report.Average')}:</b> <span>${this.getDateDiff(item.data.item.average)}</span> </div>
              </div>
              `
            }).join('<hr style="border:none; border-top: 1px solid #aaa; padding: 2px 0;"/>')
            return `<div style="padding-bottom: 2px;">
              <b>${list[0].axisValue}</b>
            </div>${listData}`
          }
        }
      } catch (error) {
        console.error(error)
      }
    },
    async usageEachCategory(query) {
      this.categoryCount = null
      try {
        const { data } = await IIMS.usageEachCategory(query)
        if (data.total <= 0) return
        this.categoryCount = {
          title: this.$t('report.Page_Usage'),
          ...data,
          tooltipFormatter: (list) => {
            const title = ` <div style="padding-bottom: 2px;">
              <div style="display: inline-block;"><b>${list[0].name}</b></div>
            </div>`
            const values = list.map(item => {
              const blockStyle = `<div style="display: inline-block; border-radius: 50%; width: 12px; height: 12px; background: ${item.color}"></div>`
              return item.seriesIndex === 0
                ? `<div> ${blockStyle} <b style="color: #bbb;">${item.seriesName}: </b> <span>${item.value}</span> </div>`
                : `<div> ${blockStyle} <b style="color: #bbb;">${item.seriesName}: </b> <span>${this.getDateDiff(item.value)}</span> </div>`
            }).join('')
            return `<div style="padding: 2px;"> ${title} ${values}</div>`
          }
        }
      } catch (error) {
        console.error(error)
      }
    },
    barChart(data) {
      if (!data) return
      const color = [
        (colors.getBrand('positive') || '#01FF00'),
        '#5c6bc0',
        '#79D3F3'
      ]
      return {
        color,
        grid: {
          left: '3%',
          right: '4%',
          bottom: '55',
          top: '90',
          containLabel: true
        },
        legend: {
          top: '40',
          left: '10%'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
            label: {
              backgroundColor: '#6a7985'
            }
          },
          formatter: data.tooltipFormatter
        },
        xAxis: {
          type: 'category',
          axisLine: {
            show: true,
            lineStyle: {
              color: '#ddd'
            }
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: '#ccc'
            }
          },
          data: data.data.map(d => d.account)
        },
        yAxis: {
          name: this.$t('report.Secs'),
          nameTextStyle: {
            color: '#ddd'
          },
          type: 'value',
          axisLabel: {
            textStyle: {
              color: '#fff'
            }
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#ddd'
            }
          },
          splitLine: {
            show: false,
            lineStyle: {
              color: '#333'
            }
          }
        },
        dataZoom: ChartSetting.dataZoom(),
        series: data.series
      }
    },
    barLineChart(data) {
      if (!data) return
      const color = [
        '#01FF00',
        '#5c6bc0',
        '#79D3F3'
      ]
      return {
        color,
        grid: {
          left: '3%',
          right: '4%',
          bottom: '55',
          top: '90',
          containLabel: true
        },
        legend: {
          top: '40',
          left: '10%'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
            label: {
              backgroundColor: '#6a7985'
            }
          },
          formatter: data.tooltipFormatter
        },
        toolbox: ChartSetting.toolbox(true),
        xAxis: [
          {
            type: 'category',
            axisLine: {
              show: true,
              lineStyle: {
                color: '#ddd'
              }
            },
            splitLine: {
              show: false
            },
            axisLabel: {
              textStyle: {
                color: '#ccc'
              }
            },
            axisPointer: {
              type: 'shadow'
            },
            data: data.data.map(d => d.category)
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: this.$t('report.Counts'),
            nameTextStyle: {
              color: '#ddd'
            },
            axisLabel: {
              textStyle: {
                color: '#fff'
              }
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: '#ddd'
              }
            },
            splitLine: {
              show: false,
              lineStyle: {
                color: '#333'
              }
            }
          },
          {
            type: 'value',
            name: this.$t('report.Secs'),
            nameTextStyle: {
              color: '#ddd'
            },
            axisLabel: {
              textStyle: {
                color: '#fff'
              }
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: '#ddd'
              }
            },
            splitLine: {
              show: false,
              lineStyle: {
                color: '#333'
              }
            }
          }
        ],
        dataZoom: ChartSetting.dataZoom(),
        series: [
          {
            name: this.$t('report.Usage_counts'),
            type: 'bar',
            cursor: 'default',
            barMaxWidth: 40,
            data: data.data.map(d => d.count)
          },
          {
            name: this.$t('report.Usage_time'),
            type: 'line',
            cursor: 'default',
            yAxisIndex: 1,
            data: data.data.map(d => d.total)
          }
        ]
      }
    },
    async download() {
      try {
        const { data } = await IIMS.exportCsvUserActivity(this.query)
        data && this.downloadCSV(data, `UserActive_${this.dateRange}`)
      } catch (error) {
        console.error(error)
      }
    }
  },
  mounted() {
    this.query.fromTs = parseInt(date.formatDate(`${this.date.from} 00:00:00`, 'X'), 10)
    this.query.toTs = parseInt(date.formatDate(`${this.date.to} 23:59:59`, 'X'), 10)
    this.onRequest({ pagination: this.pagination })
  }
}
</script>
