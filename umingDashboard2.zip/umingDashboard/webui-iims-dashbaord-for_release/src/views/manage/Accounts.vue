<template>
<q-page class="q-pa-md">
  <div class="col q-pa-md">
    <div class="text-h6 q-mb-md">{{$t('menu.accounts')}}</div>
    <q-table
      :grid="$q.screen.lt.sm"
      :title="$route.params.id"
      :data="data"
      :columns="columns"
      row-key="name"
      :loading="loading"
      color="primary"
      :pagination.sync="pagination"
      :rows-per-page-label="$t('report.rowPage')"
      @row-click="editTable"
    >
     <template v-slot:body="props">
        <q-tr :props="props">
          <q-td key="account" :props="props">{{ props.row.account }}</q-td>
          <q-td key="name" :props="props">
            <div class="flex justify-start items-center">
              <div class="q-mr-sm">{{ props.row.name }}</div>
              <!-- <q-btn dense flat size="sm" round icon="edit"/> -->
            </div>
            <!-- <q-popup-edit
              @save="editTable(props.row)"
              v-model="props.row.name"
              title="Name"
              buttons
              label-set="Save"
              label-cancel="Cancel">
              <q-input
                type="text"
                v-model="props.row.name"
                dense
                autofocus>
              </q-input>
            </q-popup-edit> -->
          </q-td>
          <q-td key="role" :props="props">
            <q-select
              dense
              filled
              @input="editTable(props.row)"
              v-model="props.row.role"
              :options="roleOpt"/>
          </q-td>
          <q-td key="tokenExpiredDuration" :props="props">
            <div class="flex justify-end items-center">
              <div class="q-mr-sm" v-if="props.row.tokenExpiredDuration > 0">{{ props.row.tokenExpiredDuration }} Secs</div>
              <div class="q-mr-sm" v-else> Default </div>
              <q-btn dense flat size="xs" round icon="edit"/>
            </div>
            <q-popup-edit
              @save="editTable(props.row)"
              v-model="props.row.tokenExpiredDuration"
              title="Expired Duration"
              buttons
              label-set="Save"
              label-cancel="Cancel">
              <q-input
                type="number"
                v-model="props.row.tokenExpiredDuration"
                dense
                hint="如果設為 0 時，此帳號的 token 有效期會使用 Default"
                autofocus>
              </q-input>
            </q-popup-edit>
          </q-td>
          <q-td key="loginTimeString" :props="props">{{ formatDate(props.row.loginTimeString) }}</q-td>
          <q-td key="delete" :props="props">
            <q-btn dense flat size="10px" round icon="delete" @click="deleteUser(props.row.id)"/>
          </q-td>
        </q-tr>
     </template>
    </q-table>
  </div>
  <q-page-sticky position="bottom-right" :offset="[18, 18]">
    <q-btn
      round
      size="lg"
      icon="add"
      color="primary"
      @click="addAccountModal = true"/>
  </q-page-sticky>
  <q-dialog v-model="addAccountModal">
      <q-card style="width: 420px; max-width: 50vw;">
        <q-card-section class="row justify-between items-center q-pb-none">
          <b class="q-mr-md"> {{$t('report.addAccount')}} </b>
          <q-btn icon="close" flat round dense v-close-popup />
        </q-card-section>
        <q-card-section>
          <div class="q-pa-md">
            <q-form ref="AccountForm" class="q-gutter-lg" @submit="editTable(form)">
              <q-input
                filled
                dense
                v-model="form.account"
                :label="$t('report.Account') + '*'"
                hint="AD Account"
                lazy-rules
                :rules="[ val => val && val.length > 0 || $t('validation.empty')]"
              />
              <q-input
                filled
                dense
                type="number"
                v-model="form.tokenExpiredDuration"
                :label="$t('report.tokenExpiredDuration')"
                hint="如果設為 0 時，此帳號的 token 有效期會使用 Default"
                lazy-rules
                :rules="[
                  val => val !== null && val !== '' || $t('validation.empty')
                ]"
              />
              <q-select
                dense
                filled
                v-model="form.role"
                :options="roleOpt"
                :label="$t('report.role')"
                :rules="[ val => val && val.length > 0 || $t('validation.emptyRole')]"/>
                <!-- addAccountFailMsg -->
              <div class="bg-negative q-pa-md rounded-borders" v-if="addAccountFailMsg">
                {{addAccountFailMsg}}
              </div>
              <div class="flex justify-end">
                <q-btn :label="$t('form.Cancel')" color="primary" @click="addAccountModal = false" flat class="q-mr-sm" />
                <q-btn :label="$t('form.Submit')" type="submit" color="primary"/>
              </div>
            </q-form>
          </div>
        </q-card-section>
      </q-card>
  </q-dialog>
</q-page>
</template>

<script>
import { date } from 'quasar'
import { mapGetters } from 'vuex'
import IIMS from '@/api/iims'
export default {
  name: 'Accounts',
  props: {
    // type: {
    //   type: String
    // }
  },
  data() {
    return {
      form: {
        account: '',
        role: '',
        tokenExpiredDuration: 0
      },
      roleOpt: ['Admin', 'Normal'],
      columns: [
        { name: 'account',
          label: this.$t('report.Account'),
          field: 'account',
          align: 'left',
          sortable: true
        },
        {
          name: 'name',
          label: this.$t('report.UserName'),
          required: true,
          align: 'left',
          field: row => row.name,
          format: val => `${val}`,
          sortable: true
        },
        { name: 'role',
          label: this.$t('report.role'),
          field: 'role',
          align: 'left',
          sortable: true
        },
        { name: 'tokenExpiredDuration',
          label: this.$t('report.tokenExpiredDuration'),
          field: 'tokenExpiredDuration',
          sortable: true
        },
        { name: 'loginTimeString',
          label: this.$t('report.loginTimeString'),
          format: val => `${val}`,
          field: 'loginTimeString',
          sortable: true
        },
        { name: 'delete',
          label: '',
          align: 'right',
          // format: val => `${val}`,
          // field: 'loginTimeString',
          sortable: false
        }
      ],
      pagination: {
        descending: true,
        page: 1,
        rowsPerPage: 10
      },
      data: [],
      addAccountModal: false,
      addAccountFailMsg: '',
      loading: false
    }
  },
  watch: {
    addAccountModal() {
      if (!this.addAccountModal) {
        this.addAccountFailMsg = ''
        this.form = {
          account: '',
          role: '',
          tokenExpiredDuration: 0
        }
      }
    }
  },
  computed: {
    ...mapGetters({
      'user': 'user/user'
    })
  },
  methods: {
    formatDate(val) {
      return date.formatDate(val, 'YYYY/MM/DD HH:mm')
    },
    async editTable(data) {
      this.addAccountFailMsg = ''
      if (this.addAccountModal) {
        const res = await this.$refs.AccountForm.validate()
        if (!res) return
      }
      try {
        const res = await IIMS.Userconfig(
          {
            account: data.account,
            role: data.role,
            tokenExpiredDuration: parseInt(data.tokenExpiredDuration, 10)
          }
        )
        // TODO: handle error
        if (res.status === 200) {
          this.getAllusers()
          this.addAccountModal = false
        }
      } catch (error) {
        console.error(error)
        this.addAccountFailMsg = error.response?.data?.errMsg || 'error'
      }
    },
    async getAllusers() {
      let params = ''
      try {
        if (this.user.authority <= 8) {
          params = ''
          // params = '?role=Normal'
        }
        const res = await IIMS.getUsers(params)
        this.data = res.data.data
      } catch (error) {
        console.error(error)
      }
    },
    async deleteUser(userId) {
      try {
        this.loading = true
        await IIMS.deleteUser(userId)
        await this.getAllusers()
        this.loading = false
      } catch (error) {
        console.error(error)
      }
    }
  },
  mounted() {
    this.getAllusers()
    // IIMS.Userconfig
    // IIMS.getUsers
  }
}
</script>
<style scoped>
.q-btn>>>.q-icon {
  font-size: 1rem;
}
</style>
