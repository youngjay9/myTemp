<template>
<q-page class="q-pa-md">
  <div class="col q-pa-md">
    <div class="text-h6 q-mb-md">{{$t('menu.info')}}</div>
    <div id="help">
      <div class="row full-width">
        <div class="col-12 col-sm-12 col-md-4 col-md-4">
          <div style="background: #FF0007" class="text-dark text-center q-mx-xs q-pa-xs">{{$t('Info.red')}}</div>
          <div class="flex q-mx-xs q-pa-xs justify-between column editSpace" @click="edit('helpPageDescriptionRed')">
            <div class="full-width q-pa-sm" v-html="info.helpPageDescriptionRed"></div>
            <div class="edit-icon self-end">
              <q-btn dense flat size="md" round icon="edit" @click="edit('helpPageDescriptionRed')"/>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-12 col-md-4 col-md-4">
          <div style="background: #FFF002" class="text-dark text-center q-mx-xs q-pa-xs">{{$t('Info.yellow')}}</div>
            <div class="flex q-mx-xs q-pa-xs justify-between column editSpace" @click="edit('helpPageDescriptionYellow')">
            <div class="full-width q-pa-sm" v-html="info.helpPageDescriptionYellow"></div>
            <div class="edit-icon self-end">
              <q-btn dense flat size="md" round icon="edit" @click="edit('helpPageDescriptionYellow')"/>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-12 col-md-4 col-md-4">
          <div style="background: #01FF00" class="text-dark text-center q-mx-xs q-pa-xs">{{$t('Info.green')}}</div>
          <div class="flex q-mx-xs q-pa-xs justify-between column editSpace" @click="edit('helpPageDescriptionGreen')">
            <div class="full-width q-pa-sm" v-html="info.helpPageDescriptionGreen"></div>
            <div class="edit-icon self-end">
              <q-btn dense flat size="md" round icon="edit" @click="edit('helpPageDescriptionGreen')"/>
            </div>
          </div>
        </div>
      </div>
    </div>
    <q-dialog v-model="showEditor" >
      <q-card  style="width: 810px; max-width: 90vw;">
        <q-card-section v-if="editing">
          <div class="text-h6">{{editing.block }}</div>
        </q-card-section>

        <div class="q-pa-md q-gutter-sm scroll" style="max-height: 85vh">
          <q-editor
            v-model="editing.content"
            :toolbar="toolbar"
            min-height="15rem" />
        </div>

        <q-card-actions align="right">
          <q-btn flat label="OK" color="primary" v-close-popup @click="updateInfo(editing)"/>
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</q-page>
</template>

<script>
import { mapGetters } from 'vuex'
import IIMS from '@/api/iims'
const initData = () => {
  return {
    helpPageDescriptionRed: '',
    helpPageDescriptionYellow: ``,
    helpPageDescriptionGreen: ''
  }
}
export default {
  name: 'VesselInfo',
  props: {
    // type: {
    //   type: String
    // }
  },
  data() {
    return {
      showEditor: false,
      editing: {
        block: '',
        content: ''
      },
      info: {
        helpPageDescriptionRed: '',
        helpPageDescriptionYellow: '',
        helpPageDescriptionGreen: ''
      },
      toolbar: [
        ['left', 'center', 'right', 'justify'],
        ['bold', 'italic', 'strike', 'underline', 'subscript', 'superscript'],
        ['token', 'hr', 'link'],
        ['quote', 'unordered', 'ordered', 'outdent', 'indent'],
        ['removeFormat', 'undo', 'redo'],
        ['fullscreen', 'viewsource']
      ]
    }
  },
  computed: {
    ...mapGetters({
      'user': 'user/user'
    })
  },
  methods: {
    edit(block) {
      this.editing.block = block
      this.editing.content = this.info[block]
      this.showEditor = true
    },
    async getInfo() {
      try {
        const { data: {
          data: {
            helpPageDescriptionRed,
            helpPageDescriptionYellow,
            helpPageDescriptionGreen
          }
        }} = await IIMS.getGlobalconfig()
        this.info = {
          helpPageDescriptionRed,
          helpPageDescriptionYellow,
          helpPageDescriptionGreen
        }
      } catch (error) {
        console.log(error)
        this.info = initData()
      }
    },
    async updateInfo(editing) {
      this.info[editing.block] = editing.content
      try {
        const { data: {
          data: {
            helpPageDescriptionRed,
            helpPageDescriptionYellow,
            helpPageDescriptionGreen
          }
        }} = await IIMS.putGlobalconfig(this.info)
        this.info = initData()
        this.info = {
          ...this.info,
          helpPageDescriptionRed,
          helpPageDescriptionYellow,
          helpPageDescriptionGreen
        }
      } catch (error) {
        console.log(error)
        this.info = initData()
      }
    }
  },
  mounted() {
    this.getInfo()
  }
}
</script>
<style lang="sass">
  .editSpace
    cursor: pointer
    height: 100%
    position: relative
    .edit-icon
      position: absolute
      bottom: 36px
      right: 5px
      opacity: .25
    &:hover
      .edit-icon
        opacity: 1
</style>
