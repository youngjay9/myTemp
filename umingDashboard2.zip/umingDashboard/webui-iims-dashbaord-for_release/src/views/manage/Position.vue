<template>
<q-page class="q-pa-md bg-blue-grey-10">
  <div class="text-h6 q-mb-md">{{$t('menu.position')}}</div>
  <div ref="overall" class="column flex-center" style="min-height: inherit;">
    <div class="col-auto hex-wrap" :style="hexSize">
      <HexGrid
        v-if="hexSize"
        :permission="permission"
        :storePosition="storePosition"
        :darkMode="$q.dark.isActive"
        :size="hexSize"
        :data="hexdata"/>
    </div>
  </div>
</q-page>
</template>

<script>
import { dom } from 'quasar'
import { mapActions, mapGetters } from 'vuex'
import HexGrid from '@/components/HexGrid'
import IIMS from '@/api/iims'
const { height, width } = dom

export default {
  components: {
    HexGrid
  },
  watch: {
  },
  data() {
    return {
      // hexdata: [],
      hexSize: null,
      shipPosition: [],
      positions: []
    }
  },
  computed: {
    ...mapGetters({
      user: 'user/user',
      boats: 'nagiosxi/boats'
      // positions: 'vessel/positions'
    }),
    hexdata() {
      if (!this.positions || !this.boats) return []
      return this.boats
        .map(d => {
          const obj = this.positions.find(({ host_display_name }) => host_display_name === d.vesselCode) || null
          return {
            ...d,
            coordinate: obj ? (obj.coordinate || null) : null
          }
        })
    },
    permission() {
      if (this.user.authority > 8) return true
      else return false
    }
  },
  methods: {
    ...mapActions({
      setTimer: 'nagiosxi/setTimer'
      // getPosition: 'vessel/getPosition',
      // storePosition: 'vessel/storePosition'
    }),
    async getPosition() {
      try {
        const { data } = await IIMS.getGlobalShipPosition()
        this.positions = data ? data.data : []
      } catch (error) {
        console.error(error)
      }
    },
    async storePosition(data) {
      const vessel = data
        .filter(({ data }) => data)
        .map(d => {
          return {
            coordinate: {
              x: d.x,
              y: d.y,
              z: d.z
            },
            host_display_name: d.data.vesselCode
          }
        })
      try {
        await IIMS.storeGlobalShipPosition({
          data: vessel
        })
      } catch (error) {
        console.error(error)
      }
    },
    sized() {
      const w = width(this.$refs.overall)
      const h = height(this.$refs.overall)
      const asRatio = 0.5625
      if (w * asRatio > h) {
        // 超過高度
        this.hexSize = {
          width: `${h / asRatio}px`,
          height: `${h}px`
        }
      } else {
        this.hexSize = {
          width: `${w}px`,
          height: `${(w * asRatio)}px`
        }
      }
    }
  },
  async mounted() {
    this.setTimer(true)
    await this.$nextTick()
    this.sized()
    this.getPosition()
  },
  beforeDestroy() {
    this.setTimer(false)
  }
}
</script>
<style lang="sass">
  .hex-wrap
    width: 99%
    display: flex
    align-items: center
</style>
