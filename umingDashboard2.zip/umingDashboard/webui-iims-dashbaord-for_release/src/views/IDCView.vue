<template>
  <q-page padding class="idc-detail row q-col-gutter-md">
    <div class="col-xs-12 col-sm-12 col-md-4 my-card">
      <q-card class="full-height">
        <q-card-section class="q-pa-sm">
          <b class="text-primary">{{$t('idcView.Host')}}</b>
        </q-card-section>
        <q-card-section class="row q-pa-xs">
          <div class="full-height col-6">
            <router-link tag="div" to="/vessel/TPE/all" class="cursor-pointer" :style="{ height: blockHeight }" >
              <DougnhutChart
                v-if="chartsHostTPE"
                chartId="cht-host"
                id="cht-host"
                :key="'cht-host'"
                class="cursor-pointer"
                :data="DoughnutData(chartsHostTPE)"/>
            </router-link>
            <q-scroll-area
              :style="{ height: scrollAreaHeight + 'px' }"
              class="full-width rounded-borders q-px-md q-pt-xs"
              v-if="hostTPE.total">
              <q-btn
                v-for="(item, index) in hostTPE.critical"
                :key="item.host_alias"
                :href="`${nagiosxiLink}host%3D${item.host_alias}`"
                push
                type="a"
                target="_blank"
                no-caps
                block
                flat
                class="full-width">
                <div class="nagiosxi-link q-my-xs">
                  <div>
                    {{index + 1}}/
                    <b class="text-negative">{{item.host_address}}</b>
                  </div>
                  <span>time out</span>
                </div>
              </q-btn>
            </q-scroll-area>
          </div>
          <!--  :style="{ height: blockHeight }" -->
          <div class="full-height col-6">
            <router-link tag="div" to="/vessel/IDC/all" class="cursor-pointer" :style="{ height: blockHeight }" >
              <DougnhutChart
                v-if="chartsHostIDC"
                chartId="cht-host2"
                id="cht-host2"
                :key="'cht-host2'"
                :data="DoughnutData(chartsHostIDC)" />
            </router-link>
            <q-scroll-area :style="{ height: scrollAreaHeight + 'px' }" class="full-width rounded-borders q-px-md" v-if="hostIDC.total">
              <q-btn
                v-for="(item, index) in hostIDC.critical"
                :key="item.host_alias"
                :href="`${nagiosxiLink}host%3D${item.host_alias}`"
                push
                type="a"
                target="_blank"
                no-caps
                block
                flat
                class="full-width"
              >
                <div class="nagiosxi-link q-my-xs">
                  <div>
                    {{index + 1}}/
                    <b class="text-negative">{{item.host_address}}</b>
                  </div>
                  <span class="text-negative">time out</span>
                </div>
              </q-btn>
            </q-scroll-area>
          </div>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-4 my-card">
      <q-card class="full-height">
        <q-card-section class="q-pa-sm">
          <b class="text-primary">CPU</b>
        </q-card-section>
        <q-card-section class="row q-pa-xs">
          <div class="full-height col-6" v-if="CPUTPE.total">
            <div :style="{ height: blockHeight }">
              <GaugeChart chartId="cht-cpu" :data="GaugeChartData(CPUTPE.reduce)" class="col-8" />
            </div>
            <div>
              <h6 class="text-center q-ma-none">
                <span class="text-negative">{{CPUTPE.critical.length}}</span> /{{CPUTPE.total}}
                <q-tooltip anchor="top middle" self="bottom middle" :offset="[10, 10]">Warning: SLA > {{Math.round(CPUTPE.reduce.warning / CPUTPE.reduce.total) }} %</q-tooltip>
              </h6>
            </div>
          </div>
          <div class="full-height col-6" v-if="CPUIDC.total">
            <div :style="{ height: blockHeight }">
              <GaugeChart chartId="cht-cpu2" :data="GaugeChartData(CPUIDC.reduce)" class="col-8" />
            </div>
            <div>
              <h6 class="text-center q-ma-none">
                <span class="text-negative">{{CPUIDC.critical.length}}</span> /{{CPUIDC.total}}
                <q-tooltip anchor="top middle" self="bottom middle" :offset="[10, 10]">Warning: SLA > {{Math.round(CPUIDC.reduce.warning / CPUIDC.reduce.total) }} %</q-tooltip>
              </h6>
            </div>
          </div>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-4 my-card">
      <q-card class="full-height">
        <q-card-section class="q-pa-sm">
          <b class="text-primary">Memory Usage</b>
        </q-card-section>
        <q-card-section class="row q-pa-xs">
           <div class="full-height col-6">
             <div :style="{ height: blockHeight }">
              <DougnhutChart
                v-if="chartsMemTPE"
                chartId="cht-disk"
                id="cht-disk"
                :key="'cht-disk'"
                :data="DoughnutData(chartsMemTPE)"/>
             </div>
            <q-scroll-area
              :style="{ height: scrollAreaHeight + 'px' }"
              class="rounded-borders q-px-md"
              v-if="MemTPE.total">
              <q-btn
                v-for="(item, index) in MemTPE.critical"
                :key="item.host_alias"
                :href="`${nagiosxiLink}host%3D${item.host_alias}`"
                target="_blank"
                push
                type="a"
                no-caps
                block
                flat
                class="full-width">
                <div class="nagiosxi-link q-my-xs">
                  <div>
                    {{index + 1}}/
                    <b class="text-negative">{{item.host_alias}}</b>
                  </div>
                  <div class="text-negative">{{item.perf_data.Physical_Memory_Utilisation[0]}}</div>
                </div>
              </q-btn>
            </q-scroll-area>
           </div>
           <div class="full-height col-6">
              <div :style="{ height: blockHeight }">
                <DougnhutChart
                  v-if="chartsMemIDC"
                  class="col-8"
                  chartId="cht-disk2"
                  id="cht-disk2"
                  :key="'cht-disk2'"
                  :data="DoughnutData(chartsMemIDC)"/>
              </div>
              <q-scroll-area :style="{ height: scrollAreaHeight + 'px' }" class="rounded-borders q-px-md" v-if="MemIDC.total">
                <q-btn
                  v-for="(item, index) in MemIDC.critical"
                  :key="item.host_alias"
                  :href="`${nagiosxiLink}host%3D${item.host_alias}`"
                  target="_blank"
                  push
                  type="a"
                  no-caps
                  block
                  flat
                  class="full-width">
                  <div class="nagiosxi-link q-my-xs">
                    <div>
                      {{index + 1}}/
                      <b class="text-negative">{{item.host_alias}}</b>
                    </div>
                    <div class="text-negative">{{item.perf_data.Physical_Memory_Utilisation[0]}}</div>
                  </div>
                </q-btn>
              </q-scroll-area>
          </div>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-4 my-card">
      <q-card class="full-height">
        <q-card-section class="q-pa-sm">
          <b class="text-primary">Disk Usage</b>
        </q-card-section>
        <q-card-section class="row q-pa-xs">
          <div class="full-height col-6">
            <div :style="{ height: blockHeight }">
              <DougnhutChart
                v-if="chartsDiskTPE"
                class="col-8"
                chartId="cht-s=dick"
                id="cht-s=dick"
                :key="'cht-s=dick'"
                :data="DoughnutData(chartsDiskTPE)"/>
            </div>
            <q-scroll-area
              :style="{ height: scrollAreaHeight + 'px' }"
              class="rounded-borders q-px-md"
              v-if="DiskTPE.total">
              <q-btn
                v-for="(item, index) in DiskTPE.critical"
                :key="item.host_alias"
                :href="`${nagiosxiLink}host%3D${item.host_alias}`"
                target="_blank"
                push
                type="a"
                no-caps
                block
                flat
                class="full-width"
              >
                <div class="nagiosxi-link q-my-xs">
                  <div>
                    {{index + 1}}/
                    <b class="text-negative">{{item.host_alias}}</b>
                  </div>
                  <span
                    class="text-negative"
                    v-if="item.perf_data['/ Percent']"
                  >{{item.perf_data['/ Percent'][0]}}</span>
                  <span class="text-negative" v-else>Warning</span>
                </div>
              </q-btn>
            </q-scroll-area>
          </div>
           <div class="full-height col-6">
             <div :style="{ height: blockHeight }">
              <DougnhutChart
                v-if="chartsDiskIDC"
                class="col-8"
                chartId="cht-s=dick2"
                id="cht-s=dick2"
                :key="'cht-s=dick2'"
                :data="DoughnutData(chartsDiskIDC)"/>
             </div>
             <q-scroll-area
              :style="{ height: scrollAreaHeight + 'px' }"
              class="rounded-borders q-px-md"
              v-if="DiskIDC.total">
              <q-btn
                v-for="(item, index) in DiskIDC.critical"
                :key="item.host_alias"
                :href="`${nagiosxiLink}host%3D${item.host_alias}`"
                target="_blank"
                push
                type="a"
                no-caps
                block
                flat
                class="full-width"
              >
                <div class="nagiosxi-link q-my-xs">
                  <div>
                    {{index + 1}}/
                    <b class="text-negative">{{item.host_alias}}</b>
                  </div>
                  <span
                    class="text-negative"
                    v-if="item.perf_data['/ Percent']"
                  >{{item.perf_data['/ Percent'][0]}}</span>
                  <span class="text-negative" v-else>Warning</span>
                </div>
              </q-btn>
            </q-scroll-area>
          </div>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-4 my-card">
      <q-card class="full-height column">
        <q-card-section class="col-2 q-pa-sm">
          <b class="text-primary">{{$t('idcView.facility')}}</b>
        </q-card-section>
        <q-card-section class="q-pa-sm row col-10 ">
          <div class="map-svg">
            <svg xmlns="http://www.w3.org/2000/svg" width="598.152" height="568.923" viewBox="0 0 598.152 568.923">
              <g id="map" data-name="Group 42" transform="translate(3033.267 -750.225)">
                <path id="tp" d="M1179.151,329.661l-10.3-1.92-6.947.5-17.367,6.447-14.883.989-18.857,13.4-3.971,4.46h-7.936l-6.452-2.481-14.388-.992-4.963,3.974-1.49,5.955-2.481,4.963,11.413,16.375-3.974,11.91-16.375,10.918-14.886-.989-6.447.989-8.436,6.947-6.947,8.934,1.49,6.447-.5,5.961-3.971,4.96-.5,5.955.5,3.473-6.947,1.489-4.96,2.481-20.841-2.973-6.452.989-5.458,2.976-7.444,8.931-13.4,7.2-1.489,4.713-4.957,4.463-2.976,4.96-5.958,1.987-1.987,5.46-4.463-4.96-9.923,4.96-29.274,3.474,3.971,3.473-1.487,5.955-6.449,4.963-6.947-1.984-4.963,2.973-5.955,1.487-2.484,5.46.5,6.947-.989,6.45-5.46,4.466.989,6.947,3.974,3.968,1.984,5.958v7.447L866.66,569.4l-6.447.989-4.463,3.474-2.976,4.466-5.958,1.984-7.444.5-16.378,8.931-1.49,6.947-14.389,9.434-12.9,1.984-6.45,3.971-13.263-.756-4.1-1.72L768.908,595.7l-5.46-3.974-3.971-5.46-6.947-1.984-.5-4.963-6.947-2.973,1.49-5.46-8.931-8.434-5.46-13.894v-2.976l-2.481-4.963-.992-6.45,2.976-5.458,8.934-7.444,2.976-4.466,4.463-2.973v-7.447L741.6,504.4l-2.482-6.947-.5-6.947-4.463-4.963-4.465-2.482-7.936-7.939-1.984-5.458L715.8,465.7l-.989-2.484-3.473-1.987-14.886.992L691,465.193l-7.444.5-7.939-1.984-4.957-2.979-4.466-4.463-4.465,3.474-6.947-.989.5-5.958,12.9-2.484,4.463-3.474-6.947-4.463-.5-.5-.986-5.955,3.474-4.465-9.434-14.391-12.4-7.444-2.481-11.907,2.481-5.46,3.474-3.974,5.958-3.971-4.463-3.473-5.958-.495-3.473-6.452,2.484-5.458,3.968-3.974,1.49-13.894-2.973-5.458,1.484-5.958,4.963-2.484,31.261.992,7.939-5.46,5.458-9.923,5.955-1.984,4.465-2.976-.5-5.958-5.958-4.463,5.458-1.987,5.463-3.473,2.481-4.46-6.45-4.465-3.473-3.971-.989-6.45,2.484-4.963v-1.984l-1.49-6.45-4.963-5.958-3.474-2.484H681.59L667.2,256.77l-5.463-4.957,1.49-9.926-25.8-12.4-13.894-1.489-3.473-4.463-3.474-.989-5.038-6.905,2.656-3.876,6.686-6.338,33.345-.347,3.557-2.431,14.328-4.516,11.638-7.728,4.168-1.042,7.725-4.6,4.516-1.389,10.248-9.809,1.737-6.686,3.126-2.779h5.3L736.721,174.6l6.252,6.336L744.8,185.8l.347,4.949,5.558,7.38.695,4.516,2.17,4.6.695,4.516,2.432-2.084L756,188.659l-5.991-12.332-2.779-3.473-3.907-2.865-4.168-7.294-9.812-4.6-5.294-.347-9.464-8.77-.695-3.126,3.126.347,5.3-1.473,5.641-10.854.695-5.21,5.9-5.991,3.56-2.084,2.431-3.56.695-5.21,3.56-7.03,1.042-4.254,2.779-3.126.347-4.949,3.474-2.779,10.248,1.389,1.737-.347,9.812-20.669,4.6-1.389,3.821-2.865,9.465-2.431,3.9-3.126.695-4.949,1.737-1.737,1.737,4.516,14.069-2.084,3.126-2.084V48.6l3.126-2.084,5.3,5.644h16.848l1.389-4.254,2.779-3.126,3.735-.609,1.217.261,3.474,2.084,2.865,3.126,3.821,2.518h5.294l3.821,2.084L876,60.58l8.77,2.779,10.159,14.416,3.126,2.779,1.82,3.473,1.042,4.949-1.473,10.507,5.641,5.644,3.907,1.737h5.558l1.737,3.473-3.474,3.557.695,3.473,13.722,14.069,17.542-1.042,12.591-10.854,1.042,3.126-3.474,3.126-3.907,2.17-2.779,3.126,3.126,2.779.781,2.084-8.075,3.907-1.823,4.168,1.476,3.557,4.516,3.126L952.5,152.1l8.095,5.819-4.124,3.09-5.46,1.987-2.976,4.463-6.447,1.487-3.473,4.466L926.7,178.37l-6.947.5-5.458,1.984-4.963,3.473-13.4,1.489v7.442l2.976,5.46,6.45,1.984,3.971,4.466.5,6.947,8.436,18.857,6.45,4.46,4.46,5.96,6.452,1.487,3.968-3.473v5.46l4.466,4.96,19.354,4.96,14.883,12.9,14.391.989,12.9-6.447,6.947-.5,2.979-4.96,1.984-5.958-12.9-12.407v-13.4l-1.49-5.955,6.449-1.489,7.936-8.434,6.947,1.487,4.963,3.473,2.484.5,4.957-7.933,3.974-3.974,2.484-5.958-.058-3.215,5.032,0,4.515-1.737h5.3l-1.737,1.737-2.17,3.56-1.042,4.516,2.865,3.473h4.515l3.56-3.473,3.821-2.084,8.073,2.431,12.243.347,3.907,1.737,4.168-1.737,16.5,3.56h5.3l9.465-3.212,2.779-2.779,4.6-1.042,4.863.347v5.21l-3.474,2.17-2.084,3.473,1.737,2.431,2.779,2.515,1.737,3.473-1.042,4.168-4.168,2.865-4.254,12.591,3.56,8.422,11.546,11.638.695,1.737-3.821,2.779,1.737,2.084v15.806l1.042,3.9,13.722,11.2,11.2,1.042,4.7-2.948,2.334-2.354,5.038-.17,4.082.95,2.431,2.779,3.821,1.389,3.212,5.991,3.126-2.865,3.907-.347,5.21,5.644-.175,4.076-1.909,4-5.227.509-2.154,3.66-7.728,3.557-2.084,3.126-4.877.333-2.156,4.268-3.112,1.395h0Z" transform="translate(-3644.197 706.566)" fill="none" stroke="#707070" stroke-width="1"/>
                <path id="ntp" d="M681.224,129.5l-3.474,7.442-3.473,3.473-.989,1.987-3.473,3.971v7.447l-4.96,2.973-.992,6.45,1.987,6.45,4.96,3.474,15.881,1.984,9.923,9.428,3.971,7.447.5,22.825-7.444,10.42-4.96,4.463-2.484,5.46,1.487,14.391,2.976,5.955,5.958-.5,5.458-2.976,3.474-4.96,3.473-.5,7.939,3.473,4.463,3.473,1.987,5.458v7.447l3.474,5.955,6.447,4.465,6.947.5,2.976,11.91,10.42,6.947,27.788,2.973,5.958-2.484h7.936l.5-4.96-13.394-6.45-.992-6.947.5-5.958L778.487,261v-6.447l3.474-5.46,4.963-2.976,13.894.992,4.463-2.973,5.958-1.489,18.854.992,1.49-3.971-4.466-1.987-6.447,1.987L809.748,234.7l-13.391-9.92-2.484-5.46,3.474-4.463-.989-5.458-3.974-3.974,2.976-3.473,6.449-13.394-1.487-12.907L778.982,157.3l1.49-6.452,3.971-4.463-1.487-4.96-7.942-6.947-2.976-4.466-.5-14.389-7.936-7.942v-7.444l1.987-5.458V87.333l-12.9.989-5.46-9.923-3.971-4.463-6.947,10.915-5.458,2.484-2.484,5.46-10.42,5.955-2.484,6.452L711,108.177l-6.947.5-5.46,2.481-8.433,9.923-2.484,6.45-6.449,1.97h0Z" transform="translate(-3551.131 759.518)" fill="none" stroke="#707070" stroke-width="1"/>
              </g>
              <g>
                <router-link to="/vessel/TPE/all" tag="rect" x="215" :y="235 - TPEStatus" width="50" :height="TPEStatus" :fill="mapDot(TPEStatus)"></router-link>
                <router-link to="/vessel/TPE/all" tag="text" x="280" y="235" font-size="40" font-weight="bold" storke="#fff" :fill="mapDot(TPEStatus)">{{$t(`idcView.TPE`)}} {{TPEStatus}}</router-link>
                <router-link to="/vessel/IDC/all" tag="rect"  x="120" :y="305 - IDCStatus" width="50" :height="IDCStatus" :fill="mapDot(IDCStatus)"></router-link>
                <router-link to="/vessel/IDC/all" tag="text" x="185" y="305" font-size="40" font-weight="bold" storke="#fff" :fill="mapDot(IDCStatus)">{{$t(`idcView.IDC`)}} {{IDCStatus}}</router-link>
              </g>
            </svg>
          </div>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-4 my-card">
      <q-card class="full-height column">
        <q-card-section class="col-2 q-pa-sm">
          <b class="text-primary">{{$t('idcView.Website')}}</b>
        </q-card-section>
        <q-card-section class="col-10 q-pa-none q-pb-md q-px-md">
          <q-scroll-area class="full-height">
            <!-- class="overflow-auto" -->
             <q-btn
                v-for="item in web"
                :key="item.name"
                :href="`${nagiosxiLink}host%3D${item.host_alias}`"
                target="_blank"
                push
                type="a"
                no-caps
                block
                align="left"
                flat
                class="full-width q-ma-sm">
                <div class="flex justify-between full-width">
                  <b
                    :class="[
                    'text-positive',
                    {'text-warning': item.state === 1 },
                    {'text-negative': item.state >= 2 }]">
                    {{ item.display_name }}
                  </b>
                  <span
                    :class="['text-white',
                      {'text-warning': item.state === 1 },
                      {'text-negative': item.state >= 2 }]"
                    v-if="item.perf_data">{{item.perf_data.time[0]}}</span>
                </div>
            </q-btn>
          </q-scroll-area>
        </q-card-section>
      </q-card>
    </div>
    <div class="full-width">
      <q-card class="idc-chart chart q-mt-sm">
        <q-card-section class="row q-col-gutter-sm q-pb-none">
          <div class="col-xs-12 col-sm-6 col-md-3 flex items-baseline q-gutter-sm">
            <!-- <q-select dense filled v-model="chartTimeType" :options="TimeOptions" class="col" /> -->
            <q-select
              dense
              filled
              v-model="serverType"
              :options="serverOptions"
              :option-label="opt => Object(opt) === opt && 'display_name' in opt ? opt.display_name : '- -'"
              class="col"
            />
          </div>
        </q-card-section>
        <q-card-section class="q-pt-xs full-width" v-if="LineChartData">
          <LineChart chartId="LineChart-idc" :data="LineChartData" style="height: 420px" />
        </q-card-section>
      </q-card>
     </div>
  </q-page>
</template>

<script>
import { colors, date } from 'quasar'
import { mapActions, mapGetters } from 'vuex'
import IIMS from '@/api/iims'
import Nagiosxi from '@/api/nagiosxi'
import DougnhutChart from '@/components/charts/DougnhutChart'
import LineChart from '@/components/charts/LineChart'
import GaugeChart from '@/components/charts/GaugeChart'

export default {
  name: 'BoatDetail',
  components: {
    DougnhutChart,
    LineChart,
    GaugeChart
  },
  props: {
    id: {
      type: String
    }
  },
  data() {
    return {
      keepTimer: null,
      blockHeight: '190px',
      // 列表資料滾動區塊的高度 - BC
      scrollAreaHeight: 200,
      chartsHostTPE: null,
      chartsHostIDC: null,
      hostTPE: {
        total: 0,
        critical: []
      },
      hostIDC: {
        total: 0,
        critical: []
      },
      CPUTPE: {
        total: 0,
        critical: [],
        reduce: null
      },
      CPUIDC: {
        total: 0,
        critical: [],
        reduce: null
      },
      chartsMemTPE: null,
      chartsMemIDC: null,
      MemTPE: {
        total: 0,
        critical: []
      },
      MemIDC: {
        total: 0,
        critical: []
      },
      chartsDiskTPE: null,
      chartsDiskIDC: null,
      DiskTPE: {
        total: 0,
        critical: []
      },
      DiskIDC: {
        total: 0,
        critical: []
      },
      chartTimeType: null,
      serverType: null,
      serverOptions: [],
      web: [],
      queryStrings: [],
      LineChartData: null
    }
  },
  watch: {
    queryString() {
      if (this.queryString) {
        this.getWebsResTime()
      }
      // console.log('queryString', this.queryString)
    }
  },
  computed: {
    ...mapGetters({
      nagiosxiLink: 'user/nagiosxiLink'
    }),
    TimeOptions() {
      return [
        {
          label: this.$t('idcView.chart.realtime'),
          value: 'now() - 2d GROUP BY time(5m)',
          id: 'realtime'
        },
        {
          label: this.$t('idcView.chart.day'),
          value: 'now() - 180d GROUP BY time(1d)',
          id: 'day'
        },
        {
          label: this.$t('idcView.chart.week'),
          value: 'now() - 360d GROUP BY time(7d,-4d)',
          id: 'week'
        },
        {
          label: this.$t('idcView.chart.month'),
          value: 'now() - 720d GROUP BY time(30d)',
          id: 'month'
        }
      ]
    },
    TPEStatus() {
      return (
        (this.hostTPE?.critical?.length || 0) +
        (this.CPUTPE?.critical?.length || 0) +
        (this.MemTPE?.critical?.length || 0) +
        (this.DiskTPE?.critical?.length || 0)
      )
    },
    IDCStatus() {
      return (
        (this.hostIDC?.critical?.length || 0) +
        (this.CPUIDC?.critical?.length || 0) +
        (this.MemIDC?.critical?.length || 0) +
        (this.DiskIDC?.critical?.length || 0)
      )
    },
    queryString() {
      if (!this.chartTimeType) return ''
      if (!this.serverType) return ''
      // value
      const service = `"host"= '${this.serverType.host_display_name}' AND "service"= '${this.serverType.description}'`
      const time = this.chartTimeType.value
      return `SELECT last("value") FROM "metrics" WHERE (${service} AND "performanceLabel" = 'time') and time >= ${time}`
    }
  },
  methods: {
    ...mapActions({
      trackEvent: 'user/trackEvent'
    }),
    endDateOptionsFn(date) {
      return date >= this.date.startDate
    },
    async getHost() {
      const dataCenters = await Promise.all(
        Array.from(['host_tpe_status', 'host_idc_status'], (x) =>
          Nagiosxi.thruk(`/hostgroups/${x}/stats?columns=down,up,total`)
        )
      )
      this.chartsHostTPE = {
        groupName: 'TPE',
        ...dataCenters[0].data
      }
      this.chartsHostIDC = {
        groupName: 'IDC',
        ...dataCenters[1].data
      }
      const TPE = await Nagiosxi.thruk(
        '/services?description[regex]=uptime&host_groups[regex]=host_tpe_status&columns=description,host_alias,host_address,display_name,perf_data,state'
      )
      const IDC = await Nagiosxi.thruk(
        '/services?description[regex]=uptime&host_groups[regex]=host_idc_status&columns=description,host_alias,host_address,display_name,perf_data,state'
      )
      this.hostTPE = {
        total: (TPE.data || []).length,
        critical: TPE.data.filter((d) => d.state > 0)
      }
      this.hostIDC = {
        total: (IDC.data || []).length,
        critical: IDC.data.filter((d) => d.state > 0)
      }
    },
    async getCPU() {
      const TPE = await Nagiosxi.thruk(
        '/services?description[regex]=Cpu Usage&host_groups[regex]=host_idc_status&columns=description,host_alias,host_address,display_name,perf_data,state'
      )
      const IDC = await Nagiosxi.thruk(
        '/services?description[regex]=Cpu Usage&host_groups[regex]=host_tpe_status&columns=description,host_alias,host_address,display_name,perf_data,state'
      )
      const criticalTPE = TPE.data.filter((d) => d.state > 0)
      const criticalIDC = IDC.data.filter((d) => d.state > 0)
      this.CPUTPE = {
        total: (TPE.data || []).length,
        data: TPE.data,
        critical: criticalTPE,
        reduce: TPE.data.reduce(
          (cpuAvg, data, index) => {
            const value = data.perf_data
              ? parseFloat(data.perf_data.split('=')[1].split(';')[0], 10)
              : 0
            const warning = data.perf_data
              ? parseFloat(data.perf_data.split('=')[1].split(';')[1], 10)
              : 75
            const critical = data.perf_data
              ? parseFloat(data.perf_data.split('=')[1].split(';')[2], 10)
              : 85
            return {
              groupName: 'TPE',
              avg: cpuAvg.avg + value,
              warning: cpuAvg.warning + warning,
              critical: cpuAvg.critical + critical,
              total: index + 1
            }
          },
          {
            groupName: 'TPE',
            avg: 0,
            warning: 0,
            critical: 0,
            total: 0
          }
        )
      }
      this.CPUIDC = {
        total: (IDC.data || []).length,
        data: IDC.data,
        critical: criticalIDC,
        // 'Avg_CPU_Utilisation'=2%;75;85;0",
        reduce: IDC.data.reduce(
          (cpuAvg, data, index) => {
            const value = data.perf_data
              ? parseFloat(data.perf_data.split('=')[1].split(';')[0], 10) || 0
              : 0
            const warning = data.perf_data
              ? parseFloat(data.perf_data.split('=')[1].split(';')[1], 10) || 0
              : 75
            const critical = data.perf_data
              ? parseFloat(data.perf_data.split('=')[1].split(';')[2], 10) || 0
              : 85
            return {
              groupName: 'IDC',
              avg: cpuAvg.avg + value,
              warning: cpuAvg.warning + warning,
              critical: cpuAvg.critical + critical,
              total: index + 1
            }
          },
          {
            groupName: 'IDC',
            avg: 0,
            warning: 0,
            critical: 0,
            total: 0
          }
        )
      }
    },
    async getMem() {
      const Pattern = /[a-zA-Z]+/g
      const TPE = await Nagiosxi.thruk(
        '/services?description[regex]=Mem Usage&host_groups[regex]=host_idc_status&columns=description,host_alias,host_address,display_name,perf_data,state'
      )
      const IDC = await Nagiosxi.thruk(
        '/services?description[regex]=Mem Usage&host_groups[regex]=host_tpe_status&columns=description,host_alias,host_address,display_name,perf_data,state'
      )
      const perfData = (str) =>
        str.split(' ').reduce((map, val) => {
          if (val) {
            const key = (val.split('=')[0].match(Pattern) || []).join('_')
            if (key === 'Physical_Memory_Utilisation') {
              map[key] = val.split('=')[1].split(';')
            } else {
              map[key] = val.split('=')[1]
            }
          } else {
            map['Physical_Memory_Utilisation'] = ['Error']
          }
          return map
        }, {})
      this.MemTPE = {
        total: TPE.data.length,
        critical: TPE.data
          .filter((d) => d.state > 0)
          .map((d) => {
            // console.log(JSON.stringify())
            return {
              ...d,
              perf_data: perfData(d.perf_data)
            }
          })
      }
      this.MemIDC = {
        total: IDC.data.length,
        critical: IDC.data
          .filter((d) => d.state > 0)
          .map((d) => {
            return {
              ...d,
              perf_data: perfData(d.perf_data)
            }
          })
      }
      this.chartsMemTPE = {
        groupName: 'TPE',
        down: this.MemTPE.critical.length,
        up: this.MemTPE.total - this.MemTPE.critical.length,
        total: this.MemTPE.total
      }
      this.chartsMemIDC = {
        groupName: 'IDC',
        down: this.MemIDC.critical.length,
        up: this.MemIDC.total - this.MemIDC.critical.length,
        total: this.MemIDC.total
      }
    },
    async getDisk() {
      // const Pattern = /[a-zA-Z]+/g
      const Pattern2 = /'/g
      const Pattern3 = /'[^'"]*'(?=(?:[^"]*"[^"]*")*[^"]*$)/g
      const TPE = await Nagiosxi.thruk(
        '/services?description[regex]=Disk Usage&host_groups[regex]=host_idc_status&columns=description,host_alias,host_address,display_name,perf_data,state'
      )
      const IDC = await Nagiosxi.thruk(
        '/services?description[regex]=Disk Usage&host_groups[regex]=host_tpe_status&columns=description,host_alias,host_address,display_name,perf_data,state'
      )
      const perfData = (str) => {
        //  "data": "'/'=84GB;81;86;0;96 '/ Percent'=87%;85;90;0;100"
        const vals = str.replace(Pattern3, '').split(' ')
        if (str) {
          return str.match(Pattern3).reduce((map, key, index) => {
            if (key) {
              map[key.replace(Pattern2, '')] = vals[index]
                .replace('=', '')
                .split(';')
            }
            return map
          }, {})
        } else {
          return {
            '/ Percent': ['--']
          }
        }
      }
      this.DiskTPE = {
        total: TPE.data.length,
        critical: TPE.data
          .filter((d) => d.state > 0)
          .map((d) => {
            return {
              ...d,
              perf_data: {
                ...perfData(d.perf_data),
                data: d.perf_data
              }
            }
          })
      }
      this.DiskIDC = {
        total: IDC.data.length,
        critical: IDC.data
          .filter((d) => d.state > 0)
          .map((d) => {
            return {
              ...d,
              perf_data: {
                ...perfData(d.perf_data),
                data: d.perf_data
              }
            }
          })
      }
      this.chartsDiskTPE = {
        groupName: 'TPE',
        down: this.DiskTPE.critical.length,
        up: this.DiskTPE.total - this.DiskTPE.critical.length,
        total: this.DiskTPE.total
      }
      this.chartsDiskIDC = {
        groupName: 'IDC',
        down: this.DiskIDC.critical.length,
        up: this.DiskIDC.total - this.DiskIDC.critical.length,
        total: this.DiskIDC.total
      }
    },
    DoughnutData(data) {
      if (!data) return null
      return {
        groupName: this.$t(`idcView.${data.groupName}`),
        options: {
          title: {
            text: `${Math.round((data.up / data.total) * 100)}%`,
            top: '25%',
            left: 'center',
            textStyle: {
              color: '#fff'
            },
            subtext: `{value|${data.down}}/{total|${
              data.total
            }}\n{Name| ${this.$t(`idcView.${data.groupName}`)}}`,
            subtextStyle: {
              rich: {
                value: {
                  fontWeight: 'bold',
                  color: data.down ? 'red' : '#ccc'
                },
                total: {
                  fontWeight: 'bold',
                  color: '#efefef'
                },
                Name: {
                  lineHeight: 20,
                  fontWeight: 'bold',
                  color: '#fff'
                }
              }
            }
          },
          legend: {
            bottom: 2
          }
        },
        data: [
          {
            value: data.down,
            name: this.$t('topView.host_down'),
            itemStyle: {
              normal: {
                color: colors.getBrand('negative') || '#FF0007'
              }
            }
          },
          {
            value: data.up,
            name: this.$t('topView.host_up'),
            itemStyle: {
              normal: {
                color: colors.getBrand('positive') || '#01FF00'
              }
            }
          }
        ]
      }
    },
    GaugeChartData(data) {
      if (!data) return {}
      return {
        colorSet: [
          [data.warning / data.total / 100, (colors.getBrand('positive') || '#01FF00')],
          [data.critical / data.total / 100, (colors.getBrand('warning') || '#FFF002')],
          [1, (colors.getBrand('negative') || '#FF0007')]
        ],
        seriesName: 'CPU',
        data: [
          {
            value: parseFloat(data.avg / data.total).toFixed(2),
            name: this.$t(`idcView.${data.groupName}`)
          }
        ]
      }
    },
    async getWebStatus() {
      const lang = JSON.parse(localStorage.getItem('lang')) || 'zh-TW'
      try {
        // host 只有 11 個  需用 services 有 13 個才符合使用
        const web = await Nagiosxi.thruk(
          `/services?host_groups[regex]=web_status&columns=host_display_name,description,display_name,perf_data,state,host_alias,notes`
        )
        this.web = web.data.map((d, index) => {
          const cName = d.notes.split('_')[0] || d.notes
          const eName = d.notes.split('_')[1] || d.notes
          const perf_data = {}
          if (d.perf_data) {
            d.perf_data.split(' ').reduce((map, val) => {
              const key = val.split('=')[0]
              map[key] = val.split('=')[1].split(';')
              return map
            }, perf_data)
          }
          return {
            ...d,
            name: eName,
            display_name: lang === 'zh-TW' ? `${cName}` : `${eName}`,
            // display_name: lang === 'zh-TW' ? `${cName}` : `${eName}`,
            perf_data
          }
        })
        this.serverOptions = this.web.sort((a, b) => b.state - a.state)
        this.serverType = this.web.find(
          (d) => d.name === 'U-Ming Official Website'
        )
      } catch (error) {
        console.error(error)
      }
    },
    async getWebsResTime() {
      let results = null
      try {
        const res = await IIMS.influxDb(this.queryString)
        results = res.data.results
      } catch (error) {
        console.error(error)
      }
      if (!results || !results[0].series[0].values) {
        this.LineChartData = null
        return
      }
      // const dates = results
      const series = results.map((d) => {
        return {
          type: 'line',
          areaStyle: {
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [{
                offset: 0, color: '#365470' // 0%
              }, {
                offset: 1, color: '#242933 ' // 100%
              }],
              global: false
            }
          },
          showSymbol: false,
          name: d.statement_id,
          data: d.series[0].values
        }
      })
      this.LineChartData = {
        legend: {
          show: false
        },
        tooltip: {
          trigger: 'axis',
          formatter: (params) => {
            params = params[0]
            const theDate = date.formatDate(
              new Date(params.axisValue),
              'HH:mm MM/DD'
            )
            const value = params.value[1]
            return `${params.marker} ${theDate} <br/> ${value ? value + 's' : '--'}`
          },
          axisPointer: {
            animation: false,
            type: 'cross'
          }
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            formatter: '{value}s',
            textStyle: {
              color: '#fff'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: '#333'
            }
          }
        },
        xAxis: {
          type: 'time',
          splitLine: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: '#ccc'
            }
          }
        },
        series
      }
    },
    mapDot(data) {
      return data > 0 ? (colors.getBrand('negative') || '#FF0007') : (colors.getBrand('positive') || '#01FF00')
    }
  },
  async created() {
    this.trackEvent({
      category: 'IDC_View_Detail',
      action: 'Click'
    })
    await Promise.all([
      this.getHost(),
      this.getWebStatus(),
      this.getCPU(),
      this.getMem(),
      this.getDisk()
    ]).then(() => {
      this.queryStrings = this.web.map((d) => {
        return `SELECT last("value") FROM "metrics" WHERE ("host"='${d.host_display_name}' AND "service"= '${d.description}' AND "performanceLabel" = 'time')`
      })
      this.chartTimeType = this.TimeOptions[0]
      // this.getWebsResTime()
    })
    // this.date.endDate = date.formatDate(new Date(), 'YYYY-MM-DD')
    // this.date.startDate = date.formatDate(date.subtractFromDate(this.date.endDate, { days: 7 }), 'YYYY-MM-DD')
  },
  async mounted() {
    this.chartTimeType = this.TimeOptions[0]
    this.keepTimer = setInterval(async() => {
      this.trackEvent({
        category: 'IDC_View_Detail',
        action: 'Live'
      })
      if (this.$route.name === 'IDCView') {
        await this.getHost()
        await this.getWebStatus()
        await this.getCPU()
        await this.getMem()
        await this.getDisk()
        if (this.chartTimeType.id === 'realtime') {
          await this.getWebsResTime()
        }
      }
    }, 300000)
  },
  beforeDestroy() {
    clearInterval(this.keepTimer)
    console.log('beforeDestroy idcview timer')
  }
}
</script>
<style lang="sass" scoped>
.my-card
  min-height: calc( 50vh - 40px )
.idc-chart
  width: 100%
  height: 100%
.map-svg
  width: 100%
  svg
    width: auto
    height: 90%
    position: absolute
    left: 50%
    -ms-transform: translateX(-50%)
    transform: translateX(-50%)
    path
      stroke-width: 2px
      stroke: #686868
      fill: #2c2c2c
    path, text
      cursor: pointer
</style>

