<template>
<q-layout>
  <q-page-container>
    <q-page class="bg-blue-grey-10">
      <div ref="overall" class="column flex-center" style="min-height: inherit;">
        <div class="col-auto hex-wrap" :style="hexSize">
          <HexGrid
            v-if="hexSize"
            :permission="false"
            :storePosition="storePosition"
            :darkMode="$q.dark.isActive"
            :size="hexSize"
            :data="hexdata"/>
        </div>
      </div>
      <q-page-sticky position="top-right" :offset="[18, 18]" style="z-index: 10;">
        <q-btn
          round
          flat
          icon="arrow_upward"
          class="rotate-45"
          text-color="blue-grey-5"
          to="/" />
      </q-page-sticky>
    </q-page>
  </q-page-container>
</q-layout>
</template>

<script>
import { dom } from 'quasar'
import { mapActions, mapGetters } from 'vuex'
import HexGrid from '@/components/HexGrid'
const { height, width } = dom

export default {
  components: {
    HexGrid
  },
  watch: {
  },
  data() {
    return {
      hexSize: null,
      shipPosition: []
    }
  },
  computed: {
    ...mapGetters({
      user: 'user/user',
      boats: 'nagiosxi/boats',
      positions: 'vessel/positions'
    }),
    hexdata() {
      if (!this.positions || !this.boats) return []
      return this.boats
        .map(d => {
          const obj = this.positions.find(({ host_display_name }) => host_display_name === d.vesselCode) || null
          return {
            ...d,
            coordinate: obj ? (obj.coordinate || null) : null
          }
        })
    },
    permission() {
      if (this.user.authority > 8) return true
      else return false
    }
  },
  methods: {
    ...mapActions({
      getGlobalShipPosition: 'vessel/getGlobalShipPosition',
      getPosition: 'vessel/getPosition',
      storePosition: 'vessel/storePosition',
      setTimer: 'nagiosxi/setTimer'
    }),
    sized() {
      const w = width(this.$refs.overall)
      const h = height(this.$refs.overall)
      const asRatio = 0.5625
      if (w * asRatio > h) {
        // 超過高度
        this.hexSize = {
          width: `${h / asRatio}px`,
          height: `${h}px`
        }
      } else {
        this.hexSize = {
          width: `${w}px`,
          height: `${(w * asRatio)}px`
        }
      }
    }
  },
  async mounted() {
    this.setTimer(true)
    await this.$nextTick()
    await this.sized()
    this.getGlobalShipPosition()
  //   if (this.permission) {
  //     this.getPosition()
  //   } else {
  //   }
  },
  beforeDestroy() {
    this.setTimer(false)
  }
}
</script>
<style lang="sass">
  .hex-wrap
    width: 99%
    display: flex
    align-items: center
</style>
