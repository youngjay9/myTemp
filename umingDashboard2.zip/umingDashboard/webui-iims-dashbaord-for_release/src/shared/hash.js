import crypto from 'crypto'

export function hashPassword(account, password) {
  const key = crypto.pbkdf2Sync(password, account.toLowerCase(), 1, 28, 'sha1')
  // console.log(key.toString('hex'))
  return key.toString('hex')
}
