import Vue from 'vue'
import VueRouter from 'vue-router'
// import Home from '../views/Home.vue'
import settings from '../settings'

Vue.use(VueRouter)
// layout
const DefaultContainer = () => import('@/layouts/DefaultContainer')
const FreeContainer = () => import('@/layouts/FreeContainer')
// U-MING IT Monitoring System Introduction
const routes = [
  {
    path: '/',
    // component: IndexContainer,
    component: DefaultContainer,
    children: [
      {
        path: '/',
        name: 'dashboard',
        component: () => import('@/views/Dashboard'),
        meta: {
          role: [4096, 1024, 256, 128, 64, 8],
          category: 'Top_View'
        }
      },
      // {
      //   path: 'idc',
      //   redirect: '/dashboard'
      // },
      {
        path: 'idc',
        name: 'IDCView',
        component: () => import('@/views/IDCView'),
        meta: {
          role: [4096, 1024, 256, 128, 64, 8],
          category: 'IDC_View_Detail'
        }
      },
      {
        path: 'vessel',
        name: 'vessels',
        redirect: '/overall'
      },
      {
        path: 'vessel/:id',
        redirect: '/vessel/:id/all'
        // props: true,
        // name: 'vessel',
        // component: () => import('@/views/vessel'),
        // meta: {
        //   role: [4096, 1024, 256, 128, 64, 8]
        // }
      },
      {
        path: 'vessel/:id/:type',
        props: true,
        name: 'vesselDetailsatellite',
        component: () => import('@/views/VesselView'),
        meta: {
          role: [4096, 1024, 256, 128, 64, 8],
          category: 'Boat_View_Detail'
        }
      },
      // url: '/manage/accounts',
      //
      {
        path: 'manage',
        name: 'Manage',
        redirect: '/manage/accounts'
      },
      {
        path: 'manage/position',
        component: () => import('@/views/manage/Position'),
        meta: {
          role: [4096, 1024, 256, 128, 64]
        }
      },
      {
        path: 'manage/accounts',
        component: () => import('@/views/manage/Accounts'),
        meta: {
          role: [4096, 1024, 256, 128, 64]
        }
      },
      {
        path: 'manage/info',
        component: () => import('@/views/manage/Information'),
        meta: {
          role: [4096, 1024, 256, 128, 64]
        }
      },
      {
        path: 'report',
        name: 'Report',
        redirect: '/report/summary'
      },
      {
        path: 'report/online',
        name: 'Online',
        component: () => import('@/views/report/Online'),
        meta: {
          role: [4096, 1024, 256, 128, 64, 8]
        }
      },
      {
        path: 'report/summary',
        name: 'UserSummary',
        component: () => import('@/views/report/UserSummary'),
        meta: {
          role: [4096, 1024, 256, 128, 64, 8]
        }
      },
      {
        path: 'report/activity',
        name: 'UserActive',
        component: () => import('@/views/report/UserActive'),
        meta: {
          role: [4096, 1024, 256, 128, 64, 8]
        }
      }
    ]
  },
  {
    path: '/overall',
    name: 'Overall',
    component: () => import('@/views/Overall'),
    meta: {
      role: [4096, 1024, 256, 128, 64, 8]
    }
  },
  {
    path: '/pages',
    redirect: '/pages/login',
    name: 'Pages',
    component: FreeContainer,
    children: [
      {
        path: 'login',
        name: 'Login',
        component: () => import('@/views/pages/Login')
      },
      {
        path: '*',
        name: 'Page404',
        component: () => import('@/views/pages/error404'),
        hidden: true
      }
    ]
  },
  {
    path: '*',
    redirect: '/',
    hidden: true
  }
]
const router = new VueRouter({
  mode: 'history', // (history:'http://localhost/mode' || hash:'http://localhost/#/mode')
  base: settings.publicPath,
  linkActiveClass: 'open active',
  scrollBehavior: () => ({ y: 0 }),
  routes
})

export default router
