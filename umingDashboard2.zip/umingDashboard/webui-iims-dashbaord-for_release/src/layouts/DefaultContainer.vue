<template>
  <q-layout view="hHh Lpr lff" >
    <q-header elevated class="bg-blue-grey-10">
      <q-toolbar>
        <!-- <q-btn dense flat round icon="menu" @click="left = !left" /> -->
        <!-- 移除按鍵移上圓形效果 - BC -->
        <div class="col-3 text-left">
          <q-btn dense flat icon="menu" @click="left = !left" />
        </div>
        <q-toolbar-title  class="text-center col">
          <!-- <q-avatar> -->
            <!-- <img src="https://cdn.quasar.dev/logo/svg/quasar-logo.svg"> -->
            <!-- icon -->
          <!-- </q-avatar> -->
          {{$t('title')}}
        </q-toolbar-title>
        <!-- logout -->
        <!-- <div class="no-wrap self-stretch row"> -->
        <!-- 移除按鍵移上拉伸效果 - BC -->
        <div class="col-3 justify-end no-wrap row">
          <!-- <q-btn v-if="$q.screen.gt.sm" round dense flat color="text-grey-7" icon="apps">
            <q-tooltip>Google Apps</q-tooltip>
          </q-btn>
          <q-btn round dense flat color="grey-8" icon="notifications">
            <q-badge color="red" text-color="white" floating>
              2
            </q-badge>
            <q-tooltip>Notifications</q-tooltip>
          </q-btn> -->
          <!-- q-gutter-sm row items-center n -->
            <!-- <q-btn-dropdown auto-close no-caps flat stretch icon="person" bordered> -->
            <!-- 移除按鍵移上拉伸效果 - BC -->
            <q-btn-dropdown auto-close no-caps flat icon="person" bordered>
              <!-- dropdown content goes here -->
              <q-list dense padding style="min-width: 150px;">
                <!-- <q-item>
                  <q-item-section>
                    <q-toggle
                      v-model="darkmode"
                      label="Dark mode"
                      left-label
                    />
                  </q-item-section>
                </q-item>
                <q-separator /> -->
                <q-item v-if="user" class="q-mb-sm">
                  <q-item-section>
                    <q-item-label class="q-pa-xs">  Hi, {{user.name}}</q-item-label>
                  </q-item-section>
                </q-item>
                <q-item clickable v-close-popup @click="logout">
                  <q-item-section avatar>
                    <q-avatar icon="login"/>
                  </q-item-section>
                  <q-item-section>
                    <q-item-label> {{ $t('form.logout') }}</q-item-label>
                  </q-item-section>
                </q-item>
              </q-list>
            </q-btn-dropdown>
            <div v-if="user" style="min-width: 100px;" class="q-mx-sm">
              <q-select dense emit-value map-options v-model="lang" :options="options"/>
            </div>
        </div>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="left" side="left" bordered overlay class="side-menu" >
      <!-- drawer content -->
      <q-scroll-area class="fit">
        <!-- nav -->
        <!-- <q-list padding class="text-grey-8">
          <q-item class="UM__drawer-item" v-ripple v-for="link in nav" :key="link.name" clickable>
            <q-item-section avatar>
              <q-icon :name="link.icon" />
            </q-item-section>
            <q-item-section>
              <q-item-label>{{ link.name }}</q-item-label>
            </q-item-section>
          </q-item> -->
      <q-list padding class="text-grey-5">
        <template v-for="link in nav">
          <q-expansion-item
            :content-inset-level=".2"
            v-if="link.children"
            :key="link.name"
            :icon="link.icon"
            :label="link.name"
            :ref="link.url"
            default-opened
            class="UM__expansion">
            <q-item
              class="UM__drawer-item"
              v-ripple
              v-for="nav in link.children"
              :key="nav.name"
              :to="nav.url"
              :active="$route.path === nav.url"
              >
              <q-item-section avatar>
                <q-icon :name="nav.icon" />
              </q-item-section>
              <q-item-section>
                <q-item-label>{{ nav.name }}</q-item-label>
              </q-item-section>
            </q-item>
          </q-expansion-item>
          <q-item
            class="UM__drawer-item"
            v-else
            v-ripple
            :key="link.name"
            :to="link.url"
            :active="$route.path === link.url"
            exact
            >
            <q-item-section avatar>
              <q-icon :name="nav.icon" />
            </q-item-section>
            <q-item-section>
              <q-item-label>{{ link.name }}</q-item-label>
            </q-item-section>
          </q-item>
        </template>
          <!-- Privacy Terms -->
          <div class="q-mt-md">
            <div class="flex flex-center q-gutter-xs">
              v{{ settings.version}}
            </div>
            <!-- <div class="flex flex-center q-gutter-xs">
              <a class="UM__drawer-footer-link" href="javascript:void(0)" aria-label="Privacy">Privacy</a>
              <span> · </span>
              <a class="UM__drawer-footer-link" href="javascript:void(0)" aria-label="Terms">Terms</a>
              <span> · </span>
              <a class="UM__drawer-footer-link" href="javascript:void(0)" aria-label="About">About Google</a>
            </div> -->
          </div>
        </q-list>
      </q-scroll-area>
    </q-drawer>

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
// import router from '@/router'
import { nav, filterNavItems } from '@/_nav'
import settings from '@/settings'
export default {
  data() {
    return {
      nav,
      settings,
      left: false,
      darkmode: true,
      lang: 'zh-TW',
      options: [
        { label: '中文', value: 'zh-TW' },
        { label: 'English', value: 'en-US' }
      ]
    }
  },
  watch: {
    darkmode() {
      // this.$q.dark.toggle()
      this.$q.dark.set(this.darkmode)
    },
    lang() {
      if (JSON.parse(localStorage.getItem('lang')) !== this.lang) {
        localStorage.setItem('lang', JSON.stringify(this.lang))
        location.reload()
      }
    }
  },
  computed: {
    ...mapGetters({
      user: 'user/user',
      isExpired: 'user/isExpired'
    })
  },
  methods: {
    ...mapActions({
      cleanData: 'user/logout',
      storeUserData: 'user/storeUserData'
    }),
    async logout() {
      try {
        await this.cleanData()
      } catch (error) {
        console.error(error)
      }
      this.storeUserData(null)
      sessionStorage.clear()
      this.$router.push('/pages/login')
    }
  },
  created() {
    const navs = nav()
    this.nav = filterNavItems(navs.items)
    this.lang = JSON.parse(localStorage.getItem('lang')) || 'zh-TW'
    // this.$i18n.locale = this.lang
    // const recaptcha = this.$recaptchaInstance
    // if (recaptcha) recaptcha.hideBadge()
  }
}
</script>
<style lang="scss">
.UM {
  &__expansion {
    margin-top: 1rem;
  }
  &__drawer-item {
    border-radius: 0 24px 24px 0;
    margin-right: 12px;
    min-height: 28px;
    .q-item__section--avatar {
      .q-icon {
        color: #5f6368;
      }
    }
    .q-item__label {
      // color: #3c4043;
      letter-spacing: .01785714em;
      font-size: .875rem;
      font-weight: 500;
      line-height: .5rem;
    }
    &.q-item--active {
      color: var(--q-color-primary);
    }
  }
  &__drawer-footer-link {
    color: inherit;
    text-decoration: none;
    font-weight: 500;
    font-size: .75rem;
    &:hover {
      color: var(--q-color-dark);
    }
  }
}
</style>
