<template>
  <q-layout view="lHr lpR fFr">
    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { mapActions } from 'vuex'
export default {
  data() {
    return {
    }
  },
  methods: {
    ...mapActions({
      cleanData: 'user/logout'
    }),
    logout() {
    }
  },
  created() {
  }
}
</script>
