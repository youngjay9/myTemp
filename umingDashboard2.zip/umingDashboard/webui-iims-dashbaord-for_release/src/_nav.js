import store from '@/store'
import router from '@/router'
import i18n from '@/vendor/vue-i18n'

const nav = () => ({
  items: [
    {
      name: i18n.t('menu.dashboard'),
      url: '/',
      icon: 'bookmark'
    },
    {
      name: i18n.t('menu.idc'),
      url: '/idc',
      icon: ''
    },
    {
      name: i18n.t('menu.vessel'),
      url: '/overall',
      icon: 'ship'
    },
    {
      name: i18n.t('menu.manage'),
      url: '/manage/accounts',
      icon: 'ship',
      children: [
        {
          name: i18n.t('menu.position'),
          url: '/manage/position',
          icon: ''
        },
        {
          name: i18n.t('menu.accounts'),
          url: '/manage/accounts',
          icon: ''
        },
        {
          name: i18n.t('menu.info'),
          url: '/manage/info',
          icon: ''
        }
      ]
    },
    {
      name: i18n.t('menu.report'),
      url: '/report',
      icon: 'ship',
      children: [
        {
          name: i18n.t('menu.online'),
          url: '/report/online',
          icon: ''
        },
        {
          name: i18n.t('menu.summary'),
          url: '/report/summary',
          icon: ''
        },
        {
          name: i18n.t('menu.activity'),
          url: '/report/activity',
          icon: ''
        }
      ]
    }
  ]
})
function filterNavItems(items) {
  const navItems = items.map(item => {
    const thisPath = router.resolve({
      path: item.url
    })
    if (thisPath.resolved.matched.length === 0) {
      return undefined
    }
    const user = store.getters['user/user']
      ? store.getters['user/user'].authority
        ? store.getters['user/user']
        : JSON.parse(sessionStorage.getItem('user') || '{}')
      : JSON.parse(sessionStorage.getItem('user') || '{}')
    // const hasPermission = (thisPath.resolved.meta && thisPath.resolved.meta.role) ? thisPath.resolved.meta.role.includes(user.authority) : true
    const role = (thisPath.resolved.meta && thisPath.resolved.meta.role) ? thisPath.resolved.meta.role : []
    const chkPermission = (authority) => role.indexOf(authority) > -1
    const hasPermission = chkPermission(user.authority)
    // console.log(hasPermission)
    // 無權限不顯示
    if (!hasPermission && thisPath.resolved.meta.role) {
      return undefined
    }
    const children = filterNavItems(item.children || [])
    item.children = children.length > 0
      ? children.filter(el => !!el)
      : null
    return item
  })
  return navItems.filter(el => !!el)
}

// nav.items = filterNavItems(nav.items)
export { nav, filterNavItems }
