裕民海運 iims-dashboard
=======

## 文件(專案文件)
*   [專案管理平台](#)
*   [API文件](#)
*   [網站](#)

## 套件
*   [Chart.js](https://github.com/chartjs/Chart.js).
*   [quasar](https://quasar.dev/).

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your unit tests
```
npm run test:unit
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


## 基本資料夾結構
```
Frontend-Base-template/
├── public/              # pure static assets (directly copied)
│   └── index.html           # index.html template
├── src/                 # project root
│   ├── api/                 # api
│   ├── assets/                 # module assets (processed by webpack)
│   ├── components/             # ui components
│   ├── directives/             # directives
│   ├── layouts/                # ui layouts
│   ├── router/                 # routing 
│   ├── shared/                 # utils
│   ├── store/                  # vuex store
│   ├── styles/                 # user styles
│   ├── lang/                   # i18n lang
│   ├── vendor/                 # vendors
│   │   └── vue-i18n/               # i18n
│   │   └── axios                   # axios interceptors
│   │   └── index.js                # global vendor
│   ├── views/                  # ui views
│   ├── tests/                  # unit tests
│   ├── _nav.js                 # sidebar nav config
│   ├── App.vue                 # main app component
│   ├── main.js                 # app entry file
│   ├── quasar.js               # quasar config / pugins
│   ├── permission.js           # permission control
│   └── settings.js             # settings config
├── .eslintrc.js         # eslint config
├── .gitignore           # defaults for gitignore
├── babel.config.js      # babel config
├── package.json         # build scripts and dependencies
├── README.md
└── vue.config.js        # vue-cli config
```