-- TPC.dbo.ACCOUNTING definition

-- Drop table

-- DROP TABLE TPC.dbo.ACCOUNTING;

CREATE TABLE TPC.dbo.ACCOUNTING (
	SEQ int IDENTITY(1,1) NOT NULL,
	FORM_SEQ int NOT NULL,
	REGION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_NUM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCOUNTING nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CALCULATE nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	AGENT nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	STATUS nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	MEMO nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	DISPATCH_TYPE nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCOUNTING_DEPT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT '1050403' NULL,
	CONSTRAINT PK__ACCOUNTI__CA1938C0328ABA52 PRIMARY KEY (SEQ)
);


-- TPC.dbo.ACCOUNTING_DISPATCH definition

-- Drop table

-- DROP TABLE TPC.dbo.ACCOUNTING_DISPATCH;

CREATE TABLE TPC.dbo.ACCOUNTING_DISPATCH (
	SEQ int IDENTITY(1,1) NOT NULL,
	REGION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CLASS_NAME nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCOUNTING nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCOUNTING_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CALCULATE nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CALCULATE_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	[TYPE] nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	COMPUTE_DATE nvarchar(500) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ELECTRIC_NUM_START nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ELECTRIC_NUM_END nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SETTING_USER nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SETTING_USER_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__ACCOUNTI__CA1938C04BCD0D89 PRIMARY KEY (SEQ)
);


-- TPC.dbo.AGENT_APPLICATION definition

-- Drop table

-- DROP TABLE TPC.dbo.AGENT_APPLICATION;

CREATE TABLE TPC.dbo.AGENT_APPLICATION (
	SEQ int IDENTITY(1,1) NOT NULL,
	REGION nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	DIVISION nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_GROUP nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	[SECTION] nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	APPLICANT nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	APPLICANT_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	START_DATE datetime NOT NULL,
	END_DATE datetime NOT NULL,
	AGENT nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	AGENT_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	DATA_SOURCE nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__AGENT_AP__CA1938C0AB85EC8F PRIMARY KEY (SEQ)
);


-- TPC.dbo.AUTH_AUTOSET_ROLE definition

-- Drop table

-- DROP TABLE TPC.dbo.AUTH_AUTOSET_ROLE;

CREATE TABLE TPC.dbo.AUTH_AUTOSET_ROLE (
	SEQ int IDENTITY(1,1) NOT NULL,
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_DIVISION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_GROUP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_SECTION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	POS_SEQ nvarchar(4) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	[LEVEL] nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__AUTH_AUT__CA1938C08A2EFA07 PRIMARY KEY (SEQ)
);


-- TPC.dbo.AUTH_EMP_ROLE_MAP definition

-- Drop table

-- DROP TABLE TPC.dbo.AUTH_EMP_ROLE_MAP;

CREATE TABLE TPC.dbo.AUTH_EMP_ROLE_MAP (
	EMP_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SETTING_STYLE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	MEMO nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT AUTH_EMP_ROLE_MAP_PK PRIMARY KEY (EMP_NO,ROLE_CODE,ROLE_DEPT_NUM)
);


-- TPC.dbo.AUTH_EMP_ROLE_MAP_1209 definition

-- Drop table

-- DROP TABLE TPC.dbo.AUTH_EMP_ROLE_MAP_1209;

CREATE TABLE TPC.dbo.AUTH_EMP_ROLE_MAP_1209 (
	EMP_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SETTING_STYLE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	MEMO nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK__AUTH_EMP__1209 PRIMARY KEY (EMP_NO,ROLE_CODE,ROLE_DEPT_NUM)
);


-- TPC.dbo.AUTH_PRIVILEGE definition

-- Drop table

-- DROP TABLE TPC.dbo.AUTH_PRIVILEGE;

CREATE TABLE TPC.dbo.AUTH_PRIVILEGE (
	PRIVILEGE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	PRIVILEGE_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	PRIVILEGE_TYPE nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__AUTH_PRI__B8BD152228085AA6 PRIMARY KEY (PRIVILEGE_CODE)
);


-- TPC.dbo.AUTH_ROLE definition

-- Drop table

-- DROP TABLE TPC.dbo.AUTH_ROLE;

CREATE TABLE TPC.dbo.AUTH_ROLE (
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	DESCRIPTION nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	[LIMIT] int NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__AUTH_ROL__20BB649C3040A816 PRIMARY KEY (ROLE_CODE)
);


-- TPC.dbo.AUTH_ROLE_PRIVILEGE_MAP definition

-- Drop table

-- DROP TABLE TPC.dbo.AUTH_ROLE_PRIVILEGE_MAP;

CREATE TABLE TPC.dbo.AUTH_ROLE_PRIVILEGE_MAP (
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	PRIVILEGE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	PRIVILEGE_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK_ROLE_PRIVILEGE PRIMARY KEY (ROLE_CODE,PRIVILEGE_CODE)
);


-- TPC.dbo.AUTH_ROLE_SETTING_RANGE definition

-- Drop table

-- DROP TABLE TPC.dbo.AUTH_ROLE_SETTING_RANGE;

CREATE TABLE TPC.dbo.AUTH_ROLE_SETTING_RANGE (
	SEQ int IDENTITY(1,1) NOT NULL,
	REGION nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	DIVISION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_GROUP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	[SECTION] nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	[LEVEL] nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__AUTH_ROL__CA1938C0FD7769C6 PRIMARY KEY (SEQ)
);


-- TPC.dbo.AUTH_ROLE_SETTING_TARGET definition

-- Drop table

-- DROP TABLE TPC.dbo.AUTH_ROLE_SETTING_TARGET;

CREATE TABLE TPC.dbo.AUTH_ROLE_SETTING_TARGET (
	SEQ int IDENTITY(1,1) NOT NULL,
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SET_ROLE_CODE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SET_ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__AUTH_ROL__CA1938C0ADECC0D8 PRIMARY KEY (SEQ)
);


-- TPC.dbo.CFG_CERTIFICATE_RULE definition

-- Drop table

-- DROP TABLE TPC.dbo.CFG_CERTIFICATE_RULE;

CREATE TABLE TPC.dbo.CFG_CERTIFICATE_RULE (
	SEQ int IDENTITY(1,1) NOT NULL,
	FORM_TYPE nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FORM_TYPE_DESC nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCEPT_ITEM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_ITEM_DESC nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	IDENTITY_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_CODE nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_CODE_DESC nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SIGN_FLAG nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SEAL_FLAG nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CATEGORY nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'CERTIFICATE' NOT NULL,
	ACCT_UPLOAD_FLAG nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'N' NOT NULL,
	APPLY_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'NCPS' NOT NULL,
	CONSTRAINT PK__CFG_CERT__CA1938C0DDB2D17D PRIMARY KEY (SEQ)
);


-- TPC.dbo.CFG_CLOSE_FORM_STATUS_PROPERTIES definition

-- Drop table

-- DROP TABLE TPC.dbo.CFG_CLOSE_FORM_STATUS_PROPERTIES;

CREATE TABLE TPC.dbo.CFG_CLOSE_FORM_STATUS_PROPERTIES (
	SEQ int IDENTITY(1,1) NOT NULL,
	FORM_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_ITEM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	MEMO nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__CFG_CLOS__CA1938C08049643A PRIMARY KEY (SEQ)
);


-- TPC.dbo.CFG_ERR_CODE definition

-- Drop table

-- DROP TABLE TPC.dbo.CFG_ERR_CODE;

CREATE TABLE TPC.dbo.CFG_ERR_CODE (
	ERROR_CODE nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ERROR_MSG nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ERROR_DESC nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ITEM_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	MEMO nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__CFG_ERR___6A4921C3A1EF7D94 PRIMARY KEY (ERROR_CODE)
);


-- TPC.dbo.CFG_FORM_SIGN definition

-- Drop table

-- DROP TABLE TPC.dbo.CFG_FORM_SIGN;

CREATE TABLE TPC.dbo.CFG_FORM_SIGN (
	SEQ int IDENTITY(1,1) NOT NULL,
	FORM_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ALL_APPLY_FLAG nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	POSITION_SEQ int NULL,
	WIDTH int NULL,
	HEIGHT int NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__CFG_FORM__CA1938C04BB146D8 PRIMARY KEY (SEQ)
);


-- TPC.dbo.CFG_MWARE_PROPERTIES definition

-- Drop table

-- DROP TABLE TPC.dbo.CFG_MWARE_PROPERTIES;

CREATE TABLE TPC.dbo.CFG_MWARE_PROPERTIES (
	SEQ int IDENTITY(1,1) NOT NULL,
	CATEGORY nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CODE_GROUP nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CODE nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	VALUE nvarchar(500) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ENVIRONMENT nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	MEMO nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__CFG_MWAR__CA1938C0DC401ADD PRIMARY KEY (SEQ)
);


-- TPC.dbo.CFG_REGION definition

-- Drop table

-- DROP TABLE TPC.dbo.CFG_REGION;

CREATE TABLE TPC.dbo.CFG_REGION (
	REGION nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'ACTIVATE' NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__CFG_REGI__C5CCC58ECE1CD6F7 PRIMARY KEY (REGION)
);


-- TPC.dbo.CFG_SIGN_OFF_LEVEL definition

-- Drop table

-- DROP TABLE TPC.dbo.CFG_SIGN_OFF_LEVEL;

CREATE TABLE TPC.dbo.CFG_SIGN_OFF_LEVEL (
	SEQ int IDENTITY(1,1) NOT NULL,
	[ACTION] nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACTION_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	[LEVEL] int NOT NULL,
	SIGNER nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__CFG_SIGN__CA1938C0A278786B PRIMARY KEY (SEQ)
);


-- TPC.dbo.CFG_SYSTEM_PROPERTIES definition

-- Drop table

-- DROP TABLE TPC.dbo.CFG_SYSTEM_PROPERTIES;

CREATE TABLE TPC.dbo.CFG_SYSTEM_PROPERTIES (
	SEQ int IDENTITY(1,1) NOT NULL,
	CODE nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CODE_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CODE_CATE nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CODE_VALUE nvarchar(2000) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	DESCRIPTION nvarchar(2000) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__CFG_SYST__CA1938C0F9176F29 PRIMARY KEY (SEQ)
);


-- TPC.dbo.DEPARTMENT definition

-- Drop table

-- DROP TABLE TPC.dbo.DEPARTMENT;

CREATE TABLE TPC.dbo.DEPARTMENT (
	DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	DEPT_NAME nvarchar(30) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_DIVISION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_GROUP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	[SECTION] nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REGION nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__DEPARTME__DA3BF9106B02C69C PRIMARY KEY (DEPT_NUM)
);


-- TPC.dbo.EMPLOYEE definition

-- Drop table

-- DROP TABLE TPC.dbo.EMPLOYEE;

CREATE TABLE TPC.dbo.EMPLOYEE (
	EMP_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_DIVISION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_GROUP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_SECTION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SYNC_REMOVE_TIME datetime NULL,
	EMP_POS_SEQ nvarchar(4) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	REGION nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT '07' NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'default' NOT NULL,
	CONSTRAINT PK__EMPLOYEE__16EB127DDC32CBD6 PRIMARY KEY (EMP_NO)
);


-- TPC.dbo.EMPLOYEE_1209 definition

-- Drop table

-- DROP TABLE TPC.dbo.EMPLOYEE_1209;

CREATE TABLE TPC.dbo.EMPLOYEE_1209 (
	EMP_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_DIVISION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_GROUP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_SECTION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	PASSWORD nvarchar(500) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SYNC_REMOVE_TIME datetime NULL,
	EMP_POS_SEQ nvarchar(4) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	REGION nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT '07' NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'default' NOT NULL,
	CONSTRAINT PK__EMPLOYEE_1209 PRIMARY KEY (EMP_NO)
);


-- TPC.dbo.LOG_CALL_API definition

-- Drop table

-- DROP TABLE TPC.dbo.LOG_CALL_API;

CREATE TABLE TPC.dbo.LOG_CALL_API (
	SEQ int IDENTITY(1,1) NOT NULL,
	REQUEST_IP nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	API_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	INPUT_VALUE nvarchar(MAX) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	OUTPUT_VALUE nvarchar(MAX) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ERROR_MSG nvarchar(MAX) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	BASE64 text COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK__LOG_CALL__CA1938C0C4870913 PRIMARY KEY (SEQ)
);


-- TPC.dbo.LOG_EMP_ROLE_MAP definition

-- Drop table

-- DROP TABLE TPC.dbo.LOG_EMP_ROLE_MAP;

CREATE TABLE TPC.dbo.LOG_EMP_ROLE_MAP (
	SEQ int IDENTITY(1,1) NOT NULL,
	EMP_NO nvarchar(12) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SETTING_STYLE nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	RECORD_TYPE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__LOG_EMP___CA1938C0CE967F47 PRIMARY KEY (SEQ)
);


-- TPC.dbo.LOG_LOGIN definition

-- Drop table

-- DROP TABLE TPC.dbo.LOG_LOGIN;

CREATE TABLE TPC.dbo.LOG_LOGIN (
	SEQ int IDENTITY(1,1) NOT NULL,
	LOGIN_KEY nvarchar(12) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	LOGIN_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	LOGIN_DEPT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	DEPT_NAME nvarchar(30) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	LOGIN_RESULT nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	LOGIN_PATH nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	LOGIN_IP nvarchar(30) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	API_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK__LOG_LOGI__CA1938C068A02D93 PRIMARY KEY (SEQ)
);


-- TPC.dbo.LOG_ROLE_PRIVILEGE_MAP definition

-- Drop table

-- DROP TABLE TPC.dbo.LOG_ROLE_PRIVILEGE_MAP;

CREATE TABLE TPC.dbo.LOG_ROLE_PRIVILEGE_MAP (
	SEQ int IDENTITY(1,1) NOT NULL,
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	PRIVILEGE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	PRIVILEGE_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	RECORD_TYPE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__LOG_ROLE__CA1938C03DA9A835 PRIMARY KEY (SEQ)
);


-- TPC.dbo.LOG_VIEW_FORM definition

-- Drop table

-- DROP TABLE TPC.dbo.LOG_VIEW_FORM;

CREATE TABLE TPC.dbo.LOG_VIEW_FORM (
	SEQ int IDENTITY(1,1) NOT NULL,
	REGION nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_NUM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_DEPT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_DEPT_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_USER nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_USER_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	BROWSER nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	BROWSER_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	BROWSE_PAGE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	BROWSE_STYLE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__LOG_VIEW__CA1938C0C812228B PRIMARY KEY (SEQ)
);


-- TPC.dbo.MARQUEE definition

-- Drop table

-- DROP TABLE TPC.dbo.MARQUEE;

CREATE TABLE TPC.dbo.MARQUEE (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	MARQUEE_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MARQUEE_TYPE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MARQUEE_CONTENT nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MARQUEE_CONTENT_HTML nvarchar(MAX) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ANIMATION_DURATION nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MEMO nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REGION nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	STATUS nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SIGN_STATUS nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	RELEASE_START_DATE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	RELEASE_END_DATE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CUR_LEVEL int NULL,
	FINAL_LEVEL int NULL,
	LEADER_SIGN_DATE datetime NULL,
	MANAGER_SIGN_DATE datetime NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	CREATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_USER nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_REASON nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_DESC nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_DATE datetime NULL,
	CREATE_AUTHOR_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_AUTHOR_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_USER_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK_MARQUEE PRIMARY KEY (SEQ)
);
 CREATE  UNIQUE NONCLUSTERED INDEX MARQUEE_NAME_IDX ON dbo.MARQUEE (  MARQUEE_NAME ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;


-- TPC.dbo.MATERIAL definition

-- Drop table

-- DROP TABLE TPC.dbo.MATERIAL;

CREATE TABLE TPC.dbo.MATERIAL (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	MATERIAL_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MATERIAL_TYPE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	FILE_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ORIGINAL_FILE_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	FILE_PATH nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	FILE_EXT nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	FILE_SIZE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	HOST nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MEMO nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REGION nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	STATUS nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	CREATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_AUTHOR_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_AUTHOR_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK_MATERIAL PRIMARY KEY (SEQ)
);
 CREATE  UNIQUE NONCLUSTERED INDEX MATERIAL_MATERIAL_NAME_IDX ON dbo.MATERIAL (  MATERIAL_NAME ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;


-- TPC.dbo.MEDIA_SIGN_OFF definition

-- Drop table

-- DROP TABLE TPC.dbo.MEDIA_SIGN_OFF;

CREATE TABLE TPC.dbo.MEDIA_SIGN_OFF (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	ACTION_SEQ nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACTION_TYPE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	[LEVEL] int NULL,
	SIGNER nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SIGNER_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	AGENT nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	AGENT_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	STATUS nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SIGN_OFF_TIME datetime NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	CREATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SIGNER_DEPT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'ttt' NOT NULL,
	CONSTRAINT PK_MEDIA_SIGN_OFF PRIMARY KEY (SEQ)
);


-- TPC.dbo.OPTIMISTIC_LOCK_TEST definition

-- Drop table

-- DROP TABLE TPC.dbo.OPTIMISTIC_LOCK_TEST;

CREATE TABLE TPC.dbo.OPTIMISTIC_LOCK_TEST (
	EMP_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SETTING_STYLE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	MEMO nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL
);


-- TPC.dbo.PMC_COMPUTER definition

-- Drop table

-- DROP TABLE TPC.dbo.PMC_COMPUTER;

CREATE TABLE TPC.dbo.PMC_COMPUTER (
	COMPUTER_ID int IDENTITY(1,1) NOT NULL,
	HOSTNAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	COMPUTER_DIVISION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	COMPUTER_GROUP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	COMPUTER_SECTION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	COMPUTER_IP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MEMO nvarchar(1000) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	UPDATE_DATE datetime NULL,
	CONSTRAINT PK_PMC_COMPUTER PRIMARY KEY (COMPUTER_ID)
);
 CREATE  UNIQUE NONCLUSTERED INDEX IDX_PMC_CO_HOSTNNM ON dbo.PMC_COMPUTER (  HOSTNAME ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;


-- TPC.dbo.PMC_COMPUTER_TEMP22 definition

-- Drop table

-- DROP TABLE TPC.dbo.PMC_COMPUTER_TEMP22;

CREATE TABLE TPC.dbo.PMC_COMPUTER_TEMP22 (
	COMPUTER_ID int NOT NULL,
	HOSTNAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	COMPUTER_DIVISION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	COMPUTER_GROUP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	COMPUTER_SECTION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	COMPUTER_IP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MEMO nvarchar(1000) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	UPDATE_DATE datetime NULL,
	CONSTRAINT PMC_COMPUTER_TEMP PRIMARY KEY (COMPUTER_ID)
);


-- TPC.dbo.PMC_COMPUTER_UPD_LOG definition

-- Drop table

-- DROP TABLE TPC.dbo.PMC_COMPUTER_UPD_LOG;

CREATE TABLE TPC.dbo.PMC_COMPUTER_UPD_LOG (
	PMC_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	COMPUTER_ID int NOT NULL,
	VERSION_MD5 nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	UPDATE_DATE datetime NULL
);


-- TPC.dbo.PMC_VERSION definition

-- Drop table

-- DROP TABLE TPC.dbo.PMC_VERSION;

CREATE TABLE TPC.dbo.PMC_VERSION (
	PMC_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	VERSION_MD5 nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	DOWNLOAD_FILE_URL nvarchar(500) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CLIENT_FILE_PATH nvarchar(500) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NULL,
	UPDATE_DATE datetime NULL,
	CONSTRAINT PK_PMC_VERSION PRIMARY KEY (PMC_TYPE)
);
 CREATE NONCLUSTERED INDEX IDX_PMC_VER_MD5 ON dbo.PMC_VERSION (  VERSION_MD5 ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
 CREATE NONCLUSTERED INDEX IDX_PMC_VER_TYPE ON dbo.PMC_VERSION (  PMC_TYPE ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;


-- TPC.dbo.PMC_VERSION_HISTORY definition

-- Drop table

-- DROP TABLE TPC.dbo.PMC_VERSION_HISTORY;

CREATE TABLE TPC.dbo.PMC_VERSION_HISTORY (
	PMC_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	VERSION_MD5 nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	DOWNLOAD_FILE_URL nvarchar(500) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CLIENT_FILE_PATH nvarchar(500) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NULL,
	UPDATE_DATE datetime NULL
);


-- TPC.dbo.PROD_AUTH_EMP_ROLE_MAP definition

-- Drop table

-- DROP TABLE TPC.dbo.PROD_AUTH_EMP_ROLE_MAP;

CREATE TABLE TPC.dbo.PROD_AUTH_EMP_ROLE_MAP (
	EMP_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_CODE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SETTING_STYLE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ROLE_DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	MEMO nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK_AUTH_EMP PRIMARY KEY (EMP_NO,ROLE_CODE,ROLE_DEPT_NUM)
);


-- TPC.dbo.PROD_EMPLOYEE definition

-- Drop table

-- DROP TABLE TPC.dbo.PROD_EMPLOYEE;

CREATE TABLE TPC.dbo.PROD_EMPLOYEE (
	EMP_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_DIVISION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_GROUP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_SECTION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SYNC_REMOVE_TIME datetime NULL,
	EMP_POS_SEQ nvarchar(4) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	REGION nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__PROD_EMP__16EB127D40824BFA PRIMARY KEY (EMP_NO)
);


-- TPC.dbo.PROD_PIS definition

-- Drop table

-- DROP TABLE TPC.dbo.PROD_PIS;

CREATE TABLE TPC.dbo.PROD_PIS (
	EMP_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_DIVISION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_GROUP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_SECTION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_POS_SEQ nvarchar(4) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__PROD_PIS__16EB127DD90A7D00 PRIMARY KEY (EMP_NO)
);


-- TPC.dbo.PROGRAM definition

-- Drop table

-- DROP TABLE TPC.dbo.PROGRAM;

CREATE TABLE TPC.dbo.PROGRAM (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	PROGRAM_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	PROGRAM_TYPE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MEMO nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REGION nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	STATUS nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SIGN_STATUS nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	RELEASE_START_DATE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	RELEASE_END_DATE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CUR_LEVEL int NULL,
	FINAL_LEVEL int NULL,
	LEADER_SIGN_DATE datetime NULL,
	MANAGER_SIGN_DATE datetime NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	CREATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_USER nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_REASON nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_DESC nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_DATE datetime NULL,
	CREATE_AUTHOR_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_AUTHOR_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_USER_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK_PROGRAM PRIMARY KEY (SEQ)
);
 CREATE  UNIQUE NONCLUSTERED INDEX PROGRAM_NAME_IDX ON dbo.PROGRAM (  PROGRAM_NAME ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;


-- TPC.dbo.QUESTIONNAIRE definition

-- Drop table

-- DROP TABLE TPC.dbo.QUESTIONNAIRE;

CREATE TABLE TPC.dbo.QUESTIONNAIRE (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	QUESTIONNAIRE_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	QUESTIONNAIRE_TYPE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MEMO nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REGION nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	STATUS nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SIGN_STATUS nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	RELEASE_START_DATE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	RELEASE_END_DATE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CUR_LEVEL int NULL,
	FINAL_LEVEL int NULL,
	LEADER_SIGN_DATE datetime NULL,
	MANAGER_SIGN_DATE datetime NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	CREATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_USER nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_REASON nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_DESC nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_DATE datetime NULL,
	CREATE_AUTHOR_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_AUTHOR_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_USER_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK_QUESTIONNAIRE PRIMARY KEY (SEQ)
);
 CREATE  UNIQUE NONCLUSTERED INDEX QUESTIONNAIRE_NAME_IDX ON dbo.QUESTIONNAIRE (  QUESTIONNAIRE_NAME ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;


-- TPC.dbo.QUESTIONNAIRE_FEEDBACK_AGREE definition

-- Drop table

-- DROP TABLE TPC.dbo.QUESTIONNAIRE_FEEDBACK_AGREE;

CREATE TABLE TPC.dbo.QUESTIONNAIRE_FEEDBACK_AGREE (
	ACCEPT_NUM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	QUESTION_SEQ bigint NOT NULL,
	AGREE_FLAG nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_DEPT nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCEPT_DEPT_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCEPT_USER nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCEPT_USER_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	CONSTRAINT QUESTIONNAIRE_FEEDBACK_AGREE_PK PRIMARY KEY (ACCEPT_NUM)
);


-- TPC.dbo.QUESTIONNAIRE_QUESTION definition

-- Drop table

-- DROP TABLE TPC.dbo.QUESTIONNAIRE_QUESTION;

CREATE TABLE TPC.dbo.QUESTIONNAIRE_QUESTION (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	QUESTIONNAIRE_SEQ bigint NULL,
	QUESTION_NAME varchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	QUESTION_TYPE varchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	REQUIRED varchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SORT varchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	CREATE_AUTHOR varchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_AUTHOR varchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK_QUESTIONNAIRE_QUESTION PRIMARY KEY (SEQ)
);


-- TPC.dbo.QUESTIONNAIRE_REPORT definition

-- Drop table

-- DROP TABLE TPC.dbo.QUESTIONNAIRE_REPORT;

CREATE TABLE TPC.dbo.QUESTIONNAIRE_REPORT (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	REPORT_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REGION nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CATEGORY nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	DATA_DATE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	CREATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK_QUESTIONNAIRE_REPORT PRIMARY KEY (SEQ)
);


-- TPC.dbo.QUESTIONNAIRE_USER_ANSWER definition

-- Drop table

-- DROP TABLE TPC.dbo.QUESTIONNAIRE_USER_ANSWER;

CREATE TABLE TPC.dbo.QUESTIONNAIRE_USER_ANSWER (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	QUESTION_SEQ bigint NOT NULL,
	QUESTIONNAIRE_SEQ bigint NOT NULL,
	ANSWER_SEQ bigint NOT NULL,
	ANSWER_LABEL nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ANSWER_VALUE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	REGION nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCEPT_NUM nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCEPT_DEPT nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCEPT_DEPT_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCEPT_USER nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCEPT_USER_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ACCEPT_DATE datetime NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_QUESTIONNAIRE_USER_ANSWER PRIMARY KEY (SEQ)
);


-- TPC.dbo.READ_APPLY definition

-- Drop table

-- DROP TABLE TPC.dbo.READ_APPLY;

CREATE TABLE TPC.dbo.READ_APPLY (
	READ_NUM nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FORM_SEQ int NOT NULL,
	REGION nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_NUM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_READER nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_READER_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	APPLIER nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	APPLIER_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CUR_LEVEL int NOT NULL,
	FINAL_LEVEL int NOT NULL,
	READ_DATE datetime NULL,
	VALID_DATE datetime NULL,
	ELECTRIC_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ARCHIVE_NUM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_DATE datetime NOT NULL,
	ARCHIVE_DATE datetime NOT NULL,
	CUST_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONTRACT_TYPE nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_ITEM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	READ_REASON nvarchar(500) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	READ_DEPT nvarchar(30) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	MEMO nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_REASON nvarchar(1000) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_DESC nvarchar(2000) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__READ_APP__C821460F9EFB3BEB PRIMARY KEY (READ_NUM)
);


-- TPC.dbo.READ_REPORT definition

-- Drop table

-- DROP TABLE TPC.dbo.READ_REPORT;

CREATE TABLE TPC.dbo.READ_REPORT (
	SEQ int IDENTITY(1,1) NOT NULL,
	READ_DATE_START nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	READ_DATE_END nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_NO int NOT NULL,
	READ_MGMT_SIGNER nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	READ_MGMT_SIGN_AGENT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	READ_MGMT_SIGN_DATE datetime NULL,
	LEADER_SIGNER nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	LEADER_SIGN_AGENT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	LEADER_SIGN_DATE datetime NULL,
	MANAGER_SIGNER nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MANAGER_SIGN_AGENT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MANAGER_SIGN_DATE datetime NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	region nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	READ_MGMT_SIGNER_DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'ttt' NOT NULL,
	LEADER_SIGNER_DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'ttt' NOT NULL,
	MANAGER_SIGNER_DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'ttt' NOT NULL,
	CONSTRAINT PK__READ_REP__CA1938C0FD571CF7 PRIMARY KEY (SEQ)
);


-- TPC.dbo.READ_SIGN_OFF definition

-- Drop table

-- DROP TABLE TPC.dbo.READ_SIGN_OFF;

CREATE TABLE TPC.dbo.READ_SIGN_OFF (
	SEQ int IDENTITY(1,1) NOT NULL,
	READ_NUM nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	[LEVEL] int NOT NULL,
	SIGNER nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SIGNER_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	AGENT nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	AGENT_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	STATUS nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SIGN_OFF_TIME datetime NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'ttt' NOT NULL,
	CONSTRAINT PK__READ_SIG__CA1938C05356B1D1 PRIMARY KEY (SEQ)
);


-- TPC.dbo.REJECT_REPORT definition

-- Drop table

-- DROP TABLE TPC.dbo.REJECT_REPORT;

CREATE TABLE TPC.dbo.REJECT_REPORT (
	SEQ int IDENTITY(1,1) NOT NULL,
	REJECT_DATE_START datetime NULL,
	REJECT_DATE_END datetime NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	REGION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_NO int NOT NULL,
	SALES_PLANNER_SIGNER nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SALES_PLANNER_SIGN_AGENT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	SALES_PLANNER_SIGN_DATE datetime NULL,
	LEADER_SIGNER nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	LEADER_SIGN_AGENT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	LEADER_SIGN_DATE datetime NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SALES_PLANNER_SIGNER_DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'ttt' NOT NULL,
	LEADER_SIGNER_DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT 'ttt' NOT NULL,
	CONSTRAINT PK__REJECT_R__CA1938C093424D8A PRIMARY KEY (SEQ)
);


-- TPC.dbo.SEAL_SIGN_OFF definition

-- Drop table

-- DROP TABLE TPC.dbo.SEAL_SIGN_OFF;

CREATE TABLE TPC.dbo.SEAL_SIGN_OFF (
	SEQ int IDENTITY(1,1) NOT NULL,
	FORM_SEQ int NOT NULL,
	SEAL_STATUS nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	REGION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SIGNER nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SIGNER_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	AGENT nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS DEFAULT '105' NOT NULL,
	CONSTRAINT PK__SEAL_SIG__CA1938C064A8E256 PRIMARY KEY (SEQ)
);


-- TPC.dbo.SPRING_SESSION definition

-- Drop table

-- DROP TABLE TPC.dbo.SPRING_SESSION;

CREATE TABLE TPC.dbo.SPRING_SESSION (
	PRIMARY_ID nvarchar(36) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SESSION_ID nvarchar(36) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATION_TIME bigint NOT NULL,
	LAST_ACCESS_TIME bigint NOT NULL,
	MAX_INACTIVE_INTERVAL int NOT NULL,
	EXPIRY_TIME bigint NOT NULL,
	PRINCIPAL_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT SPRING_SESSION_PK PRIMARY KEY (PRIMARY_ID)
);
 CREATE  UNIQUE NONCLUSTERED INDEX SPRING_SESSION_IX1 ON dbo.SPRING_SESSION (  SESSION_ID ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
 CREATE NONCLUSTERED INDEX SPRING_SESSION_IX2 ON dbo.SPRING_SESSION (  EXPIRY_TIME ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
 CREATE NONCLUSTERED INDEX SPRING_SESSION_IX3 ON dbo.SPRING_SESSION (  PRINCIPAL_NAME ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;


-- TPC.dbo.TMP_EMPLOYEE definition

-- Drop table

-- DROP TABLE TPC.dbo.TMP_EMPLOYEE;

CREATE TABLE TPC.dbo.TMP_EMPLOYEE (
	EMP_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_DIVISION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_GROUP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_SECTION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	DEPT_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	EMP_POS_SEQ nvarchar(4) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__TMP_EMPL__16EB127D3A8D4F59 PRIMARY KEY (EMP_NO)
);


-- TPC.dbo.TPES_FILES definition

-- Drop table

-- DROP TABLE TPC.dbo.TPES_FILES;

CREATE TABLE TPC.dbo.TPES_FILES (
	FILE_NO int NOT NULL,
	UPLOAD_NO nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CATEGORY nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_CODE nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_NAME nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ORIGINAL_FILE_NAME nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FORM_SEQ int NULL,
	REGION nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_PATH nvarchar(1000) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FILE_EXT nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	NEED_SEAL nvarchar(1) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	VERSION int NOT NULL,
	IS_FINAL_VERSION nvarchar(1) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	IS_ENCRYPT nvarchar(1) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__TPES_FIL__49C7F10DA804A7EB PRIMARY KEY (FILE_NO)
);


-- TPC.dbo.TPES_FORM definition

-- Drop table

-- DROP TABLE TPC.dbo.TPES_FORM;

CREATE TABLE TPC.dbo.TPES_FORM (
	SEQ int IDENTITY(1,1) NOT NULL,
	ACCEPT_NUM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	REGION nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CUST_NAME nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	STATUS nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONTRACT_TYPE nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ELECTRIC_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	COMPUTE_DATE nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_DEPT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_DEPT_NAME nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_USER nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_USER_NAME nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ACCEPT_DATE datetime NOT NULL,
	ACCEPT_ITEM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	FORM_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	APPLY_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	IS_AGENT nvarchar(1) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UNIFORM_NUM nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ARCHIVE_NUM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ARCHIVE_DATE datetime NULL,
	CLOSE_DATE datetime NULL,
	REJECT_TO_DEPT nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_USER nvarchar(50) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_REASON nvarchar(1000) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_DESC nvarchar(2000) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REJECT_DATE datetime NULL,
	CANCEL_REASON nvarchar(1000) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CANCEL_DATE datetime NULL,
	FORM_HISTORY nvarchar(4000) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SIGN_TRAJECTORY nvarchar(4000) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK__TPES_FOR__CA1938C0E7AD8898 PRIMARY KEY (SEQ)
);


-- TPC.dbo.TPES_FORM_CANCEL_DATA definition

-- Drop table

-- DROP TABLE TPC.dbo.TPES_FORM_CANCEL_DATA;

CREATE TABLE TPC.dbo.TPES_FORM_CANCEL_DATA (
	SEQ int IDENTITY(1,1) NOT NULL,
	ACCEPT_NUM nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	SR_TP nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CANCEL_CODE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	DEPT_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	USER_SC_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	USER_DEPT_NO nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	USER_ID nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	RECORD_KIND nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	DCIS_FG nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REGION nvarchar(10) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime NOT NULL,
	CREATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	UPDATE_DATE datetime NOT NULL,
	UPDATE_AUTHOR nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CONSTRAINT PK__TPES_FOR__CA1938C0FCB08F7A PRIMARY KEY (SEQ)
);


-- TPC.dbo.TPES_MEDIA_FILES definition

-- Drop table

-- DROP TABLE TPC.dbo.TPES_MEDIA_FILES;

CREATE TABLE TPC.dbo.TPES_MEDIA_FILES (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	CATEGORY nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	FILE_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	ORIGINAL_FILE_NAME nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	FILE_PATH nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	FILE_EXT nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	FILE_SIZE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	RELATED_SEQ bigint NULL,
	MEMO nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REGION nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	STATUS nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	CREATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	REPORT_DATA_DATE nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK_TPES_MEDIA_FILES PRIMARY KEY (SEQ)
);


-- TPC.dbo.sysdiagrams definition

-- Drop table

-- DROP TABLE TPC.dbo.sysdiagrams;

CREATE TABLE TPC.dbo.sysdiagrams (
	name sysname COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	principal_id int NOT NULL,
	diagram_id int IDENTITY(1,1) NOT NULL,
	version int NULL,
	definition varbinary(MAX) NULL,
	CONSTRAINT PK__sysdiagr__C2B05B6165237571 PRIMARY KEY (diagram_id),
	CONSTRAINT UK_principal_name UNIQUE (principal_id,name)
);


-- TPC.dbo.MARQUEE_HISTORY definition

-- Drop table

-- DROP TABLE TPC.dbo.MARQUEE_HISTORY;

CREATE TABLE TPC.dbo.MARQUEE_HISTORY (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	MARQUEE_SEQ bigint NOT NULL,
	MARQUEE_CONTENT nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	MARQUEE_CONTENT_HTML nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	RELEASE_START_DATE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	RELEASE_END_DATE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_MARQUEEHISTORY PRIMARY KEY (SEQ),
	CONSTRAINT FK_MARQUEE_HISTORY FOREIGN KEY (MARQUEE_SEQ) REFERENCES TPC.dbo.MARQUEE(SEQ)
);


-- TPC.dbo.PMC_COMPUTER_VERSION definition

-- Drop table

-- DROP TABLE TPC.dbo.PMC_COMPUTER_VERSION;

CREATE TABLE TPC.dbo.PMC_COMPUTER_VERSION (
	PMC_TYPE nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	COMPUTER_ID int NOT NULL,
	VERSION_MD5 nvarchar(100) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime NULL,
	UPDATE_DATE datetime NULL,
	CONSTRAINT PK_PMC_COMPUTER_VERSION PRIMARY KEY (PMC_TYPE,COMPUTER_ID),
	CONSTRAINT FK_PMC_COMP_REFERENCE_PMC_COMP FOREIGN KEY (COMPUTER_ID) REFERENCES TPC.dbo.PMC_COMPUTER(COMPUTER_ID),
	CONSTRAINT FK_PMC_COMP_REFERENCE_PMC_VERS FOREIGN KEY (PMC_TYPE) REFERENCES TPC.dbo.PMC_VERSION(PMC_TYPE)
);


-- TPC.dbo.PROGRAM_ITEM definition

-- Drop table

-- DROP TABLE TPC.dbo.PROGRAM_ITEM;

CREATE TABLE TPC.dbo.PROGRAM_ITEM (
	PROGRAM_SEQ bigint NOT NULL,
	MATERIAL_SEQ bigint NOT NULL,
	SORT nvarchar(20) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_PROGRAM_ITEM PRIMARY KEY (PROGRAM_SEQ,MATERIAL_SEQ),
	CONSTRAINT FK_PROGRAM_ITEM_ON_MATERIAL_SEQ FOREIGN KEY (MATERIAL_SEQ) REFERENCES TPC.dbo.MATERIAL(SEQ),
	CONSTRAINT FK_PROGRAM_ITEM_ON_PROGRAM_SEQ FOREIGN KEY (PROGRAM_SEQ) REFERENCES TPC.dbo.PROGRAM(SEQ)
);


-- TPC.dbo.QUESTIONNAIRE_QUESTION_ANSWER definition

-- Drop table

-- DROP TABLE TPC.dbo.QUESTIONNAIRE_QUESTION_ANSWER;

CREATE TABLE TPC.dbo.QUESTIONNAIRE_QUESTION_ANSWER (
	SEQ bigint IDENTITY(1,1) NOT NULL,
	QUESTION_SEQ bigint NULL,
	SORT nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ANSWER_LABEL nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ANSWER_VALUE nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	CREATE_DATE datetime DEFAULT getdate() NULL,
	CREATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	UPDATE_DATE datetime DEFAULT getdate() NULL,
	UPDATE_AUTHOR nvarchar(255) COLLATE Chinese_Taiwan_Stroke_CI_AS NULL,
	CONSTRAINT PK_QUESTIONNAIRE_QUESTION_ANSWER PRIMARY KEY (SEQ),
	CONSTRAINT FK_QUESTION_ANSWER_ON_QUESTION_SEQ FOREIGN KEY (QUESTION_SEQ) REFERENCES TPC.dbo.QUESTIONNAIRE_QUESTION(SEQ)
);


-- TPC.dbo.SPRING_SESSION_ATTRIBUTES definition

-- Drop table

-- DROP TABLE TPC.dbo.SPRING_SESSION_ATTRIBUTES;

CREATE TABLE TPC.dbo.SPRING_SESSION_ATTRIBUTES (
	SESSION_PRIMARY_ID nvarchar(36) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ATTRIBUTE_NAME nvarchar(200) COLLATE Chinese_Taiwan_Stroke_CI_AS NOT NULL,
	ATTRIBUTE_BYTES varbinary(MAX) NOT NULL,
	CONSTRAINT SPRING_SESSION_ATTRIBUTES_PK PRIMARY KEY (SESSION_PRIMARY_ID,ATTRIBUTE_NAME),
	CONSTRAINT SPRING_SESSION_ATTRIBUTES_FK FOREIGN KEY (SESSION_PRIMARY_ID) REFERENCES TPC.dbo.SPRING_SESSION(PRIMARY_ID) ON DELETE CASCADE
);